<?php include_once("php_action/core.php");
    include_once("php_action/database.php");
 ?>
<?php

$success = array();
$errors = array();

 if($_POST)
  {
   if(isset($_POST['submit']))
    {
     $applicant_code = $_POST['applicant_code'];
     $applicant_name = $_POST['applicant_name'];
     $film_name = $_POST['film_name'];
     $location = $_POST['location'];
     $mobile = $_POST['mobile'];
     $languages = $_POST['languages'];

  $sql = "insert into candidatedetails(applicant_code,applicant_name,film_name,location,mobile_number,languages) values('$applicant_code','$applicant_name','$film_name','$location','$mobile','$languages')";

     $query = mysqli_query($con,$sql);
    if($query)
    {
        $success[] = " Response saved sucessfully ";
     
    }
    else if(!$query)
    {
        $errors[] = " Failed to save responses ";
    }   
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <title> Navi Mumbai Mahanagar Palika </title>
<link rel="shortcut icon" href="images/career.png" />
  
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
   <link rel="stylesheet" href="vendors/css/feather.css">

  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">

  <link rel="stylesheet" href="vendors/icheck/skins/all.css">
  
  <link rel="stylesheet" href="vendors/css/style.css">
  <link rel="stylesheet" href="css/style.css">
 


</head>

<body>

  <div class="container-scroller">
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo" href="dashboard.php">
          <img src="images/career.png" class="img" alt="logo" style="height: 69px;" />
        </a>

        <a class="navbar-brand brand-logo-mini" href="dashboard.php">
          <img src="images/career.png" class="img" style="height: 100%; width: 100%" />
        </a>
      </div>

      <div class="navbar-menu-wrapper d-flex align-items-center" style="background: linear-gradient(100deg,#00ce68,#75e62e);">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
        <ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="mdi mdi-home"></i>Home
            </a>
          </li>
          <li class="nav-item active">
            <a href="#" class="nav-link">
              <i class="mdi mdi-elevation-rise"></i>About</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="mdi mdi-bookmark-plus-outline"></i>Services</a>
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown d-none d-xl-inline-block">
              <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <span class="profile-text"> Ajay Gaikwad </span>
                <img class="img-xs rounded-circle" src="images/faces/admin.jpg" alt=""> </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                <a class="dropdown-item p-0">
                  <div class="d-flex border-bottom">
                    <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                      <i class="mdi mdi-bookmark-plus-outline mr-0 text-gray"></i>
                    </div>
                    <div class="py-3 px-4 d-flex align-items-center justify-content-center border-left border-right">
                      <i class="mdi mdi-account-outline mr-0 text-gray"></i>
                    </div>
                    <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                      <i class="mdi mdi-alarm-check mr-0 text-gray"></i>
                    </div>
                  </div>
                </a>
                <a class="dropdown-item" href="php_action/changePassword.php"> Change Password </a>
                <a class="dropdown-item" href="logout.php"> Sign Out </a>
              </div>
            </li>                      
  
          
        </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
      </button>
    </div>
  </nav>
     <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.php -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="images/faces/admin.jpg" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"> Ajay Gaikwad </p>
                  <div>
                    <small class="designation text-muted">Manager</small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
              <button class="btn btn-success btn-block">New Project
                <i class="mdi mdi-plus"></i>
              </button>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <i class="menu-icon mdi mdi-television"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
         
         <div class="row">
           <div class="col-md-12 grid-margin stretch-card">
          
                <div class="msg" style="width: 100%">
                   <?php 
                           if($success)
                            {
                             foreach ($success as $key => $value) {
                               echo '<div class="alert alert-success"><i class="mdi mdi-checkbox-marked-circle-outline"></i><button type="button" class="close" data-dismiss="alert">&times;</button>'.$value.'</div>'; 
                             }
                            }
                            else if($errors)
                            {
                               foreach ($errors as $key => $value) {
                               echo '<div class="alert alert-danger"><i class="mdi mdi-alert-circle"></i>  <button type="button" class="close" data-dismiss="alert">&times;</button>'.$value.'</div>'; 
                              }
                            }
                     ?>
                </div>
           
           </div>
         </div>
 
          <div class="row">
            
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Candidate Form</h4>
                  
                  <form class="forms-sample" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
                    <div class="form-group">
                      <label for="applicant_code">Applicant Code</label>
                      <input type="text" class="form-control address" name="applicant_code" id="applicant_code" placeholder="Applicant Code" required autocomplete="off"/>
                    </div>
                    <div class="form-group">
                      <label for="applicant_name">Applicant Name</label>
                      <input type="text" class="form-control address" name="applicant_name" id="applicant_name" placeholder="Applicant Name" required autocomplete="off">
                    </div>

                    <div class="form-group">
                      <label for="film_name">Film Name</label>
                      <input type="text" class="form-control address" name="film_name" id="film_name" placeholder="Film Name" required autocomplete="off">
                    </div>
                    

                    <div class="form-group">
                      <label for="location"> Location </label>
                      <select class="form-control" name="location" required="required">
                              <option value="" selected disabled>Please select...</option><option value="airoli">Airoli</option>
              <option value="Rabale">Rabale</option>
                <option value="Ghansoli">Ghansoli</option>
              <option value="Koparkhairane">Koparkhairane</option>
              <option value="Turbhe">Turbhe</option>
              <option value="Sanpada">Sanpada</option>
              <option value="Vashi">Vashi</option>
              <option value="Nerul">Nerul</option>
              <option value="CBD Belapur">Belapur CBD</option>
                            </select>
                    </div>

                    <div class="form-group">
                      <label for="mobile">Mobile Number</label>
  
              <input type="text" class="form-control" id="phone" name="mobile" pattern="[1-9]{1}[0-9]{9}" placeholder="Mobile" title="Please Enter valid mobile number" 
                       required autocomplete="off" maxlength="10" onkeypress="return isNumber(event)">

                    </div>

                    
                    <div class="form-group">
                      <label for="languages">Languages</label>
                      <input type="text" class="form-control text" name="languages" id="language" placeholder="Language" required autocomplete="off"  pattern="[a-zA-Z]+" title="Enter valid Language">
                    </div>

                    <button type="submit" class="btn btn-success btn-fw" name="submit">
                            <i class="mdi mdi-file-document" ></i>Submit</button>
                    <button type="reset" class="btn btn-secondary btn-fw">
                            <i class="mdi mdi-refresh"></i>Reset</button>
                  </form>
                </div>
              </div>
            </div>

            

            <div class="col-lg-6 grid-margin " >

                <div class="card" >
                  <div class="card-body">
                    <h4 class="card-title d-flex">Upload Image

                    </h4>
                    <input type="file" class="dropify" /> </div>
                </div>
                 <div class="card" >
                  <div class="card-body" >
                    <h4 class="card-title d-flex">Upload Image

                    </h4>
                    <input type="file" class="dropify" /> </div>
                </div>
                <div class="form-group">
                  <br>
                        <label>File upload</label>
                        <input type="file" name="img[]" class="file-upload-default">
                        <div class="input-group col-xs-12">
                          <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                          <span class="input-group-append">
                            <button class="file-upload-browse btn btn-info btn-fw" type="button">
                            <i class="mdi mdi-upload"></i>Upload</button>
                          </span>
                        </div>
            </div>
            </div>
        </div>
   </div>    
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.php -->
        <footer class="footer">
          <div class="container-fluid clearfix">
           <center> <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
             <a href="#" target="_blank">Analyst World</a>. All rights reserved.</span></center>
            
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>

<!-- container-scroller -->
  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>

  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="vendors/js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="vendors/js/settings.js"></script>
  <script src="vendors/js/todolist.js"></script>

  <script src="vendors/js/file-upload.js"></script>
  <script src="vendors/js/iCheck.js"></script>
  <script src="vendors/js/typeahead.js"></script>
  <script src="vendors/js/select2.js"></script>
  <script src="js/dropify.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
  
  

</body>

</html>