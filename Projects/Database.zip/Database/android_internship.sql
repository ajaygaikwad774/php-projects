-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 12, 2019 at 01:39 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `android_internship`
--

-- --------------------------------------------------------

--
-- Table structure for table `hh_de_login`
--

CREATE TABLE `hh_de_login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `disabled` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hh_de_login`
--

INSERT INTO `hh_de_login` (`id`, `username`, `password`, `disabled`) VALUES
(1213, 'admin', '123456', 0);

-- --------------------------------------------------------

--
-- Table structure for table `intern_project_details`
--

CREATE TABLE `intern_project_details` (
  `intern_project_id` varchar(255) NOT NULL,
  `intern_batch_id` int(255) NOT NULL,
  `intern_project_name` varchar(200) NOT NULL,
  `intern_project_descp` varchar(255) NOT NULL,
  `intern_project_logo` varchar(255) NOT NULL,
  `i_short_discription` varchar(255) NOT NULL,
  `intern_project_screen_shots_1` varchar(255) NOT NULL,
  `intern_project_screen_shots_2` varchar(255) NOT NULL,
  `intern_project_screen_shots_3` varchar(255) NOT NULL,
  `intern_project_screen_shots_4` varchar(255) NOT NULL,
  `intern_project_screen_shots_5` varchar(255) NOT NULL,
  `intern_project_screen_shots_6` varchar(255) NOT NULL,
  `intern_project_zip_file` varchar(255) NOT NULL,
  `intern_project_apk` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intern_project_details`
--

INSERT INTO `intern_project_details` (`intern_project_id`, `intern_batch_id`, `intern_project_name`, `intern_project_descp`, `intern_project_logo`, `i_short_discription`, `intern_project_screen_shots_1`, `intern_project_screen_shots_2`, `intern_project_screen_shots_3`, `intern_project_screen_shots_4`, `intern_project_screen_shots_5`, `intern_project_screen_shots_6`, `intern_project_zip_file`, `intern_project_apk`) VALUES
('APPINFGPM009052019', 9, 'Diploma colleges in Mumbai', 'android application consisting of the list of divisions, list of colleges located in that division and the details of that colleges specifying the website, Direction to reach that college and a contact no. button.\r\nit consists of 4 Activity\'s. we have use', 'images/20/logo_Diploma colleges in Mumbai.png', 'this android application consist of all the diploma colleges in Mumbai divisions. which is very useful and convenient for the student who are in need of diploma courses after Post SSC. ', 'images/20/ss/image1-20.png', 'images/20/ss/images2-20.png', 'images/20/ss/image3-20.png', 'images/20/ss/image4-20.png', 'images/20/ss/images5-20.png', 'images/20/ss/images6-20.png', 'images/20/file/p_name20.zip', 'images/20/file/Diploma colleges in Mumbai.apk'),
(' APPINFGPM003052019', 3, 'Otp verification using firebase ', 'Our project name is OTP verification. We have used Firebase for authentication for OTP and Firebase Database for storing user data and retrieving. We have also used SharedPreference for offline data storage. Last page is WebView. We have attach spinner fo', 'images/3/logo_Otp verification using firebase .png', 'OTP is generated using Firebase. After entering mobile number you can register and can view news through TOI. Once registered after that you can sign in directly.', 'images/3/ss/images1-3.jpeg', 'images/3/ss/images2-3.jpeg', 'images/3/ss/images3-3.jpeg', 'images/3/ss/images4-3.jpeg', '0', '0', 'images/3/file/p_name3.zip', 'images/3/file/Otp verification using firebase .apk'),
('APPINFINT019042019', 19, 'TableSpace', 'Our App shows nearby workplaces as per location of the user .\r\nIndividuals, freelancers, startups can find workspace at affordable price with good ease of convenience.', 'images/19/logo_TableSpace.png', 'A App which shows nearby workplaces for individual to startups.', 'images/19/ss/images1-19.png', 'images/19/ss/images2-19.png', 'images/19/ss/images3-19.png', 'images/19/ss/images4-19.png', 'images/19/ss/image5-19.png', 'images/19/ss/images6-19.png', 'images/19/file/p_name19.zip', 'images/19/file/TableSpace.apk'),
('APPINFIN0123', 25, 'Testing', 'Detail discription....', 'images/25/logo_Testing.png', 'short discription...', 'images/25/ss/images1-25.png', 'images/25/ss/images2-25.png', 'images/25/ss/images3-25.png', 'images/25/ss/images4-25.png', '0', '0', 'images/25/file/p_name25.zip', 'images/25/file/Testing.apk'),
(' APPINFGPM002052019 ', 2, 'Medicare', 'The App Name is MEDICARE. \r\n1. This Give the information about specialized Doctors And Clinic near us. \r\n2.Doctors and Clinic Information Like Address , Clinic Time ,Email Id , Phone No.', 'images/2/logo_Medicare.jpg', 'The App Name is MEDICARE. \r\n1. This Give the information about Doctors And Clinic near us. \r\n2.Doctors and Clinic Information Like Address , Clinic Time , Email Id , Phone No.', 'images/2/ss/image1-2.png', 'images/2/ss/image2-2.png', 'images/2/ss/images3-2.png', 'images/2/ss/images4-2.png', '0', '0', 'images/2/file/p_name2.zip', 'images/2/file/Medicare.'),
('APPINFGPM013052019', 13, 'Diploma question papers ', 'we created a app which name is Diploma question papers in which there are two departments i.e. IT and Computer in which we collected the question paper pdf of semester 5 and 6 for both IT department and computer department. In which we have take 4 subject', 'images/13/logo_Diploma question papers .jpg', 'We have created app which contains the diploma question paper of three years.It contains two department IT and COMs. Both department contains eight subject of sem5 and sem6.', 'images/13/ss/image1-13.png', 'images/13/ss/image2-13.png', 'images/13/ss/images3-13.png', 'images/13/ss/images4-13.png', '0', '0', 'images/13/file/p_name13.zip', 'images/13/file/Diploma question papers .apk'),
('APPINFGPM015052019', 15, 'Best Engineering Colleges in Mumbai', 'We have created app called &quot;Best Engineering colleges in Mumbai&quot;.As many student face problems as well as confused while choosing the colleges .This app will helpful to all of them. In this app we provide all information about Engineering colleg', 'images/15/logo_Best Engineering Colleges in Mumbai.png', 'We have created app called &quot;Best Engineering Colleges in Mumbai&quot;.This app provide all information about Engineering colleges in Mumbai.', 'images/15/ss/images1-15.png', 'images/15/ss/images2-15.png', 'images/15/ss/image3-15.png', 'images/15/ss/images4-15.png', '0', '0', 'images/15/file/p_name15.json', 'images/15/file/Best Engineering Colleges in Mumbai.apk'),
('APPINFGPM004052019', 4, 'Sim Info', '1.we are display the information like customer care number and   \r\n2.also showing balance of particular sim card.  \r\n3.we also provided online recharge for the given sim. ', 'images/4/logo_Sim Info.png', 'Our project name is sim info it display the information of the sim Available in the market.  ', 'images/4/ss/images1-4.jpeg', 'images/4/ss/images2-4.jpeg', 'images/4/ss/images3-4.jpeg', 'images/4/ss/images4-4.jpeg', '0', '0', 'images/4/file/p_name4.zip', 'images/4/file/Sim Info.apk'),
('APPINFGPM007052019', 7, 'Emergency services', 'Emergency service ,this project  is based on services provided in emergency cases.On emergency cases like calling police,fire brigade , ambulance etc .This application contains information ,contact details,location of services as per your current location', 'images/7/logo_Emergency services.png', 'This app provide services likes calling ,mapping at current location at emergency cases.', 'images/7/ss/images1-7.jpg', 'images/7/ss/image2-7.jpg', 'images/7/ss/images3-7.jpg', 'images/7/ss/images4-7.jpg', 'images/7/ss/images5-7.jpg', 'images/7/ss/images6-7.jpg', 'images/7/file/p_name7.zip', 'images/7/file/Emergency services.apk'),
('APPINFGPM016052019', 16, 'Mobile service center', 'We have created app which is mobile service center .This mobile service center app is time consuming,flexible,and with the help of this one can find best mobile center,contact,visit and navigate to that place easily.', 'images/16/logo_Mobile service center.png', 'We have created app which is mobile service center .This mobile service center app is time consuming,flexible,and  easily.', 'images/16/ss/images1-16.png', 'images/16/ss/images2-16.png', 'images/16/ss/images3-16.png', 'images/16/ss/images4-16.png', 'images/16/ss/images5-16.png', 'images/16/ss/images6-16.png', 'images/16/file/p_name16.zip', 'images/16/file/Mobile service center.apk');

-- --------------------------------------------------------

--
-- Table structure for table `intern_user`
--

CREATE TABLE `intern_user` (
  `intern_id` int(255) NOT NULL,
  `intern_name` varchar(200) NOT NULL,
  `intern_email_id` varchar(100) NOT NULL,
  `intern_contact` int(11) NOT NULL,
  `inter_college` varchar(200) NOT NULL,
  `intern_branch` varchar(200) NOT NULL,
  `intern_year` varchar(200) NOT NULL,
  `intern_photo` varchar(255) NOT NULL,
  `intern_batch_id` int(255) NOT NULL,
  `intern_project_contribution` varchar(200) NOT NULL,
  `intern_contest_letter` varchar(255) NOT NULL,
  `intern_training_certi` varchar(255) NOT NULL,
  `intern_internship_certi` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intern_user`
--

INSERT INTO `intern_user` (`intern_id`, `intern_name`, `intern_email_id`, `intern_contact`, `inter_college`, `intern_branch`, `intern_year`, `intern_photo`, `intern_batch_id`, `intern_project_contribution`, `intern_contest_letter`, `intern_training_certi`, `intern_internship_certi`) VALUES
(33, 'HardikDadas', 'hdadas67@gmail.com', 2147483647, 'Government Polytechnic, Mumbai', 'Computer Engineering', '2019', 'images/007/photo/Hardik.jpg', 7, 'Java Coding, Information Collection, XML coding, etc.', '', '', 'images/007/Internship letter/HardikDadas.pdf'),
(22, 'PrachiSonawane', 'prachiakki1307@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'computer engineering', 'THIRD YEAR diploma', 'images/9/photo/Prachi.jpg', 9, 'We have created a Diploma Colleges in Mumbai App. Which includes all the Diploma Collges in Mumbai divisons, each colleges consists of its Name, Website , Direction , Phone No , Courses Offered and it', '', '', 'images/9/Internship letter/PrachiSonawane.jpg'),
(34, 'DikshaRaut', 'diksharaut2511@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer Engineering ', 'Diploma ', 'images/13/photo/Diksha.jpg', 13, 'Data collection ', '', '', 'images/13/Internship letter/DikshaRaut.pdf'),
(20, 'NidaKhan', 'tunein2001khan@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'computer engineering', 'THIRD YEAR', 'images/9/photo/Nida.JPG', 9, 'Created NORTH-EAST part of diploma colleges in mumbai . I have done xml and java code of it. NORTH-EAST is a particular division of mumbai that consist of severeal colleges that comes under it.IT is v', '', '', 'images/9/Internship letter/NidaKhan.pdf'),
(32, 'PriyushKhobragade', 'khobragadepriyush@gmail.com', 2147483647, 'Government Polytechnic, Mumbai', 'Computer Engineering', '2019', 'images/007/photo/Priyush.jpg', 7, 'XML desing, Java Coding, etc.', '', '', 'images/007/Internship letter/PriyushKhobragade.pdf'),
(18, 'RehanChaudhary', 'rehanchaudhary020gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '3rd year', 'images/8/photo/Rehan.JPG', 8, 'Xml code', '', '', 'images/8/Internship letter/RehanChaudhary.pdf'),
(12, 'MilanSamanta', 'milansam360@gmail.com', 2147483647, 'K C college of Engineering', 'IT', 'BE', 'images/19/photo/Milan.jpg', 19, 'Developed splash screen, Post ad ,My ads Section which includes UI, Backend.\r\nDeveloped APIs for the the app ', '', '', 'images/19/Internship letter/MilanSamanta.pdf'),
(13, 'AnkitKumar', 'ankitk2703@gmail.com', 2147483647, 'K.C College of Engg. , Thane', 'Information Technology', 'Final Year', 'images/19/photo/Ankit.jpg', 19, 'Project Name - TableSpace App\r\nPHP Server Part\r\nLogin Application', '', '', 'images/19/Internship letter/AnkitKumar.pdf'),
(14, 'RINKEEMISHRA', 'suman.india.75@gmail.com', 2147483647, 'KC College of Engineering, Thane', 'IT', '2019-2020', 'images/19/photo/RINKEE.jpg', 19, 'Project name:- Tablespace-Android project\r\nProject Description  :- Infrastructure Renting application\r\nDetails                          :- A app through which users and provider will create account. P', '', '', 'images/19/Internship letter/RINKEEMISHRA.pdf'),
(15, 'SIDDHANTSALVE', 'salvesiddhant32@gmail.com', 2147483647, 'K.C.COLLEGE OF ENGINEERING', 'IT', '2016-2020', 'images/19/photo/SIDDHANT.jpeg', 19, 'Project Id: APPINFINT0190420191.Circular\r\n1.Image view for Profile Image.\r\n2.Database for user and provider login/signup.\r\n3.Designed UI for Login and Signup page(Activity).\r\n4.Helped in creating \"Lic', '', '', 'images/19/Internship letter/SIDDHANTSALVE.pdf'),
(16, 'RahulYadav', 'rahulyadav1598@gmail.com', 2147483647, 'kc college', 'Computer Engineering', 'BE', 'images/25/photo/Rahul.png', 25, 'Individual work Contribution in detail...', '', '', 'images/25/Internship letter/RahulYadav.pdf'),
(17, 'DarshanKomu', 'darshkomu2605@gmail.com', 2147483647, 'kc college', 'Computer Engineering ', 'BE', 'images/25/photo/Darshan.png', 25, 'Work Contribution in detail....', '', '', 'images/25/Internship letter/DarshanKomu.pdf'),
(23, 'MansiKumbhar', 'kumbharmansi25@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'computer engineering', 'THIRD YEAR diploma', 'images/9/photo/Mansi.jpeg', 9, 'I have done xml and java coding of two divisions', '', '', 'images/9/Internship letter/MansiKumbhar.pdf'),
(24, 'ReetikaJadhav', 'jadhavreetika8501@gmail.com ', 2147483647, 'Government polytechnic mumbai ', 'Andheri ', 'Diploma 3rd year', 'images/2/photo/Reetika.jpg', 2, 'Created logo, design java code of main page, xml layout of sub pages', '', '', 'images/2/Internship letter/ReetikaJadhav.pdf'),
(30, 'PratikThakur', 'pratikthakurpt1234@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '2019', 'images/APPINFGPM003052019/photo/Pratik.jpg', 0, 'News app using otp verification and webview\r\nI contributed in webview and helping in making xml of page ', '', '', 'images/APPINFGPM003052019/Internship letter/PratikThakur.jpg'),
(26, 'SahilAnsari', 'sahil382000@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer engineering', '2019', 'images/9/photo/Sahil.jpg', 9, 'Data collection and app icon settings.', '', '', 'images/9/Internship letter/SahilAnsari.pdf'),
(27, 'AbhishekYadav', 'yadavabhi1522@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', 'Third', 'images/3/photo/Abhishek.jpg', 3, 'FireBase Authentication and XML,Country code picker', '', '', 'images/3/Internship letter/AbhishekYadav.pdf'),
(28, 'OmkarGhanekar', 'omkarghanekar12@gmail.com', 2147483647, 'Government Polyetechinc Mumbai', 'Computer Engineerung', 'Third Year', 'images/ APPINFGPM009052019/photo/Omkar.jpg', 0, 'back end and UI Updation', '', '', 'images/ APPINFGPM009052019/Internship letter/OmkarGhanekar.pdf'),
(31, 'AnjaliGaikwad', 'anjaligaikwad1312@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '2019', 'images/APPINFGPM003052019/photo/Anjali.jpg', 0, 'News app using otp verification and webview\r\nI contributed in sharepreference', '', '', 'images/APPINFGPM003052019/Internship letter/AnjaliGaikwad.jpg'),
(35, 'ShrutiDashpute', 'dashpute.shruti2002@gmail.com', 2147483647, 'Goverment Polytechnic Mumbai. ', 'Computer', '2019', 'images/APPINFGPM013052019/photo/Shruti.jpg', 0, 'Shruti Dashpute : - Java code\r\nSanika Bangar : - Java code\r\nRuby shaikh : - xml code\r\nIsha Modak : - xml code\r\nDiksha Raut : Data collection ', '', '', 'images/APPINFGPM013052019/Internship letter/ShrutiDashpute.pdf'),
(36, 'SanikaBangar', 'sanikabangar18@yahoo.com ', 2147483647, 'Government polytechnic mumbai ', 'Computer engineering ', '2019', 'images/13/photo/Sanika.jpg', 13, 'Shruti Dashpute : - Java code\r\nSanika Bangar : - java code\r\nRuby Shaikh : - xml code\r\nIsha Modak : - xml code\r\nDiksha Raut : - Data collection', '', '', 'images/13/Internship letter/SanikaBangar.pdf'),
(37, 'ShrutiDashpute', 'dashpute.shruti2002@gmail.com', 2147483647, 'Goverment Polytechnic Mumbai.', 'Computer', '2019', 'images/13/photo/Shruti.jpg', 13, 'Shruti Dashpute : - Java code\r\nSanika Bangar : - java code\r\nRuby Shaikh : - xml code\r\nIsha Modak : - xml code\r\nDiksha Raut : - Data collection', '', '', 'images/13/Internship letter/ShrutiDashpute.pdf'),
(38, 'SatyamGupta', 'sg.satyamgupta98@gmail.com', 2147483647, 'Government polytechnic mumbai', 'IT', 'Second year', 'images/14/photo/Satyam.png', 14, 'collection of images related to meditaion', '', '', 'images/14/Internship letter/SatyamGupta.jpg'),
(39, 'Rutuja Kurale', 'rutujakurale@gmail.com', 2147483647, 'government Polytechnic Mumbai', 'computer', 'Third', 'images/2/photo/Rutuja .png', 2, 'Xml of main Page , Created Adapter and Pojo Classes , Design Layout of the Recyclerview', '', '', 'images/2/Internship letter/Rutuja Kurale.pdf'),
(40, 'IshaModak', 'ishamodak34@gmail.com', 2147483647, 'Government polytechnic Mumbai', 'Computer', 'Diploma', 'images/13/photo/Isha.jpg', 13, 'Shruti Dashpute : - Java code\r\nSanika Bangar : - java code\r\nRuby Shaikh : - xml code\r\nIsha Modak : - xml code\r\nDiksha Raut : - Data collection', '', '', 'images/13/Internship letter/IshaModak.pdf'),
(41, 'AfifaShaikh', 'afifashaikh291001@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer Engineering ', '3rd', 'images/15/photo/Afifa.jpg', 15, 'XML of Thane and Navi Mumbai and information collection ', '', '', 'images/15/Internship letter/AfifaShaikh.pdf'),
(42, 'Prerna Karande ', 'karandeprerna@gmail.com', 2147483647, 'Government polytechnic Mumbai ', 'Computer ', '2019', 'images/2/photo/Prerna .png', 2, ' Sub Pages , Added Data in Recyclerview , Data Collection of Clinic	3 Week																						\r\n7\r\n', '', '', 'images/2/Internship letter/Prerna Karande .pdf'),
(43, 'TryambakeshRane', 'tryambakeshrane42@gmail.com', 2147483647, 'Government Polytechnic Mumbai ', 'Information Technology ', '2019', 'images/14/photo/Tryambakesh.jpeg', 14, 'Creating xml for Second Activity ', '', '', 'images/14/Internship letter/TryambakeshRane.pdf'),
(44, 'Aman Gadadare', 'gaman889811@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', 'Third', 'images/15/photo/Aman .jpg', 15, 'Front end ,colleges , Option menu,,\r\nback end option menu and colleges\r\nfront and back end-north central all colleges', '', '', 'images/15/Internship letter/Aman Gadadare.pdf'),
(45, 'TryambakeshRane', 'tryambakeshrane42@gmail.com', 2147483647, 'Government Polytechnic Mumbai ', 'Information Technology ', 'Third Year', 'images/14/photo/Tryambakesh.jpeg', 14, 'Creating xml for Second Activity ', '', '', 'images/14/Internship letter/TryambakeshRane.pdf'),
(46, 'Saim Bardi', 'saimbardi@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', 'Third', 'images/15/photo/Saim .jpg', 15, 'front end,splash screen,special thanks to\r\nnew mumbai and thane back end', '', '', 'images/15/Internship letter/Saim Bardi.pdf'),
(47, 'AfifaShaikh', 'afifashaikh291001@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', 'Third', 'images/15/photo/Afifa.jpg', 15, 'xml of thane and navi mumbai\r\nInformation collection', '', '', 'images/15/Internship letter/AfifaShaikh.pdf'),
(48, 'Samiksha Hankare', 'samihankare12@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', 'Third', 'images/15/photo/Samiksha .jpg', 15, 'front end and back end of- south and north mumbai', '', '', 'images/15/Internship letter/Samiksha Hankare.pdf'),
(49, 'TryambakeshRane', 'tryambakeshrane42@gmail.com', 2147483647, 'Government Polytechnic Mumbai ', 'Information Technology ', 'Third Year', 'images/14/photo/Tryambakesh.jpeg', 14, 'Creating xml for Second Activity ', '', '', 'images/14/Internship letter/TryambakeshRane.pdf'),
(50, 'Azim Momin', 'Astornmartin250@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', 'Third', 'images/15/photo/Azim .jpg', 15, 'xml and java code of Top colleges', '', '', 'images/15/Internship letter/Azim Momin.pdf'),
(51, 'RubyShaikh', 'shaikhruby678@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', '3rd ', 'images/APPINFGPM013052019/photo/Ruby.jpg', 0, 'XML for Years', '', '', 'images/APPINFGPM013052019/Internship letter/RubyShaikh.jpg'),
(52, 'NiketPawar', 'pawarniket123@gmail.com', 2147483647, 'Government polytechnic Mumbai', 'Information technology', 'Diploma in 3rd year', 'images/4/photo/Niket.jpg', 4, 'Web view of java code', '', '', 'images/4/Internship letter/NiketPawar.pdf'),
(53, 'MitheshGawande', 'mitheshgawande2115@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '3rd year', 'images/4/photo/Mithesh.png', 4, 'Java code of All activities', '', '', 'images/4/Internship letter/MitheshGawande.png'),
(54, 'AlpeshShinde', 'shindealpesh3010@gmail.com', 2147483647, 'Government polytechnic Mumbai', 'Information technology', '3rd', 'images/APPINFGPM004052019/photo/Alpesh.jpg', 0, 'Xml of main activity', '', '', 'images/APPINFGPM004052019/Internship letter/AlpeshShinde.pdf'),
(55, 'aniketDHEKALE', 'aniket9503696516@gmail.com', 2147483647, 'goverment polytechnic mumbai', 'computer engineering', 'third year', 'images/10/photo/aniket.jpeg', 10, 'collecting links for maps information on Wikipedia.', '', '', 'images/10/Internship letter/aniketDHEKALE.pdf'),
(56, 'shubham kadam', 'Sk6000707@gmail.com', 2147483647, 'goverment polytechnic mumbaith', 'computer engineering', 'third year', 'images/10/photo/shubham .jpg', 10, 'Xml of all pages and java coding and  app logo.', '', '', 'images/10/Internship letter/shubham kadam.pdf'),
(78, 'AlpeshShinde', 'shindealpesh3010@gmail.com', 2147483647, 'Government polytechnic Mumbai', 'Information technology', '3rd', 'images/APPINFGPM004052019/photo/Alpesh.jpg', 0, 'Xml of main activity', '', '', 'images/APPINFGPM004052019/Internship letter/AlpeshShinde.pdf'),
(58, 'RubyShaikh', 'shaikhruby678@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Computer', '3rd ', 'images/APPINFGPM013052019/photo/Ruby.jpg', 0, 'XML for Years', '', '', 'images/APPINFGPM013052019/Internship letter/RubyShaikh.jpg'),
(59, 'RushikeshDhawade', 'rushidhawade23@gmail.com', 2147483647, 'Government Polytechnic,Mumbai', 'Information Technology', '3rd year', 'images/5/photo/Rushikesh.jpg', 5, 'XML coding and collecting information', '', '', 'images/5/Internship letter/RushikeshDhawade.pdf'),
(77, 'HetalPanchal', 'hetalpanchal@gmail.com', 2147483647, 'government polytechnic mumbai', 'information technology', '3rd', 'images/16/photo/Hetal.pdf', 16, 'We have created app which is mobile service center .This mobile service center app is time consuming,flexible,and with the help of this one can find best mobile center,contact,visit and navigate to th', '', '', 'images/16/Internship letter/HetalPanchal.pdf'),
(61, 'RohitCatholic', 'rohitkathlic@gmail.com ', 2147483647, 'Government polytechnic mumbai ', 'Information  technology ', '3rd year', 'images/3/photo/Rohit.jpg', 3, 'Webview ', '', '', 'images/3/Internship letter/RohitCatholic.docx'),
(62, 'MarutiMore', 'marutikmore348@gmail.com', 2147483647, 'Government Polytechnic,Mumbai', 'Information Technology', '3rd year', 'images/5/photo/Maruti.JPG', 5, 'XML and Java coding in which scroll bar and applying videos and string functions and manifest coding', '', '', 'images/5/Internship letter/MarutiMore.pdf'),
(63, 'Abdul GaniShaikh', 'shkhabdulgani@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '2019', 'images/3/photo/Abdul Gani.jpg', 3, 'FireBase Database And XML', '', '', 'images/3/Internship letter/Abdul GaniShaikh.pdf'),
(64, 'NikitaDubey', 'nikdubey06@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '2019', 'images/7/photo/Nikita.jpg', 7, 'java code,logo ,xml', '', '', 'images/7/Internship letter/NikitaDubey.pdf'),
(65, 'LalitVinde', 'lalit5102001@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '2019', 'images/1/photo/Lalit.jpg', 1, 'Complete project created by me', '', '', 'images/1/Internship letter/LalitVinde.pdf'),
(66, 'HetalPanchal', 'hetalpanchal@gmail.com', 2147483647, 'government polytechnic mumbai', 'information technology', '3rd', 'images/16/photo/Hetal.pdf', 16, 'java and xml code,logo and error solving', '', '', 'images/16/Internship letter/HetalPanchal.pdf'),
(67, 'Anjali Gaikwad', 'anjaligaikwad1312@gmail.com', 2147483647, 'government polytechnic mumbai', 'information technology', '3rd', 'images/3/photo/Anjali .jpg', 3, 'SharedPreferences and AvatarView.', '', '', 'images/3/Internship letter/Anjali Gaikwad.pdf'),
(68, 'MehzabeenShaikh', 'shaikhmehzabeen2001@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology', '3rd', 'images/7/photo/Mehzabeen.jpg', 7, 'XML, Data collection', '', '', 'images/7/Internship letter/MehzabeenShaikh.pdf'),
(69, 'PratikThakur', 'pratikthakurpt1234@gmail.com', 2147483647, 'government polytechnic mumbai', 'information technology', '3rd', 'images/3/photo/Pratik.jpg', 3, 'SharedPreferences and XML.', '', '', 'images/3/Internship letter/PratikThakur.pdf'),
(70, 'TulsiPatil', 'tulsipatil2002@gmail.com', 2147483647, 'Government Polytechnic,Mumbai', 'Information Technology', 'Third year', 'images/12/photo/Tulsi.jpg', 12, 'xml coding.', '', '', 'images/12/Internship letter/TulsiPatil.pdf'),
(71, 'VIPULGUPTA', 'vipul97621@gmail.com', 2147483647, 'Government polytechnic, Mumbai', 'IT', '3rd year', 'images/14/photo/VIPUL.jpg', 14, 'Xml for main activity', '', '', 'images/14/Internship letter/VIPULGUPTA.png'),
(72, 'VIPULGUPTA', 'vipul97621@gmail.com', 2147483647, 'Government polytechnic, Mumbai', 'IT', '3rd year', 'images/14/photo/VIPUL.jpg', 14, 'Xml for main activity', '', '', 'images/14/Internship letter/VIPULGUPTA.png'),
(73, 'vivekchaurasiya', 'vrchaurasiya2000@gmail.com', 2147483647, 'GPM', 'information technology ', '3rd year ', 'images/14/photo/vivek.jpeg', 14, 'We have to created meditation app which is relaxation of human brain and increasing thinking power.We can do the meditation in  different places such as riverside,temple. we have to put the relaxation', '', '', 'images/14/Internship letter/vivekchaurasiya.pdf'),
(74, 'vivekchaurasiya', 'vrchaurasiya2000@gmail.com', 2147483647, 'GPM', 'information technology ', '3rd year ', 'images/14/photo/vivek.jpeg', 14, 'Java coding for all activity pages', '', '', 'images/14/Internship letter/vivekchaurasiya.pdf'),
(75, 'RasikaPatil', 'patilrasika972@gmail.com', 2147483647, 'Government polytechnic mumbai', 'Information technology', '2018-2019', 'images/7/photo/Rasika.jpg', 7, 'Java code and UI', '', '', 'images/7/Internship letter/RasikaPatil.pdf'),
(76, 'RasikaPatil', 'patilrasika972@gmail.com', 2147483647, 'Government polytechnic mumbai', 'Information technology', '2018-2019', 'images/7/photo/Rasika.jpg', 7, 'Java code and ui', '', '', 'images/7/Internship letter/RasikaPatil.pdf'),
(79, 'MalikaShaikh', 'malikashaikh5522@gmail.com', 2147483647, 'Government Polytechnic Mumbai', 'Information Technology ', 'Third year', 'images/19/photo/Malika.jpg', 19, 'The name of my project is All in One Net Banking. The whole project was made by me. I used the buttons,CardView,Textfields,etc in my project. ', '', '', 'images/19/Internship letter/MalikaShaikh.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hh_de_login`
--
ALTER TABLE `hh_de_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intern_project_details`
--
ALTER TABLE `intern_project_details`
  ADD PRIMARY KEY (`intern_project_id`);

--
-- Indexes for table `intern_user`
--
ALTER TABLE `intern_user`
  ADD PRIMARY KEY (`intern_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hh_de_login`
--
ALTER TABLE `hh_de_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1214;

--
-- AUTO_INCREMENT for table `intern_user`
--
ALTER TABLE `intern_user`
  MODIFY `intern_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
