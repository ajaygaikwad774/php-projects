-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 12, 2019 at 01:38 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `washing_machine_service_center`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `atrollno` varchar(100) DEFAULT NULL,
  `atdiv` varchar(5) DEFAULT NULL,
  `atstatus` varchar(25) DEFAULT NULL,
  `atdate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `atrollno`, `atdiv`, `atstatus`, `atdate`) VALUES
(1, '1', 'A', 'present', '2017-04-23'),
(2, '2', 'A', 'present', '2017-04-23'),
(3, '4', 'A', 'present', '2017-04-23'),
(4, '5', 'A', 'present', '2017-04-23'),
(5, '3', 'A', 'present', '2017-04-23'),
(6, '6', 'A', 'absent', '2017-04-23'),
(7, '8', 'A', 'absent', '2017-04-23'),
(8, '7', 'A', 'absent', '2017-04-23'),
(9, '10', 'A', 'absent', '2017-04-23'),
(10, '13', 'A', 'absent', '2017-04-23'),
(11, '12', 'A', 'absent', '2017-04-23'),
(12, '16', 'A', 'absent', '2017-04-23'),
(13, '11', 'A', 'absent', '2017-04-23'),
(14, '9', 'A', 'absent', '2017-04-23'),
(15, '15', 'A', 'absent', '2017-04-23'),
(16, '14', 'A', 'absent', '2017-04-23'),
(17, '21', 'A', 'absent', '2017-04-23'),
(18, '17', 'A', 'absent', '2017-04-23'),
(19, '18', 'A', 'absent', '2017-04-23'),
(20, '20', 'A', 'absent', '2017-04-23'),
(21, '19', 'A', 'absent', '2017-04-23'),
(22, '22', 'A', 'absent', '2017-04-23'),
(23, '23', 'A', 'absent', '2017-04-23'),
(24, '25', 'A', 'absent', '2017-04-23'),
(25, '27', 'A', 'absent', '2017-04-23'),
(26, '26', 'A', 'absent', '2017-04-23'),
(27, '24', 'A', 'absent', '2017-04-23'),
(28, '30', 'A', 'absent', '2017-04-23'),
(29, '28', 'A', 'absent', '2017-04-23'),
(30, '29', 'A', 'absent', '2017-04-23'),
(31, '31', 'A', 'absent', '2017-04-23'),
(32, '32', 'A', 'absent', '2017-04-23'),
(33, '37', 'A', 'absent', '2017-04-23'),
(34, '35', 'A', 'absent', '2017-04-23'),
(35, '33', 'A', 'absent', '2017-04-23'),
(36, '38', 'A', 'absent', '2017-04-23'),
(37, '34', 'A', 'absent', '2017-04-23'),
(38, '36', 'A', 'absent', '2017-04-23'),
(39, '39', 'A', 'absent', '2017-04-23'),
(40, '41', 'A', 'absent', '2017-04-23'),
(41, '42', 'A', 'absent', '2017-04-23'),
(42, '40', 'A', 'absent', '2017-04-23'),
(43, '43', 'A', 'absent', '2017-04-23'),
(44, '44', 'A', 'absent', '2017-04-23'),
(45, '47', 'A', 'absent', '2017-04-23'),
(46, '48', 'A', 'absent', '2017-04-23'),
(47, '49', 'A', 'absent', '2017-04-23'),
(48, '45', 'A', 'absent', '2017-04-23'),
(49, '46', 'A', 'absent', '2017-04-23'),
(50, '52', 'A', 'absent', '2017-04-23'),
(51, '51', 'A', 'absent', '2017-04-23'),
(52, '50', 'A', 'absent', '2017-04-23'),
(53, '53', 'A', 'absent', '2017-04-23'),
(54, '54', 'A', 'absent', '2017-04-23'),
(55, '55', 'A', 'absent', '2017-04-23'),
(56, '56', 'A', 'absent', '2017-04-23'),
(57, '58', 'A', 'absent', '2017-04-23'),
(58, '57', 'A', 'absent', '2017-04-23'),
(59, '59', 'A', 'absent', '2017-04-23'),
(60, '60', 'A', 'absent', '2017-04-23'),
(61, '62', 'A', 'absent', '2017-04-23'),
(62, '63', 'A', 'absent', '2017-04-23'),
(63, '65', 'A', 'absent', '2017-04-23'),
(64, '61', 'A', 'absent', '2017-04-23'),
(65, '67', 'A', 'absent', '2017-04-23'),
(66, '64', 'A', 'absent', '2017-04-23'),
(67, '69', 'A', 'absent', '2017-04-23'),
(68, '71', 'A', 'absent', '2017-04-23'),
(69, '70', 'A', 'absent', '2017-04-23'),
(70, '72', 'A', 'absent', '2017-04-23'),
(71, '66', 'A', 'absent', '2017-04-23'),
(72, '68', 'A', 'absent', '2017-04-23'),
(73, '73', 'A', 'absent', '2017-04-23'),
(74, '77', 'A', 'absent', '2017-04-23'),
(75, '75', 'A', 'absent', '2017-04-23'),
(76, '74', 'A', 'absent', '2017-04-23'),
(77, '76', 'A', 'absent', '2017-04-23'),
(78, '79', 'A', 'absent', '2017-04-23'),
(79, '80', 'A', 'absent', '2017-04-23'),
(80, '78', 'A', 'absent', '2017-04-23'),
(81, '2', 'A', 'present', '2017-04-23'),
(82, '3', 'A', 'present', '2017-04-23'),
(83, '1', 'A', 'absent', '2017-04-23'),
(84, '5', 'A', 'absent', '2017-04-23'),
(85, '4', 'A', 'absent', '2017-04-23'),
(86, '10', 'A', 'absent', '2017-04-23'),
(87, '9', 'A', 'absent', '2017-04-23'),
(88, '6', 'A', 'absent', '2017-04-23'),
(89, '8', 'A', 'absent', '2017-04-23'),
(90, '11', 'A', 'absent', '2017-04-23'),
(91, '14', 'A', 'absent', '2017-04-23'),
(92, '7', 'A', 'absent', '2017-04-23'),
(93, '15', 'A', 'absent', '2017-04-23'),
(94, '13', 'A', 'absent', '2017-04-23'),
(95, '12', 'A', 'absent', '2017-04-23'),
(96, '16', 'A', 'absent', '2017-04-23'),
(97, '17', 'A', 'absent', '2017-04-23'),
(98, '20', 'A', 'absent', '2017-04-23'),
(99, '21', 'A', 'absent', '2017-04-23'),
(100, '24', 'A', 'absent', '2017-04-23'),
(101, '18', 'A', 'absent', '2017-04-23'),
(102, '19', 'A', 'absent', '2017-04-23'),
(103, '23', 'A', 'absent', '2017-04-23'),
(104, '22', 'A', 'absent', '2017-04-23'),
(105, '26', 'A', 'absent', '2017-04-23'),
(106, '30', 'A', 'absent', '2017-04-23'),
(107, '25', 'A', 'absent', '2017-04-23'),
(108, '27', 'A', 'absent', '2017-04-23'),
(109, '28', 'A', 'absent', '2017-04-23'),
(110, '31', 'A', 'absent', '2017-04-23'),
(111, '33', 'A', 'absent', '2017-04-23'),
(112, '29', 'A', 'absent', '2017-04-23'),
(113, '35', 'A', 'absent', '2017-04-23'),
(114, '32', 'A', 'absent', '2017-04-23'),
(115, '34', 'A', 'absent', '2017-04-23'),
(116, '36', 'A', 'absent', '2017-04-23'),
(117, '43', 'A', 'absent', '2017-04-23'),
(118, '44', 'A', 'absent', '2017-04-23'),
(119, '37', 'A', 'absent', '2017-04-23'),
(120, '45', 'A', 'absent', '2017-04-23'),
(121, '39', 'A', 'absent', '2017-04-23'),
(122, '42', 'A', 'absent', '2017-04-23'),
(123, '38', 'A', 'absent', '2017-04-23'),
(124, '41', 'A', 'absent', '2017-04-23'),
(125, '40', 'A', 'absent', '2017-04-23'),
(126, '50', 'A', 'absent', '2017-04-23'),
(127, '51', 'A', 'absent', '2017-04-23'),
(128, '49', 'A', 'absent', '2017-04-23'),
(129, '47', 'A', 'absent', '2017-04-23'),
(130, '46', 'A', 'absent', '2017-04-23'),
(131, '52', 'A', 'absent', '2017-04-23'),
(132, '48', 'A', 'absent', '2017-04-23'),
(133, '58', 'A', 'absent', '2017-04-23'),
(134, '55', 'A', 'absent', '2017-04-23'),
(135, '57', 'A', 'absent', '2017-04-23'),
(136, '56', 'A', 'absent', '2017-04-23'),
(137, '59', 'A', 'absent', '2017-04-23'),
(138, '54', 'A', 'absent', '2017-04-23'),
(139, '60', 'A', 'absent', '2017-04-23'),
(140, '53', 'A', 'absent', '2017-04-23'),
(141, '64', 'A', 'absent', '2017-04-23'),
(142, '63', 'A', 'absent', '2017-04-23'),
(143, '66', 'A', 'absent', '2017-04-23'),
(144, '61', 'A', 'absent', '2017-04-23'),
(145, '62', 'A', 'absent', '2017-04-23'),
(146, '65', 'A', 'absent', '2017-04-23'),
(147, '67', 'A', 'absent', '2017-04-23'),
(148, '73', 'A', 'absent', '2017-04-23'),
(149, '74', 'A', 'absent', '2017-04-23'),
(150, '69', 'A', 'absent', '2017-04-23'),
(151, '71', 'A', 'absent', '2017-04-23'),
(152, '72', 'A', 'absent', '2017-04-23'),
(153, '68', 'A', 'absent', '2017-04-23'),
(154, '70', 'A', 'absent', '2017-04-23'),
(155, '76', 'A', 'absent', '2017-04-23'),
(156, '78', 'A', 'absent', '2017-04-23'),
(157, '75', 'A', 'absent', '2017-04-23'),
(158, '77', 'A', 'absent', '2017-04-23'),
(159, '79', 'A', 'absent', '2017-04-23'),
(160, '80', 'A', 'absent', '2017-04-23');

-- --------------------------------------------------------

--
-- Table structure for table `attendance1`
--

CREATE TABLE `attendance1` (
  `id` int(100) NOT NULL,
  `atrollno` varchar(100) NOT NULL,
  `atdiv` varchar(100) NOT NULL,
  `atstatus` varchar(100) NOT NULL,
  `atdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `attendance2`
--

CREATE TABLE `attendance2` (
  `id` int(100) NOT NULL,
  `atrollno` varchar(100) NOT NULL,
  `atdiv` varchar(100) NOT NULL,
  `atstatus` varchar(100) NOT NULL,
  `atdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance2`
--

INSERT INTO `attendance2` (`id`, `atrollno`, `atdiv`, `atstatus`, `atdate`) VALUES
(1, '6', 'A', 'present', '2017-04-23'),
(2, '2', 'A', 'absent', '2017-04-23'),
(3, '1', 'A', 'absent', '2017-04-23'),
(4, '4', 'A', 'absent', '2017-04-23'),
(5, '7', 'A', 'absent', '2017-04-23'),
(6, '5', 'A', 'absent', '2017-04-23'),
(7, '10', 'A', 'absent', '2017-04-23'),
(8, '8', 'A', 'absent', '2017-04-23'),
(9, '3', 'A', 'absent', '2017-04-23'),
(10, '9', 'A', 'absent', '2017-04-23'),
(11, '11', 'A', 'absent', '2017-04-23'),
(12, '12', 'A', 'absent', '2017-04-23'),
(13, '16', 'A', 'absent', '2017-04-23'),
(14, '18', 'A', 'absent', '2017-04-23'),
(15, '19', 'A', 'absent', '2017-04-23'),
(16, '17', 'A', 'absent', '2017-04-23'),
(17, '15', 'A', 'absent', '2017-04-23'),
(18, '13', 'A', 'absent', '2017-04-23'),
(19, '14', 'A', 'absent', '2017-04-23'),
(20, '20', 'A', 'absent', '2017-04-23'),
(21, '21', 'A', 'absent', '2017-04-23'),
(22, '26', 'A', 'absent', '2017-04-23'),
(23, '22', 'A', 'absent', '2017-04-23'),
(24, '25', 'A', 'absent', '2017-04-23'),
(25, '27', 'A', 'absent', '2017-04-23'),
(26, '29', 'A', 'absent', '2017-04-23'),
(27, '28', 'A', 'absent', '2017-04-23'),
(28, '24', 'A', 'absent', '2017-04-23'),
(29, '23', 'A', 'absent', '2017-04-23'),
(30, '30', 'A', 'absent', '2017-04-23'),
(31, '33', 'A', 'absent', '2017-04-23'),
(32, '34', 'A', 'absent', '2017-04-23'),
(33, '35', 'A', 'absent', '2017-04-23'),
(34, '31', 'A', 'absent', '2017-04-23'),
(35, '37', 'A', 'absent', '2017-04-23'),
(36, '32', 'A', 'absent', '2017-04-23'),
(37, '36', 'A', 'absent', '2017-04-23'),
(38, '38', 'A', 'absent', '2017-04-23'),
(39, '39', 'A', 'absent', '2017-04-23'),
(40, '43', 'A', 'absent', '2017-04-23'),
(41, '40', 'A', 'absent', '2017-04-23'),
(42, '42', 'A', 'absent', '2017-04-23'),
(43, '41', 'A', 'absent', '2017-04-23'),
(44, '45', 'A', 'absent', '2017-04-23'),
(45, '44', 'A', 'absent', '2017-04-23'),
(46, '46', 'A', 'absent', '2017-04-23'),
(47, '48', 'A', 'absent', '2017-04-23'),
(48, '49', 'A', 'absent', '2017-04-23'),
(49, '47', 'A', 'absent', '2017-04-23'),
(50, '52', 'A', 'absent', '2017-04-23'),
(51, '54', 'A', 'absent', '2017-04-23'),
(52, '51', 'A', 'absent', '2017-04-23'),
(53, '50', 'A', 'absent', '2017-04-23'),
(54, '53', 'A', 'absent', '2017-04-23'),
(55, '55', 'A', 'absent', '2017-04-23'),
(56, '56', 'A', 'absent', '2017-04-23'),
(57, '58', 'A', 'absent', '2017-04-23'),
(58, '63', 'A', 'absent', '2017-04-23'),
(59, '60', 'A', 'absent', '2017-04-23'),
(60, '61', 'A', 'absent', '2017-04-23'),
(61, '62', 'A', 'absent', '2017-04-23'),
(62, '66', 'A', 'absent', '2017-04-23'),
(63, '59', 'A', 'absent', '2017-04-23'),
(64, '67', 'A', 'absent', '2017-04-23'),
(65, '57', 'A', 'absent', '2017-04-23'),
(66, '64', 'A', 'absent', '2017-04-23'),
(67, '65', 'A', 'absent', '2017-04-23'),
(68, '71', 'A', 'absent', '2017-04-23'),
(69, '68', 'A', 'absent', '2017-04-23'),
(70, '72', 'A', 'absent', '2017-04-23'),
(71, '75', 'A', 'absent', '2017-04-23'),
(72, '74', 'A', 'absent', '2017-04-23'),
(73, '76', 'A', 'absent', '2017-04-23'),
(74, '69', 'A', 'absent', '2017-04-23'),
(75, '73', 'A', 'absent', '2017-04-23'),
(76, '70', 'A', 'absent', '2017-04-23'),
(77, '78', 'A', 'absent', '2017-04-23'),
(78, '77', 'A', 'absent', '2017-04-23'),
(79, '80', 'A', 'absent', '2017-04-23'),
(80, '79', 'A', 'absent', '2017-04-23');

-- --------------------------------------------------------

--
-- Table structure for table `attendance3`
--

CREATE TABLE `attendance3` (
  `id` int(100) NOT NULL,
  `atrollno` varchar(100) NOT NULL,
  `atdiv` varchar(100) NOT NULL,
  `atstatus` varchar(100) NOT NULL,
  `atdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `attendance4`
--

CREATE TABLE `attendance4` (
  `id` int(100) NOT NULL,
  `atrollno` varchar(100) NOT NULL,
  `atdiv` varchar(100) NOT NULL,
  `atstatus` varchar(100) NOT NULL,
  `atdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `attendance5`
--

CREATE TABLE `attendance5` (
  `id` int(100) NOT NULL,
  `atrollno` varchar(100) NOT NULL,
  `atdiv` varchar(100) NOT NULL,
  `atstatus` varchar(100) NOT NULL,
  `atdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance5`
--

INSERT INTO `attendance5` (`id`, `atrollno`, `atdiv`, `atstatus`, `atdate`) VALUES
(1, '1', 'A', 'present', '2017-04-23'),
(2, '2', 'A', 'absent', '2017-04-23'),
(3, '9', 'A', 'absent', '2017-04-23'),
(4, '4', 'A', 'absent', '2017-04-23'),
(5, '10', 'A', 'absent', '2017-04-23'),
(6, '5', 'A', 'absent', '2017-04-23'),
(7, '8', 'A', 'absent', '2017-04-23'),
(8, '7', 'A', 'absent', '2017-04-23'),
(9, '13', 'A', 'absent', '2017-04-23'),
(10, '3', 'A', 'absent', '2017-04-23'),
(11, '11', 'A', 'absent', '2017-04-23'),
(12, '6', 'A', 'absent', '2017-04-23'),
(13, '17', 'A', 'absent', '2017-04-23'),
(14, '16', 'A', 'absent', '2017-04-23'),
(15, '12', 'A', 'absent', '2017-04-23'),
(16, '15', 'A', 'absent', '2017-04-23'),
(17, '18', 'A', 'absent', '2017-04-23'),
(18, '14', 'A', 'absent', '2017-04-23'),
(19, '19', 'A', 'absent', '2017-04-23'),
(20, '20', 'A', 'absent', '2017-04-23'),
(21, '22', 'A', 'absent', '2017-04-23'),
(22, '21', 'A', 'absent', '2017-04-23'),
(23, '26', 'A', 'absent', '2017-04-23'),
(24, '24', 'A', 'absent', '2017-04-23'),
(25, '23', 'A', 'absent', '2017-04-23'),
(26, '25', 'A', 'absent', '2017-04-23'),
(27, '27', 'A', 'absent', '2017-04-23'),
(28, '29', 'A', 'absent', '2017-04-23'),
(29, '31', 'A', 'absent', '2017-04-23'),
(30, '28', 'A', 'absent', '2017-04-23'),
(31, '33', 'A', 'absent', '2017-04-23'),
(32, '30', 'A', 'absent', '2017-04-23'),
(33, '32', 'A', 'absent', '2017-04-23'),
(34, '36', 'A', 'absent', '2017-04-23'),
(35, '37', 'A', 'absent', '2017-04-23'),
(36, '34', 'A', 'absent', '2017-04-23'),
(37, '39', 'A', 'absent', '2017-04-23'),
(38, '38', 'A', 'absent', '2017-04-23'),
(39, '35', 'A', 'absent', '2017-04-23'),
(40, '42', 'A', 'absent', '2017-04-23'),
(41, '40', 'A', 'absent', '2017-04-23'),
(42, '47', 'A', 'absent', '2017-04-23'),
(43, '44', 'A', 'absent', '2017-04-23'),
(44, '43', 'A', 'absent', '2017-04-23'),
(45, '48', 'A', 'absent', '2017-04-23'),
(46, '41', 'A', 'absent', '2017-04-23'),
(47, '45', 'A', 'absent', '2017-04-23'),
(48, '46', 'A', 'absent', '2017-04-23'),
(49, '49', 'A', 'absent', '2017-04-23'),
(50, '51', 'A', 'absent', '2017-04-23'),
(51, '52', 'A', 'absent', '2017-04-23'),
(52, '55', 'A', 'absent', '2017-04-23'),
(53, '53', 'A', 'absent', '2017-04-23'),
(54, '54', 'A', 'absent', '2017-04-23'),
(55, '50', 'A', 'absent', '2017-04-23'),
(56, '56', 'A', 'absent', '2017-04-23'),
(57, '61', 'A', 'absent', '2017-04-23'),
(58, '57', 'A', 'absent', '2017-04-23'),
(59, '60', 'A', 'absent', '2017-04-23'),
(60, '59', 'A', 'absent', '2017-04-23'),
(61, '58', 'A', 'absent', '2017-04-23'),
(62, '62', 'A', 'absent', '2017-04-23'),
(63, '64', 'A', 'absent', '2017-04-23'),
(64, '66', 'A', 'absent', '2017-04-23'),
(65, '65', 'A', 'absent', '2017-04-23'),
(66, '67', 'A', 'absent', '2017-04-23'),
(67, '68', 'A', 'absent', '2017-04-23'),
(68, '69', 'A', 'absent', '2017-04-23'),
(69, '70', 'A', 'absent', '2017-04-23'),
(70, '72', 'A', 'absent', '2017-04-23'),
(71, '71', 'A', 'absent', '2017-04-23'),
(72, '74', 'A', 'absent', '2017-04-23'),
(73, '63', 'A', 'absent', '2017-04-23'),
(74, '73', 'A', 'absent', '2017-04-23'),
(75, '75', 'A', 'absent', '2017-04-23'),
(76, '77', 'A', 'absent', '2017-04-23'),
(77, '76', 'A', 'absent', '2017-04-23'),
(78, '78', 'A', 'absent', '2017-04-23'),
(79, '79', 'A', 'absent', '2017-04-23'),
(80, '80', 'A', 'absent', '2017-04-23');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_product` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `active_deactive_flag` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`c_id`, `c_name`, `c_product`, `contact_person`, `contact_no`, `active_deactive_flag`, `disable_flag`, `added_date`) VALUES
(1, 'qnnwkldcnk', 'nckdlnlkn', 'nkldnkl', 'nklsknlcn', 0, 1, '2019-04-10 18:46:38'),
(2, 'fd', 'ewfwe', '33333', '9999', 0, 1, '2019-04-11 09:49:01'),
(3, 'xyz', 'xyz', 'xyz', '1234556', 0, 1, '2019-04-11 10:12:34'),
(4, 'global solution', 'AMC', 'amar', '1232456', 0, 0, '2019-04-11 10:38:55'),
(5, 'appdid', 'androod', 'rahul', '99999', 0, 0, '2019-04-11 10:56:51'),
(6, 'ssds', 'fdffd', 'ssff', 'sfffd', 0, 1, '2019-04-16 14:53:27');

-- --------------------------------------------------------

--
-- Table structure for table `customer_query`
--

CREATE TABLE `customer_query` (
  `customer_id` int(11) NOT NULL,
  `ticket_no` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `customer_number` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `dept` int(11) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_query`
--

INSERT INTO `customer_query` (`customer_id`, `ticket_no`, `user_id`, `name`, `customer_name`, `company_name`, `product`, `customer_number`, `description`, `dept`, `flag`, `added_date`) VALUES
(1, '0', 1, '', 'ROhan', '', '', '9967077028', 'ldncnc', 0, 1, '2019-04-10 15:18:38'),
(2, '0', 1, '', 'dcmdc;', '', '', 'mle;mcll;', 'ml;m;mx', 0, 1, '2019-04-10 15:20:41'),
(3, '0', 1, '', 'dmcmk', 'mkmk', '', '8765t543r3r4 ', 'mklmkl', 0, 1, '2019-04-10 15:21:49'),
(4, '0', 1, '', 'dmcmk', 'mkmk', '', '8765t543r3r4 ', 'mklmkl', 0, 1, '2019-04-10 15:23:14'),
(5, '0', 1, '', 'effk`', ' jk ckj k', 'nfn', '98894u92409', ' k', 0, 1, '2019-04-10 15:52:42'),
(6, '0', 1, '', 'lfnlkvn', 'klnklnkl', 'nklnkl', 'nlfknnnk', 'nklnlk', 0, 0, '2019-04-10 15:58:14'),
(7, 'T-nklnkln', 1, '', 'vm;fmq;m;lwm;l`', 'nknklnkl', 'nklnkklnklnnlk', 'nklnkln', 'lknnklkln', 0, 1, '2019-04-10 15:59:03'),
(8, 'T-jnjnj', 2, 'TEch1', 'jnjnjnnj', 'jnjn', 'njnjn', 'jnjnj', 'nnjnjn', 0, 1, '2019-04-11 08:19:43'),
(9, 'T-jnjn', 2, 'TEch1', ',mnjkknkjn', 'lknknk', 'lmnklnk', 'jnjn', 'kjjkij', 0, 1, '2019-04-11 08:20:23'),
(10, 'T-222', 3, 'emp1', 'r', 'fd', 'ffda', '222', 'c', 0, 1, '2019-04-11 09:46:22'),
(11, 'T-123456', 1, 'admin', 'amar', 'global solution', 'AMC', '123456', 'harddisk problem', 0, 1, '2019-04-11 10:45:41'),
(12, 'T-999668', 3, 'emp1', 'rahul', 'appdid', '55', '999668', 'khfghx', 0, 1, '2019-04-12 07:06:42'),
(13, 'T-4544444', 3, 'emp1', 'parvesh', 'ACE', 'AMC', '4544444', 'asffgggggfreer', 0, 1, '2019-04-12 08:39:22'),
(14, 'T-9967856357', 3, 'emp1', 'rahul', 'appdidinfo', 'aaaaaa', '9967856357', 'yrcgvj hg n gjh', 0, 1, '2019-04-12 11:01:41'),
(15, 'T-55555', 3, 'emp1', 'hujb', 'dxgfc', 'rdxf', '55555', 'fdc', 0, 1, '2019-04-12 11:03:00'),
(16, 'T-1111112', 3, 'emp1', 'asd', 'aaaaaa', 'aaaaa', '1111112', 'lkheflteglgtkeet/te', 0, 1, '2019-04-12 14:59:42'),
(17, 'T-444444444', 3, 'emp1', 'wwwww', 'ppppppp', 'sssss', '444444444', 'ewffffffffaaaaaaaa', 0, 1, '2019-04-12 15:00:31'),
(18, 'T-232322323', 7, 'emp2', 'aaaaa', 'llllllllll', 'ppppppppppp', '232322323', 'hhhhhhhhhhhhhhhhhy', 0, 1, '2019-04-12 15:23:10'),
(19, 'T-999999999999', 7, 'emp2', 'eeeeeeeeee', 'iiiiiiiiiiiiiii', 'jjjjjjjjjjjjj', '999999999999', 'ooooooooooooooooooooooooooo', 0, 1, '2019-04-12 15:24:00'),
(20, 'T-5555', 7, 'emp2', 'yyyyyyyy', 'rrrrrrrrrrr', 'tttttttttttt', '5555', 'sdjdglklkjeglerjer', 0, 1, '2019-04-13 04:11:24'),
(21, 'T-1456345', 3, 'emp1', 'yyyyyyyyt', 'power', 'aaaaa', '1456345', 'asdfrt', 0, 1, '2019-04-13 04:16:49'),
(22, 'T-123456999', 3, 'emp1', 'parvesh', 'zxxxcxz', '23kuyt', '123456999', 'xfghghjkjhgfd', 0, 1, '2019-04-13 06:32:33'),
(23, 'T-9999666666', 7, 'emp2', 'amar', '56kjgf', '4lkjhgf', '9999666666', 'fffffffgh', 0, 1, '2019-04-13 06:33:50'),
(24, 'T-456256', 3, 'emp1', 'lll', 'as', 'ppiiuy', '456256', 'hfdrdtyuhlijo;', 0, 1, '2019-04-14 04:26:34'),
(25, 'T-1w', 3, 'TEch1', '1qwertyuio', 'eretyui', '456u7io', '1w', 'asdfghjkl', 0, 1, '2019-04-15 13:28:08'),
(26, 'T-1255663', 3, 'TEch1', 'trtrtrt', 'bnmvd', 'rw6w4', '1255663', 'as436537', 0, 1, '2019-04-16 02:31:20'),
(27, 'T-qwr3a', 3, 'TEch1', 'qreww3', 'Q32TA3Q2', 'QW3A3TQ2', 'qwr3a', '3Q26Y5E9O68P9789P5RSS5TDR', 0, 1, '2019-04-16 04:32:40'),
(28, 'T-96', 3, 'pradeep', 'ih', 'oijh', 'oiuhg', '96', 'kg', 0, 1, '2019-04-19 07:58:56'),
(29, 'T-36363235', 3, 'pradeep', 'parvesh', 'fdgfgjk', 'gfhgk', '36363235', 'kjl', 0, 1, '2019-04-19 11:53:58'),
(30, 'T-xdxdxdd', 3, 'emp1', 'edecde', 'dxdxdx', 'dxdxd', 'xdxdxdd', 'xdxdxdx', 0, 0, '2019-04-23 07:18:12'),
(31, 'T- cx x ', 3, 'admin', 'ecwdc', 'cc c ', 'c c cc ', ' cx x ', 'c c c', 0, 0, '2019-04-23 07:23:58'),
(32, 'T-12345', 3, 'TEch1', 'global', 'globalee', 'wergrh', '12345', 'err4hyu', 0, 1, '2019-04-25 07:30:51');

-- --------------------------------------------------------

--
-- Table structure for table `emp_leave`
--

CREATE TABLE `emp_leave` (
  `leave_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0',
  `disable_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_leave`
--

INSERT INTO `emp_leave` (`leave_id`, `user_id`, `user_name`, `from_date`, `to_date`, `reason`, `flag`, `disable_flag`) VALUES
(1, 3, 'emp1 ', '17-04-2019', '19-04-2019', 'CL', 2, 0),
(2, 3, 'emp1 ', '16-04-2019', '24-04-2019', 'SL', 1, 0),
(3, 1, 'admin ', '17-04-2019', '19-04-2019', 'SL', 0, 1),
(4, 3, 'emp1 ', '13-04-2019', '15-04-2019', 'other', 1, 0),
(5, 3, 'emp1 ', '12-04-2019', '19-04-2019', 'other', 2, 0),
(6, 3, 'emp1 ', '12-04-2019', '17-04-2019', 'SL', 1, 0),
(7, 2, 'TEch1 ', '12-04-2019', '13-04-2019', 'other', 2, 0),
(8, 5, 'parvesh ', '12-04-2019', '30-04-2019', 'SL', 1, 0),
(9, 2, 'TEch1 ', '17-04-2019', '26-04-2019', 'other', 1, 0),
(10, 3, 'emp1 ', '20-04-2019', '23-04-2019', 'CL', 1, 0),
(11, 3, 'emp1 ', '19-04-2019', '20-04-2019', 'SL', 1, 0),
(12, 6, 'pradeep ', '13-04-2019', '27-04-2019', 'SL', 1, 0),
(13, 2, 'TEch1 ', '03-12-2018', '27-04-2019', 'SL', 0, 1),
(14, 8, 'parvesh ', '26-09-2019', '28-09-2019', 'SL', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `heena_health_user_register`
--

CREATE TABLE `heena_health_user_register` (
  `user_id` int(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email_id` varchar(255) NOT NULL,
  `encrypted_password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `KC_Students`
--

CREATE TABLE `KC_Students` (
  `student_id` int(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `student_div` varchar(255) NOT NULL,
  `student_roll_no` varchar(255) NOT NULL,
  `student_mobile_no` varchar(255) NOT NULL,
  `student_parent_mobile_no` varchar(255) NOT NULL,
  `student_year` varchar(255) NOT NULL,
  `student_course` varchar(255) NOT NULL,
  `student_present` int(255) NOT NULL,
  `student_absent` int(255) NOT NULL,
  `student_count_absent` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `KC_Students`
--

INSERT INTO `KC_Students` (`student_id`, `student_name`, `student_div`, `student_roll_no`, `student_mobile_no`, `student_parent_mobile_no`, `student_year`, `student_course`, `student_present`, `student_absent`, `student_count_absent`) VALUES
(1, 'Darshan Komu', 'A', '10', '8652453473', '8652453473', 'B.E', 'Comps', 1, 1, 0),
(3, 'Rahul Yadav', 'B', '11', '8652453493', '8652453473', 'B.E', 'Comps', 0, 0, 1),
(4, 'Ajay', 'A', '12', '1234567890', '8652453473', 'B.E', 'Comps', 1, 0, 0),
(5, 'Sumit', 'A', '1', '123456789', '8652453473', 'B.E', 'Comps', 0, 0, 1),
(6, 'Shri', 'A', '12', '1234567890', '8652453473', 'B.E', 'Comps', 1, 0, 0),
(7, 'Deepak', 'A', '1', '123456789', '8652453473', 'B.E', 'Comps', 0, 0, 1),
(8, 'Madar Sir', 'A', '100', '9970626178', '8652453473', 'B.E', 'Comps', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lecturerinfo`
--

CREATE TABLE `lecturerinfo` (
  `_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `lecturerId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturerinfo`
--

INSERT INTO `lecturerinfo` (`_id`, `name`, `lecturerId`) VALUES
(1, 'Kristof Cools', 1),
(2, 'Nothofer Angela', 2),
(3, 'Phil Sewell', 3),
(4, 'James Bonnyman', 4),
(5, 'Alessandro Costabeber', 5),
(6, 'John Crowe', 6),
(7, 'Steve Sharples', 7);

-- --------------------------------------------------------

--
-- Table structure for table `lecturermodule`
--

CREATE TABLE `lecturermodule` (
  `_id` int(11) NOT NULL,
  `Lecturer_id` int(11) NOT NULL,
  `Module_id` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturermodule`
--

INSERT INTO `lecturermodule` (`_id`, `Lecturer_id`, `Module_id`) VALUES
(1, 1, 'MA0001'),
(4, 1, 'H63JAV-1'),
(6, 3, 'H63ESD'),
(7, 4, 'TEL001'),
(8, 6, 'H63BPE-1'),
(9, 6, 'H63BPE-2'),
(10, 1, 'JAV001'),
(12, 4, 'TLC001'),
(13, 2, 'JAP001'),
(14, 1, 'H63JAV-2');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer_users`
--

CREATE TABLE `lecturer_users` (
  `_id` int(11) NOT NULL,
  `unique_id` varchar(23) NOT NULL,
  `name` varchar(50) NOT NULL,
  `lecturer_id` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `encrypted_password` varchar(256) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lecturer_users`
--

INSERT INTO `lecturer_users` (`_id`, `unique_id`, `name`, `lecturer_id`, `email`, `encrypted_password`, `salt`, `created_at`) VALUES
(1, '58f7a32aec0639.73079853', 'Kristof Cools', 1, 'kristof@cools.com', '$2y$10$hMNkFGUAc8wvzBav17OXJeAbS4QydB4sEbYb3tJEjcv12BJeDsmaG', '13e145006c', '2017-04-19 17:49:31'),
(2, '58f8b6c3e32bc1.60752956', 'Nothofer Angela', 2, 'nothofer@angela.com', '$2y$10$sop1vU6CnzaSLyQFpR09vuC6CfJ5UsRykkrMjrp2Z1x/HjdA5jsaW', '68fb45ba39', '2017-04-20 13:25:24'),
(3, '58f8b71b8dd114.54569734', 'Phil Sewell', 3, 'phil@sewell.com', '$2y$10$Phnp3M36lm2HfzjfPvEAN.Oiw9Jc7MFVlpyULf9WIvR9kXp2kPUAy', '888b6c6734', '2017-04-20 13:26:51'),
(4, '58f8b733ab1410.95755606', 'James Bonnyman', 4, 'james@bonnyman.com', '$2y$10$UStja5R4FfHHKDY9t4cPeeECRgx.XLMTXbafN2bDyO1vb5ffLj7Aq', '6c121e87b9', '2017-04-20 13:27:15'),
(5, '58f8b750d89df6.97184707', 'Allessandro Coastabeber', 5, 'allessandro@coastabeber.com', '$2y$10$3Ql5fLvqu.wjr4tUOHJlwunah6xR11AhppAWR.cwx3jgVqLXZJAoS', '90a67105b0', '2017-04-20 13:27:44'),
(6, '58f8b764aa7e50.31910209', 'John Crowe', 6, 'john@crowe.com', '$2y$10$ZN0SRsAMAuij7sg9tiPu.uUe0CSmYYMJVWivWVsVqbDOacDA3LsdK', 'db251c3515', '2017-04-20 13:28:04'),
(7, '58f8b777ed9b13.76815159', 'Steve Sharples', 7, 'steve@sharples.com', '$2y$10$MF4n8cAMdqIQ55vwYhCnNuE8PlL47PIG2O.cBHuiiXAdy9do6LvFG', '2549ed2779', '2017-04-20 13:28:24');

-- --------------------------------------------------------

--
-- Table structure for table `moduleinfo`
--

CREATE TABLE `moduleinfo` (
  `_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `moduleId` varchar(8) NOT NULL,
  `startDate` datetime DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `checkInStart` datetime DEFAULT NULL,
  `checkInEnd` datetime DEFAULT NULL,
  `room` text NOT NULL,
  `LocLat` double DEFAULT NULL,
  `LocLng` double NOT NULL,
  `ModStatus` text NOT NULL,
  `Day` varchar(3) NOT NULL,
  `Lecturer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `moduleinfo`
--

INSERT INTO `moduleinfo` (`_id`, `name`, `moduleId`, `startDate`, `endDate`, `checkInStart`, `checkInEnd`, `room`, `LocLat`, `LocLng`, `ModStatus`, `Day`, `Lecturer`) VALUES
(1, 'Mathematic for super cool engineer ', 'MA0001', '2017-01-15 09:40:00', '2018-07-17 12:44:00', '2017-04-16 09:38:00', '2017-04-16 09:42:00', 'Coates', 52.94119, -1.189594, 'inactive', 'Sat', 'Kristof Cools'),
(2, 'Interview', 'JAV001', '2017-01-16 09:40:00', '2018-07-17 10:40:00', '2017-04-16 09:39:00', '2017-04-16 10:21:00', 'Charnwood Building', 52.758847, -1.246605, 'inactive', 'Wed', 'Kristof Cools'),
(3, 'JAPAN', 'JAP001', '2017-01-17 08:36:00', '2018-07-17 08:43:00', '2017-04-16 08:35:00', '2017-04-16 08:37:00', 'Portland', 51.513613, -0.136499, 'inactive', 'Mon', 'Nothofer Angela'),
(4, 'PHP', 'PHP001', '2017-01-18 00:00:00', '2018-07-17 00:00:00', '2017-04-16 08:45:00', '2017-04-16 09:15:00', 'Tower Building', 52.942368, -1.188579, 'inactive', 'Mon', 'Phil Sewell'),
(6, 'TeleElec', 'TLC001', '2017-01-01 20:47:00', '2018-07-17 22:58:00', '2017-04-16 20:20:00', '2017-04-16 22:57:00', 'Coates', 52.94119, -1.188579, 'inactive', 'Tue', 'James Bonnyman'),
(7, 'Telecom2', 'TEL001', '2017-01-01 20:25:00', '2018-07-17 21:42:00', '2017-04-16 20:20:00', '2017-04-09 21:40:00', 'Coates', 52.94119, -1.189594, 'inactive', 'Fri', 'Alessandro Costabeber'),
(27, 'Web Based Computing', 'H63JAV-2', '2017-02-01 23:13:00', '2018-07-17 23:15:00', '2017-04-17 23:12:00', '2017-04-17 23:14:00', 'ESLC-B14', 52.941475, -1.189167, 'inactive', 'Wed', 'Kristof Cools'),
(28, 'Web Based Computing', 'H63JAV-1', '2017-02-01 09:00:00', '2018-07-17 11:00:00', '2017-04-17 09:08:00', '2017-04-17 09:15:00', 'Tower Building 308', 52.942368, -1.188579, 'inactive', 'Mon', 'Kristof Cools'),
(29, 'Business Planning for engineers', 'H63BPE-1', '2017-02-01 12:00:00', '2018-07-17 13:00:00', '2017-04-17 11:45:00', '2017-04-17 12:15:00', 'Tower Building 203', 52.942368, -1.188579, 'inactive', 'Mon', 'John Crowe'),
(30, 'Business Planning for Engineers', 'H63BPE-2', '2017-02-01 12:00:00', '2018-07-17 17:30:00', '2017-04-17 11:45:00', '2017-04-17 12:15:00', 'POPE C17', 52.941032, -1.190089, 'inactive', 'Wed', 'John Crowe'),
(31, 'Telecommunication Electronics', 'H63TCE', '2017-02-01 09:00:00', '2018-07-17 11:00:00', '2017-04-17 08:45:00', '2017-04-17 09:15:00', 'Tower Building 203', 52.942368, -1.188579, 'inactive', 'Tue', 'Steve Sharples'),
(32, 'Engineering Software: Design and Implementation', 'H63ESD', '2017-02-01 00:25:00', '2018-07-17 17:30:00', '2017-04-17 01:23:00', '2017-04-17 17:27:00', 'PSYC-A16', 52.939483, -1.189159, 'inactive', 'Fri', 'Phil Sewell');

-- --------------------------------------------------------

--
-- Table structure for table `service_center`
--

CREATE TABLE `service_center` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `locality` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `type_of_load` varchar(100) NOT NULL,
  `date_of_service` varchar(100) NOT NULL,
  `time_of_service` varchar(100) NOT NULL,
  `date_on_server` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_center`
--

INSERT INTO `service_center` (`id`, `name`, `address`, `locality`, `mobile`, `type`, `type_of_load`, `date_of_service`, `time_of_service`, `date_on_server`) VALUES
(17, 'Dayanand Patil', 'Panvel', 'panvel', '9561370921', 'Office', 'Top Load', '28-11-2019', '11 A.M', '2019-11-04 17:10:50'),
(14, 'darshan', 'thane', 'Mumbai', '8652453473', 'Office', 'Front Load', '04-11-2019', '3 P.M', '2019-11-04 09:48:00'),
(15, 'Dayanand Patil', 'hahah', 'aghaa', '5555555555', 'Home', 'Top Load', '14-11-2019', '3 P.M', '2019-11-04 10:15:42'),
(16, 'fff', 'ggh', 'gg', '555555', 'Home', 'Top Load', '22-11-2019', '9 A.M', '2019-11-04 10:18:39');

-- --------------------------------------------------------

--
-- Table structure for table `studentinfo`
--

CREATE TABLE `studentinfo` (
  `_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `student_id` int(11) NOT NULL,
  `course` text NOT NULL,
  `AVG` int(11) NOT NULL,
  `AttendanceStatus` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentinfo`
--

INSERT INTO `studentinfo` (`_id`, `name`, `student_id`, `course`, `AVG`, `AttendanceStatus`) VALUES
(1, 'JOHN DOE', 1, 'Electrical and Electronic Engineering', 70, 'end'),
(2, 'HARRY POTTER', 2, 'Electronic and Computer Engineering', 60, 'end'),
(3, 'ROWAN ATKINSON', 3, 'Electrical Engineering', 50, 'end'),
(4, 'TONY STARK', 4, 'Electrical Engineering', 90, 'end'),
(5, 'TANIN ROJANAPIANSATITH', 4256422, 'Electronic and computer Engineering', 100, 'end');

-- --------------------------------------------------------

--
-- Table structure for table `studentmodule`
--

CREATE TABLE `studentmodule` (
  `_id` int(11) NOT NULL,
  `Student_id` int(11) NOT NULL,
  `Module_id` varchar(8) NOT NULL,
  `status` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentmodule`
--

INSERT INTO `studentmodule` (`_id`, `Student_id`, `Module_id`, `status`) VALUES
(2, 1, 'JAV001', 'checked'),
(7, 3, 'JAP001', 'end'),
(8, 3, 'PHP001', 'end'),
(9, 4, 'PHP001', 'end'),
(10, 4, 'TLC001', 'end'),
(11, 1, 'TEL001', 'end'),
(12, 1, 'TLC001', 'end'),
(13, 1, 'JAP001', 'end'),
(15, 4256422, 'H63JAV-1', 'end'),
(16, 4256422, 'H63JAV-2', 'end'),
(17, 4256422, 'H63BPE-1', 'end'),
(18, 4256422, 'H63BPE-2', 'end'),
(19, 4256422, 'H63TCE', 'end'),
(20, 4256422, 'H63ESD', 'end'),
(23, 4, 'JAV001', 'checked'),
(28, 3, 'MA0001', 'end'),
(29, 2, 'MA0001', 'end'),
(30, 2, 'MA0001', 'end'),
(31, 3, 'MA0001', 'end'),
(32, 3, 'JAV001', 'end'),
(33, 2, 'JAV001', 'end'),
(34, 2, 'JAV001', 'end'),
(35, 3, 'JAV001', 'end'),
(37, 4256422, 'H63JAV-2', 'end'),
(43, 1, 'MA0001', 'end'),
(44, 4, 'TEL001', 'end'),
(45, 4, 'JAP001', 'end'),
(46, 1, 'H63JAV-2', 'end'),
(47, 4, 'H63JAV-2', 'end'),
(49, 4, 'JAV001', 'checked'),
(50, 4, 'JAV001', 'checked');

-- --------------------------------------------------------

--
-- Table structure for table `student_users`
--

CREATE TABLE `student_users` (
  `_id` int(11) NOT NULL,
  `unique_id` varchar(23) NOT NULL,
  `name` varchar(50) NOT NULL,
  `student_id` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `encrypted_password` varchar(256) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_users`
--

INSERT INTO `student_users` (`_id`, `unique_id`, `name`, `student_id`, `email`, `encrypted_password`, `salt`, `created_at`) VALUES
(1, '58efcae56c9470.34410783', 'JOHN DOE', 1, 'johndoe@johndoe.com', '$2y$10$MPrAg8l0yy5f0CVdasce5uKMGkyC5vXnngbNPOr.33uyNnzgOUBhS', '52b585a964', '2017-04-13 19:00:53'),
(2, '58efcb5a559fd2.30550164', 'HARRY POTTER', 2, 'harrypotter@harrypotter.com', '$2y$10$noxZuxEGvO0be0MdFdSv8OPSFJRm/EyVx/f4.ubLhSTlAkZpEcZrG', '308d4cab2a', '2017-04-13 19:02:50'),
(3, '58efcc919792f0.67099008', 'ROWAN ATKINSON', 3, 'rowanatkinson@rowanatkinson.com', '$2y$10$x.AxYRgQzzful.nmExU4wuy5AXR1DMaTTFOtbx1DYW2XqAzFTZYCu', '4ba1ae84f1', '2017-04-13 19:08:01'),
(4, '58efccdedc3144.58297441', 'TONY STARK', 4, 'tonystark@tonystark.com', '$2y$10$0zp7rakUtqWaInyLhJbayeuNy5NBHQTRdYN87V/vQcykeCIgjyHXe', '0debd212ae', '2017-04-13 19:09:18'),
(6, '58efcf0fdb88c6.75771560', 'TANIN ROJANAPIANSATITH', 4256422, 'eeytr1@nottingham.ac.uk', '$2y$10$Cb0JMNx5zM8WTWxR3TyLtuD3z7zy66ztSsag28WJ2YZcxARK4xkN6', '8bb7a88899', '2017-04-13 19:18:39'),
(7, '58fa1f030d0ba8.65547168', 'WILSON', 5, 'wilson@wilson.com', '$2y$10$sTmavAYoQCKNI34EWBvwbOxwH7l/Pt5K0UPF3pzunkNY1MCnJAwDi', 'fcd30a93b0', '2017-04-21 15:02:27'),
(8, '5900dda3a3bff6.78741164', 'no salt', 6, 'nosalt@nosalt.com', '$2y$10$TS5llQ9TH2bkzdv5q1693uRb/qfjzOFhRD8I0ehnyJi.YyCC9sooe', '9b4c5d4065', '2017-04-26 17:49:23'),
(9, '5900de9b95c616.64264107', 'only hash, no salt', 7, 'onlyhash@nosalt.com', '$2y$10$NMm9Jti82VaIOiXGuT.mDuAoTCu8A9hWVrsiUPqIkCgiOQAOwc8fW', '51186d95fd', '2017-04-26 17:53:31'),
(10, '5900df8d61ffe9.39094541', 'HASH WITH NO SALT', 8, 'hashwithnosalt@nosalt.com', '$2y$10$MRljBfiHeOAG2EmZzGCEB.fRjzhHEQo7toIR/E1cVo.x3m98FGedK', 'e69abe545d', '2017-04-26 17:57:33'),
(11, '5900e00edc29e3.23316944', 'HASH WITH NO SALT2', 9, 'hashwithnosalt2@nosalt.com', '$2y$10$nkTfji9c4KddNAxh8brrneSeYADAb3Uid2VTs1iYpuoavyjPVaI2y', 'f9eb2f030b', '2017-04-26 17:59:42'),
(12, '5900e046889487.52708045', 'HASH WITH SALT', 10, 'hashwithsalt@nosalt.com', '$2y$10$o08j4hI79pTDEOd6wFOtPutysCMSGNRdmrpNvRvglFapGUL5VXcZu', '08a48a2f86', '2017-04-26 18:00:38'),
(13, '5900e4096eb659.05031566', 'no salt', 11, 'cryptnosalt@nosalt.com', '$1$80Dlr6Zx$V54s6AgYjHA5QU3BXvDkx0', 'f71e89d375', '2017-04-26 18:16:41'),
(14, '5900e4d217e914.03976400', 'no salt', 12, 'md5nosalt@nosalt.com', '4f4e04a5f8ffded8609f0dd98c39ce3c', '607910b985', '2017-04-26 18:20:02');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `username` varchar(55) DEFAULT NULL,
  `userpassword` varchar(55) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `username`, `userpassword`) VALUES
(1, 'admin', 'admin24');

-- --------------------------------------------------------

--
-- Table structure for table `track_attendance`
--

CREATE TABLE `track_attendance` (
  `a_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attendance_time` time NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_number` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `active_deactive_flag` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `user_number`, `email_id`, `username`, `password`, `user_address`, `user_role`, `active_deactive_flag`, `disable_flag`, `added_date`) VALUES
(1, 'admin', '', '', 'admin', '12345', '', 'admin', 0, 0, '2019-04-10 14:37:57'),
(2, 'TEch1', '', '', 'tech1', '12345', '', 'technician', 0, 0, '2019-04-10 14:38:33'),
(3, 'emp1', '', '', 'emp1', '12345', '', 'employee', 0, 0, '2019-04-10 14:39:12'),
(4, 'dncskjdj', '9967077027', '', 'qwerty', '12345', '', 'employee', 1, 1, '2019-04-11 04:03:54'),
(5, 'parvesh', '1223344', '', 'parvesh', '12345', '', 'technician', 0, 1, '2019-04-11 13:08:22'),
(6, 'pradeep', '11111111', '', 'pradeep_yadav', 'pradeep@123', '', 'technician', 0, 0, '2019-04-12 14:50:19'),
(7, 'emp2', '44444444', '', 'emp4', '12345', '', 'employee', 1, 0, '2019-04-12 15:20:12'),
(8, 'parvesh', '1223344', '', 'parvesh', '12345', '', 'technician', 0, 0, '2019-04-16 14:17:47'),
(9, 'Rohan Naik', '9967077027', '', 'rohan', '12345', '', 'technician', 1, 0, '2019-04-19 05:18:58'),
(10, '', '', '', '', '', '', 'employee', 0, 1, '2019-04-19 11:56:27'),
(11, '', '', '', '', '', '', 'technician', 0, 1, '2019-04-19 11:56:58'),
(12, '', '', '', '', '', '', 'employee', 0, 1, '2019-04-19 14:04:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance1`
--
ALTER TABLE `attendance1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance2`
--
ALTER TABLE `attendance2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance3`
--
ALTER TABLE `attendance3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance4`
--
ALTER TABLE `attendance4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance5`
--
ALTER TABLE `attendance5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `customer_query`
--
ALTER TABLE `customer_query`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `emp_leave`
--
ALTER TABLE `emp_leave`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `heena_health_user_register`
--
ALTER TABLE `heena_health_user_register`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `KC_Students`
--
ALTER TABLE `KC_Students`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `lecturerinfo`
--
ALTER TABLE `lecturerinfo`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `lecturerId` (`lecturerId`);

--
-- Indexes for table `lecturermodule`
--
ALTER TABLE `lecturermodule`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `Lecturer_id` (`Lecturer_id`),
  ADD KEY `Module_id` (`Module_id`);

--
-- Indexes for table `lecturer_users`
--
ALTER TABLE `lecturer_users`
  ADD PRIMARY KEY (`_id`);

--
-- Indexes for table `moduleinfo`
--
ALTER TABLE `moduleinfo`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `_id` (`_id`),
  ADD KEY `moduleId` (`moduleId`),
  ADD KEY `moduleId_2` (`moduleId`);

--
-- Indexes for table `service_center`
--
ALTER TABLE `service_center`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentinfo`
--
ALTER TABLE `studentinfo`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `studentId` (`student_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `studentmodule`
--
ALTER TABLE `studentmodule`
  ADD PRIMARY KEY (`_id`),
  ADD KEY `Student_id` (`Student_id`),
  ADD KEY `Module_id` (`Module_id`),
  ADD KEY `Module_id_2` (`Module_id`);

--
-- Indexes for table `student_users`
--
ALTER TABLE `student_users`
  ADD PRIMARY KEY (`_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track_attendance`
--
ALTER TABLE `track_attendance`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `attendance1`
--
ALTER TABLE `attendance1`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance2`
--
ALTER TABLE `attendance2`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `attendance3`
--
ALTER TABLE `attendance3`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance4`
--
ALTER TABLE `attendance4`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance5`
--
ALTER TABLE `attendance5`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_query`
--
ALTER TABLE `customer_query`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `emp_leave`
--
ALTER TABLE `emp_leave`
  MODIFY `leave_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `heena_health_user_register`
--
ALTER TABLE `heena_health_user_register`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `KC_Students`
--
ALTER TABLE `KC_Students`
  MODIFY `student_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lecturerinfo`
--
ALTER TABLE `lecturerinfo`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lecturermodule`
--
ALTER TABLE `lecturermodule`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `lecturer_users`
--
ALTER TABLE `lecturer_users`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `moduleinfo`
--
ALTER TABLE `moduleinfo`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `service_center`
--
ALTER TABLE `service_center`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `studentinfo`
--
ALTER TABLE `studentinfo`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `studentmodule`
--
ALTER TABLE `studentmodule`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `student_users`
--
ALTER TABLE `student_users`
  MODIFY `_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `track_attendance`
--
ALTER TABLE `track_attendance`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lecturermodule`
--
ALTER TABLE `lecturermodule`
  ADD CONSTRAINT `LM_lecturer_fk` FOREIGN KEY (`Lecturer_id`) REFERENCES `lecturerinfo` (`lecturerId`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `LM_module_fk` FOREIGN KEY (`Module_id`) REFERENCES `moduleinfo` (`moduleId`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `studentmodule`
--
ALTER TABLE `studentmodule`
  ADD CONSTRAINT `SM_module_fk` FOREIGN KEY (`Module_id`) REFERENCES `moduleinfo` (`moduleId`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `SM_student_fk` FOREIGN KEY (`Student_id`) REFERENCES `studentinfo` (`student_id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
