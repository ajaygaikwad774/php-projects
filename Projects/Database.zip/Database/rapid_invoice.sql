-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 12, 2019 at 03:25 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rapid_invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `town` varchar(255) NOT NULL,
  `county` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `name_ship` varchar(255) NOT NULL,
  `address_1_ship` varchar(255) NOT NULL,
  `address_2_ship` varchar(255) NOT NULL,
  `town_ship` varchar(255) NOT NULL,
  `county_ship` varchar(255) NOT NULL,
  `postcode_ship` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `invoice`, `name`, `email`, `address_1`, `address_2`, `town`, `county`, `postcode`, `phone`, `name_ship`, `address_1_ship`, `address_2_ship`, `town_ship`, `county_ship`, `postcode_ship`) VALUES
(1, '1', 'rahul', 'rahulyadav1598@gmail.com', 'sakinaka', '', 'mumbai', 'GSTIN2010291', '400072', '09967856357', '', '', '', '', '', ''),
(2, '2', 'vicky jha', 'iamvickyjha@gmail.com', 'vashi', '', 'mumbai', 'OKGSTNO', '400703', '9768825774', '', '', '', '', '', ''),
(3, '3', 'DARSAHN jha', 'rahulyadav1598@gmail.com', 'vashi', 'sakinkaa', 'mumbai', 'Maharashtra', '400703', '09967856357', '', '', '', '', '', ''),
(4, '4', 'rahul', 'rahulyadav1598@gmail.com', 'sakinaka', '', 'mumbai', 'GSTIN2010291', '400072', '09967856357', '', '', '', '', '', ''),
(5, '5', 'DARSAHN jha', 'iamvickyjha@gmail.com', 'vashi', '', 'sakinkaa', 'OOOKKK', '400703', '9768825774', '', '', '', '', '', ''),
(6, '6', 'rahul', 'rahulyadav1598@gmail.com', 'sakinaka', 'sakinkaa', 'mumbai', 'GSTIN2010291', '400072', '09967856357', '', '', '', '', '', ''),
(7, '7', 'Darshan', 'darsh@gmaill.com', '505, Namdev Nagar, Digha, ', 'Thane Belapur Road, Navi Mumbai', 'Navi Mumbai', 'PKPKPKLPKLL', '400708', '08652453473', '', '', '', '', '', ''),
(8, '8', 'Darshan', 'darsh@gmaill.com', '505, Namdev Nagar, Digha, ', 'Thane Belapur Road, Navi Mumbai', 'Navi Mumbai', 'PKPKPKLPKLL', '400708', '08652453473', '', '', '', '', '', ''),
(9, '9', 'rahul', 'rahulyadav1598@gmail.com', 'sakinaka', 'sakinkaa', 'mumbai', 'GSTIN2010291', '400072', '09967856357', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `dealer`
--

CREATE TABLE `dealer` (
  `d_id` int(11) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `d_address` varchar(255) NOT NULL,
  `d_email` varchar(255) NOT NULL,
  `d_mobile` varchar(255) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealer`
--

INSERT INTO `dealer` (`d_id`, `d_name`, `d_address`, `d_email`, `d_mobile`, `p_name`, `disable_flag`, `added_date`) VALUES
(1, 'Saurabh', 'sakinaka, sakinkaa', 'rahulyadav1598@gmail.com', '09967856357', 'Bislery - 20Liter', 0, '07/10/2019'),
(2, '', '', '', '', 'Bislery - 20Liter', 0, '07/10/2019');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `invoice` int(11) NOT NULL,
  `custom_email` text NOT NULL,
  `invoice_date` varchar(255) NOT NULL,
  `invoice_due_date` varchar(255) NOT NULL,
  `subtotal` decimal(10,0) NOT NULL,
  `shipping` decimal(10,0) NOT NULL,
  `discount` decimal(10,0) NOT NULL,
  `vat` decimal(10,0) NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `notes` text NOT NULL,
  `invoice_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `invoice`, `custom_email`, `invoice_date`, `invoice_due_date`, `subtotal`, `shipping`, `discount`, `vat`, `total`, `notes`, `invoice_type`, `status`) VALUES
(1, 1, '', '07/10/2019', '08/10/2019', '500', '0', '0', '90', '590', '', 'invoice', ''),
(2, 2, '', '06/10/2019', '09/10/2019', '500', '0', '0', '0', '500', '', 'invoice', ''),
(3, 3, '', '07/10/2019', '08/10/2019', '150', '0', '0', '27', '177', '', 'invoice', ''),
(4, 4, '', '06/10/2019', '08/10/2019', '50', '0', '0', '9', '59', '', 'invoice', ''),
(5, 5, '', '07/10/2019', '07/10/2019', '100', '0', '0', '18', '118', '', 'invoice', ''),
(6, 6, '', '07/10/2019', '07/10/2019', '50', '0', '0', '9', '59', '', 'invoice', ''),
(7, 7, '', '07/10/2019', '07/10/2019', '50', '0', '0', '9', '59', '', 'invoice', ''),
(8, 8, '', '27/10/2019', '30/10/2019', '1000', '0', '0', '180', '1180', '', 'invoice', ''),
(9, 9, '', '09/11/2019', '10/11/2019', '50', '0', '0', '9', '59', '', 'invoice', '');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `product` text NOT NULL,
  `qty` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `subtotal` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice`, `product`, `qty`, `price`, `discount`, `subtotal`) VALUES
(1, '1', 'Bislery - 20Liter', 10, '50', '', '500.00'),
(2, '2', 'Bislery - 20Liter', 10, '50', '', '500.00'),
(3, '3', 'Bislery - 50Liter', 1, '100', '', '100.00'),
(4, '3', 'Bislery - 20Liter', 1, '50', '', '50.00'),
(5, '4', 'Bislery - 20Liter', 1, '50', '', '50.00'),
(6, '5', 'Bislery - 50Liter', 1, '100', '', '100.00'),
(7, '6', 'Bislery - 20Liter', 1, '50', '', '50.00'),
(8, '7', 'Bislery - 20Liter', 1, '50', '', '50.00'),
(9, '8', 'Bislery - 100', 1, '1000', '', '1000.00'),
(10, '9', 'Bislery - 20Liter', 1, '50', '', '50.00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` text NOT NULL,
  `product_desc` text NOT NULL,
  `product_price` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_desc`, `product_price`) VALUES
(1, 'Bislery', '20Liter', '50'),
(2, 'Bislery', '50Liter', '100'),
(3, 'Bislery', '100', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE `purchase_order` (
  `p_id` int(11) NOT NULL,
  `d_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `prod_desc` varchar(255) NOT NULL,
  `buy_price` int(11) NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `disabled_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`p_id`, `d_id`, `product_name`, `prod_desc`, `buy_price`, `p_quantity`, `total_amount`, `disabled_flag`, `added_date`) VALUES
(1, 1, 'Bislery - 20Liter', '', 50, 100, 5000, 0, '07/10/2019'),
(2, 1, 'Bislery - 20Liter', '', 50, 200, 10000, 0, '07/10/2019'),
(3, 2, 'Bislery - 20Liter', '', 50, 100, 5000, 0, '07/10/2019'),
(4, 2, 'Bislery - 20Liter', '', 50, 200, 10000, 0, '07/10/2019'),
(5, 1, 'Bislery - 50Liter', '', 100, 500, 50000, 0, '07/10/2019'),
(6, 1, 'Bislery - 20Liter', '', 0, 0, 0, 0, '07/10/2019'),
(7, 1, 'Bislery - 100', '', 50, 100, 5000, 0, '27/10/2019');

-- --------------------------------------------------------

--
-- Table structure for table `store_customers`
--

CREATE TABLE `store_customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `town` varchar(255) NOT NULL,
  `county` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `gst_no` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_customers`
--

INSERT INTO `store_customers` (`id`, `name`, `email`, `address_1`, `address_2`, `town`, `county`, `postcode`, `phone`, `gst_no`) VALUES
(1, 'rahul', 'rahulyadav1598@gmail.com', 'sakinaka', 'sakinkaa', 'mumbai', '', '400072', '09967856357', 'GSTIN2010291'),
(2, 'vicky jha', 'iamvickyjha@gmail.com', 'vashi', 'RAILWAY ', 'mumbai', '', '400703', '9768825774', 'OKGSTNO'),
(3, 'DARSAHN jha', 'iamvickyjha@gmail.com', 'vashi', 'sakinkaa', 'mumbai', '', '400703', '9768825774', 'OOOKKK'),
(4, 'Darshan', 'darsh@gmaill.com', '505, Namdev Nagar, Digha, ', 'Thane Belapur Road, Navi Mumbai', 'Navi Mumbai', '', '400708', '08652453473', 'PKPKPKLPKLL');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `phone`, `password`) VALUES
(1, 'Abhi Raj', 'admin', 'admin@abhishekraj.info', '', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer`
--
ALTER TABLE `dealer`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `store_customers`
--
ALTER TABLE `store_customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dealer`
--
ALTER TABLE `dealer`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `store_customers`
--
ALTER TABLE `store_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
