-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 12, 2019 at 01:21 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomytra`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `CONTENT` text NOT NULL,
  `PHOTO` text NOT NULL,
  `CATEGORY` int(11) NOT NULL DEFAULT '0',
  `CREATE_DATE` varchar(50) NOT NULL,
  `ISENABLED` varchar(20) NOT NULL DEFAULT 'true'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`ID`, `TITLE`, `CONTENT`, `PHOTO`, `CATEGORY`, `CREATE_DATE`, `ISENABLED`) VALUES
(10, 'Lorem Ipsum', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'admin/uploads/posts/24102019024739article-1.jpg', 4, '24-10-2019', 'true'),
(11, 'Lorem Ipsum Dolor', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'admin/uploads/posts/24102019024759article-1.jpg', 5, '24-10-2019', 'true'),
(12, 'Lorem Ipsum Dolor Sit Amet', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'admin/uploads/posts/24102019032121recipes.jpg', 0, '24-10-2019', 'false'),
(13, 'Lorem Ipsum Dolor Sit', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'admin/uploads/posts/24102019032425article-1.jpg', 4, '24-10-2019', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `IMAGE` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `TITLE`, `IMAGE`) VALUES
(0, 'No Category', ''),
(4, 'Informative Blogs', 'admin/uploads/categories/24102019024132banner-1.jpg'),
(5, 'Recipe', 'admin/uploads/categories/24102019024154article-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `catpromobanner`
--

CREATE TABLE `catpromobanner` (
  `ID` int(11) NOT NULL,
  `PRODUCTCAT` int(11) NOT NULL,
  `IMAGE` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `catpromobanner`
--

INSERT INTO `catpromobanner` (`ID`, `PRODUCTCAT`, `IMAGE`) VALUES
(3, 16, 'admin/uploads/banners/24102019031652discount.png'),
(4, 17, 'admin/uploads/banners/24102019031725landscape-1466718212-delish-lemonade-cheatsheet-index.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `ID` int(11) NOT NULL,
  `USER` int(11) NOT NULL,
  `PRODUCT` int(11) NOT NULL,
  `COMMENT` text NOT NULL,
  `STARS` varchar(5) NOT NULL DEFAULT '3',
  `DATE` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`ID`, `USER`, `PRODUCT`, `COMMENT`, `STARS`, `DATE`) VALUES
(1, 12, 24, 'NICE :D', '3', '13-11-2019');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ID` int(11) NOT NULL,
  `PHONE1` varchar(255) NOT NULL DEFAULT '',
  `PHONE2` varchar(255) NOT NULL DEFAULT '',
  `EMAIL1` varchar(255) NOT NULL DEFAULT '',
  `EMAIL2` varchar(255) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL DEFAULT '',
  `GOOGLEMAPS` varchar(800) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `PHONE1`, `PHONE2`, `EMAIL1`, `EMAIL2`, `ADDRESS`, `GOOGLEMAPS`) VALUES
(3, '+919090909090', '+918888888888', 'admin@gmail.com', 'contact@gmail.com', 'Lorem ipsum,\r\nDolor Sit,\r\nAmet - 111 111', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d482634.69489416416!2d72.60097763955191!3d19.082039053861898!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1571885530525!5m2!1sen!2sin\" width=\"100%\" height=\"350\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\"></iframe>');

-- --------------------------------------------------------

--
-- Table structure for table `contactform`
--

CREATE TABLE `contactform` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CONTACT` varchar(255) NOT NULL,
  `MESSAGE` varchar(500) NOT NULL,
  `CREATE_DATE` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dealoftheday`
--

CREATE TABLE `dealoftheday` (
  `ID` int(11) NOT NULL,
  `CONTENT` text NOT NULL,
  `IMAGE` varchar(500) NOT NULL DEFAULT '',
  `LINK` varchar(500) NOT NULL,
  `BTNTEXT` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealoftheday`
--

INSERT INTO `dealoftheday` (`ID`, `CONTENT`, `IMAGE`, `LINK`, `BTNTEXT`) VALUES
(4, '<h2>Lorem Ipsum Dolor</h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'admin/uploads/banners/24102019031110product-1.png', 'https://google.com', 'Buy Now');

-- --------------------------------------------------------

--
-- Table structure for table `frontpageslider`
--

CREATE TABLE `frontpageslider` (
  `ID` int(11) NOT NULL,
  `IMAGE` varchar(500) NOT NULL DEFAULT '',
  `CONTENT` text NOT NULL,
  `CONTENTALIGNMENT` varchar(50) NOT NULL DEFAULT 'Left'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `frontpageslider`
--

INSERT INTO `frontpageslider` (`ID`, `IMAGE`, `CONTENT`, `CONTENTALIGNMENT`) VALUES
(7, 'admin/uploads/sliders/04112019090550coconut oil.jpg', '', 'Right'),
(8, 'admin/uploads/sliders/04112019090837ghee.jpg', '', 'Left'),
(12, 'admin/uploads/sliders/04112019091012spices.jpg', '', 'Left'),
(13, 'admin/uploads/sliders/04112019091549salttt.jpg', '', 'Left'),
(14, 'admin/uploads/sliders/04112019091727brown sugar.jpg', '', 'Left'),
(15, 'admin/uploads/sliders/04112019095953condiments.jpg', '', 'Left'),
(16, 'admin/uploads/sliders/04112019100043condi.jpg', '', 'Left'),
(17, 'admin/uploads/sliders/04112019100123flour.jpg', '', 'Left'),
(18, 'admin/uploads/sliders/04112019100223rice.jpg', '', 'Left'),
(19, 'admin/uploads/sliders/04112019100306pasta.jpg', '', 'Left'),
(20, 'admin/uploads/sliders/04112019100357pickel.jpg', '', 'Left'),
(21, 'admin/uploads/sliders/04112019100504triphala.jpg', '', 'Left');

-- --------------------------------------------------------

--
-- Table structure for table `galleryimage`
--

CREATE TABLE `galleryimage` (
  `ID` int(11) NOT NULL,
  `DESCRIPTION` varchar(500) NOT NULL,
  `IMAGE` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galleryimage`
--

INSERT INTO `galleryimage` (`ID`, `DESCRIPTION`, `IMAGE`) VALUES
(7, 'New Year', 'admin/uploads/galleryimages/24102019033436newyear.jpg'),
(8, 'Diwali Celebration', 'admin/uploads/galleryimages/24102019033534diwali.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ID` int(11) NOT NULL,
  `USER` int(11) NOT NULL,
  `ORDER_DATE` varchar(50) NOT NULL,
  `ORDERJSON` varchar(800) NOT NULL,
  `ORDERSTATUS` varchar(50) NOT NULL,
  `ISENABLED` varchar(20) NOT NULL DEFAULT 'true',
  `PINCODE` varchar(20) NOT NULL DEFAULT '',
  `STREETADDR1` varchar(500) NOT NULL DEFAULT '',
  `STREETADDR2` varchar(500) NOT NULL DEFAULT '',
  `LANDMARK` varchar(500) NOT NULL DEFAULT '',
  `CITY` varchar(500) NOT NULL DEFAULT '',
  `STATE` varchar(200) NOT NULL DEFAULT '',
  `ADDRESSTYPE` varchar(50) NOT NULL DEFAULT '',
  `ORDERID` varchar(255) NOT NULL DEFAULT '',
  `TOTALPAID` varchar(20) NOT NULL,
  `SHIPPINGCHARGE` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `USER`, `ORDER_DATE`, `ORDERJSON`, `ORDERSTATUS`, `ISENABLED`, `PINCODE`, `STREETADDR1`, `STREETADDR2`, `LANDMARK`, `CITY`, `STATE`, `ADDRESSTYPE`, `ORDERID`, `TOTALPAID`, `SHIPPINGCHARGE`) VALUES
(29, 11, '24-10-2019', '[{\"product\":\"23\",\"quantity\":2,\"product_price\":\"10\",\"pweight\":\"1\",\"sweight\":\"1.5\"}]', 'Packed', 'true', '400605', 'Street Name', 'Building Name, Room No, Suburb Name', 'Landmark', 'Mumbai', 'Maharashtra', 'Home', 'order_DXlIxoYzYhiGvd', '60', '40'),
(30, 11, '24-10-2019', '[{\"product\":\"23\",\"quantity\":\"10\",\"product_price\":\"10\",\"pweight\":\"1\",\"sweight\":\"1.5\"}]', 'Dispatched', 'false', '400605', 'Street Name', 'Building Name, Room No, Suburb Name', 'Landmark', 'Mumbai', 'Maharashtra', 'Home', 'order_DXlMdwQaEFDhTc', '128', '28'),
(31, 13, '03-11-2019', '[{\"product\":\"23\",\"quantity\":1,\"product_price\":\"10\",\"pweight\":\"1\",\"sweight\":\"1.5\"}]', 'pending', 'true', '111111', 'Dhhd', 'Xhhx', 'Dhdh', 'Dhdh', 'Maharashtra', 'Home', 'order_DbuCUNUsTnqrDt', '50', '40');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `IMAGE` text NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `PRICE` varchar(20) NOT NULL,
  `DISCOUNTPRICE` varchar(20) NOT NULL DEFAULT 'none',
  `IS_SLIDER` varchar(10) NOT NULL DEFAULT 'false',
  `CATEGORY` int(11) NOT NULL DEFAULT '0',
  `CREATE_DATE` varchar(20) NOT NULL,
  `ISENABLED` varchar(20) NOT NULL DEFAULT 'true',
  `IS_FEATURED` varchar(10) NOT NULL DEFAULT 'no',
  `IS_TRENDING` varchar(10) NOT NULL DEFAULT 'no',
  `PRDWEIGHT` varchar(50) NOT NULL DEFAULT '1',
  `SHPWEIGHT` varchar(50) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `TITLE`, `IMAGE`, `DESCRIPTION`, `PRICE`, `DISCOUNTPRICE`, `IS_SLIDER`, `CATEGORY`, `CREATE_DATE`, `ISENABLED`, `IS_FEATURED`, `IS_TRENDING`, `PRDWEIGHT`, `SHPWEIGHT`) VALUES
(22, 'Cup Noodles', 'admin/uploads/products/24102019032021product-1.png', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '45', '40', 'no', 16, '24-10-2019', 'true', 'no', 'yes', '1', '1.5'),
(23, 'Lassi', 'admin/uploads/products/24102019024632product-3.jpg', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '20', '10', 'no', 17, '24-10-2019', 'true', 'no', 'yes', '1', '1.5'),
(24, 'Jeera Bites', 'admin/uploads/products/24102019024709product-2.png', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '20', '10', 'no', 16, '24-10-2019', 'true', 'no', 'yes', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `IMAGE` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`ID`, `TITLE`, `IMAGE`) VALUES
(0, 'No Category', ''),
(16, 'Food', 'admin/uploads/categories/24102019024104product-1.png'),
(17, 'Drinks', 'admin/uploads/categories/24102019024218product-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `promobanner`
--

CREATE TABLE `promobanner` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `DEFAULTIMAGE` varchar(500) NOT NULL,
  `IMAGE` varchar(500) NOT NULL DEFAULT '',
  `LINK` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `promobanner`
--

INSERT INTO `promobanner` (`ID`, `TITLE`, `DEFAULTIMAGE`, `IMAGE`, `LINK`) VALUES
(4, 'topright', '', 'admin/uploads/banners/24102019030746banner-1.jpg', 'https://google.com'),
(5, 'topleft', '', 'admin/uploads/banners/24102019030810banner-1.jpg', 'https://google.com'),
(6, 'bottom', '', 'admin/uploads/banners/24102019030839discount.png', 'https://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `socialmedia`
--

CREATE TABLE `socialmedia` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `LINK` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `socialmedia`
--

INSERT INTO `socialmedia` (`ID`, `TITLE`, `LINK`) VALUES
(1, 'facebook', 'https://facebook.com/ecomytra'),
(2, 'instagram', 'https://instagram.com/ecomytra'),
(3, 'twitter', 'https://twitter.com/ecomytra'),
(4, 'linkedin', 'https://linkedin.com/ecomytra');

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `ID` int(11) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `PIC` varchar(500) NOT NULL DEFAULT 'images/user.png',
  `COMMENT` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`ID`, `AUTHOR`, `PIC`, `COMMENT`) VALUES
(9, 'John', 'admin/uploads/testimonials/24102019030131user.png', 'Lorem Ipsum Dolor Sit Amet'),
(10, 'Katy', 'admin/uploads/testimonials/24102019030152user-female.png', 'Lorem Ipsum Dolor Sit Amet');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CONTACT` varchar(255) NOT NULL DEFAULT ' ',
  `DOB` varchar(20) NOT NULL DEFAULT '',
  `GENDER` varchar(10) NOT NULL DEFAULT '',
  `PINCODE` varchar(20) NOT NULL DEFAULT '',
  `STREETADDR1` varchar(500) NOT NULL DEFAULT '',
  `STREETADDR2` varchar(500) NOT NULL DEFAULT '',
  `LANDMARK` varchar(500) NOT NULL DEFAULT '',
  `CITY` varchar(200) NOT NULL DEFAULT '',
  `STATE` varchar(200) NOT NULL DEFAULT '',
  `ADDRESSTYPE` varchar(50) NOT NULL DEFAULT '',
  `PIC` varchar(500) NOT NULL DEFAULT 'images/user.png',
  `PASSWORD` varchar(255) NOT NULL,
  `TYPE` varchar(20) NOT NULL DEFAULT 'user',
  `ISENABLED` varchar(10) NOT NULL DEFAULT 'true',
  `CREATE_DATE` varchar(50) NOT NULL DEFAULT '',
  `OTP` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `NAME`, `EMAIL`, `CONTACT`, `DOB`, `GENDER`, `PINCODE`, `STREETADDR1`, `STREETADDR2`, `LANDMARK`, `CITY`, `STATE`, `ADDRESSTYPE`, `PIC`, `PASSWORD`, `TYPE`, `ISENABLED`, `CREATE_DATE`, `OTP`) VALUES
(1, 'Administrator', 'admin@gmail.com', ' ', '', '', '', '', '', '', '', '', '', '', 'admin@123', 'admin', 'true', '', ''),
(11, 'Ajay Sharma', 'ajay90560@gmail.com', '9022549480', '12-11-1997', 'male', '400605', 'Street Name', 'Building Name, Room No, Suburb Name', 'Landmark', 'Mumbai', 'Maharashtra', 'Home', 'admin/uploads/users/24102019033837Ajay-Sharma.jpg', 'pass@123', 'user', 'true', '24-10-2019', '955254'),
(12, 'Virat Pawar', 'viratpawar10@gmail.com', '8080497300', '15-07-2019', 'male', '400610', '23/703 Satham Paradise Tulsidham Complex Ghodbunder Road Thane West', 'Tulsidham', 'MAHARASHTRA', 'Thane', 'Maharashtra', 'Home', 'images/user.png', 'newpassword', 'user', 'true', '01-11-2019', '785191'),
(13, 'Yash Dubey', 'yash.vdubey@gmail.com', '9819000975', '11-11-1111', 'male', '111111', 'Dhhd', 'Xhhx', 'Dhdh', 'Dhdh', 'Maharashtra', 'Home', 'images/user.png', 'possword', 'user', 'true', '03-11-2019', ''),
(14, 'rahul', 'rahulyadav1598@gmail.com', '9967856357', '', '', '', '', '', '', '', '', '', 'images/user.png', '111111', 'user', 'true', '04-11-2019', '');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(255) NOT NULL,
  `LINK` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`ID`, `TITLE`, `LINK`) VALUES
(63, 'Blank Video', 'https://youtu.be/8tPnX7OPo0Q');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `catpromobanner`
--
ALTER TABLE `catpromobanner`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `contactform`
--
ALTER TABLE `contactform`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `dealoftheday`
--
ALTER TABLE `dealoftheday`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `frontpageslider`
--
ALTER TABLE `frontpageslider`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `galleryimage`
--
ALTER TABLE `galleryimage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `promobanner`
--
ALTER TABLE `promobanner`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `socialmedia`
--
ALTER TABLE `socialmedia`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `catpromobanner`
--
ALTER TABLE `catpromobanner`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contactform`
--
ALTER TABLE `contactform`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dealoftheday`
--
ALTER TABLE `dealoftheday`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `frontpageslider`
--
ALTER TABLE `frontpageslider`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `galleryimage`
--
ALTER TABLE `galleryimage`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `promobanner`
--
ALTER TABLE `promobanner`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `socialmedia`
--
ALTER TABLE `socialmedia`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
