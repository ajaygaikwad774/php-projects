-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 12, 2019 at 01:40 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wisdomacademynew`
--

-- --------------------------------------------------------

--
-- Table structure for table `fh_assignment`
--

CREATE TABLE `fh_assignment` (
  `assignment_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `assignment_name` varchar(255) NOT NULL,
  `assignment_content` text NOT NULL,
  `assignment_image` varchar(255) NOT NULL,
  `assignment_submit_date` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_assignment`
--

INSERT INTO `fh_assignment` (`assignment_id`, `batch_id`, `subject`, `assignment_name`, `assignment_content`, `assignment_image`, `assignment_submit_date`, `added_date`, `disable_flag`) VALUES
(1, 2, 'STD IX ', 'ddc', 'dccdc dcdwec  rfcw', '', '2019-07-10', '2019-07-07 09:30:53', 1),
(2, 2, 'STD X ', 'kokokoko', 'SKJDNVKJE EVNEJNVEJNVJE VEKV RKEJVNJRVN ERVEJFNEKRJ C', '', '2019-07-09', '2019-07-08 09:08:03', 1),
(3, 2, 'STD X ', 'KOOOO', 'MKM CAMCKACKAC ACKACMKACK CCKMACKMACK  KCAKCM', '', '2019-07-10', '2019-07-08 09:08:59', 1),
(4, 3, 'STD X ', 'LMLMLMLM', 'm,.m,m mmsm;mc; ckm,ls;cl;amcl;mas;c;a calc,l;a,cl;a,', '', '2019-07-09', '2019-07-08 09:09:31', 1),
(5, 2, 'STD X ', 'kokkokoko', 'mkmk mmkmkmkm  mmkmk mmkmkk', '', '2019-07-10', '2019-07-08 09:11:00', 1),
(6, 4, 'STD IX ', 'lplpppp', ',,,,,,,pplplplpplplp', '', '2019-07-10', '2019-07-08 09:18:47', 1),
(7, 4, 'STD IX ', 'mkokokokk', 'jhjhjhjhjhjhj', '', '2019-07-10', '2019-07-08 09:20:54', 1),
(8, 4, 'STD IX ', 'mkokokokk', 'jhjhjhjhjhjhj', '', '2019-07-10', '2019-07-08 09:22:19', 1),
(9, 4, 'STD X ', 'Chapter2-3', 'kokokokko', '', '2019-07-16', '2019-07-08 09:24:39', 1),
(10, 3, 'STD IX ', 'demo', 'demo demo ', '', '2019-07-10', '2019-07-08 09:49:02', 1),
(11, 3, 'STD IX ', 'demo', 'eeeeeee', '', '2019-07-09', '2019-07-08 11:34:25', 1),
(12, 3, 'STD IX ', 'demo', 'jjj', '', '2019-07-09', '2019-07-08 11:40:07', 1),
(13, 3, 'STD IX ', 'demo', 'jjj', '', '2019-07-09', '2019-07-08 11:42:57', 1),
(14, 3, 'STD IX ', 'demo', 'eee eee eee eee', '', '2019-07-09', '2019-07-08 11:43:25', 1),
(15, 3, 'STD IX ', 'demo', 'demo', '', '2019-07-16', '2019-07-08 12:06:40', 1),
(16, 3, 'STD IX ', 'demo', 'demo', '', '2019-07-16', '2019-07-08 12:07:22', 1),
(17, 3, 'STD IX ', 'demo', 'okk', '', '2019-07-17', '2019-07-08 12:09:52', 1),
(18, 3, 'STD IX ', 'emo', 'dddddd', '', '2019-07-09', '2019-07-08 12:14:12', 1),
(19, 3, 'STD IX ', 'okkkk', 'demoooo', '', '2019-07-09', '2019-07-08 12:23:05', 1),
(20, 3, 'STD IX ', 'demo', 'demo', '', '2019-07-10', '2019-07-08 12:25:34', 1),
(21, 3, 'STD IX ', 'demo', 'demo', '', '2019-07-10', '2019-07-08 12:29:57', 1),
(22, 3, 'STD IX ', 'demo', 'de,o', '', '2019-07-09', '2019-07-08 12:30:24', 1),
(23, 3, 'History ', 'Science', 'Chapter 3&4', '', '2019-07-12', '2019-07-11 17:00:23', 1),
(24, 3, 'STD X ', 'Science', 'Chapter 3&4', '', '2019-07-12', '2019-07-11 17:02:28', 0),
(25, 2, '', 'demo', 'demo', '', '2019-07-15', '2019-07-14 11:22:55', 1),
(26, 2, 'demo', 'demo', 'demo', '', '2019-07-15', '2019-07-14 11:24:00', 1),
(27, 5, 'demo', 'chap2', 'A', '', '2019-07-22', '2019-07-21 11:59:39', 1),
(28, 3, 'demo', 'demo', 'wer', '', '2019-06-15', '2019-08-28 12:25:33', 1),
(29, 3, 'demo', 'demo', 'qwe', '', '2019-06-14', '2019-08-28 12:27:03', 1),
(30, 3, 'demo', 'demo', 'sd', '', '2019-06-12', '2019-08-28 12:28:55', 1),
(31, 3, 'aa', 'demo', 'mmmm', '', '2019-06-15', '2019-08-28 12:31:49', 1),
(32, 3, 'demo', 'chap2', 'oihg', '', '2019-06-03', '2019-08-28 13:40:19', 1),
(33, 3, 'all', 'demo', 'i', '', '2019-06-14', '2019-08-28 13:42:10', 1),
(34, 4, 'aa', 'Marathi ', 'OIH', '', '2019-06-15', '2019-08-28 13:44:09', 1),
(35, 3, 'demo', 'demo', 'ok', '', '2019-06-12', '2019-08-28 13:54:25', 0),
(36, 2, 'aa', 'Marathi ', 'ihg', '', '2019-09-19', '2019-09-06 15:48:44', 0),
(37, 2, 'ds', 'ads', 'vb', '', '2019-09-23', '2019-09-06 16:08:00', 0),
(38, 2, 'iuy', 'kjh', 'iouyt', '', '2019-09-25', '2019-09-06 16:22:19', 0),
(39, 2, 'Never', 'Never', 'new', '', '2019-09-06', '2019-09-06 22:32:21', 0),
(40, 2, 'PHP', 'Test', 'Success', '', '2019-09-07', '2019-09-07 11:29:11', 0),
(41, 2, 'PHP', 'Test', 'Success', '', '2019-09-07', '2019-09-07 11:29:54', 0),
(42, 2, 'qrf', 'rf', 'wf', '', '2019-09-07', '2019-09-07 11:35:35', 0),
(43, 2, 'wer', 'wef', 'eqr', '', '2019-09-07', '2019-09-07 11:37:40', 0),
(44, 2, 'wthb', 'twrhb', 'thqt', '', '2019-09-07', '2019-09-07 11:41:15', 0),
(45, 2, 'rgv', 'fsv', 'wfvdc', '', '2019-09-07', '2019-09-07 11:44:17', 0),
(46, 2, 'efdc', 'qv', 'qwrg', '', '2019-09-07', '2019-09-07 11:45:49', 0),
(47, 2, 'dwvf', 'vc3', 'fvwd', '', '2019-09-07', '2019-09-07 11:46:58', 0),
(48, 2, 'qwd', 'f2r', '2rfc', '', '2019-09-07', '2019-09-07 11:49:50', 0),
(49, 2, 'wcd', 'ervc', '2evcd', '', '2019-09-07', '2019-09-07 11:53:22', 0),
(50, 2, 'wv', 'e2', 'werv', '', '2019-09-07', '2019-09-07 12:02:28', 0),
(51, 2, 'wfv', '2evq', 'qevf', '', '2019-09-07', '2019-09-07 12:04:24', 0),
(52, 2, 'efvcd', 'qevsdc', 'vrdc', '', '2019-09-07', '2019-09-07 12:18:59', 0),
(53, 2, 'af', 'wfr', 'qerg', '', '2019-09-07', '2019-09-07 12:24:33', 0),
(54, 2, 'qdw', 'vfc', 'efv', '', '2019-09-07', '2019-09-07 13:41:50', 0),
(55, 2, 'dryg', 'SDfv', 'zsdv', '', '2019-09-07', '2019-09-07 13:42:23', 0),
(56, 2, 'n njnjhijbhb', 'uhbuhbyb', 'ygibhbh', '', '2019-09-07', '2019-09-07 13:49:36', 0),
(57, 2, 'wef', 'asc', 'dav', '', '2019-09-07', '2019-09-07 14:18:25', 0),
(58, 2, 'maths', 'New', 'lll', '', '2019-09-08', '2019-09-08 12:44:40', 0),
(59, 2, 'dwc', 'ec', 'wc', '', '2019-09-08', '2019-09-08 12:44:58', 0),
(60, 2, 'aa', 'hindi', 'iuyg', '', '2019-06-03', '2019-09-08 12:45:59', 0),
(61, 2, 'Maths', 'wv', 'wfve', '', '2019-09-08', '2019-09-08 13:12:21', 1),
(62, 2, 'avf', 'faev', 'av', '', '2019-09-08', '2019-09-08 13:17:07', 1),
(63, 2, 'qdc', 'qv', 'dw', '', '2019-09-08', '2019-09-08 13:17:56', 0),
(64, 2, 'qwcd', 'wdc', 'qdsvc', '', '2019-09-08', '2019-09-08 13:19:36', 0),
(65, 2, 'Now', 'qed', 'ds', '', '2019-09-08', '2019-09-08 13:31:52', 0),
(66, 2, 'fev', '2ed', 'd', '', '2019-09-08', '2019-09-08 13:39:14', 0),
(67, 2, 'j', 'ok', 'ok', '', '2019-09-16', '2019-09-08 13:43:40', 0),
(68, 2, 'hj', 'i', 'io', '', '2019-09-23', '2019-09-08 13:44:55', 0),
(69, 2, 'kjn', 'k', 'ok', '', '2019-09-13', '2019-09-08 13:46:51', 0),
(70, 2, 'iuh', 'iouj', 'oook', '', '2019-09-24', '2019-09-08 13:47:59', 0),
(71, 2, 'wfv', 'rf', 'heel', '', '2019-09-01', '2019-09-08 13:52:25', 0),
(72, 2, 'Maths', 'maths test', 'maths 2&3 chap', '', '2019-09-24', '2019-09-08 14:06:22', 0),
(73, 2, 'oij', 'po', 'o', '', '2019-09-25', '2019-09-08 14:12:52', 0),
(74, 2, 'pl', 'okm', 'om', '', '2019-09-27', '2019-09-08 14:16:19', 0),
(75, 2, 'ok', 'ok', 'ok', '', '2019-09-30', '2019-09-08 14:16:56', 0),
(76, 2, 'pol', 'pol', 'ok,ll,p', '', '2019-09-25', '2019-09-08 14:22:34', 0),
(77, 2, 'h', 'e', 'll', '', '2019-09-16', '2019-09-08 14:33:59', 0),
(78, 2, 'Science', 'test', 'Hhh', '', '2019-09-09', '2019-09-08 14:49:29', 0),
(79, 2, 'Maths', 'test', 'New', '', '2019-09-08', '2019-09-08 14:54:14', 0),
(80, 2, 'ee', 'ee', 'ee', '', '2019-09-08', '2019-09-08 15:08:02', 0),
(81, 2, 'qq', 'qq', 'qq', '', '2019-09-08', '2019-09-08 15:09:05', 0),
(82, 2, 'demo', 'Marathi ', 'cha 2', '', '2019-07-12', '2019-09-08 15:58:47', 0),
(83, 2, 'all', 'Marathi ', 'l', '', '2019-06-12', '2019-09-08 16:04:17', 0),
(84, 2, 'aa', 'chap2', 'ok', '', '2019-07-12', '2019-09-08 16:07:49', 0),
(85, 2, 'demo', 'demo', 'testing', '', '2019-09-28', '2019-09-08 16:09:54', 0),
(86, 2, 'kkkk', 'kkmmmm', 'mmkm mkmkm mkmkm mkmk', 'images/Chrysanthemum.jpg', '2019-09-16', '2019-09-08 17:46:13', 0),
(87, 6, 'maths', 'qwerty ', 'demo dmeo', 'images/Chrysanthemum.jpg', '2019-09-10', '2019-09-08 18:08:29', 0),
(88, 6, 'maths', 'demo', 'demo demo demo', 'images/Chrysanthemum.jpg', '2019-09-16', '2019-09-08 18:10:17', 0),
(89, 6, 'demo', 'demmdemide ', 'dwjdnij wndjqn jnjidnq ndjinqwdnq ndjwnd', 'images/Chrysanthemum.jpg', '2019-09-17', '2019-09-08 18:12:18', 0),
(90, 2, 'wefcwq', 'qwef', 'Sms', '', '2019-09-08', '2019-09-08 20:14:02', 0),
(91, 2, 'Maths', 'hello', 'hhhh', '', '2019-09-08', '2019-09-08 20:18:05', 0),
(92, 2, 'Today', 'today', 'ikkk', '', '2019-09-14', '2019-09-14 12:54:48', 0),
(93, 2, 'Today', 'todayy', 'ikkk', '', '2019-09-14', '2019-09-14 12:57:58', 0),
(94, 2, 'maths', 'assignment', 'content', '', '2019-09-15', '2019-09-14 12:59:45', 0),
(95, 2, 'uih', 'hjkb', 'gv', '', '2019-09-16', '2019-09-14 13:02:05', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fh_attendance`
--

CREATE TABLE `fh_attendance` (
  `atten_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `user_full_name` varchar(255) NOT NULL,
  `attendance_flag` int(11) NOT NULL COMMENT '0=present,1=absent,2=holiday',
  `attendance_date` varchar(255) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_attendance`
--

INSERT INTO `fh_attendance` (`atten_id`, `user_id`, `batch_id`, `user_full_name`, `attendance_flag`, `attendance_date`, `added_date`) VALUES
(1, 19, 1, '', 1, '2019-06-24', '2019-06-24 22:18:33'),
(2, 35, 2, '', 0, '2019-06-25', '2019-06-25 21:02:48'),
(3, 36, 2, '', 0, '2019-06-25', '2019-06-25 21:02:48'),
(4, 39, 2, '', 0, '2019-06-25', '2019-06-25 21:02:48'),
(5, 40, 2, '', 0, '2019-06-25', '2019-06-25 21:02:48'),
(6, 35, 2, '', 0, '2019-06-24', '2019-06-25 21:03:42'),
(7, 36, 2, '', 0, '2019-06-24', '2019-06-25 21:03:42'),
(8, 39, 2, '', 0, '2019-06-24', '2019-06-25 21:03:42'),
(9, 40, 2, '', 0, '2019-06-24', '2019-06-25 21:03:42'),
(10, 35, 2, '', 0, '2019-06-23', '2019-06-25 21:04:15'),
(11, 36, 2, '', 0, '2019-06-23', '2019-06-25 21:04:15'),
(12, 39, 2, '', 0, '2019-06-23', '2019-06-25 21:04:15'),
(13, 40, 2, '', 0, '2019-06-23', '2019-06-25 21:04:15'),
(14, 49, 4, '', 0, '2019-07-04', '2019-07-04 14:27:18'),
(17, 65, 3, '', 0, '2019-07-09', '2019-07-11 16:40:33'),
(18, 65, 3, '', 1, '2019-07-10', '2019-07-11 16:40:44'),
(19, 65, 3, '', 0, '2019-07-11', '2019-07-11 16:40:53'),
(20, 75, 2, '', 0, '2019-09-06', '2019-09-06 15:53:58'),
(21, 73, 2, '', 0, '2019-09-06', '2019-09-06 15:53:58'),
(22, 37, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(23, 38, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(24, 41, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(25, 43, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(26, 44, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(27, 45, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(28, 48, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(29, 49, 4, '', 0, '2019-10-22', '2019-10-22 12:15:47'),
(30, 79, 2, '', 0, '2019-11-20', '2019-11-20 19:32:36'),
(31, 81, 2, '', 1, '2019-11-20', '2019-11-20 19:32:36'),
(32, 83, 2, '', 1, '2019-11-20', '2019-11-20 19:32:36');

-- --------------------------------------------------------

--
-- Table structure for table `fh_batch`
--

CREATE TABLE `fh_batch` (
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(255) NOT NULL,
  `batch_time` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_batch`
--

INSERT INTO `fh_batch` (`batch_id`, `batch_name`, `batch_time`, `disable_flag`) VALUES
(2, 'MORNING', '9 to 11', 0),
(3, 'AFTERNOON', '2:30 to 4:30', 0),
(4, 'EVENING 1', '4:00 to 6:00', 0),
(5, 'EVENING 2', '6:15 to 8:15 ', 0),
(6, 'qw', '1 TO 2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fh_course`
--

CREATE TABLE `fh_course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `subjects` varchar(255) NOT NULL,
  `total_fees` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_course`
--

INSERT INTO `fh_course` (`course_id`, `course_name`, `subjects`, `total_fees`, `disable_flag`, `added_date`) VALUES
(2, 'STD X', 'STD X', 18500, 0, '2019-06-25 15:17:13'),
(3, 'STD IX', 'STD IX', 14500, 0, '2019-06-25 15:17:25'),
(4, 'STD VIII', 'STD VIII', 9900, 0, '2019-06-25 15:17:35'),
(5, 'iohug', 'STD X', 18500, 1, '2019-08-06 17:30:47');

-- --------------------------------------------------------

--
-- Table structure for table `fh_fees`
--

CREATE TABLE `fh_fees` (
  `fees_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_fees` varchar(255) NOT NULL,
  `payment_type` varchar(255) NOT NULL,
  `installment_amount` varchar(255) NOT NULL,
  `no_installment` int(11) NOT NULL,
  `installment_date` varchar(255) NOT NULL,
  `total_fees` int(11) NOT NULL,
  `discount_amount` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_fees`
--

INSERT INTO `fh_fees` (`fees_id`, `user_id`, `username`, `batch_id`, `course_id`, `course_name`, `course_fees`, `payment_type`, `installment_amount`, `no_installment`, `installment_date`, `total_fees`, `discount_amount`, `paid_amount`, `due_amount`, `payment_mode`, `disable_flag`, `added_date`) VALUES
(2, 20, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 16500, 2000, 7500, 9000, '', 0, '2019-06-25 15:31:13'),
(3, 21, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 16500, 2000, 7500, 9000, '', 0, '2019-06-25 15:38:46'),
(4, 22, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 16000, 2500, 16000, 0, '', 0, '2019-06-25 15:44:33'),
(5, 23, 'KULJIT DODIYA SINGH', 5, 2, 'STD X', '18500', 'None', '', -1, '', 16000, 2500, 16000, 0, '', 0, '2019-06-25 15:56:15'),
(6, 24, 'KULJIT DODIYA SINGH', 5, 2, 'STD X', '18500', 'None', ' ', 0, '', 16500, 2500, 0, 0, '', 0, '2019-06-25 16:05:26'),
(7, 25, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 17000, 2500, 10000, 7000, '', 0, '2019-06-25 16:11:17'),
(8, 26, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 16500, 2500, 6000, 10500, '', 0, '2019-06-25 16:19:50'),
(9, 27, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 16500, 2500, 6000, 10500, '', 0, '2019-06-25 16:19:50'),
(10, 28, 'ABHAYMaurya', 5, 2, 'STD X', '18500', 'None', '', -1, '2019-06-10', 16500, 2500, 6000, 10500, '', 0, '2019-06-25 16:25:38'),
(11, 29, 'HARSHITABHARASHDIYA', 5, 2, 'STD X', '18500', 'None', '', -1, '', 16500, 2000, 16500, 0, '', 0, '2019-06-25 16:31:29'),
(12, 30, 'ZEESHANKHAN', 5, 2, 'STD X', '18500', 'None', '', -1, '', 17000, 1500, 7500, 9500, '', 0, '2019-06-25 16:55:06'),
(13, 31, 'VARUNYADAV', 5, 2, 'STD X', '18500', 'None', '', -1, '', 17000, 1500, 6000, 11000, '', 0, '2019-06-25 17:01:23'),
(14, 32, 'PAWAN PARMAR', 5, 2, 'STD X', '18500', 'None', '', -1, '', 16000, 2500, 10000, 6500, '', 0, '2019-06-25 17:06:22'),
(15, 33, 'PAWAN PARMAR', 5, 2, 'STD X', '18500', 'None', '', -1, '', 17000, 1500, 3500, 13500, '', 0, '2019-06-25 17:13:58'),
(16, 34, 'PRATHMESHNATEKAR', 5, 2, 'STD X', '180', '0', '', -1, '', 17000, 1500, 17500, 0, '', 0, '2019-06-25 17:32:38'),
(19, 37, 'SHIFAShaikh', 4, 3, 'STD IX', '14500', '0', '', -1, '', 10500, 4000, 10500, 0, '', 0, '2019-06-25 18:29:08'),
(20, 38, 'MANTHAN KONGIL', 4, 3, 'STD IX', '14500', '1', '11000', 0, '', 11000, 3500, 4000, 7000, '', 0, '2019-06-25 18:43:43'),
(23, 41, 'NIDAANSARI', 4, 3, 'STD IX', '14500', '0', '', -1, '', 10500, 4000, 10500, 0, '', 0, '2019-06-26 19:02:54'),
(24, 42, 'SHIFAShaikh', 4, 3, 'STD IX', '14500', '0', '', -1, '', 10500, 4000, 10500, 0, '', 0, '2019-06-26 19:09:44'),
(25, 43, 'MANTHANKOGIL', 4, 3, 'STD IX', '14500', 'None', '', -1, '', 11000, 3500, 11000, 0, '', 0, '2019-06-26 19:36:04'),
(26, 44, 'ARHAMKHAN', 4, 3, 'STD IX', '14500', '0', '', -1, '', 10500, 4000, 10500, 0, '', 0, '2019-06-26 19:41:42'),
(27, 45, 'MITESHKAMBLE', 4, 3, 'STD IX', '14500', 'None', '', -1, '', 11000, 3500, 0, 11000, '', 0, '2019-06-27 15:35:45'),
(28, 46, 'MITESHKAMBLE', 2, 3, 'STD IX', '14500', 'None', '', -1, '', 11000, 3500, 0, 11000, '', 0, '2019-05-27 15:40:03'),
(30, 48, 'MUSKANANSARI', 4, 3, 'STD IX', '14500', 'None', '', -1, '', 11000, 3500, 4000, 7000, '', 0, '2019-05-27 16:13:36'),
(31, 49, 'REHANSHAIKH', 4, 3, 'STD IX', '14500', 'None', '', -1, '', 11000, 3500, 4000, 7000, '', 0, '2019-05-27 16:26:25'),
(32, 50, 'ANJALIRAI', 5, 2, 'STD X', '18500', 'None', '', -1, '', 16500, 2000, 7500, 9000, '', 0, '2019-05-27 16:44:05'),
(33, 51, 'ADITIKATKE', 5, 2, 'STD X', '18500', '0', '', -1, '', 16500, 2000, 10500, 6000, '', 0, '2019-08-29 16:22:38'),
(34, 52, 'PRIYANKA VIJAYMALE', 5, 2, 'STD X', '18500', 'None', '', -1, '', 17000, 1500, 3500, 13500, '', 0, '2019-08-29 16:32:46'),
(35, 53, 'YASHGORAKH', 5, 2, 'STD X', '18500', 'None', '', -1, '', 16500, 2000, 10000, 6500, '', 0, '2019-08-29 16:41:21'),
(36, 54, 'YASHSHARMA', 5, 2, 'STD X', '18500', 'None', '', -1, '', 16000, 2500, 16000, 0, '', 0, '2019-08-29 17:25:33'),
(39, 57, 'RohanNaik', 3, 2, 'STD X', '18500', '0', '', -1, '', 17800, 700, 17800, 0, '', 0, '2019-07-08 09:52:43'),
(41, 59, 'darshyadav', 3, 2, 'STD X', '18500', '0', '', -1, '', 18000, 500, 17000, 1000, '', 0, '2019-07-08 12:54:31'),
(42, 60, 'aarshyadav', 3, 3, 'STD IX', '14500', '0', '', -1, '', 14000, 500, 14000, 0, '', 0, '2019-07-08 15:54:18'),
(43, 61, 'darshkomu', 3, 2, 'STD X', '18500', '0', '', -1, '', 18000, 500, 18000, 0, '', 0, '2019-07-08 15:58:12'),
(44, 62, 'darshkomu', 3, 2, 'STD X', '18500', '0', '', -1, '', 17500, 1000, 17500, 0, '', 0, '2019-05-08 16:01:21'),
(45, 63, 'darshyadav', 3, 2, 'STD X', '18500', '0', '', -1, '', 18000, 500, 18000, 0, '', 0, '2019-05-08 16:16:09'),
(46, 64, 'darshankomu', 3, 2, 'STD X', '18500', '0', '', -1, '', 18000, 500, 18000, 0, '', 0, '2019-07-08 16:22:51'),
(47, 65, 'demodemo', 5, 3, 'STD IX', '14500', '0', '', -1, '', 14000, 500, 14000, 0, '', 0, '2019-05-09 12:59:31'),
(49, 65, 'RahulYadav', 3, 2, 'STD X', '18500', '0', '', -1, '', 18000, 500, 10001, 8000, '', 0, '2019-02-11 16:07:00'),
(53, 69, 'naguyadav', 3, 2, 'STD X', '18500', '0', '', -1, '', 18000, 500, 8001, 10000, '', 1, '2019-01-13 11:40:06'),
(58, 79, 'VickyJha', 2, 2, 'STD X', '18500', 'None', '', -1, '2019-09-08', 17500, 1000, 1000, 16500, '', 0, '2019-09-08 19:43:01'),
(60, 81, 'Rahul Yadav', 2, 2, 'STD X', '18500', 'None', '', -1, '', 17500, 1000, 2000, 15500, '', 0, '2019-09-14 12:46:10'),
(61, 83, 'Rahul Yadav', 2, 2, 'STD X', '18500', '0', '', -1, '', 17500, 1000, 10000, 7500, '', 0, '2019-10-09 09:28:29'),
(62, 84, 'vickyjha', 3, 2, 'STD X', '18500', 'None', '', -1, '2019-10-04', 17500, 1000, 500, 17000, '', 0, '2019-10-13 19:39:31');

-- --------------------------------------------------------

--
-- Table structure for table `fh_imp_content`
--

CREATE TABLE `fh_imp_content` (
  `imp_id` int(11) NOT NULL,
  `imp_topic_name` varchar(255) NOT NULL,
  `imp_file` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fh_notice`
--

CREATE TABLE `fh_notice` (
  `notice_id` int(11) NOT NULL,
  `notice_name` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `batch_id` varchar(255) NOT NULL,
  `notice_type` varchar(255) NOT NULL COMMENT 'all or individual',
  `notice_content` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL,
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_notice`
--

INSERT INTO `fh_notice` (`notice_id`, `notice_name`, `user_id`, `batch_id`, `notice_type`, `notice_content`, `disable_flag`, `added_date`) VALUES
(1, '123', '36', '2', 'individual', '123', 0, '2019-07-07 09:27:52'),
(2, 'Meeting', 'All', 'All', 'All', 'Parents Meeting is Scheduled on 15th July 2019 at 11 am.', 0, '2019-07-11 16:42:55'),
(3, 'Performance', '65', '3', 'individual', 'Last week performance was well keep it up.', 0, '2019-07-11 17:08:05'),
(4, 'rohn', '68', '2', 'individual', 'demo', 0, '2019-07-13 12:20:59'),
(5, 'kkk', '68', '2', 'individual', 'emo d3mo demo demo', 0, '2019-07-13 12:24:00'),
(6, 'test', '68', '2', 'individual', 'demo', 0, '2019-07-13 12:27:39'),
(7, 'test', '68', '2', 'individual', 'demo test', 0, '2019-07-13 12:30:25'),
(8, 'Demo', '68', '2', 'individual', 'De llll', 0, '2019-07-13 12:34:05'),
(9, 'oticw', '68', '2', 'individual', 'demo demo demo', 0, '2019-07-13 12:34:39'),
(10, 'Test', '68', '2', 'individual', 'Demo Demo Demo DEmo', 0, '2019-07-13 13:00:14'),
(11, 'Test', '68', '2', 'individual', 'Demo', 0, '2019-07-13 13:03:40'),
(12, 'test', '68', '2', 'individual', 'demi', 0, '2019-07-13 13:07:12'),
(13, 'demo', '68', '2', 'individual', 'demo test', 0, '2019-07-13 13:09:35'),
(14, 'demo', '68', '2', 'individual', 'demo test', 0, '2019-07-13 13:11:38'),
(15, 'demo', '68', '2', 'individual', 'test', 0, '2019-07-13 13:13:11'),
(16, 'test', '68', '2', 'individual', 'test', 0, '2019-07-13 13:16:53'),
(17, 'jjjj', '68', '2', 'individual', 'okkkooo  kkkk kkk  k', 0, '2019-07-13 13:21:48'),
(18, 'jjjj', '68', '2', 'individual', 'okkkooo  kkkk kkk  k', 0, '2019-07-13 13:23:11'),
(19, 'ko', '68', '2', 'individual', 'koooo', 0, '2019-07-13 13:25:49'),
(20, 'kook', '68', '2', 'individual', 'weed drdrddrdr se', 0, '2019-07-13 13:28:08'),
(21, 'kook', '68', '2', 'individual', 'weed drdrddrdr se', 0, '2019-07-13 13:28:37'),
(22, 'kook', '68', '2', 'individual', 'weed drdrddrdr se', 0, '2019-07-13 13:28:59'),
(23, 'kook', '68', '2', 'individual', 'weed drdrddrdr se', 0, '2019-07-13 13:29:22'),
(24, 'okokok', '68', '2', 'individual', 'demo momm moomom', 0, '2019-07-13 13:31:19'),
(25, 'demo', '68', '2', 'individual', 'demo demo', 0, '2019-07-13 15:15:16'),
(26, 'demo', '68', '2', 'individual', 'demo demo', 0, '2019-07-13 15:21:42'),
(27, 'ok demoq', '68', '2', 'individual', 'demo', 0, '2019-07-13 15:57:59'),
(28, 'ok demoq', '68', '2', 'individual', 'demo', 0, '2019-07-13 16:00:00'),
(29, 'Invalide', '68', '2', 'individual', 'Demo Demo', 0, '2019-07-13 18:13:11'),
(30, 'valide', '66', '2', 'individual', 'Demo Demo', 0, '2019-07-13 18:13:56'),
(31, 'demo', '66', '2', 'individual', 'demo deo ', 0, '2019-07-13 18:16:58'),
(32, 'okokoko', '68', '2', 'individual', 'demo demo demo ', 0, '2019-07-13 18:56:46'),
(33, 'okokoko', '68', '2', 'individual', 'demo demo demo ', 0, '2019-07-13 19:14:38'),
(34, 'demo', '68', '2', 'individual', 'demooo', 0, '2019-07-13 19:15:45'),
(35, 'demo', '68', '2', 'individual', 'demo', 0, '2019-07-13 19:19:32'),
(36, 'demo', '68', '2', 'individual', 'demo', 0, '2019-07-13 19:22:37'),
(37, 'demo', '68', '2', 'individual', 'dmeo', 0, '2019-07-13 19:23:53'),
(38, 'dmeo', '68', '2', 'individual', 'dmeoo', 0, '2019-07-13 19:29:35'),
(39, 'dmeo', '68', '2', 'individual', 'dmeoo', 0, '2019-07-13 19:41:50'),
(40, 'demo', '68', '2', 'individual', 'demo demo demo', 0, '2019-07-13 19:44:10'),
(41, 'demo', '68', '2', 'individual', 'demo demo', 0, '2019-07-13 20:44:17'),
(42, 'demo', 'All', '3', 'individual', 'demo demo', 0, '2019-07-13 20:50:44'),
(43, 'demo', 'All', '3', 'individual', 'demo demo demo', 0, '2019-07-13 20:56:51'),
(44, 'demo', 'All', '3', 'individual', 'demo dmeo demo', 0, '2019-07-13 20:58:33'),
(45, 'demo', 'All', '3', 'individual', 'demo', 0, '2019-07-13 21:27:27'),
(46, 'demo', 'All', '3', 'individual', 'demo demo demo ', 0, '2019-07-13 21:36:58'),
(47, 'erty', '70', '3', 'individual', 'dfg', 1, '2019-07-29 17:53:53'),
(48, 'ere', 'All', 'All', 'All', '2e3r', 0, '2019-09-06 15:53:28'),
(49, 'Meeting', '79', '2', 'individual', 'Come', 0, '2019-09-24 16:45:22'),
(50, 'h', '79', '2', 'individual', 'h', 0, '2019-09-24 17:13:53');

-- --------------------------------------------------------

--
-- Table structure for table `fh_student_remark`
--

CREATE TABLE `fh_student_remark` (
  `remark_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `remark_name` int(11) NOT NULL,
  `description` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fh_subject`
--

CREATE TABLE `fh_subject` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `subject_fees` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_subject`
--

INSERT INTO `fh_subject` (`subject_id`, `subject_name`, `subject_fees`, `disable_flag`) VALUES
(2, 'STD X', '18500', 0),
(3, 'STD IX', '14500', 0),
(4, 'STD VIII', '9900', 0),
(5, 'History', '2000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fh_test`
--

CREATE TABLE `fh_test` (
  `test_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `test_name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `chapter` varchar(255) NOT NULL,
  `marks` int(11) NOT NULL,
  `test_date` varchar(255) NOT NULL,
  `from_time` varchar(255) NOT NULL,
  `to_time` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_test`
--

INSERT INTO `fh_test` (`test_id`, `batch_id`, `test_name`, `subject`, `chapter`, `marks`, `test_date`, `from_time`, `to_time`, `disable_flag`, `added_date`) VALUES
(1, 3, 'History', 'STD X ', '1-2', 20, '2019-07-11', '7pm', '8pm', 1, '2019-07-11 16:47:00'),
(2, 3, 'weekely', 'History ', '1-2', 20, '2019-07-11', '7pm', '8pm', 0, '2019-07-11 16:48:12'),
(3, 4, 'test', 'Maths', '2', 30, '2019-07-15', '1:00', '3:00', 0, '2019-07-14 11:19:33'),
(4, 2, 'Weekend ', 'Sci', '1&2', 30, '2019-07-16', '7', '8', 0, '2019-07-14 21:03:01'),
(5, 2, 'weekely', 'History', '1-2', 20, '2019-07-11', '7pm', '8pm', 0, '2019-07-19 12:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `fh_track_test`
--

CREATE TABLE `fh_track_test` (
  `track_test_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `obtained_marks` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_track_test`
--

INSERT INTO `fh_track_test` (`track_test_id`, `test_id`, `user_id`, `batch_id`, `obtained_marks`, `total_marks`, `remark`, `disable_flag`, `added_date`) VALUES
(1, 2, 65, 3, 15, 20, '', 0, '2019-07-11 16:48:46');

-- --------------------------------------------------------

--
-- Table structure for table `fh_user`
--

CREATE TABLE `fh_user` (
  `user_id` int(11) NOT NULL,
  `roll_no` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `parent_name_1` varchar(255) NOT NULL,
  `parent_name_2` varchar(255) NOT NULL,
  `p_mobile_no_1` varchar(255) NOT NULL,
  `p_mobile_no_2` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(255) NOT NULL,
  `batch_time` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fcm_id` varchar(255) NOT NULL,
  `device_type` varchar(255) NOT NULL,
  `version_code` varchar(255) NOT NULL,
  `version_name` varchar(255) NOT NULL,
  `sms_count` int(11) NOT NULL DEFAULT '0',
  `credit_sms` int(11) NOT NULL DEFAULT '0',
  `admin_disabled` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_user`
--

INSERT INTO `fh_user` (`user_id`, `roll_no`, `f_name`, `l_name`, `email_id`, `user_name`, `password`, `role`, `gender`, `mobile_no`, `dob`, `parent_name_1`, `parent_name_2`, `p_mobile_no_1`, `p_mobile_no_2`, `address`, `course_id`, `course_name`, `batch_id`, `batch_name`, `batch_time`, `subject`, `disable_flag`, `reg_date`, `fcm_id`, `device_type`, `version_code`, `version_name`, `sms_count`, `credit_sms`, `admin_disabled`) VALUES
(1, 0, 'Wisdom', 'Admin', '', 'admin', '123456', 'admin', '', '', '', '', '', '9999999999', '', '', 0, '', 0, '', '', '', 0, '2019-06-13 17:22:38', '', '', '', '', 0, 0, 0),
(35, 1, 'SUDHANSHU', 'MUNI', '', 'W-SUDHANSHU-1', '362243', 'student', 'Male', '9321302424', '2006-02-19', 'SANATAN MUNI', '', '9892958969', '9969267991', 'A.10 GOLDEN CHAWL L.B.S NAGAR QOFEET ROAD SAKINAKA MUMBAI ,400072', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-06-25 12:28:28', '', '', '', '', 0, 0, 0),
(36, 2, 'HARISH ', 'GUPTA', '', 'W-HARISH -36', '547220', 'student', 'Male', '9321302424', '2005-11-24', 'SOMNATH GUPTA', '', '9702533221', '8355811280', 'NETAJI NAER  HILL NO .3 JAI DURGA H.S.G. SOCIETY ROOM NO 16 CHWAL NO.G  SAKINAKA-400072', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-06-25 12:49:03', '', '', '', '', 0, 0, 0),
(37, 1, 'SHIFA', 'Shaikh', '', 'W-SHIFA-1', '313769', 'student', 'Female', '9321302424', '2006-03-29', 'HAFIZ SHAIKH', '', '9619436310', '9137178324', 'GOLD PLAZA BLDG 2nd FLOR ROOM NO 201 KURLA WEST MUMBAI-72', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-25 12:59:08', '', '', '', '', 0, 0, 0),
(38, 2, 'MANTHAN ', 'KONGIL', '', 'W-MANTHAN -38', '299526', 'student', 'Male', '9321302424', '2006-06-04', 'RAMESH ARJUN ', '', '8070003402', '9152736926', 'SAIKURPA CHAWL TANAJI OLOMPIK  KRIDA MANDAL JUNI BAVADI SHIVAJI NAGAR  KURLA SAKINA MAHARASHTRA MUMBAI 400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-25 13:13:43', '', '', '', '', 0, 0, 0),
(39, 3, 'ANJALI', 'Maurya', '', 'W-ANJALI-37', '864210', 'student', 'Female', '9321302424', '2006-04-22', 'UMESH MAURY', '', '9819257366', '9768643208', 'G.14/1 JAIDURGACHS NETAJI NAGAR KHADI NO.3 90FT ROAD SAKINAKA', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-06-25 13:19:34', '9a10ca0f-3ef2-4809-bd9f-3faca3352e7e', '', '', '', 0, 0, 0),
(40, 4, 'VAISHNAVI', 'PANIGRAHI', '', 'W-VAISHNAVI-40', '005495', 'student', 'Female', '9321302424', '2005-09-01', 'BALRAM PANIGRAHI', '', '9819947754', '9004147958', 'ROOM NO 3 FIRST FLOOR SAINATH SOC.. TILAK NGA, SAKINAKA MUMBAI ,400072', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-06-25 13:30:02', '07fff7a1-35d2-4242-945c-a3839a013e72', '', '', '', 0, 0, 0),
(41, 3, 'NIDA', 'ANSARI', '', 'W-NIDA-39', '723206', 'student', 'Female', '9321302424', '2005-05-18', 'MOHD.HANIF ANSARI', '', '7506115406', '9619254018', 'ROOM NO.A/1,CHAWDHARY,  SADAN ,NEAR  EDEN HIGH SCHOOL ,SAFEED POOL MUMBAI  400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-26 13:32:54', '', '', '', '', 0, 0, 0),
(42, 4, 'SHIFA', 'Shaikh', '', 'W-SHIFA-42', '313769', 'student', 'Female', '9321302424', '2006-03-29', 'MOHD.HAFIZ SHAIKH', '', '9619436310', '9137178324', 'GOLD PLAZA BLDG 2nd FLOOR RM NO.201 KAJUPADA PIPELINE ROAD KURLA [W] MUMBAI 400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 1, '2019-06-26 13:39:44', '', '', '', '', 0, 0, 0),
(43, 5, 'MANTHAN', 'KOGIL', '', 'W-MANTHAN-43', '646487', 'student', 'Male', '9321302424', '2006-06-04', 'RAMESH ARJUN  KONGIL', '', '8070034029', '9152736926', 'SAIKURPA CHAWL TANAJI OLOMPIK  KRIDA MANDAL JUNI BAVADI SHIVAJI NAGAR  SAKINAKA MUMBAI MAHARASHTRA 400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-26 14:06:04', '', '', '', '', 0, 0, 0),
(44, 6, 'ARHAM', 'KHAN', '', 'W-ARHAM-44', '148411', 'student', 'Male', '9321302424', '2006-02-07', 'ZAHID KHAN', '', '9594448601', '9136339795', 'B/701 PARAMOUNT BLDG OPP D\'SOUZA SAKINAKA MUMBAI ,400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-26 14:11:42', '07fff7a1-35d2-4242-945c-a3839a013e72', '', '', '', 0, 0, 0),
(45, 7, 'MITESH', 'KAMBLE', '', 'W-MITESH-45', '992649', 'student', 'Male', '9321302424', '2005-04-23', 'BABA SAHEB MANAJI KAMBLE', '', '9920009862', '', 'SAI NATH CHAWL ,SAFED POOI KURLA', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-27 10:05:45', '', '', '', '', 0, 0, 0),
(46, 5, 'MITESH', 'KAMBLE', '', 'W-MITESH-41', '172056', 'student', 'Male', '9321302424', '2005-04-23', 'BABA SAHEB MANAJI KAMBLE', '', '9920098962', '', 'SAI NATH CHAWL ,SAFED POOI KURLA', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-06-27 10:10:03', '', '', '', '', 0, 0, 0),
(47, 6, 'URVI', 'GUPTA', '', 'W-URVI-47', '798637', 'student', 'Female', '9321302424', '2006-06-02', 'KESHAV PRASAD GUPTA', '', '9029516593', '8419951296', 'R.NO.6 ,CHAWL DEVIL KOSTAL ,KAJUPADA PIPELINE KURLA [W]', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-06-27 10:16:30', '', '', '', '', 0, 0, 0),
(48, 8, 'MUSKAN', 'ANSARI', '', 'W-MUSKAN-46', '477261', 'student', 'Female', '9321302424', '2005-12-15', 'JAMSHED ANSARI', '', '8180258126', '9699801548', 'ROOM NO.3 BHARAT CHAWL  SHIVAJI NAGAR   JARIMARI K.A. ROAD KURLA MUMBAI. 400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-27 10:43:36', '', '', '', '', 0, 0, 0),
(49, 9, 'REHAN', 'SHAIKH', '', 'W-REHAN-49', '593016', 'student', 'Male', '9321302424', '2005-12-25', 'SHAIKH MEHOOB ALI', '', '9594708786', '9664928786', 'ROOM NO.23 OPP DR.GALA KAJUPADA  KURLA ANDHERI ROAD MUMBAI .400072', 3, 'STD IX', 4, 'EVENING 1', '4:00 to 6:00', 'STD IX', 0, '2019-06-27 10:56:25', 'f66035ec-2ac0-4d7c-b78b-1d60abf5dd03', '', '', '', 0, 0, 0),
(55, 2, 'FURQAN', 'SAYYED', '', 'W-FURQAN-1', '852405', 'student', 'Male', '9321302424', '2002-09-24', 'JAMIL UDDIN SAYYED', '', '9819612736', '9967855873', 'R/12 ,KHAN CHAWL ,KHADI  NO.3 ,90 FEET ROAD   SAKINAKA', 2, 'STD X', 0, 'None', '', 'STD X', 1, '2019-06-29 12:15:15', '', '', '', '', 0, 0, 0),
(57, 2, 'Rohan', 'Naik', '', 'W-Rohan-57', '247937', 'student', 'Male', '9999999999', '2019-07-02', 'P', '', '9967077027', '', 'thanr ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-08 04:22:43', '', '', '', '', 0, 0, 0),
(59, 3, 'darsh', 'yadav', '', 'W-darsh-58', '692854', 'student', 'Male', '', '2019-07-04', 'p1', '', '9967856357', '', 'gfd ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-08 07:24:31', '', '', '', '', 0, 0, 0),
(60, 4, 'aarsh', 'yadav', '', 'W-aarsh-60', '976578', 'student', 'Female', '', '2019-07-04', 'aa', '', '9860129876', '', 'A ', 3, 'STD IX', 3, 'AFTERNOON', '2:30 to 4:30', 'STD IX', 1, '2019-07-08 10:24:18', '', '', '', '', 0, 0, 0),
(61, 5, 'darsh', 'komu', '', 'W-darsh-61', '258520', 'student', 'Male', '', '2019-07-05', 'p1', '', '8652453473', '', 'gfd ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-08 10:28:12', '', '', '', '', 0, 0, 0),
(62, 6, 'darsh', 'komu', '', 'W-darsh-62', '289463', 'student', 'Male', '', '2019-06-13', 'gf', '', '8928394609', '', 'mumbra ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-08 10:31:21', '', '', '', '', 0, 0, 0),
(63, 7, 'darsh', 'yadav', '', 'W-darsh-63', '692854', 'student', 'Male', '', '2019-07-05', 'p1', '', '9967856357', '', 'mumbra ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-08 10:46:09', '', '', '', '', 0, 0, 0),
(64, 8, 'darshan', 'komu', '', 'W-darshan-64', '289463', 'student', 'Male', '', '2019-06-01', 'p1', '', '8928394609', '', 's ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-08 10:52:51', '', '', '', '', 0, 0, 0),
(65, 1, 'Rahul', 'Yadav', '', 'W-Rahul-1', '990376', 'student', 'Male', '', '2019-07-05', 'gf', '', '9967856357', '', 's ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-11 10:37:00', '472a7bb1-e996-4363-854a-49572d207d0b', '', '', '', 0, 0, 0),
(66, 5, 'Rahul ', 'Yadav', '', 'W-Rahul -48', '049397', 'student', 'Male', '9967077027', '2019-07-12', 'p', '', '9967077027', '', 'thane ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-07-12 21:04:37', '', '', '', '', 0, 0, 0),
(67, 5, 'Rohan', 'Naik', '', 'W-Rohan-67', '049397', 'student', 'Male', '9999999999', '2019-07-04', 'p', '', '9967077027', '', 'thane ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-07-12 21:06:55', '', '', '', '', 0, 0, 0),
(68, 8, 'Rohan', 'Naik', '', 'W-Rohan-68', '049397', 'student', 'Male', '9999999999', '2019-07-04', 'p', '', '9967077027', '', 'thane ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-07-12 21:08:02', '', '', '', '', 0, 0, 0),
(69, 2, 'nagu', 'yadav', '', 'W-nagu-66', '732189', 'student', 'Male', '', '2019-07-05', 'gf', '', '9967856357', '', 'abc ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-13 06:10:06', '', '', '', '', 0, 0, 0),
(70, 2, 'Rahul', 'Yadav', '', 'W-Rhaul-70', '049397', 'student', 'Male', '9990999099', '2019-07-10', 'Papa', '', '9967077027', '', 'thane ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 1, '2019-07-13 15:18:46', '', '', '', '', 0, 0, 0),
(71, 5, 'Rahul', 'yadav', '', 'W-Rahul-69', '668278', 'student', 'Male', '', '2019-06-11', 'gf', '', '9860129876', '', 'oiuy ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-07-19 06:34:54', '', '', '', '', 0, 0, 0),
(72, 5, 'Rahul', 'yadav', '', 'W-Rahul-72', '668278', 'student', 'Male', '', '2019-06-11', 'gf', '', '9860129876', '', 'oiuy ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-07-19 06:35:02', '', '', '', '', 0, 0, 0),
(73, 5, 'vicky', 'jhg', '', 'W-vicky-48', '464465', 'student', 'Male', '9999999999', '2019-06-04', 'likjh', '', '9768825774', '', 'wef ewe', 3, 'STD IX', 2, 'MORNING', '9 to 11', 'STD IX', 1, '2019-09-06 10:07:58', '', '', '', '', 0, 0, 0),
(74, 1, 'Rahul', 'yadav', '', 'W-Rahul-74', '101783', 'student', 'Male', '', '2019-08-28', 'gf', '', '9967856357', '', 'sakinaka ', 4, 'STD VIII', 2, 'MORNING', '9 to 11', 'STD VIII', 1, '2019-09-06 10:17:39', '', '', '', '', 0, 0, 0),
(75, 1, 'Rahul', 'yadav', '', 'W-Rahul-75', '101783', 'student', 'Male', '', '2019-08-28', 'gf', '', '9967856357', '', 'sakinaka ', 4, 'STD VIII', 2, 'MORNING', '9 to 11', 'STD VIII', 1, '2019-09-06 10:17:51', '', '', '', '', 0, 0, 0),
(76, 1, 'Rahul', 'yadav', '', 'W-Rahul-76', '101783', 'student', 'Male', '', '2019-08-28', 'gf', '', '9967856357', '', 'sakinaka ', 4, 'STD VIII', 2, 'MORNING', '9 to 11', 'STD VIII', 1, '2019-09-06 10:17:59', '', '', '', '', 0, 0, 0),
(77, 1, 'Vicky ', 'Jha', '', 'W-Vicky -76', '464465', 'student', 'Male', '', '2019-09-06', 'Mukesh', '', '9967856357', '9967856357', 'Vashi ', 2, 'STD X', 6, 'qw', '9 to 11', 'STD X', 1, '2019-09-06 16:47:15', '', '', '', '', 0, 0, 0),
(78, 35, 'Rohan', 'naik', '', 'W-Yadav-76', '096528', 'student', 'Male', '', '2019-09-08', 'hh', 'dnb', '9967077027', '9967077027', 'Thane ', 2, 'STD X', 6, 'qw', '9 to 11', 'STD X', 1, '2019-09-08 09:23:12', '', '', '', '', 0, 0, 0),
(79, 1, 'Vicky', 'Jha', '', 'W-Vicky-1', '585246', 'student', 'Male', '', '2019-09-08', 'Mukesh', '', '9768825774', '', 'Vashi ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 0, '2019-09-08 14:13:01', '', '', '', '', 0, 0, 0),
(80, 1, 'Rahulyadav', 'yadav', '', 'W-Rahulyadav-80', '653460', 'student', 'Male', '', '2019-09-08', 'rrrr', '', '8080830233', '', 'Thane ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-09-08 14:24:56', '', '', '', '', 0, 0, 0),
(81, 1, 'Rahul ', 'Yadav', '', 'W-Rahul -80', '690676', 'student', 'Male', '', '2019-09-14', 'kkk', '', '9967856357', '', 'kk ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 0, '2019-09-14 07:16:10', '', '', '', '', 0, 0, 0),
(82, 1, 'vicky', 'jha', '', 'W-vicky-82', '585246', 'student', 'Male', '9768825774', '2019-09-24', 'Abc', '', '9768825774', '', 'vashi ', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 1, '2019-09-24 11:16:34', '', '', '', '', 0, 0, 0),
(83, 1, 'Rahul ', 'Yadav', '', 'W-Rahul -82', '690676', 'student', 'Male', '9967856357', '2019-10-07', 'p1', '', '9967856357', '', 'vashi sakinkaa', 2, 'STD X', 2, 'MORNING', '9 to 11', 'STD X', 0, '2019-10-09 03:58:29', '', '', '', '', 0, 0, 0),
(84, 2, 'vicky', 'jha', '', 'W-vicky-1', '690676', 'student', 'Male', '9768825774', '2019-10-03', 'a', '', '9967856357', '', 'vashi ', 2, 'STD X', 3, 'AFTERNOON', '2:30 to 4:30', 'STD X', 0, '2019-10-13 14:09:31', '', '', '', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `studentdetails`
--

CREATE TABLE `studentdetails` (
  `id` int(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `student_std` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fh_assignment`
--
ALTER TABLE `fh_assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `fh_attendance`
--
ALTER TABLE `fh_attendance`
  ADD PRIMARY KEY (`atten_id`);

--
-- Indexes for table `fh_batch`
--
ALTER TABLE `fh_batch`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `fh_course`
--
ALTER TABLE `fh_course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `fh_fees`
--
ALTER TABLE `fh_fees`
  ADD PRIMARY KEY (`fees_id`);

--
-- Indexes for table `fh_imp_content`
--
ALTER TABLE `fh_imp_content`
  ADD PRIMARY KEY (`imp_id`);

--
-- Indexes for table `fh_notice`
--
ALTER TABLE `fh_notice`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `fh_student_remark`
--
ALTER TABLE `fh_student_remark`
  ADD PRIMARY KEY (`remark_id`);

--
-- Indexes for table `fh_subject`
--
ALTER TABLE `fh_subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `fh_test`
--
ALTER TABLE `fh_test`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `fh_track_test`
--
ALTER TABLE `fh_track_test`
  ADD PRIMARY KEY (`track_test_id`);

--
-- Indexes for table `fh_user`
--
ALTER TABLE `fh_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `studentdetails`
--
ALTER TABLE `studentdetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fh_assignment`
--
ALTER TABLE `fh_assignment`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `fh_attendance`
--
ALTER TABLE `fh_attendance`
  MODIFY `atten_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `fh_batch`
--
ALTER TABLE `fh_batch`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fh_course`
--
ALTER TABLE `fh_course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fh_fees`
--
ALTER TABLE `fh_fees`
  MODIFY `fees_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `fh_imp_content`
--
ALTER TABLE `fh_imp_content`
  MODIFY `imp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fh_notice`
--
ALTER TABLE `fh_notice`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `fh_student_remark`
--
ALTER TABLE `fh_student_remark`
  MODIFY `remark_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fh_subject`
--
ALTER TABLE `fh_subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fh_test`
--
ALTER TABLE `fh_test`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fh_track_test`
--
ALTER TABLE `fh_track_test`
  MODIFY `track_test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fh_user`
--
ALTER TABLE `fh_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `studentdetails`
--
ALTER TABLE `studentdetails`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
