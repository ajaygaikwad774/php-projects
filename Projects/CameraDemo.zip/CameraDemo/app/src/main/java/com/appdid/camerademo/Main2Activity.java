package com.appdid.camerademo;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.os.FileUriExposedException;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class Main2Activity extends AppCompatActivity {
    Button btntakevideo;
    VideoView imgdispvideo;
    private static final int VIDEO_CAPTURE = 500;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        imgdispvideo = (VideoView) this.findViewById(R.id.imgdispvideo);
        btntakevideo = (Button) this.findViewById(R.id.btntakevideo);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        btntakevideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)throws FileUriExposedException{
                Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takeVideoIntent, VIDEO_CAPTURE);
                }
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == VIDEO_CAPTURE && resultCode == RESULT_OK) {
            imgdispvideo.setVisibility(View.VISIBLE);
            assert imgdispvideo!=null;
            Uri videoUri =data.getData();
            imgdispvideo.setVideoURI(videoUri);
            imgdispvideo.setMediaController(new MediaController(getApplicationContext()));
            imgdispvideo.requestFocus();
            imgdispvideo.start();
        }
    }
}
