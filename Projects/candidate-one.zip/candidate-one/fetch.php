

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<table>
	<tr>
		<th> Ip Address </th>
		<th> Count </th>
	</tr>

<?php 

    $sql = "SELECT ip_address,count from  poll";

    $result = mysqli_query($con,$sql);
  while ($row = mysqli_fetch_array($result)) {
     ?>

     <tr>
     	<td><?php echo $row['ip_address']; ?></td>
     	<td><?php echo $row['count']; ?></td>
     </tr>
     <?php
  }

?>

</table>
</body>
</html>