<!DOCTYPE html>
<html class="no-js" lang="en">
    
<!-- Mirrored from demo.hasthemes.com/ftage-preview/ftage/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Jan 2020 05:21:36 GMT -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Home - Ftage</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="apple-touch-icon" href="#">
		<link rel="shortcut icon" type="image/x-icon" href="#">
        <!-- Place favicon.ico in the root directory -->
		
		
		<!-- all css here -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/icofont.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/meanmenu.min.css">
		<link rel="stylesheet" href="css/plugins.css">
        <link rel="stylesheet" href="css/shortcode/shortcodes.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">
		
		<!-- Revolution Slider CSS -->
		<link href="assets/revolution/css/settings.css" rel="stylesheet">
		<link href="assets/revolution/css/navigation.css" rel="stylesheet">
		<link href="assets/revolution/custom-setting.css" rel="stylesheet">

        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Page Wraper Here Start -->
        <div class="page-wraper" id="main-home">
			<!-- Header Area Start -->
			<header>
				<!-- Header Menu Area Start -->
				<div class="header-menu mt-50" id="sticky-header">
					<div class="container">
						<div class="row">
							<!-- Logo Area Start -->
							<div class="col-lg-4 col-md-12 col-sm-12">
								<div class="logo-img">
									
								</div>
							</div>
							<!-- Logo Area End -->
							<!-- Menu Area Start -->
						
							<!-- Header Menu Area Start -->
						</div>
					</div>
					<!-- MOBILE-MENU-AREA START --> 
					<div class="mobile-menu-area">
						<div class="container">
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="mobile-area">
										<div class="mobile-menu">
											<nav id="mobile-nav">
												<ul>
													<li class="active"><a href="index.html">Home</a>
														<ul>
															<li><a href="#">Film Studio</a>
																<ul class="sub-menu">
																	<li><a href="index.html">Light Version</a></li>
																	<li><a href="index-4.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="#">Film Production</a>
																<ul class="sub-menu">
																	<li><a href="index-2.html">Light Version</a></li>
																	<li><a href="index-2-black.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="index-3.html">Film Agency</a></li>
															<li><a href="#">Video & News</a>
																<ul class="sub-menu">
																	<li><a href="index-video.html">Light Version</a></li>
																	<li><a href="index-video-black.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="#">Actor Portfolio</a>
																<ul class="sub-menu">
																	<li><a href="index-actor.html">Light Version</a></li>
																	<li><a href="index-actor-black.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="#">Movie Production</a>
																<ul class="sub-menu">
																	<li><a href="index-production.html">Light Version</a></li>
																	<li><a href="index-production-black.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="#">Movie Studio</a>
																<ul class="sub-menu">
																	<li><a href="index-production-two.html">Light Version</a></li>
																	<li><a href="index-production-two-black.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="#">Campaign</a>
																<ul class="sub-menu">
																	<li><a href="index-campaign.html">Light Version</a></li>
																	<li><a href="index-campaign-black.html">Dark Version</a></li>
																</ul>
															</li>
															<li><a href="index-festival.html">Film Festival</a></li>
														</ul>
													</li>
													<li><a href="about-us.html">About</a></li>
													<li><a href="service.html">Services</a>
														<ul>
															<li><a href="service.html">Our Services</a></li>
															<li><a href="service-two.html">Our Services Two</a></li>
															<li><a href="service-details.html">Services Details</a></li>
														</ul>
													</li>
													<li><a href="gallery-three-container-style-two.html">Gallery </a>
														<ul>
															<li><a href="gallery-masonry.html">Gallery Masonary</a></li>
															<li><a href="gallery-three-column-container.html">Gallery 3 Column V1</a></li>
															<li><a href="gallery-three-container-style-two.html">Gallery 3 Column V2</a></li>
															<li><a href="gallery-three-column-full-width.html">Gallery 3 Column Full</a></li>
														</ul>
													</li>
													<li><a href="portfolio-2-column.html"> Portfolio </a>
														<ul>
															<li><a href="portfolio-2-column.html">Portfolio 2 Column</a></li>
															<li><a href="portfolio-3-column.html">Portfolio 3 Column</a></li>
															<li><a href="portfolio-details.html">Portfolio Details</a></li>
														</ul>
													</li>
													<li><a href="news.html"> News </a>
														<ul>
															<li><a href="news.html">News Single Box</a></li>
															<li><a href="news-details.html">News Right Sidebar</a></li>
															<li><a href="news-details-left.html">News Left Sidebar</a></li>
															<li><a href="news-no-sidebar.html">News No Sidebar</a></li>
														</ul>
													</li>
													<li><a href="#">Pages</a>
														<ul>
															<li><a href="about-us.html">About US</a></li>
															<li><a href="pricing.html">Pricing Table</a></li>
															<li><a href="gallery-three-column-container.html">Our Gallery</a></li>
															<li><a href="contact-us.html">Contact</a></li>
															<li><a href="404.html">404 Error</a></li>
															<li><a href="faq.html">Faq Page</a></li>
														</ul>
													</li>
													<li><a href="contact-us.html">Contact</a></li>
												</ul>
											</nav>
										</div>	
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- MOBILE-MENU-AREA END  -->
				</div>
				<!-- Header Menu Area Start -->
				<!-- Slider Area Start -->
				<div class="slider-area">
					<div id="rev_slider_6_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="duotone1" data-source="gallery" style="background:transparent;padding:0px;">
					<!-- START REVOLUTION SLIDER 5.4.7 fullscreen mode -->
						<div id="rev_slider_6_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.7">
							<ul>	<!-- SLIDE  -->
							    <li data-index="rs-15" data-transition="cube" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="img/slider/home-one/100x50_1.png"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="300" data-fsslotamount="7" data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
									<!-- MAIN IMAGE -->
							        <img src="img/slider/home-one/dummy.png"  alt=""  data-lazyload="img/slider/home-one/1.png" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="3" class="rev-slidebg" data-no-retina>
									<!-- LAYERS -->
									<!-- LAYER NR. 1 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-15-layer-2" 
										data-x="['center','center','center','center']" data-hoffset="['0','6','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['30','46','64','0']" 
										data-fontsize="['16','17','17','15']"
										data-lineheight="['24','26','26','24']"
										data-width="['893','630','480','300']"
										data-height="['none','105','none','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":700,"speed":1000,"frame":"0","from":"y:10px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 5; min-width: 893px; max-width: 893px; white-space: normal; font-size: 16px; line-height: 24px; font-weight: 400; color: rgba(255,255,255,1); font-family:Open Sans;"> </div>
									<!-- LAYER NR. 2 -->
									<div class="tp-caption rev-btn rs-parallaxlevel-4" 
										id="slide-15-layer-4" 
										data-x="['center','center','center','center']" data-hoffset="['0','-9','2','7']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['126','138','185','131']" 
										data-fontsize="['14','15','15','15']"
										data-lineheight="['45','40','40','40']"
										data-fontweight="['500','700','700','700']"
										data-color="['rgb(255,255,255)','rgba(0,0,0,1)','rgba(0,0,0,1)','rgba(0,0,0,1)']"
										data-letterspacing="['1','','','']"
										data-width="['158','none','none','none']"
										data-height="none"
										data-whitespace="nowrap"
							            data-type="button" 
										data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":"","speed":"300","ease":"Linear.easeNone"}]'
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":900,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;skX:-18px;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(255,255,255);bg:rgb(0,0,0);bs:solid;bw:0 0 0 0;transition:all 0.3s ease-in-out;"}]'
							            data-textAlign="['left','left','left','left']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[30,30,30,30]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[30,30,30,30]"
							            style="z-index: 6;  white-space: nowrap; font-size: 14px; line-height: 45px; font-weight: 500; color: #ffffff; letter-spacing:1px; font-family:Roboto;text-transform:uppercase;background-color:rgb(226,167,80);border-color:rgba(0,0,0,1);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;transition:all 0.3s ease-in-out;cursor:pointer;">Vote Me</div>
									<!-- LAYER NR. 3 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-15-layer-8" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','3']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-107','-112','-74','-130']" 
										data-fontsize="['30','30','28','16']"
										data-lineheight="['70','30','50','30']"
										data-fontweight="['400','700','700','700']"
										data-letterspacing="['6','7','3','1']"
										data-width="['333','640','480','300']"
										data-height="['73','none','none','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 7; min-width: 333px; max-width: 333px; max-width: 73px; max-width: 73px; white-space: normal; font-size: 30px; line-height: 70px; font-weight: 400; color: rgba(255,255,255,1); letter-spacing: 6px;font-family:Roboto;text-transform:uppercase;">NMMCSFF <span style="color:#e2a750">2020 </span> </div>
									<!-- LAYER NR. 4 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-15-layer-9" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','18','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-45','-52','-23','-100']" 
										data-fontsize="['60','50','35','20']"
										data-lineheight="['70','60','50','30']"
										data-letterspacing="['3','5','0','1']"
										data-width="['808','735','509','384']"
										data-height="['71','none','51','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 8; min-width: 808px; max-width: 804px; max-width: 71px; max-width: 71px; white-space: normal; font-size: 60px; line-height: 70px; font-weight: 700; color: rgba(255,255,255,1); letter-spacing: 3px;font-family:Roboto;text-transform:uppercase;">ShortFilm <span style="color:#e2a750"> Festival </span>  </div>
								</li>
								<!-- SLIDE  -->
							    <li data-index="rs-16" data-transition="cube" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="img/slider/home-one/100x50_2.png"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
									<!-- MAIN IMAGE -->
							        <img src="img/slider/home-one/dummy.png"  alt=""  data-lazyload="img/slider/home-one/2.png" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="3" class="rev-slidebg" data-no-retina>
									<!-- LAYERS -->

									<!-- LAYER NR. 5 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-16-layer-2" 
										data-x="['center','center','center','center']" data-hoffset="['0','6','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['30','46','64','0']" 
										data-fontsize="['16','17','17','15']"
										data-lineheight="['24','26','26','24']"
										data-width="['893','630','480','300']"
										data-height="['none','105','none','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":700,"speed":1000,"frame":"0","from":"y:10px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 5; min-width: 893px; max-width: 893px; white-space: normal; font-size: 16px; line-height: 24px; font-weight: 400; color: rgba(255,255,255,1); font-family:Open Sans;"> </div>

									<!-- LAYER NR. 6 -->
									<div class="tp-caption rev-btn rs-parallaxlevel-4" 
										id="slide-16-layer-4" 
										data-x="['center','center','center','center']" data-hoffset="['0','-9','2','7']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['126','138','185','131']" 
										data-fontsize="['14','15','15','15']"
										data-lineheight="['45','40','40','40']"
										data-fontweight="['500','700','700','700']"
										data-color="['rgb(255,255,255)','rgba(0,0,0,1)','rgba(0,0,0,1)','rgba(0,0,0,1)']"
										data-letterspacing="['1','','','']"
										data-width="['158','none','none','none']"
										data-height="none"
										data-whitespace="nowrap"
							            data-type="button" 
										data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":"","speed":"300","ease":"Linear.easeNone"}]'
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":900,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;skX:-18px;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(255,255,255);bg:rgb(0,0,0);bs:solid;bw:0 0 0 0;transition:all 0.3s ease-in-out;"}]'
							            data-textAlign="['left','left','left','left']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[30,30,30,30]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[30,30,30,30]"
							            style="z-index: 6;  white-space: nowrap; font-size: 14px; line-height: 45px; font-weight: 500; color: #ffffff; letter-spacing: 1px;font-family:Roboto;text-transform:uppercase;background-color:rgb(226,167,80);border-color:rgba(0,0,0,1);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;transition:all 0.3s ease-in-out;cursor:pointer;">Vote Me</div>
									<!-- LAYER NR. 7 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-16-layer-8" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','3']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-107','-112','-74','-130']" 
										data-fontsize="['30','30','28','16']"
										data-lineheight="['70','30','50','30']"
										data-fontweight="['400','700','700','700']"
										data-letterspacing="['6','7','3','1']"
										data-width="['333','640','480','300']"
										data-height="['73','none','none','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 7; min-width: 333px; max-width: 333px; max-width: 73px; max-width: 73px; white-space: normal; font-size: 30px; line-height: 70px; font-weight: 400; color: rgba(255,255,255,1); letter-spacing: 6px;font-family:Roboto;text-transform:uppercase;">NMMCSFF <span style="color:#e2a750">2020</span> </div>
									<!-- LAYER NR. 8 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-16-layer-9" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','18','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-45','-52','-23','-100']" 
										data-fontsize="['60','50','35','20']"
										data-lineheight="['70','60','50','30']"
										data-letterspacing="['3','5','0','1']"
										data-width="['804','735','509','384']"
										data-height="['71','none','51','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 8; min-width: 804px; max-width: 804px; max-width: 71px; max-width: 71px; white-space: normal; font-size: 60px; line-height: 70px; font-weight: 700; color: rgba(255,255,255,1); letter-spacing: 3px;font-family:Roboto;text-transform:uppercase;">ShortFilm  <span style="color:#e2a750">Festival</span> </div>
								</li>
								<!-- SLIDE  -->
							    <li data-index="rs-17" data-transition="cube" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="img/slider/home-one/100x50_3.png"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
									<!-- MAIN IMAGE -->
							        <img src="img/slider/home-one/dummy.png"  alt=""  data-lazyload="img/slider/home-one/3.png" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="3" class="rev-slidebg" data-no-retina>
									<!-- LAYERS -->

									<!-- LAYER NR. 9 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-17-layer-2" 
										data-x="['center','center','center','center']" data-hoffset="['0','6','0','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['30','46','64','0']" 
										data-fontsize="['16','17','17','15']"
										data-lineheight="['24','26','26','24']"
										data-width="['893','630','480','300']"
										data-height="['none','105','none','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":700,"speed":1000,"frame":"0","from":"y:10px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 5; min-width: 893px; max-width: 893px; white-space: normal; font-size: 16px; line-height: 24px; font-weight: 400; color: rgba(255,255,255,1); font-family:Open Sans;"> </div>
									<!-- LAYER NR. 10 -->
									<div class="tp-caption rev-btn rs-parallaxlevel-4" 
										id="slide-17-layer-4" 
										data-x="['center','center','center','center']" data-hoffset="['0','-9','2','7']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['126','138','185','131']" 
										data-fontsize="['14','15','15','15']"
										data-lineheight="['45','40','40','40']"
										data-fontweight="['500','700','700','700']"
										data-color="['rgb(255,255,255)','rgba(0,0,0,1)','rgba(0,0,0,1)','rgba(0,0,0,1)']"
										data-letterspacing="['1','','','']"
										data-width="['158','none','none','none']"
										data-height="none"
										data-whitespace="nowrap"
							            data-type="button" 
										data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":"","speed":"300","ease":"Linear.easeNone"}]'
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":900,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;skX:-18px;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(255,255,255);bg:rgb(0,0,0);bs:solid;bw:0 0 0 0;transition:all 0.3s ease-in-out;"}]'
							            data-textAlign="['left','left','left','left']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[30,30,30,30]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[30,30,30,30]"
							            style="z-index: 6; white-space: nowrap; font-size: 14px; line-height: 45px; font-weight: 500; color: #ffffff; letter-spacing: 1px;font-family:Roboto;text-transform:uppercase;background-color:rgb(226,167,80);border-color:rgba(0,0,0,1);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;transition:all 0.3s ease-in-out;cursor:pointer;">Vote Me</div>
									<!-- LAYER NR. 11 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-17-layer-8" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','0','3']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-107','-112','-74','-130']" 
										data-fontsize="['30','30','28','16']"
										data-lineheight="['70','30','50','30']"
										data-fontweight="['400','700','700','700']"
										data-letterspacing="['6','7','3','1']"
										data-width="['354','640','480','300']"
										data-height="['75','none','none','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 7; min-width: 354px; max-width: 354px; max-width: 75px; max-width: 75px; white-space: normal; font-size: 30px; line-height: 70px; font-weight: 400; color: rgba(255,255,255,1); letter-spacing: 6px;font-family:Roboto;text-transform:uppercase;">NMMCSFF  <span style="color:#e2a750">2020</span> </div>
									<!-- LAYER NR. 12 -->
									<div class="tp-caption rs-parallaxlevel-4" 
										id="slide-17-layer-9" 
										data-x="['center','center','center','center']" data-hoffset="['0','0','18','0']" 
										data-y="['middle','middle','middle','middle']" data-voffset="['-45','-52','-23','-100']" 
										data-fontsize="['60','50','35','20']"
										data-lineheight="['70','60','50','30']"
										data-letterspacing="['3','5','0','1']"
										data-width="['804','735','509','384']"
										data-height="['71','none','51','none']"
										data-whitespace="normal"
							            data-type="text" 
										data-responsive_offset="off" 
										data-responsive="off"
							            data-frames='[{"delay":500,"speed":1000,"frame":"0","from":"y:20px;sX:0.9;sY:0.9;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"nothing"}]'
							            data-textAlign="['center','center','center','center']"
							            data-paddingtop="[0,0,0,0]"
							            data-paddingright="[0,0,0,0]"
							            data-paddingbottom="[0,0,0,0]"
							            data-paddingleft="[0,0,0,0]"
							            style="z-index: 8; min-width: 804px; max-width: 804px; max-width: 71px; max-width: 71px; white-space: normal; font-size: 60px; line-height: 70px; font-weight: 700; color: rgba(255,255,255,1); letter-spacing: 3px;font-family:Roboto;text-transform:uppercase;">ShortFilm  <span style="color:#e2a750">Festival</span> </div>
								</li>
							</ul>
							<div style="" class="tp-static-layers">
								<!-- LAYER NR. 13 -->
								<div class="tp-caption tp-shape tp-shapewrapper rs-parallaxlevel-15 tp-static-layer" 
									id="slider-6-layer-1" 
									data-x="['left','left','left','left']" data-hoffset="['-750','-750','-750','-750']" 
									data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-1850','-1850','-1850','-1850']" 
									data-width="1500"
									data-height="1500"
									data-whitespace="nowrap"
									data-visibility="['on','on','off','off']"
									data-type="shape" 
									data-basealign="slide" 
									data-responsive_offset="off" 
									data-responsive="off"
									data-startslide="0" 
									data-endslide="2" 
									data-frames='[{"from":"opacity:0;","speed":300,"to":"o:1;rZ:45;","delay":0,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
									data-textAlign="['left','left','left','left']"
									data-paddingtop="[0,0,0,0]"
									data-paddingright="[0,0,0,0]"
									data-paddingbottom="[0,0,0,0]"
									data-paddingleft="[0,0,0,0]"
									style="z-index: 17;background-color:rgba(255,255,255,1);"></div>
								<!-- LAYER NR. 14 -->
								<div class="tp-caption tp-shape tp-shapewrapper  rs-parallaxlevel-15 tp-static-layer" 
									id="slider-6-layer-2" 
									data-x="['right','right','right','right']" data-hoffset="['-750','-750','-750','-750']" 
									data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-1850','-1850','-1850','-1850']" 
									data-width="1500"
									data-height="1500"
									data-whitespace="nowrap"
									data-visibility="['on','on','off','off']"
									data-type="shape" 
									data-basealign="slide" 
									data-responsive_offset="off" 
									data-responsive="off"
									data-startslide="0" 
									data-endslide="2" 
									data-frames='[{"from":"opacity:0;","speed":300,"to":"o:1;rZ:45;","delay":0,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
									data-textAlign="['left','left','left','left']"
									data-paddingtop="[0,0,0,0]"
									data-paddingright="[0,0,0,0]"
									data-paddingbottom="[0,0,0,0]"
									data-paddingleft="[0,0,0,0]"
									style="z-index: 18;background-color:rgba(255,255,255,1);"> </div>
							</div>
							<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>	
						</div>
					</div>
					<!-- END REVOLUTION SLIDER -->
				</div>
				<!-- Slider Area End -->
			</header>
			<!-- Header Area End -->
			<!-- Page Content Start -->
			<div class="page-content">
				<!-- About Us Area Start -->
				<section class="aboutus-area pt-90 pb-100">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="aboutus-content text-center">
									<div class="aboutus-titel">
										<h2>Ajay Gaikwad</h2>

              <input type="hidden" id="ip" value="" />
										<p>NMMC Short Film Festival 2020</p>
									</div>
									<div class="aboutus-video bg-1 bg-overlay-1">
										<div class="">
											<a href="https://www.youtube.com/watch?v=dTsLs6u-U4I" class="popup-youtube">
												<i class="icofont icofont-play-alt-2"></i>
											</a>
										</div>
									</div>
									<div class="aboutus-bottom-txt">
										<p>There are many variations of passages of Lorem Ipsum available, but in the majority have suffered alteration in some form or randomised wordst true.</p>
										<div class="person-area">
											<div class="person-img">
												<img src="img/home-one/other/person.png" alt="">
											</div>
											<div class="person-txt">
												<h6>Ajay Gaikwad</h6>
												<span>Candidate</span>
											</div>
										</div>

									</div>
									<br/>
										<button class="btn btn-info edit_data" id="btnAddProfile"><span role="status" id="spanButton" aria-hidden="true" value="">
              </span> Please Vote</button>
										<div class="container">
                                             <br/>
											<div class="row">
											<div class="col-md-12">
												
												<center><div id="idResult"></div></center>
											</div>
											</div>
										</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<!-- About Us Area End -->
				<!-- Project Area Start -->
				<!-- Project Area End -->
				<!-- Latest Tailer Area Strat -->
				<!-- Latest Tailer Area End -->
				<!-- All Service Area Start -->
				<!-- All Service Area End -->
				<!-- Gallery Area Start -->
				</div>
				<!-- Testimonial Area End -->
		
				<!-- Our Team Area End -->
			</div>
			<!-- Page Content End -->
		
			<!-- Footer Area End -->
		</div>
       <!-- Page Wraper Here Start -->

<div class="container-fluid" >
	<div class="row">
		<div class="col-md-12">
			<center><p>Copyright © 2020 <a href="https://www.sejalmedianetwork.com/">Sejal Media Network</a> </p></center>
		</div>
	</div>
</div>


       
		<!-- all js here -->
        <script src="js/vendor/jquery-1.12.4.min.js"></script>
        <script src="js/popper.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <!-- Revolution Slider JS -->
	    <script src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
	    <script src="assets/revolution/js/jquery.themepunch.tools.min.js"></script>
		<script src="assets/revolution/revolution-active.js"></script>
		
		<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
		<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
		<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
		<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
		<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
		<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
		<script type="text/javascript" src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>

		<script type="text/javascript">


     $(document).ready(function() {
      $(document).on('click', '.edit_data', function(){
       var delay = 100000;
        var ip = $('#ip').val();
             $.ajax({
                type:"POST",  
                url:"voting.php",   
                data:{ip:ip},
                 beforeSend: function() {
                     $("#spanButton").addClass("spinner-border spinner-border-sm");    
                },
                 complete: function() {
                   setTimeout(function() {
                    $("#spanButton").removeClass("spinner-border spinner-border-sm");
                    
                    $('#btnAddProfile').prop("disabled", true);
                   }, 2000);
                 },
                success:function(data){  
                   setTimeout(function() {
                     $('#idResult').html(data);
                   }, 2500);      
                }  
              });
           });
      });

   function callback(response){  
      var ip =  response.IPv4;
      console.log(response.postal)
      document.getElementById("ip").value = ip;
   }

     $(document).ready(function() {
             $.ajax({ 
                url:"https://geoip-db.com/jsonp/",   
                dataType:"jsonp"
              });
      });

</script>

    </body>

<!-- Mirrored from demo.hasthemes.com/ftage-preview/ftage/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Jan 2020 05:22:17 GMT -->
</html>
