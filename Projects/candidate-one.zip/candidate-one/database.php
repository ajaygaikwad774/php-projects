<?php
  
  $con = mysqli_connect("localhost","root","","voting");

  if(!$con)
  {
    die("Connection Failed ".mysqli_error($con));
  }else{
    
  }
?>