
<?php

include_once('database.php');

if($_POST)
{ 
	$ip = $_POST['ip'];

    $sql = "SELECT ip_address from  poll where ip_address = '$ip'";

    $result = mysqli_query($con,$sql);

    $count = mysqli_num_rows($result);
    

    if($count > 0){
        $value = " Hey!  You have already Participated ";
        echo '<div class="alert alert-danger">'.$value.'</div>';
    }
    else {
       $sql1  = "insert into poll(cid,ip_address,count) values(1,'$ip',1)";
       
       $updateQuery = "update candidatedetails set voting_count=voting_count+1 where id = 1";
   if (mysqli_query($con, $sql1) && mysqli_query($con, $updateQuery)) {
   	      $value = "You have Voted Successfuly";
          echo '<div class="alert" style="background-color:lightblue; color:black;">'.$value.'</div>';
   } else {
      echo "voting system failes to serve request : " . mysqli_error($con);
   }
    	
    }

   mysqli_close($con);
}

?>