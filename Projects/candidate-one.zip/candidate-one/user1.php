

<!DOCTYPE html>
<html>
<head>
	<title>BALA Waghmare</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>




	<div class="content-profile-page">

    
   <div class="profile-user-page card">
      <div class="img-user-profile">
        <img class="profile-bgHome" src="img/banner.jpg" class="img-responsive" />
        <img class="avatar" src="img/1.jpg" alt="allan"/>
           </div>
          
          <div class="user-profile-data">
            <h1>Atul Araskar</h1>

              <input type="hidden" id="ip" value="" />
            <br>
            <p>NMMC Short Film Festivle 2020</p>
          </div> 
         
         <div class="container">
         	<div class="row">
         		<div class="col-md-1"></div>
         		<div class="col-md-10">
         			<iframe width="560" height="315" src="https://www.youtube.com/embed/AQJYQpu17S8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
         			<h4 style="display: inline;">Navi Mumbai Short Film Festival</h4><h5 style="display: inline;"></h5>
         		</div>
         		<div class="col-md-1"></div>
         	</div>
         </div>

         	 <div class="container">
         	<div class="row">
         		
         		<div class="col-md-12">
         			<center><button class="btn btn-info edit_data" id="btnAddProfile"><span role="status" id="spanButton" aria-hidden="true" value="">
                
              </span> Please Vote</button></center>
              <br />
               <center><div id="idResult"></div></center>
         		</div>
         	</div>
         </div>

         

       <br><br>
       <ul class="data-user">
        <li><a><strong>61.780</strong><span>Views</span></a></li>
        <li><a><strong>33.480</strong><span>Likes</span></a></li>
        <li><a><strong>3.546</strong><span>Share</span></a></li>
       </ul>
      </div>
    </div>

<footer>
   <h4>Design by <a href="https://nmmcsff.in" target="_blank">NMMC</a></h4>
</footer>



<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<script type="text/javascript">


     $(document).ready(function() {
      $(document).on('click', '.edit_data', function(){
       var delay = 100000;
        var ip = $('#ip').val();
             $.ajax({
                type:"POST",  
                url:"voting.php",   
                data:{ip:ip},
                 beforeSend: function() {
                     $("#spanButton").addClass("spinner-border spinner-border-sm");    
                },
                 complete: function() {
                   setTimeout(function() {
                    $("#spanButton").removeClass("spinner-border spinner-border-sm");
                    
                    $('#btnAddProfile').prop("disabled", true);
                   }, 2000);
                 },
                success:function(data){  
                   setTimeout(function() {
                     $('#idResult').html(data);
                   }, 2500);      
                }  
              });
           });
      });

   function callback(response){  
      var ip =  response.IPv4;
      document.getElementById("ip").value = ip;
   }

     $(document).ready(function() {
             $.ajax({ 
                url:"https://geoip-db.com/jsonp/",   
                dataType:"jsonp"
              });
      });

</script>

</body>
</html>