-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2019 at 11:30 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `management`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmissiondetails`
--

CREATE TABLE `addmissiondetails` (
  `id` int(11) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `doa` date NOT NULL,
  `mobileNo` varchar(100) NOT NULL,
  `alternateNo` varchar(100) NOT NULL,
  `aadharNo` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `batchTime` varchar(100) NOT NULL,
  `courses` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `totalFees` varchar(100) NOT NULL,
  `paidFees` varchar(100) NOT NULL,
  `balanceFees` varchar(100) NOT NULL,
  `photoname` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addmissiondetails`
--

INSERT INTO `addmissiondetails` (`id`, `student_id`, `first_name`, `last_name`, `gender`, `dob`, `doa`, `mobileNo`, `alternateNo`, `aadharNo`, `email`, `qualification`, `batchTime`, `courses`, `address`, `city`, `state`, `pincode`, `totalFees`, `paidFees`, `balanceFees`, `photoname`) VALUES
(1, '19CI1000', 'AJAY', 'GAIKWAD', 'male', '1970-01-01', '2019-02-28', '9893212415', '9833965120', '4875-1487-1548', 'ajay@gmail.com', '10TH PASS ', '07:30 PM', 'java,php', 'SHIV SAGAR SOCIETY', 'NAVI MUMBAI', 'MAHJARASHTRA', '400701', '10000', '7000', '3000', 0x6d6f64756c652e706e67),
(2, '19CI1001', 'GUNWANTA', 'DHON', 'female', '1994-01-12', '2019-03-17', '9890194950', '7688644678', '1234-5677-6444', 'dhon@gmail.com', 'BE', '08:00 PM', 'perl,java', 'SS2 GHANSOLI', 'NAVI MUMBAI', 'MAHARASHTRA', '400701', '5000', '1000', '3000', 0x576861747341707020496d61676520323031392d30312d30362061742031312e34352e343820504d2e6a706567);

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `username`, `password`) VALUES
(1, 'manager', '4e064ef09c057e680b575a90de1628c0');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_details`
--

CREATE TABLE `enquiry_details` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `doe` date NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fees` varchar(100) NOT NULL,
  `flag` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry_details`
--

INSERT INTO `enquiry_details` (`id`, `first_name`, `last_name`, `doe`, `mobile_no`, `course`, `email`, `fees`, `flag`) VALUES
(1, 'AJAY', 'GAIKWAD', '2019-02-28', '7400142674', 'java,python', 'ajay@gmail.com', '10000', 0),
(2, 'GUNWANTA', 'DHON', '2019-03-17', '9890194950', 'java,php', 'dhon@gmail.com', '5000', 0),
(3, 'SANKET', 'GUPTA', '2019-04-23', '8652308481', 'java,php,asp.net', 'ajay@gmail.com', '40000', 1),
(4, 'MONIKA', 'MOHITE', '2019-06-25', '9893808393', 'java,asp.net', 'ajay@gmail.com', '25000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fee_section`
--

CREATE TABLE `fee_section` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `totalFee` varchar(100) NOT NULL,
  `takeFee` varchar(100) NOT NULL,
  `balanceFee` varchar(100) NOT NULL,
  `dof` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee_section`
--

INSERT INTO `fee_section` (`id`, `sid`, `name`, `totalFee`, `takeFee`, `balanceFee`, `dof`, `remark`) VALUES
(1, 1, 'AJAY  GAIKWAD', '10000', '1000', '9000', '12/02/2010', 'THIS IS FIRST INSTALLMENT'),
(2, 1, 'AJAY  GAIKWAD', '9000', '4000', '5000', '14/05/2045', 'THIS IS SECOND INSALLMENT'),
(3, 1, 'AJAY  GAIKWAD', '5000', '1000', '4000', '04/05/2045', 'THIS IS THIRD INSTALLMEWNT\r\n'),
(4, 2, 'GUNWANTA  DHON', '4000', '1000', '3000', '17/03/2019', 'THS IS FIRST IINSTALLMENT'),
(5, 1, 'AJAY  GAIKWAD', '4000', '1000', '3000', '06/04/2064', 'YAA NEXT PARAT BHARA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addmissiondetails`
--
ALTER TABLE `addmissiondetails`
  ADD PRIMARY KEY (`id`,`student_id`) USING BTREE;

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `enquiry_details`
--
ALTER TABLE `enquiry_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_section`
--
ALTER TABLE `fee_section`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addmissiondetails`
--
ALTER TABLE `addmissiondetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enquiry_details`
--
ALTER TABLE `enquiry_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fee_section`
--
ALTER TABLE `fee_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
