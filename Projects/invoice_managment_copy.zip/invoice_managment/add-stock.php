<?php
/*******************************************************************************
* Invoice System                                            					*
*                                                                               *
* Version: 1.0                                                      	        *
* Author:  Abhishek Raj                                   						*
*******************************************************************************/

include('header.php');
include('functions.php');

?>

<h2>Add Stock</h2>
<hr>

<div id="response" class="alert alert-success" style="display:none;">
	<a href="#" class="close" data-dismiss="alert">&times;</a>
	<div class="message"></div>
</div>
						
<div class="row">
	<div class="col-xs-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Stock Information</h4>
			</div>
			<div class="panel-body form-group form-group-sm">
				<form method="post" id="add_stock" action="add-stock-code.php" >
					<!-- action="add-stock-code.php" -->
					<!-- <input type="hidden" name="action" value="add_stock"> -->
                   <div class="row">
					<div class="col-xs-6">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="float-left">Dealer Information</h4>
							<a href="#" class="float-right select-customer">Select existing Dealer</a>
							<div class="clear"></div>
						</div>
						<div class="panel-body form-group form-group-sm">
							<div class="row">
								<div class="col-xs-6">
									<div class="form-group">
										<input type="text" class="form-control margin-bottom copy-input required" name="dealer_name" id="customer_name" placeholder="Enter Dealer Name" tabindex="1">
									</div>
									<div class="input-group float-right margin-bottom">
										<span class="input-group-addon">@</span>
										<input type="email" class="form-control copy-input required" name="dealer_email" id="customer_email" placeholder="E-mail address" aria-describedby="sizing-addon1" tabindex="2">
									</div>
									
								</div>
								<div class="col-xs-6">
									<div class="form-group">
										<input type="text" class="form-control margin-bottom copy-input required" name="dealer_address" id="customer_address_1" placeholder="Address 1" tabindex="3">	
									</div>
									
								  
								    <div class="form-group no-margin-bottom">
								    	<input type="text" class="form-control required" name="dealer_phone" id="customer_phone" placeholder="Phone number" tabindex="8">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="float-left">Add Stock</h4>
							
							<div class="clear"></div>
						</div>
						<div class="panel-body form-group form-group-sm">
							<div class="row">
								<div class="col-xs-6">
									<div class="form-group ">		
				          <div class="input-group date" id="invoice_date">
				                <input type="text" class="form-control required" name="stock_date" placeholder="Stock date" data-date-format="<?php echo DATE_FORMAT ?>" />
				                <span class="input-group-addon">
				                    <span class="glyphicon glyphicon-calendar"></span>
				                </span>
				            </div>
				        </div>

						<!--			<div class="form-group">-->
									
						<!--	<input type="text" class="form-control required" name="product_desc" placeholder="Enter product description">-->
						<!--</div>		-->
				          <div class="form-group">
								    		
							<input type="text" class="form-control required" name="p_quantity" placeholder="Enter product  Quantity">
						</div>
						
						 <div class="form-group no-margin-bottom">
								 
							<input type="text" class="form-control required" name="total_price" placeholder="Total">
								    </div>
								

								  
							
						
                        			
								</div>

								<div class="col-xs-6">
							
								
						<div class=" form-group">
							<?php addstockList(); ?>
						              </div>		
                       		
						<div class="form-group ">
							<input type="text" class="form-control required" name="buy_price" placeholder="Enter product price per unit">
						</div>
					    
					     
									


								   
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
					<div class="row">
						<div class="col-xs-12 margin-top btn-group">
							<input type="submit" id="add_stock" class="btn btn-success float-right" value="Add Stock" data-loading-text="Adding...">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<div>


	<div id="insert_customer" class="modal fade">
		  <div class="modal-dialog">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title">Select an existing customer</h4>
		      </div>
		      <div class="modal-body">
				<?php popDealerList(); ?>
		      </div>
		      <div class="modal-footer">
				<button type="button" data-dismiss="modal" class="btn">Cancel</button>
		      </div>
		    </div><!-- /.modal-content -->
		  </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->

<?php
	include('footer.php');
?>