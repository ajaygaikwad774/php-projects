package com.example.darshan.sqliteapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "test.db";

    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "test_table";

    private static final String ID = "ID";

    private static final String NAME_COLUMN = "NAME";

    private static final String DOB_COLUMN = "DOB";

    private static final String MOBILE_COLUMN = "MOBILE";



    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null,DATABASE_VERSION );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "( ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " NAME TEXT," +
                " DOB VARCHAR," +
                " MOBILE INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertDataFunc (String name, String dob, long mob )
    {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(NAME_COLUMN,name);
        contentValues.put(DOB_COLUMN,dob);
        contentValues.put(MOBILE_COLUMN,mob);

        long result = db.insert(TABLE_NAME,null,contentValues);

        if (result==-1)
            return false;
        else
            return true;
    }

    public Cursor getData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery("select * from "+TABLE_NAME,null);
        return result;
    }

    public boolean updateData(String id, String name, String dob, long mob)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID,id);
        contentValues.put(NAME_COLUMN,name);
        contentValues.put(DOB_COLUMN,dob);
        contentValues.put(MOBILE_COLUMN,mob);

        db.update(TABLE_NAME, contentValues, "ID = ?",new String[] { id });

        return true;
    }
    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?",new String[] {id});
    }
}
