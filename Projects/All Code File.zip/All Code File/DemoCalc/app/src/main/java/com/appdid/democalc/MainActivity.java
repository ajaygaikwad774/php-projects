package com.appdid.democalc;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText mEdtNum1, mEdtNum2;
    TextView mResult;
    Button mAdd,mSub,mMul,mDiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mEdtNum1 = findViewById(R.id.num1);
        mEdtNum2 = findViewById(R.id.num2);

        mResult = findViewById(R.id.result);

        mAdd = findViewById(R.id.add_btn);
        mSub = findViewById(R.id.sub_btn);
        mDiv = findViewById(R.id.div_btn);
        mMul = findViewById(R.id.mul_btn);




        mAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(TextUtils.isEmpty(mEdtNum1.getText().toString()))
                {
                    mEdtNum1.setError("Enter num1..");
                    return;
                }

                if(TextUtils.isEmpty(mEdtNum2.getText().toString()))
                {
                    mEdtNum2.setError("Enter num2..");
                    return;
                }


                String n1 = mEdtNum1.getText().toString();
                Double n1_double = Double.parseDouble(n1);

                String n2 = mEdtNum2.getText().toString();
                Double n2_double = Double.parseDouble(n2);

                Double res = n1_double + n2_double;

                mResult.setText(""+res);

            }
        });

        mSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String n1 = mEdtNum1.getText().toString();
                Double n1_double = Double.parseDouble(n1);

                String n2 = mEdtNum2.getText().toString();
                Double n2_double = Double.parseDouble(n2);

                Double res = n1_double - n2_double;

                mResult.setText(""+res);

            }
        });


        mMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String n1 = mEdtNum1.getText().toString();
                Double n1_double = Double.parseDouble(n1);

                String n2 = mEdtNum2.getText().toString();
                Double n2_double = Double.parseDouble(n2);

                Double res = n1_double * n2_double;

                mResult.setText(""+res);

            }
        });

        mDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String n1 = mEdtNum1.getText().toString();
                Double n1_double = Double.parseDouble(n1);

                String n2 = mEdtNum2.getText().toString();
                Double n2_double = Double.parseDouble(n2);

                Double res = n1_double / n2_double;

                mResult.setText(""+res);

            }
        });





    }

//    @Override
//    protected void onStart() {
//        super.onStart();
//        Toast.makeText(MainActivity.this,"Inside OnStart()",Toast.LENGTH_SHORT).show();
//
//    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        Toast.makeText(MainActivity.this,"Inside OnResume()",Toast.LENGTH_SHORT).show();
//
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        Toast.makeText(MainActivity.this,"Inside OnPause()",Toast.LENGTH_SHORT).show();
//
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        Toast.makeText(MainActivity.this,"Inside OnStop()",Toast.LENGTH_SHORT).show();
//
//    }
//
//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        Toast.makeText(MainActivity.this,"Inside onRestart()",Toast.LENGTH_SHORT).show();
//
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        Toast.makeText(MainActivity.this,"Inside OnDestroy()",Toast.LENGTH_SHORT).show();
//
//    }


}

