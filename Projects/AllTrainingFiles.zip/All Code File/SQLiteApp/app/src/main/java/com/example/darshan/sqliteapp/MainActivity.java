package com.example.darshan.sqliteapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {

    DatabaseHelper databaseHelper;

    EditText edt_id,edt_name, edt_dob, edt_mob;

    Button btn_add, btn_read, btn_del, btn_update;

    private SimpleDateFormat dateFormatter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(MainActivity.this);


        edt_id = findViewById(R.id.id_edt);
        edt_name = findViewById(R.id.name_edt);
        edt_dob = findViewById(R.id.date_of_birth_edt);
        edt_mob = findViewById(R.id.mobile_edt);

        btn_add = findViewById(R.id.add_button);
        btn_read = findViewById(R.id.read_button);
        btn_del = findViewById(R.id.delete_button);
        btn_update = findViewById(R.id.update_button);


        dateFormatter = new SimpleDateFormat("MM-dd-yyyy", Locale.US);


    }


    public void addDate(View v) {

        Calendar newCalendar = Calendar.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                Calendar newDate = Calendar.getInstance();

                newDate.set(year, monthOfYear, dayOfMonth);

                edt_dob.setText(dateFormatter.format(newDate.getTime()));
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.show();


    }

    public void readFunc(View V) {

        Cursor res = databaseHelper.getData();

        if (res.getCount() == 0) {
            // show message
            showMessage("Error", "Nothing found");
            return;
        }

        StringBuffer buffer = new StringBuffer();

        while (res.moveToNext()) {

            buffer.append("Id :" + res.getString(0) + "\n");
            buffer.append("Name :" + res.getString(1) + "\n");
            buffer.append("DOB :" + res.getString(2) + "\n");
            buffer.append("Mobile :" + res.getLong(3) + "\n\n");

        }

        // Show all data
        showMessage("Data", buffer.toString());
    }

    public void showMessage(String title,String Message){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void addFunc(View v) {

        boolean isInsert = databaseHelper.insertDataFunc(edt_name.getText().toString(), edt_dob.getText().toString(), Long.parseLong(edt_mob.getText().toString()));

        if (isInsert == true) {
            Toast.makeText(MainActivity.this, "Data Inserted...", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Data not Inserted...", Toast.LENGTH_SHORT).show();
        }

    }

    public void updateFunc(View V)
    {
        boolean isUpdate = databaseHelper.updateData(edt_id.getText().toString(),
                edt_name.getText().toString(),
                edt_dob.getText().toString(),Long.parseLong(edt_mob.getText().toString()));

        if(isUpdate == true)
            Toast.makeText(MainActivity.this,"Data Update",Toast.LENGTH_LONG).show();
        else
            Toast.makeText(MainActivity.this,"Data not Updated",Toast.LENGTH_LONG).show();
    }

    public void deleteFunc(View V)
    {
        Integer deletedRows = databaseHelper.deleteData(edt_id.getText().toString());

        if(deletedRows > 0)
            Toast.makeText(MainActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();
        else
            Toast.makeText(MainActivity.this,"Data not Deleted",Toast.LENGTH_LONG).show();
    }
}


