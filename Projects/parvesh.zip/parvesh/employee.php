<?php
session_start();

if (  isset($_SESSION['logged_in']) && isset($_SESSION["user_id"]) && isset($_SESSION["role"])  )   
{

  $user_id = $_SESSION["user_id"];
    $role = $_SESSION["role"];

include "connection.php";
  ?>




<?php include 'header.php';?> 

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.css" type="text/css" >
<link rel="stylesheet" href="css/employee.css" type="text/css" >
<link rel="stylesheet" href="plugins/datatables/Responsive-2.2.2/css/responsive.bootstrap.min.css" type="text/css" >

  <style type="text/css">
    button
    {
      width: auto;
    min-width: 0;
    }

    .container {
  border-radius: 5px;
  background-color: #F5F5F5;
 
  margin:20px 40px 40px 40px;
padding:30px;
box-sizing:border-box;
}
  </style>

  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
  <div id="main">
<section>
    <?php include 'navbar.php';?>   
    </section>

    <section>
      
<button onclick="document.getElementById('modal-wrapper').style.display='block'" style=" margin-left:80% !important; margin-top:2% !important">
Add Employee/Technician</button>

<div id="modal-wrapper" class="modal">
  
  <form class="modal-content animate" action="add_role_code.php" method="POST">
        
    <div class="imgcontainer">
      <span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close PopUp">&times;</span>
     
      <h1 style="text-align:center">Add Employee/Technician</h1>
    </div>

    <div class="container">
      <label>Name</label>
      <input type="text" placeholder="Enter Name" name="name">
       <label>Mobile Number</label>
      <input type="text" placeholder="Enter Mobile Number" name="mobile">
      <label>Role</label>
      <select class="" name="role">
  <option value="employee">Employee</option>
  <option value="technician">Technician</option>
 
</select>
    
      <label>Username</label>
      <input type="text" placeholder="Enter Username" name="username">
       <label>Password</label>
      <input type="password" placeholder="Enter Password" name="password">
       <label>Confirm Password</label>
      <input type="password" placeholder="Enter Password" name="cpassword">
      <br>
      <br>

      <button type="submit" name="submit">Add</button>
    </div>
    
  </form>
  
</div>
    </section>

    <section>
 <div id="main ">
             <div class="container">
                    <h3 class="text-themecolor"> Employees & Technicians</h3>
              
      <div class="datatable">
 <table id="demo-foo-addrow1" class="display cell-border demo-foo-addrow12 "  style="width:100%">
               
            <thead >
                                
                                           <tr>
                                            
                                             <th class="col-md-2 col-sm-2">Name</th>
                                               <th class="col-md-2 col-sm-2">Mobile Number</th>
                                                <th class="col-md-2 col-sm-2">User Name</th>
                                                <th class="col-md-2 col-sm-2"> Role</th>
                                              
                                              <th class="col-md-2 col-sm-2">Options</th> 
                                            </tr>
                                                </thead>
                                                 <tfoot >
                                           <tr>
                                            
                                             <th class="col-md-2 col-sm-2">Name</th>
                                               <th class="col-md-2 col-sm-2">Mobile Number</th>
                                               <th class="col-md-2 col-sm-2">User Name</th>
                                                <th class="col-md-2 col-sm-2"> Role</th>
                                              
                                              <th class="col-md-2 col-sm-2">Options</th> 
                                            </tr>
                                           </tfoot>
                                               <tbody>
                                 <?php
                                               $fetch_employee="SELECT `user_id` , `name`, `user_number`, `username`, `password`, `user_address`, `user_role`, `active_deactive_flag` ,`disable_flag`, `added_date` FROM `user` WHERE disable_flag='0' AND user_role !='admin' ";


$result_employee=mysqli_query($conn,$fetch_employee);
 
 
   while($row=mysqli_fetch_assoc($result_employee))
   {
    $user_id=$row["user_id"];
       $name=$row["name"];
  $user_number=$row["user_number"];
  $active_deactive_flag=$row["active_deactive_flag"];
  
  $username=$row["username"];
  $role=$row["user_role"];
 
      
     

          ?>

            <tr>
                <td><?php echo $name; ?></td>
                <td><?php echo $user_number; ?></td>

                <td><?php echo $username; ?></td>

               
                <td><?php echo $role; ?></td>
                <td><a   id="delete_employee" data-id="<?php echo $user_id;?>" href="javascript:void(0)"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;
               <?php    if($active_deactive_flag == '0')  {?>
                  <a  class="active"  data-id="<?php echo $user_id.'-'.$active_deactive_flag;?>" href="javascript:void(0)">Deactive</a></td>
                <?php } elseif($active_deactive_flag == '1'){ ?>

                   <a  class="active"  data-id="<?php echo $user_id.'-'.$active_deactive_flag;?>" href="javascript:void(0)">Active</a></td>
                <?php }?>
                  
                
            </tr>
         <?php } ?>  
                                               
                                                

                                         
                                        </tbody>
                        
 </table>
</div>
                               
                                </div>
     </section>
     </div>
 <script src="plugins/datatables/JSZip-2.5.0/jszip.min.js"></script>
 <script src="plugins/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
 <script src="plugins/datatables/pdfmake-0.1.36/vfs_fonts.js"></script> 
                                      
                                          
<script src="plugins/datatables/datatables.min.js"></script>

        


  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.js"></script>
 
    
<script >
  
        //readProducts(); /* it will load products when document loads */
        
       

          $('#demo-foo-addrow1').DataTable( {
        responsive: true,
        destroy: true,
        dom: 'Bfrtip',
        buttons: [  
           
            
            {
                extend: 'excel',
                 title:'Employee List',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5]
                }
            }, 
            
            {
                extend: 'copy',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5]
                }
            } 
           
            ],
        "pageLength": 10,


        initComplete: function () {
      
            this.api().columns([0,1,2,3,4]).every( function () {
                var column = this;
                var select = $('<select><option value="">Show all</option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );

           
              var r = $('#demo-foo-addrow1 tfoot tr');
  r.find('th').each(function(){
    $(this).css('padding', 8);
  });
  $('#demo-foo-addrow1 thead').append(r);
  $('#search_0').css('text-align', 'center');
  
$('#demo-foo-addrow1 tfoot tr').appendTo('#demo-foo-addrow1 thead');
        }


    } );

      

    
  

   $(document).on('click', '#delete_employee', function(e){

            var data;           
            var productId = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(productId);
            e.preventDefault();
        });


   
    
    function SwalDelete(productId){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'employee_delete='+productId,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                    //readProducts();
                   // $('#demo-foo-addrow1').load(document.URL +  ' #demo-foo-addrow1');
                    location.reload();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }



          $(document).on('click', '.active', function(e){

            var data;           
            var activeid = $(this).data('id');
            //var productId = $(this).data('id');
           // alert(activeid);
            Swalinactive(activeid);
            e.preventDefault();
        });
    

    function Swalinactive(activeid){
        
        swal({
            title: 'Are you sure?',
            text: "It will Affect on login!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'inactive='+activeid,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Affected!', response.message, response.status);
                  
                    location.reload();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
    
 
    </script>

</body>

</html>

<?php
}else
{
    session_unset();
  session_destroy();
  header("Location:index.php");
}
 ?>