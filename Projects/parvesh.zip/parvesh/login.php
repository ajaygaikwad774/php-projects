<?php include 'header.php';?> 
<link rel="stylesheet" type="text/css" media="screen" href="css/login.css">

</head>

<body>
<center>
<div class="login">
<form action="login.php" method="POST">
<h1>Login form</h1>
<input type="email" name="email" id="email" autocomplete="off" placeholder="Email" required><br><br>
<input type="password" name="password" id="password" autocomplete="off" placeholder="Password" required><br><br>
<input type="submit" name="submit" id="submit">
</form>
</div>
</body>
</html>
