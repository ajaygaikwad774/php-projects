<?php

include "connection.php";


if (isset($_POST["submit"])) 
{
 $name=mysqli_real_escape_string($conn,$_POST['name']);

$mobile=mysqli_real_escape_string($conn,$_POST['mobile']);

 $role=mysqli_real_escape_string($conn,$_POST['role']);

$username=mysqli_real_escape_string($conn,$_POST['username']);

 $password=mysqli_real_escape_string($conn,$_POST['password']);


 $cpassword=mysqli_real_escape_string($conn,$_POST['cpassword']);

 if($password === $cpassword )
 {

 $add_employee = "INSERT INTO `user`( `name`, `user_number`, `username`, `password`, `user_role`) VALUES ('$name' , '$mobile' , '$username','$password' ,'$role' )";
$query_employee = mysqli_query($conn,$add_employee);

 echo "<script>
			window.location.href='employee.php';
			alert('SucessFully Added!!');
			</script>";

}else {

 echo "<script>
			window.location.href='employee.php';
			alert('Password Dosen't Match');
			</script>";

}
		
}