<?php

include "connection.php";


if (isset($_POST["submit"])) 
{
$name=mysqli_real_escape_string($conn,$_POST['name']);


$user_id=mysqli_real_escape_string($conn,$_POST['user_id']);

 $from_date=mysqli_real_escape_string($conn,$_POST['from_date']);

 $to_date=mysqli_real_escape_string($conn,$_POST['to_date']);
$reason=mysqli_real_escape_string($conn,$_POST['reason']);


  $check="INSERT INTO `emp_leave`( `user_id`, `user_name`, `from_date`, `to_date` , `reason`) VALUES ('$user_id' , '$name'  , '$from_date' , '$to_date' , '$reason')";
$check1=mysqli_query($conn,$check);

echo "<script>
			window.location.href='leave.php';
			alert('SucessFully Send!!');
			</script>";	
 
}
?>