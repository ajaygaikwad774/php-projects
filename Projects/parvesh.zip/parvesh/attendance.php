


<?php include 'header.php';?> 
<link rel="stylesheet" type="text/css" media="screen" href="css/leave.css">

<link rel="stylesheet" type="text/css" media="screen" href="css/table.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
</head>
<body>
    <div id="main">
    <section>
    <?php include 'navbar.php';?>   
    </section>


    <section>
      <div class="container">
     <h4>Attendance </h4>
  <form action="/action_page.php">
    <label for="date">Date</label>
    <input type="text" id="datepicker" name="date" style="width:20%" >

  </form>
</div>
    
</section>
<section>
  <div class="container">
  

      <table>
  <caption>Attendance Report </caption>
  <thead>
    <tr>
      <th scope="col"> From Date </th>
      <th scope="col">To Date</th>
      <th scope="col">Reason</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    
    </tr>
  </thead>
  <tbody>
    <tr>
      <td data-label="Account">Visa - 3412</td>
      <td data-label="Due Date">04/01/2016</td>
      <td data-label="Amount">$1,190</td>
      <td data-label="Amount">$1,190</td>
       <td data-label="Amount">Delete</td>
  
    </tr>
    <tr>
      <td scope="row" data-label="Account">Visa - 6076</td>
      <td data-label="Due Date">03/01/2016</td>
      <td data-label="Amount">$2,443</td>
      <td data-label="Amount">$1,190</td>
      <td data-label="Amount">Delete</td>

    </tr>
    
  </tbody>
</table>
   </div>

</section>
</div>
    
</body>
</html>