<?php 
$dbServername="localhost";
$dbUsername="service_center";
$dbPassword="appdid123";
$dbName="washing_machine_service_center";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);


// if($conn)
// {
//     echo "success";
// }
// else
// {
//     echo "failed";
// }

?>