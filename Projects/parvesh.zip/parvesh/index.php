<?php include 'header.php';?> 
<link rel="stylesheet" type="text/css" media="screen" href="css/login.css">

</head>

<body>
<center>
<div class="login">
<form action="login_code.php" method="POST">
<h1>Parvesh IT Solution</h1>
<input type="text" name="username" id="email" placeholder="Username" required><br><br>
<input type="password" name="password" id="password" placeholder="Password" required><br><br>
<!--<input type="submit" name="submit" id="submit">-->

<button type="submit" name="submit" id="submit">Login</button>
</form>
</div>
</body>
</html>
