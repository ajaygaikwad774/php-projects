<?php
session_start();

if (  isset($_SESSION['logged_in']) && isset($_SESSION["user_id"]) && isset($_SESSION["role"])  )   
{

  $user_id = $_SESSION["user_id"];
    $role = $_SESSION["role"];
     $user_name     = $_SESSION['name'];

include "connection.php";
  ?>
<?php include 'header.php';?> 

<link rel="stylesheet" type="text/css" media="screen" href="css/leave.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/table.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.css" type="text/css" >
<style type="text/css">
  .container {
  border-radius: 5px;
  background-color: #F5F5F5;
 
  margin:20px 40px 40px 40px;
padding:30px;
box-sizing:border-box;
}



.space-flex 
{
  margin: 20px;
}


</style>
</head>
<body>
    <div id="main">
    <section>
  <?php include 'navbar.php';?>   
    </section>

  <?php if($role == 'admin') { ?>
    <section>
      <div class="container">
        <h3>Add Client</h3>
  <form action="company_code.php" method="POST">
  <div class="flex-container  ">
  <input type="hidden" value="<?php echo $user_name; ?> " name="name">
    <input type="hidden" value="<?php echo $user_id; ?> " name="user_id">
  <div class="space-flex"> 
    <label for="Company name"> Company name </label>

    <input type="text"  name="company_name" placeholder="Enter Company Name" required>
    </div>
   <div class="space-flex">
   <label for="Company Product"> Company Product</label>
    <input type="text"  name="company_product" placeholder="Enter Company Product" required>
    </div>
      <div class="space-flex">
    <label for="Contact Person"> Contact Person</label>
    <input type="text"  name="contact_person" placeholder="Enter Contact Person" required>
</div>
    </div>
    <div class="flex-container">
   
<div class="space-flex">
    <label for="Conatct Number">Conatct Number</label>
    <input type="text"  name="contact_number" placeholder="Enter Contact Number" required>
 </div>
 <div class="space-flex">
    <label for="Location">Location</label>
    <input type="text"  name="location" placeholder="Enter Location" required>
</div>

</div>


    <input type="submit" name="submit" value="Submit">
  </form>
</div>
    
</section>
  <?php } ?>
    <section>
        <div class="container">
      <div class="comapny-table"> 

      <table>
  <caption>Company Details </caption>
  <thead>
    <tr>
      <th scope="col">Company Name</th>
      <th scope="col">Company Product</th>
      <th scope="col">Conatct Person</th>
      <th scope="col">Conatct details</th>
      <?php   if($role == 'admin')
      {  ?>
      <th scope="col">Action</th>
    <?php } ?>
    </tr>
  </thead>
  <tbody>

<?php 
     $fetch_company="SELECT `c_id` , `c_name`, `c_product`, `contact_person`, `contact_no` FROM `company` WHERE  disable_flag='0'  ";


$result_company=mysqli_query($conn,$fetch_company);
 
 
   while($row=mysqli_fetch_assoc($result_company))
   {
                     
        $c_id=$row["c_id"];
       $c_name=$row["c_name"];
  $c_product=$row["c_product"];
  $contact_person=$row["contact_person"];
  $contact_no=$row["contact_no"];
 
?>

    <tr>
      <td data-label="Company Name"><?php echo $c_name; ?></td>
      <td data-label="Company Product"><?php echo $c_product; ?></td>
      <td data-label="Conatct Person"><?php echo $contact_person; ?></td>
       <td data-label="Contact Number"><?php echo $contact_no; ?></td>
       <?php   if($role == 'admin')
      {  ?>
       <td data-label="Action"><a   id="delete_company" data-id="<?php echo $c_id;?>" href="javascript:void(0)"><i class="fa fa-trash"></i></a></td>
     <?php } ?>
     
    </tr>
    <?php } ?>
  </tbody>
</table>
   </div>
 </div>
</section>
</div>
<script type="text/javascript">
  
      $(document).on('click', '#delete_company', function(e){

            var data;           
            var productId = $(this).data('id');
             //alert(productId);
            SwalDelete(productId);
            e.preventDefault();
        });


    
    function SwalDelete(productId){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'company_delete='+productId,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                   
                    location.reload();
                    // $( ".here" ).load(window.location.href + " .here" );
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
   
</script>
    
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.js"></script>
   
</body>
</html>
<?php
}else
{
    session_unset();
  session_destroy();
  header("Location:index.php");
}
 ?>