<?php
session_start();

if (  isset($_SESSION['logged_in']) && isset($_SESSION["user_id"]) && isset($_SESSION["role"])  )   
{

  $user_id = $_SESSION["user_id"];
    $role = $_SESSION["role"];
     $user_name     = $_SESSION['name'];

include "connection.php";
  ?>
<?php include 'header.php';?>   
</head>
<body>
    <div id="main">
    <section>
      <?php include 'navbar.php';?>   

    </section>
<?php
  
 $user_query = "SELECT * FROM `user` WHERE active_deactive_flag = '0' AND disable_flag ='0' AND user_role ='employee'";
$stmt_result = mysqli_query($conn,$user_query);
   $rowcount=mysqli_num_rows($stmt_result);

   $t_query = "SELECT * FROM `user` WHERE active_deactive_flag = '0' AND disable_flag ='0' AND user_role ='technician'";
$t_result = mysqli_query($conn,$t_query);
   $t_rowcount=mysqli_num_rows($t_result);

   $today_date=date("Y-m-d");

   $a_query = "SELECT * FROM `track_attendance` WHERE date(added_date) ='$today_date'";
$a_result = mysqli_query($conn,$a_query);
   $a_rowcount=mysqli_num_rows($a_result);

 $qo_query = "SELECT * FROM `customer_query` where DATE(added_date) = '$today_date' && flag ='0'";
$qo_result = mysqli_query($conn,$qo_query);
   $qo_rowcount=mysqli_num_rows($qo_result);


    $qc_query = "SELECT * FROM `customer_query` where DATE(added_date) = '$today_date' && flag ='1'";
$qc_result = mysqli_query($conn,$qc_query);
   $qc_rowcount=mysqli_num_rows($qc_result);

    $q_query = "SELECT * FROM `customer_query` where DATE(added_date) = '$today_date'";
$q_result = mysqli_query($conn,$q_query);
   $q_rowcount=mysqli_num_rows($q_result);

?>
    <section>
    <div class="card">
<span class="fa fa-exclamation-circle centre"></span>
<br>
<span class="centre"><?php echo $rowcount ; ?></span>

  <span class=""><h3>Total Employee</h3> </span>
</div>
<div class="card card-1">
<span class="fa fa-exclamation-circle centre"></span>
<br>
<span class="centre"><?php echo $t_rowcount ; ?></span>
<br>
  <span class=""><h3>Total Technician </h3></span>
 
</div>

<?php if($role == 'admin')
{ ?>
<div class="card card-2">
	<span class="fa fa-exclamation-circle centre"></span>
<br>
<span class="centre"><?php echo $a_rowcount ; ?></span>
<br>
  <span class=""><h3>Attandence</h3></span>
</div>

<?php } ?>
<div class="card card-3">
	<span class="fa fa-exclamation-circle centre"></span>
<br>
<span class="centre"><?php echo $qo_rowcount ; ?></span>
<br>
  <span class=""><h3> Pending Query <h3></span>
</div>

<div class="card card-4">
  <span class="fa fa-exclamation-circle centre"></span>
<br>
<span class="centre"><?php echo $qc_rowcount ; ?></span>
<br>
  <span class=""><h3>Total Query Closed<h3></span>
</div>

<div class="card card-5">
  <span class="fa fa-exclamation-circle centre"></span>
<br>
<span class="centre"><?php echo $q_rowcount ; ?></span>
<br>
  <span style="padding-bottom:20px;"><h3>Total Query<h3></span>
</div>

</section>
<section>
      <div class="col-lg-12">
                               <div class="card" style="width:97%;height:auto;">
                              
                            <div id="bar-chart" style="width:100%; height:400px;"></div>
                            
                    </div>
                    </div>
</section>
</div>
    <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "#E2E1E0";
}
</script>

  <script src="plugins/echarts/echarts-all.js"></script>


  
<?php include "echarts.php";?>
    
</body>
</html>
<?php
}else
{
    session_unset();
  session_destroy();
  header("Location:index.php");
}
 ?>