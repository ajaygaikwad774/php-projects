<?php

                session_start();

include "connection.php";


if (isset($_POST["submit"])) 
{
$username=mysqli_real_escape_string($conn,$_POST['username']);
$password=mysqli_real_escape_string($conn,$_POST['password']);

  $check="select * from user where username='$username' AND password='$password' AND disable_flag=0 ";
$check1=mysqli_query($conn,$check);
	if (mysqli_num_rows($check1)>0)
	{
				$fetch=mysqli_fetch_assoc($check1);
				
				 $check_flag = $fetch["active_deactive_flag"];
                  if($check_flag == '0')
                  {

				$_SESSION["user_id"]=$fetch["user_id"];
			 $_SESSION["name"]=$fetch["name"];
				$_SESSION["role"]=$fetch["user_role"];
				$_SESSION['logged_in']="login";
				// $_SESSION['flag']=$fetch["flag"];
				$date=date("Y-m-d");

				if ($fetch["user_role"]=="admin")
				{
				
				header("Location:dashboard.php");
					// echo"Admin";
				}
				elseif($fetch["user_role"]=="technician") 
				{

					header("Location:dashboard.php");
					// echo "Super Admin";
				}
				elseif($fetch["user_role"]=="employee")
				{
					header("Location:dashboard.php");
					
					
				}
	}else
	{
		echo "<script>
			window.location.href='index.php';
			alert('Your account has been Deactivated .Please Contact to Admin');
			</script>";

	}
}
	else{

          
		
		 echo "<script>
			window.location.href='index.php';
			alert('Wrong username or password.');
			</script>";
	    

		// header("Location:index.php");
	}

}

?>