<?php
session_start();

if (  isset($_SESSION['logged_in']) && isset($_SESSION["user_id"]) && isset($_SESSION["role"])  )   
{

  $user_id = $_SESSION["user_id"];
    $role = $_SESSION["role"];
     $user_name     = $_SESSION['name'];

include "connection.php";
  ?>


<?php include 'header.php';?> 
<link rel="stylesheet" type="text/css" media="screen" href="css/leave.css">

<link rel="stylesheet" type="text/css" media="screen" href="css/table.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.css" type="text/css" >
  <style type="text/css">
    button
    {
  width:auto !important;
    }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 <script>
  $( function() {
    $( "#datepicker" ).datepicker({
      dateFormat: 'dd-mm-yy'
    });

  } );

   $( function() {
    $( "#datepicker1" ).datepicker({
      dateFormat: 'dd-mm-yy'
    });
  } );
  </script>
</head>
<body>
    <div id="main">
    <section>
    <?php include 'navbar.php';?>   
    </section>

<?php if($role != 'admin'){ ?>
    <section>
      <div class="container">
        <h3>Leave</h3>
  <form action="leave_code.php" method="POST">
   <h3><?php echo 'Name:'.' '.$user_name;  ?></h3>
  <input type="hidden" value="<?php echo $user_name; ?> " name="name">
    <input type="hidden" value="<?php echo $user_id; ?> " name="user_id">
   
    <label for="lname"> From Date </label>
    <input type="text" id="datepicker" name="from_date" placeholder="Enter From Date" required>
    

    <label for="lname"> TO Date </label>
    <input type="text" id="datepicker1" name="to_date" placeholder="Enter To Date" required>

    <label for="country">Reason</label>
    <select id="country" name="reason" required>
      <option value="SL">SL</option>
      <option value="CL">CL</option>
      <option value="other">Other</option>
    </select>


    <input type="submit" name="submit" value="Submit">
  </form>
</div>
    
</section>
<?php } ?>
<section>
  <div class="container">
  

      <table>
  <caption>Leave Details </caption>
  <thead>
    <tr>
       <th scope="col"> Name </th>
     
      <th scope="col"> From Date </th>
      <th scope="col">To Date</th>
      <th scope="col">Reason</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    
    </tr>
  </thead>
  <tbody>

<?php 
    if($role != 'admin'){
     $fetch_leave="SELECT  `leave_id`, `user_name`  , `from_date`, `to_date`, `reason`, `flag` FROM `emp_leave` WHERE user_id='$user_id' AND disable_flag='0' ORDER BY leave_id DESC ";

  }elseif($role == 'admin')
  {
     $fetch_leave="SELECT  `leave_id` , `user_name`  , `from_date`, `to_date`, `reason`, `flag` FROM `emp_leave` WHERE  disable_flag='0' ORDER BY leave_id DESC ";
  }
$result_leave=mysqli_query($conn,$fetch_leave);
 
 
   while($row=mysqli_fetch_assoc($result_leave))
   {

$leave_id=$row["leave_id"];
 // $user_role=$row["user_role"];
  $user_name=$row["user_name"];
       $from_date=$row["from_date"];
  $to_date=$row["to_date"];
  $reason=$row["reason"];
  $flag=$row["flag"];

 
?>

    <tr>
       <td data-label="From Date"><?php echo $user_name; ?></td>
      
      <td data-label="From Date"><?php echo $from_date; ?></td>
      <td data-label="TO Date"><?php echo $to_date; ?></td>
      <td data-label="Reason"><?php echo $reason; ?></td>
      <?php if($flag == 0)
      {   ?>
   <td data-label="Status">Pending</td>

 <?php     }elseif($flag == 1)
      {   ?>

  <td data-label="Status" style="color:green;">Approved</td>
   <?php   } elseif ($flag == 2) { ?>

    <td data-label="Status" style="color:red;">Reject</td>
  
   <?php }




      if($role != 'admin')
      {

      ?>
      
       
       <td data-label="Action"><a   id="delete_leave" data-id="<?php echo $leave_id;?>" href="javascript:void(0)"><i class="fa fa-trash"></i></a></td>






     <?php }
     elseif($role == 'admin' )
     { 

     if( $flag == '0')
     {
      ?>

       <td data-label="Action"><a   id="Approve" data-id="<?php echo $leave_id;?>" href="javascript:void(0)"><button >Approve</button> </a>&nbsp;&nbsp;&nbsp;<a   id="Reject" data-id="<?php echo $leave_id;?>" href="javascript:void(0)"><button >Reject</button> </a></td>

     <?php }elseif($flag == 1)
      {   ?>

  <td data-label="Status" style="color:green;">Approved</td>
   <?php   } elseif ($flag == 2) { ?>

    <td data-label="Status" style="color:red;">Reject</td>
  
   <?php }


   }

      ?>
  
    </tr>


    <?php } ?>
  </tbody>
</table>
   </div>

</section>
</div>

<script type="text/javascript">
  
      $(document).on('click', '#delete_leave', function(e){

            var data;           
            var productId = $(this).data('id');
            // alert(productId);
            SwalDelete(productId);
            e.preventDefault();
        });


    
    function SwalDelete(productId){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'leave_delete='+productId,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                   
                    location.reload();
                    // $( ".here" ).load(window.location.href + " .here" );
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }


     $(document).on('click', '#Approve', function(e){

            var data;           
            var productId = $(this).data('id');
             //alert(productId);
            Swalapprove(productId);
            e.preventDefault();
        });



    
    function Swalapprove(productId){
        
        swal({
            title: 'Are you sure?',
            text: "",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Approve it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'leave_approve='+productId,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Approved!', response.message, response.status);
                   
                    location.reload();
                    // $( ".here" ).load(window.location.href + " .here" );
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }


     $(document).on('click', '#Reject', function(e){

            var data;           
            var productId = $(this).data('id');
             //alert(productId);
            Swalreject(productId);
            e.preventDefault();
        });



    
    function Swalreject(productId){
        
        swal({
            title: 'Are you sure?',
            text: "",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Reject it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'leave_reject='+productId,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Rejected!', response.message, response.status);
                   
                    location.reload();
                    // $( ".here" ).load(window.location.href + " .here" );
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
   
</script>
    
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.js"></script>
    
</body>
</html>
<?php
}else
{
    session_unset();
  session_destroy();
  header("Location:index.php");
}
 ?>
