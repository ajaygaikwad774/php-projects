<?php

include "connection.php";


if (isset($_POST["submit"])) 
{
$customer_name=mysqli_real_escape_string($conn,$_POST['customer_name']);
$mobile=mysqli_real_escape_string($conn,$_POST['mobile']);

$user_name=mysqli_real_escape_string($conn,$_POST['name']);
$address=mysqli_real_escape_string($conn,$_POST['address']);
$company_name=mysqli_real_escape_string($conn,$_POST['company_name']);

$query=mysqli_real_escape_string($conn,$_POST['query']);
$product=mysqli_real_escape_string($conn,$_POST['product']);

$user_id=mysqli_real_escape_string($conn,$_POST['user_id']);
$ticket_no ='T-'.$mobile; 

  $add_customer_query="INSERT INTO `customer_query`( `ticket_no` , `user_id`, `name` , `customer_name`, `company_name`, `product`, `customer_number`, `description` ) VALUES ( '$ticket_no' , '$user_id' , '$user_name' , '$customer_name' , '$company_name' , '$product' , '$mobile' , '$query') ";
$query_added=mysqli_query($conn,$add_customer_query);

 echo "<script>
			window.location.href='service.php';
			alert('SucessFully Added!!');
			</script>";		
		
// header("Location:service.php");

}
