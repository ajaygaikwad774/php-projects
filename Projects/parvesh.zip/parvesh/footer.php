
 <script src="plugins/datatables/JSZip-2.5.0/jszip.min.js"></script>
 <script src="plugins/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
 <script src="plugins/datatables/pdfmake-0.1.36/vfs_fonts.js"></script> 
                                         <!-- <script src="assets/plugins/datatables/DataTables/Responsive-2.2.2/js/dataTables.responsive.js"></script> -->
                                          
<script src="plugins/datatables/datatables.min.js"></script>

        


  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.js"></script>
 <!--<script src="assets/swal2/sweetalert2.min.js"></script>-->