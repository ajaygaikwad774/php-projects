<?php
session_start();

if (  isset($_SESSION['logged_in']) && isset($_SESSION["user_id"]) && isset($_SESSION["role"])  )   
{

  $user_id = $_SESSION["user_id"];
    $role = $_SESSION["role"];
         $login_name  = $_SESSION["name"];
include "connection.php";
  ?>


<?php include 'header.php';?> 

 
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.css" type="text/css" >

<link rel="stylesheet" href="plugins/datatables/Responsive-2.2.2/css/responsive.bootstrap.min.css" type="text/css" >
<style type="text/css">
    button
    {
      width: auto;
    min-width: 0;
    }

    </style>
</head>
<body>
   
    <div id="main">
    <section>
    <?php include 'navbar.php';?>   
    </section>

    <section>
     <div class="ticket_generate">


         
  <?php if($role == 'employee') { ?>
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Ticket Generate</button>
  <?php } ?>
  
  
  
<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form class="modal-content" action="ticket_generate_code.php" method="POST">
    <div class="container">
      <h1>Complaint Register</h1>
      <hr>
      <div class=" box flex-container">
         <div class="form-control">
      <label for="customer_name"><b>Cutomer Name</b></label>
      <input type="text" placeholder="Enter Name" name="customer_name" required>
      <input type="hidden" value="<?php echo $user_id ;?>"  name="user_id">
      <input type="text" value="<?php echo $_SESSION["name"] ;?>"  name="name">

    </div>
      <div class="form-control">
      <label for="mobile"><b>Mobile Number</b></label>
      <input type="text" placeholder="Enter Mobile Number" name="mobile" required>
    </div>

    <div class="form-control form-text">
      <label for="address"><b>Address</b></label>
      <textarea cols="80" rows="3" placeholder="Enter Address" name="address" required></textarea>
    </div>
      </div>

      <div class=" box flex-container">

    <div class="form-control">
      <label for="company_name"><b>Company Name</b></label>
      <input type="text" placeholder="Enter Company" name="company_name" required>
  </div>

      <div class="form-control">
      <label for="product"><b>Product Name</b></label>
      <input type="text" placeholder="Enter product" name="product" required>


    </div>

    </div>
      </div>
     


    

      <div class="form-control form-text">
      <label for="query"><b>Query</b></label>
      <textarea cols="50" rows="8" placeholder="Enter Query" name="query" required></textarea>
          </div>

  

      <div class="clearfix">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <button type="submit" name="submit" class="signupbtn">Generate</button>
      </div>
   
  </form>
</div>
</div>
    </section>


    <section>
      <div class="datatable">
 <table id="example" class="display cell-border  "  style="width:100%">
 
        <thead>
            <tr>
                <th>Ticket No</th>
                <th>Customer Name</th>
                <!-- <th>Contact Number</th> -->
                <th>Company</th>
                <th>Query</th>
                <th>Date</th>
                 <th>Status</th>
             <?php if($role != 'employee')
             { ?>   
                
               
                <th>Action</th>
                <?php } ?>
            </tr>
        </thead>
        <tbody >
          <?php
  if( $role == 'employee')
  {
  $today_date=date("Y-m-d");
 $fetch_customer_query="SELECT `customer_id`, `ticket_no`, `user_id`, `name`, `customer_name`, `company_name`, `product`, `customer_number`, `description`, `dept`, `flag`, `added_date` FROM `customer_query` where DATE(added_date) = '$today_date' OR flag ='0' ORDER BY customer_id DESC ";
  } else  {
 $fetch_customer_query="SELECT `customer_id`, `ticket_no`, `user_id`, `name`, `customer_name`, `company_name`, `product`, `customer_number`, `description`, `dept`, `flag`, `added_date` FROM `customer_query` ORDER BY customer_id DESC ";

}
$result=mysqli_query($conn,$fetch_customer_query);
 
 
   while($row=mysqli_fetch_assoc($result))
   {

       $customer_id=$row["customer_id"];
       $ticket_no=$row["ticket_no"];
       $name=$row["name"];
         
  $user_id=$row["user_id"];
  $customer_name=$row["customer_name"];
  $company_name=$row["company_name"];
   $customer_number=$row["customer_number"];
   $description=$row["description"];
   $product=$row["product"];
   $dept=$row["dept"];
   $flag=$row["flag"];
   $added_date=$row["added_date"]; 
      
     

          ?>

            <tr>
                <td><?php echo $ticket_no; ?></td>
                <td><?php echo $customer_name; ?></td>

                <!-- <td><?php //echo $customer_number; ?></td> -->
                <td><?php echo $company_name.' , '.$product; ?></td>

               
                <td><?php echo $description; ?></td>
                <td><?php echo $added_date; ?></td>
<?php 
                if($flag == 0)
                {  
              ?>

                <td>Open</td>
              


                
                 <?php 
                if($role != 'employee')
                {   ?>

                <td><a class="dropdown-item"  id="close_open_product" data-id="<?php echo $customer_id.'-'.$flag.'-'.$login_name;?>" href="javascript:void(0)">Close</a></td>


         <?php    }  } elseif($flag == 1)
                 { ?>

                <td>Closed by <?php echo $name; ?></td>
             <?php 
                if($role != 'employee')
                {   ?>

                <td><a class="dropdown-item"  id="close_open_product" data-id="<?php echo $customer_id.'-'.$flag.'-'.$login_name;?>" href="javascript:void(0)">open</a></td>


         <?php    } } ?>
           

          
                
            </tr>
         <?php } ?>  
            
        </tbody>
        <tfoot>
            <tr>
               <th>Ticket No</th>
                <th>Customer Name</th>
                <!-- <th>Contact Number</th> -->
                <th>Company</th>
               
                <th>Query</th>
                <th>Date</th>
                <th>Status</th>
                  <?php if($role != 'employee')
             { ?>   
               
                <th>Action</th>
                <?php } ?>
            </tr>
        </tfoot>
    </table>

 </div>
</section>
</div>
    <script>

      $(document).ready(function() {
   var datatableInstance = $('#example').DataTable({
    responsive: true,
    ordering: false,
      dom: 'Bfrtip',
        buttons: [  
           
            
            {
                extend: 'excel',
                 title:'Call Out Report',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5]
                }
            }, 
            
            {
                extend: 'copy',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5]
                }
            }
            
            
            ]

   });


  $('#example thead  th').each(function () {
                        var title = $('#example tfoot th').eq($(this).index()).text();
                        $(this).html('<input type="text" placeholder="Search ' + title + '" />');
                    });

                    datatableInstance.columns().every(function () {
                        var dataTableColumn = this;

                        $(this.footer()).find('input').on('keyup change', function () {
                            dataTableColumn.search(this.value).draw();
                        });
                    });

                    datatableInstance.columns().every(function () {
           var dataTableColumn = this;
    var searchTextBoxes = $(this.header()).find('input');

    searchTextBoxes.on('keyup change', function () {
        dataTableColumn.search(this.value).draw();
    });

    searchTextBoxes.on('click', function (e) {
        e.stopPropagation();
    });
});
} );



      $(document).on('click', '#close_open_product', function(e){

            var data;           
            var productId = $(this).data('id');
            // alert(productId);
            SwalDelete(productId);
            e.preventDefault();
        });


    
    function SwalDelete(productId){
        
        swal({
            title: 'Are you sure?',
            
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'flag.php',
                    type: 'POST',
                    data: 'service_closed='+productId,
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Done!', response.message, response.status);
                   
                    location.reload();
                    // $( ".here" ).load(window.location.href + " .here" );
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
   


</script>


 <script src="plugins/datatables/JSZip-2.5.0/jszip.min.js"></script>
 <script src="plugins/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
 <script src="plugins/datatables/pdfmake-0.1.36/vfs_fonts.js"></script> 
                                      
                                          
<script src="plugins/datatables/datatables.min.js"></script>

        


  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.5/sweetalert2.min.js"></script>
    
</body>
</html>
<?php
}else
{
    session_unset();
  session_destroy();
  header("Location:index.php");
}
 ?>
