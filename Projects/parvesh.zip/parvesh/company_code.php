<?php

include "connection.php";


if (isset($_POST["submit"])) 
{
$name=mysqli_real_escape_string($conn,$_POST['name']);

$company_name=mysqli_real_escape_string($conn,$_POST['company_name']);

 $company_product=mysqli_real_escape_string($conn,$_POST['company_product']);

 $contact_person=mysqli_real_escape_string($conn,$_POST['contact_person']);
$contact_number=mysqli_real_escape_string($conn,$_POST['contact_number']);

$location=mysqli_real_escape_string($conn,$_POST['location']);

 $add_company="INSERT INTO `company`(`c_name`, `c_product`, `contact_person`, `contact_no`) VALUES ('$company_name' , '$company_product' , '$contact_person' , '$contact_number' )";
$query_compnay=mysqli_query($conn,$add_company);

 echo "<script>
			window.location.href='company.php';
			alert('SucessFully Added!!');
			</script>";	
}