-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2019 at 10:59 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `help_desk`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_product` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `active_deactive_flag` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`c_id`, `c_name`, `c_product`, `contact_person`, `contact_no`, `active_deactive_flag`, `disable_flag`, `added_date`) VALUES
(1, 'qnnwkldcnk', 'nckdlnlkn', 'nkldnkl', 'nklsknlcn', 0, 1, '2019-04-10 18:46:38');

-- --------------------------------------------------------

--
-- Table structure for table `customer_query`
--

CREATE TABLE `customer_query` (
  `customer_id` int(11) NOT NULL,
  `ticket_no` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `customer_number` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `dept` int(11) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_query`
--

INSERT INTO `customer_query` (`customer_id`, `ticket_no`, `user_id`, `name`, `customer_name`, `company_name`, `product`, `customer_number`, `description`, `dept`, `flag`, `added_date`) VALUES
(1, '0', 1, '', 'ROhan', '', '', '9967077028', 'ldncnc', 0, 0, '2019-04-10 15:18:38'),
(2, '0', 1, '', 'dcmdc;', '', '', 'mle;mcll;', 'ml;m;mx', 0, 0, '2019-04-10 15:20:41'),
(3, '0', 1, '', 'dmcmk', 'mkmk', '', '8765t543r3r4 ', 'mklmkl', 0, 0, '2019-04-10 15:21:49'),
(4, '0', 1, '', 'dmcmk', 'mkmk', '', '8765t543r3r4 ', 'mklmkl', 0, 0, '2019-04-10 15:23:14'),
(5, '0', 1, '', 'effk`', ' jk ckj k', 'nfn', '98894u92409', ' k', 0, 0, '2019-04-10 15:52:42'),
(6, '0', 1, '', 'lfnlkvn', 'klnklnkl', 'nklnkl', 'nlfknnnk', 'nklnlk', 0, 0, '2019-04-10 15:58:14'),
(7, 'T-nklnkln', 1, '', 'vm;fmq;m;lwm;l`', 'nknklnkl', 'nklnkklnklnnlk', 'nklnkln', 'lknnklkln', 0, 1, '2019-04-10 15:59:03'),
(8, 'T-jnjnj', 2, 'TEch1', 'jnjnjnnj', 'jnjn', 'njnjn', 'jnjnj', 'nnjnjn', 0, 0, '2019-04-11 08:19:43'),
(9, 'T-jnjn', 2, 'TEch1', ',mnjkknkjn', 'lknknk', 'lmnklnk', 'jnjn', 'kjjkij', 0, 1, '2019-04-11 08:20:23');

-- --------------------------------------------------------

--
-- Table structure for table `emp_leave`
--

CREATE TABLE `emp_leave` (
  `leave_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0',
  `disable_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_leave`
--

INSERT INTO `emp_leave` (`leave_id`, `user_id`, `user_name`, `from_date`, `to_date`, `reason`, `flag`, `disable_flag`) VALUES
(1, 3, 'emp1 ', '17-04-2019', '19-04-2019', 'CL', 2, 0),
(2, 3, 'emp1 ', '16-04-2019', '24-04-2019', 'SL', 1, 0),
(3, 1, 'admin ', '17-04-2019', '19-04-2019', 'SL', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `track_attendance`
--

CREATE TABLE `track_attendance` (
  `a_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attendance_time` time NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_number` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `active_deactive_flag` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `user_number`, `email_id`, `username`, `password`, `user_address`, `user_role`, `active_deactive_flag`, `disable_flag`, `added_date`) VALUES
(1, 'admin', '', '', 'admin', '12345', '', 'admin', 0, 0, '2019-04-10 14:37:57'),
(2, 'TEch1', '', '', 'tech1', '12345', '', 'technician', 0, 0, '2019-04-10 14:38:33'),
(3, 'emp1', '', '', 'emp1', '12345', '', 'employee', 0, 0, '2019-04-10 14:39:12'),
(4, 'dncskjdj', '9967077027', '', 'qwerty', '12345', '', 'employee', 1, 0, '2019-04-11 04:03:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `customer_query`
--
ALTER TABLE `customer_query`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `emp_leave`
--
ALTER TABLE `emp_leave`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `track_attendance`
--
ALTER TABLE `track_attendance`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_query`
--
ALTER TABLE `customer_query`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `emp_leave`
--
ALTER TABLE `emp_leave`
  MODIFY `leave_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `track_attendance`
--
ALTER TABLE `track_attendance`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
