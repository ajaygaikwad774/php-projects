  <div class="main-nav flex-container">
        

        <div class="logo flex-container  ">
        <div>
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
</div>
        <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="service.php">Services</a>
  <a href="company.php">Clients</a>
<?php if($role == 'admin')
{ ?>
  

   <a href="employee.php">Add Employee</a>
   <?php } ?>
   
   
   
   
  <a href="leave.php">Leave</a>

  <?php if($role == 'admin')
{ ?>
  <!-- <a href="attendance.php">Attendance</a> -->
<?php } ?>
</div>

       <a href="dashboard.php">    <img class="img-logo" src="img/helpdesk-support.png"></a>

</div>
    


<div class="dropdown">
  <?php if($role == 'admin'){ ?>
<img class=" dropbtn responsive_img" src="img/admin.jpg" >
 <?php  } elseif( $role == 'technician' ) {?>
<img class=" dropbtn responsive_img" src="img/tech.jpg" >
 <?php } elseif ($role == 'employee') {  ?>
  <img class=" dropbtn responsive_img" src="img/emp.jpg" >
  
<?php  } ?>
  
  <div class="dropdown-content">
    <a >Name : <?php echo $_SESSION["name"]; ?></a>
    <a href="sign_out.php">Sign Out</a>
  
  </div>
</div>
 
</div>
