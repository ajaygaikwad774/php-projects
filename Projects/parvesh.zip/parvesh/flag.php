<?php

include "connection.php";


if (isset($_POST["service_closed"])) 
{
  $closed_id = mysqli_real_escape_string($conn,$_POST['service_closed']);

  $demo = array();
$demo = explode("-",$closed_id);
 $customer_id = $demo[0];
 $flag = $demo[1];
$login_name = $demo[2];
 if($flag == '0')
 {
 	$set_flag = '1';
 }	elseif($flag == '1') 
 {
 	$set_flag ='0';
 }


 $flag_change = "UPDATE `customer_query` SET   `name`= '$login_name' , `flag`='$set_flag' WHERE customer_id='$customer_id'";
$flag = mysqli_query($conn,$flag_change);

if ($flag == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = 'Successfully Done ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to closed ...';
		}
		echo json_encode($response);


}
else if (isset($_POST['company_delete']))
{

	  $company_delete = mysqli_real_escape_string($conn,$_POST['company_delete']);




 $delete_query = "UPDATE `company` SET `disable_flag`='1' WHERE c_id='$company_delete'";
$stmt = mysqli_query($conn,$delete_query);


 

		if ($stmt == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = ' Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete  ...';
		}
		echo json_encode($response);



}

else if (isset($_POST['employee_delete']))
{

	  $employee_delete = mysqli_real_escape_string($conn,$_POST['employee_delete']);




 $delete_query = "UPDATE `user` SET `disable_flag`='1' WHERE user_id='$employee_delete'";
$stmt = mysqli_query($conn,$delete_query);


 

		if ($stmt == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = ' Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete  ...';
		}
		echo json_encode($response);



}
elseif (isset($_POST['inactive'])) 
{

	  $inactive = mysqli_real_escape_string($conn,$_POST['inactive']);

  $active_check = array();
$active_check = explode("-",$inactive);
 $user_id = $active_check[0];
 $flag_active_de = $active_check[1];

 if($flag_active_de == '0')
 {
 	$adflag = '1';
 	$msg = 'Deactive';
 }	elseif($flag_active_de == '1') 
 {
 	$adflag ='0';
 	$msg = 'Active';
 }


  $adflag_change = "UPDATE `user` SET `active_deactive_flag`='$adflag' WHERE user_id = '$user_id'";
$stmt_flag = mysqli_query($conn,$adflag_change);

if ($stmt_flag == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = 'Successfully ....';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to closed ...';
		}
		echo json_encode($response);

	
}

else if (isset($_POST['leave_delete']))
{

	  $leave_delete = mysqli_real_escape_string($conn,$_POST['leave_delete']);




 $delete_query = "UPDATE `emp_leave` SET `disable_flag`='1' WHERE leave_id='$leave_delete'";
$stmt = mysqli_query($conn,$delete_query);


 

		if ($stmt == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = ' Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete  ...';
		}
		echo json_encode($response);



}
else if (isset($_POST['leave_approve']))
{

	  $leave_approve = mysqli_real_escape_string($conn,$_POST['leave_approve']);




 $delete_query = "UPDATE `emp_leave` SET `flag`='1' WHERE leave_id='$leave_approve'";
$stmt = mysqli_query($conn,$delete_query);


 

		if ($stmt == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = ' Approved Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to Approve  ...';
		}
		echo json_encode($response);



}
else if (isset($_POST['leave_reject']))
{

	  $leave_reject = mysqli_real_escape_string($conn,$_POST['leave_reject']);




 $reject_query = "UPDATE `emp_leave` SET `flag`='2' WHERE leave_id='$leave_reject'";
$stmt = mysqli_query($conn,$reject_query);


 

		if ($stmt == TRUE ) {
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response['status']  = 'success';
			$response['message'] = ' Rejected Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to Reject  ...';
		}
		echo json_encode($response);



}

?>