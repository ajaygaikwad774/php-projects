<?php 
 include('connection.php');
  require('textlocal.class.php');
  
if(isset($_POST['query']))
{

          $course_data[] = (explode("-",$_POST['query']));
        //  print_r($course_data);
         $course_id = $course_data[0][0];
         $course_name = $course_data[0][1];
         $subjects = $course_data[0][2];

         $course = "SELECT  `total_fees` FROM `fh_course` WHERE  disable_flag='0' AND course_id = '$course_id'";
         $c_data=mysqli_query($conn,$course);
         $result_co=mysqli_num_rows($c_data);
         $fetch_course = mysqli_fetch_assoc($c_data);
         if( $result_co > 0)
         {
         echo  $course_fees = $fetch_course['total_fees'];
         }else
         {
         	echo '0';
         }
}else if(isset($_POST['fname']))
{
    
   
     
      
	                $numbers = array();

	 $fname=mysqli_real_escape_string($conn,$_POST["fname"]);
	  $lname=mysqli_real_escape_string($conn,$_POST["lname"]);
	  $full_name = $fname.''.$lname;
	  $gender=mysqli_real_escape_string($conn,$_POST["gender"]);
	   $mobile_no=mysqli_real_escape_string($conn,$_POST["mobile_no"]);
	    $pname_1=mysqli_real_escape_string($conn,$_POST["pname_1"]);
	     $pmobile_1=mysqli_real_escape_string($conn,$_POST["pmobile_1"]);
	      $pname_2=mysqli_real_escape_string($conn,$_POST["pname_2"]); 
	      $pmobile_2=mysqli_real_escape_string($conn,$_POST["pmobile_2"]);
	       $address_1=mysqli_real_escape_string($conn,$_POST["address_1"]);
	        $address_2=mysqli_real_escape_string($conn,$_POST["address_2"]);
	        $dob = mysqli_real_escape_string($conn,$_POST["d_date"]);


             $roll_no = mysqli_real_escape_string($conn,$_POST["roll_no"]);
             $payment_type = mysqli_real_escape_string($conn,$_POST["payment_type"]);
             $installment = mysqli_real_escape_string($conn,$_POST["no_inst"]);
             $installment_date = mysqli_real_escape_string($conn,$_POST["installment_date"]);
             
              $send_install_val = mysqli_real_escape_string($conn,$_POST["send_install_val"]);
              
              
         echo $checkbox=mysqli_real_escape_string($conn,$_POST["check-box"]);
             
               
             

	        $full_address = $address_1.' '.$address_2;
	        
	    

	            $course_data[] = (explode("-",$_POST['course_info']));
         // print_r($course_data);
         $course_id = $course_data[0][0];
         $course_name = $course_data[0][1];
         $subjects = $course_data[0][2];

         $batch_data[] = (explode("-",$_POST['batch_info']));
         // print_r($batch_data);
         $batch_name = $batch_data[0][0];
         $batch_id = $batch_data[0][1];
         $batch_time = $batch_data[0][2];

       $course_fees=mysqli_real_escape_string($conn,$_POST["course_fees"]);
	      $discount=mysqli_real_escape_string($conn,$_POST["discount"]);
	        $f_amount=mysqli_real_escape_string($conn,$_POST["f_amount"]);
          
         $p_amount=mysqli_real_escape_string($conn,$_POST["p_amount"]);
	      $r_amount=mysqli_real_escape_string($conn,$_POST["r_amount"]);
	      
	      
	      
	       if(($installment == '0' || $installment == null || $installment == ' ') && ($p_amount == '0' || $p_amount == null || $p_amount == ' ') )
                {
                    $no_inst = 0;
                    $p_amount = 0;
                    
                }else{
                    
                    $no_inst = $installment - 1 ;
                    
                }
                
                //password and fcm id set
                
                	$sql12 = "SELECT `password`   FROM `fh_user` WHERE `p_mobile_no_1` ='$pmobile_1'  AND `role` ='student' AND `disable_flag` = 0 ";
                	
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	    // output data of each row
			$row = $result12->fetch_assoc();
				
				        $password = $row['password'];
				       
				        
				
	    
	}else {
	        $password = sprintf("%06d", mt_rand(1, 999999));
	}
                
	      
	       $today_date =  date("Y-m-d H:i:s");


                    ///assign username


            
            $lastid = "SELECT MAX(user_id) as user_id FROM fh_user  WHERE disable_flag = '0' AND role = 'student' AND batch_id = '$batch_id'";
         $lid=mysqli_query($conn,$lastid);
            $result_id=mysqli_num_rows($lid);
             if( $result_id > 0)
         {
            $get_last_id = mysqli_fetch_assoc($lid);
             $n = $get_last_id['user_id'];
              $last_g_id = $n + 1 ;
        } 
        else 
        {
             $last_g_id ='1';
        }

        

            
	      	$user_name = 'W-'.$fname.'-'.$last_g_id;

          $today_date =  date("Y-m-d H:i:s");
         $add_student = "INSERT INTO `fh_user`( `roll_no` , `f_name`, `l_name`, `user_name`, `password`, `role`, `gender`, `mobile_no`, `dob` ,  `parent_name_1`, `parent_name_2`, `p_mobile_no_1`, `p_mobile_no_2`, `address`, `course_id`, `course_name`, `batch_id`, `batch_name`, `batch_time`, `subject`) VALUES ('$roll_no' , '$fname' , '$lname' , '$user_name' ,'$password' , 'student' , '$gender' , '$mobile_no' , '$dob' ,'$pname_1' , '$pname_2', '$pmobile_1' , '$pmobile_2' ,'$full_address','$course_id','$course_name' , '$batch_id' ,'$batch_name' , '$batch_time' , '$subjects' )";
         $add_s=mysqli_query($conn,$add_student);

         if($add_s)
             {

         $last_id = $conn->insert_id;
         

         $student_fees = "INSERT INTO `fh_fees`( `user_id`, `username`, `batch_id`, `course_id`, `course_name` , `course_fees` , `payment_type` , `installment_amount` , `no_installment`, `installment_date` , `total_fees`, `discount_amount`, `paid_amount`, `due_amount` , `added_date`) VALUES ('$last_id','$full_name' , '$batch_id' , '$course_id' , '$course_name' , '$course_fees' , '$payment_type' , '$send_install_val' , '$no_inst' , '$installment_date' , '$f_amount' , '$discount' , '$p_amount' , '$r_amount' , '$today_date') ";
         $add_fees=mysqli_query($conn,$student_fees);

             }

         
             if($add_s && $add_fees)
             {
                
                
                
              
             
            //  echo "<script>
            // window.location.href='add_student.php'';
            // alert('SucessFully Added !!');
            // </script>"; 
            // // header('Location:add_student.php');
                
                 if($checkbox != '' && $checkbox != Null && $checkbox == 'yes_sms_student'  )
                {  
                    
                       
 
 
                                	$Textlocal = new Textlocal(false, false, 'Pr/NmR5gAEU-qPoFDu5kq505b5dPBTHslm5wmVLNZN');
                                	
                                
 
                                         	$numbers[] = $pmobile_1 ;
                                         	
                                         	
	print_r($numbers);
//	$full_name = 'Rohan Naik';
                                    	$sender = 'WISDOM';
                                	$message = "Dear $fname,%nThank You for Your registration.%nID: $pmobile_1%nPassword: $password%nPlease contact if any query.%nBest Wishes,%nWisdom Academy.%n9321302424";
//	echo $message;


 
                            	$response = $Textlocal->sendSms($numbers, $message, $sender);
                                //	print_r($response);
     echo "<script type='text/javascript'>alert('SucessFully Added !!! Password = $password');window.location.href='add_student.php';</script>";
        	
        
        
                       }
            
 
             }else
             {
                 echo "<script>
            window.location.href='add_student.php'';
            alert('Please Add Again!!!!');
            </script>"; 
           
             }

}else if(isset($_POST['batch_data']))
{
           $batch_data[] = (explode("-",$_POST['batch_data']));
         // print_r($batch_data);
         $batch_name = $batch_data[0][0];
         $batch_id = $batch_data[0][1];
         $batch_time = $batch_data[0][2];

          $deleteid = "SELECT `user_id` , `roll_no` FROM `fh_user` WHERE disable_flag = '1' AND batch_id = '$batch_id' AND role = 'student' ORDER BY user_id ASC";
         $gdelete=mysqli_query($conn,$deleteid);
            $result_d=mysqli_num_rows($gdelete);
         if( $result_d > 0)
         {
           $get_delete = mysqli_fetch_assoc($gdelete);
            echo $n = $get_delete['roll_no'];
        }else
        {
            
            $lastid = "SELECT MAX(roll_no) as roll_no FROM fh_user  WHERE disable_flag = '0' AND role = 'student' AND batch_id = '$batch_id'";
         $lid=mysqli_query($conn,$lastid);
            $result_id=mysqli_num_rows($lid);
             if( $result_id > 0)
         {
            $get_last_id = mysqli_fetch_assoc($lid);
             $n = $get_last_id['roll_no'];
            echo  $n + 1 ;
        } else 
        {
           echo  $n ='1';
        }

  }


}
?>