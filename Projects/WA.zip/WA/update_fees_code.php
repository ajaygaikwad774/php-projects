


<?php

//fetch.php

include('connection.php');


 require('textlocal.class.php');
 


 $userid = $_POST['userid'];


   $query = "SELECT fh_user.user_id,fh_user.roll_no, fh_user.f_name, fh_user.l_name, fh_user.user_name, fh_user.mobile_no, fh_user.p_mobile_no_1 , fh_user.batch_name, fh_user.subject , fh_fees.fees_id, fh_fees.course_fees, fh_fees.total_fees, fh_fees.discount_amount, fh_fees.paid_amount, fh_fees.due_amount , fh_fees.installment_amount , fh_fees.no_installment FROM fh_user INNER JOIN fh_fees ON fh_user.user_id = fh_fees.user_id WHERE fh_user.disable_flag='0' AND fh_user.role = 'student' AND fh_user.user_id ='$userid'";


$user_q = mysqli_query($conn,$query);
   $count = mysqli_num_rows($user_q);

  if(isset($_POST['update_fees']))
{

$row=mysqli_fetch_assoc($user_q);
                 

     if($row['due_amount'] != '0')
     {
?>
<!-- action="update_details_code.php" -->
 <form  method="POST" id='update_d' class="form-horizontal" >
                            <div class="form-body">
                                    
                                       
                                            
                                       
                                        <h3 class="box-title">Fees Details</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <div class="row">
                                        	<div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" value="<?php echo $row['f_name'].' '.$row['l_name'];?>" disabled  required class="form-control">
                                                    </div>
                                                </div>
                                            </div><div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Roll No<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" value="<?php echo $row['roll_no'];?>" disabled required  class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Batch Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" value="<?php echo $row['batch_name'];?>" disabled required  class="form-control">
                                                        <input type="hidden"  name="feesid"
                                                         value="<?php echo $row['fees_id'];?>" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Final Amount<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id='f_amount' required name="f_amount" value="<?php echo $row['total_fees']?>" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                         
                                            <!--/span-->
                                        </div>
                                        <!--/row-->

                                        <div class="row">
                                            
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Paid amount<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id='paid_amount' required   value=" <?php echo $row['paid_amount']?>" class="form-control">
                                                        <input type="hidden" id='sp_amount' required name="sp_amount" class="form-control">
                                                         <input type="hidden"  name="userid" value="<?php echo $userid?>" class="form-control">
                                                         <small ><h5  style="color:red;">Per Installment Amount<span > <?php echo $row['installment_amount']?></span></h5></small>
                                                         
                                                             <input type="hidden" readonly name='i_amount'    value=" <?php echo $row['installment_amount']?>" class="form-control">
                                                         
                                                         


                                                    </div>
                                                </div>
                                            </div>
                                   
                                       <div class="col-md-6">
                                                <div class="form-group row">
                                                 <label class="control-label text-right col-md-3">Pay Amount</label>
                                                   <div class="col-md-9">
                                                        <input type="text" required id="p_amount"  name="p_amount" class="form-control">
                                                         <small ><h5  style="color:red;">Due Amount<span id="d_amount"> <?php echo $row['due_amount']?></span></h5><input type="hidden" required id="final_amount" name="r_amount"></small>
                                                    </div> 
                                            </div>
                                            <!--/span-->
                                        </div>
                                         <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Do you want to send sms? <span style="color:red">*</span>
                                                    <input type="checkbox"  name="check-box" value="yes_sms_fees" >
                                                    </label>
                                                    
                                            
                                                    
                                                </div>
                                              </div>
                                        <!--/row-->
                                     </div>
                                    <hr>
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                          <button type="button" id="update_submit" name="update_submit" class="btn btn-success">Update</button>
                                                    </div>
                                                </div>
                                            </div>
                                          
                                        </div>
                                    </div>
                                  </div>
                    </form>

 <?php }else {


             echo"Already Paid";
             



             }
     
   }else if(isset($_POST['sp_amount']))
   {

         $sp_amount=mysqli_real_escape_string($conn,$_POST["sp_amount"]);
     //  echo '<br>';
	      $r_amount=mysqli_real_escape_string($conn,$_POST["r_amount"]);

	      $feesid=mysqli_real_escape_string($conn,$_POST["feesid"]);
	      $i_amount=mysqli_real_escape_string($conn,$_POST["i_amount"]);
	      
	       echo $checkbox=mysqli_real_escape_string($conn,$_POST["check-box"]);
	      
	      $no_installment = $r_amount / $i_amount ;
	      


   $query = "UPDATE `fh_fees` SET `paid_amount`='$sp_amount',`due_amount`='$r_amount' , `installment_amount` ='$i_amount' , `no_installment`='$no_installment'  WHERE user_id='$userid' AND fees_id='$feesid'";


$stmt = mysqli_query($conn,$query);

            	$query_noti = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `p_mobile_no_1` ,  `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND role = 'student' AND user_id = '$userid'";


	                        
  
 			                      	$result_data = mysqli_query($conn,$query_noti);
 			                      	
                 
                 
 			
 				    

	       function sendMessage($token,$notice_name,$notice_content)
         {


        //   print_r($token);

        // $content = ["en" => 'English Message'];
                  $headings=["en" => $notice_name]; 

                   $content = array(
                   	//  "title" =>$notice_name,
                       "en" => $notice_content
                       );

                    $fields = array(
                    	//app id from one signal
                        'app_id' => "69e4fa75-66e9-4e1a-9b70-7f859e4afd74",
                        // device id from database

                        'include_player_ids' => $token ,
                        // 'included_segments' => array('All'),
                        'data' => array("foo" => "bar"),
                         'small_icon' => "https://www.appdid.com/WA//assets/images/small.png",
                         'large_icon' => "https://www.appdid.com/WA//assets/images/large.png",
                        //'big_picture'=>"http://onthefield.in/Pass2fit/assets/images/notification_icon2.png",
                          'headings'=> $headings,

                         'contents' => $content
                     );

                                $fields = json_encode($fields);
                            //print("\nJSON sent:\n");
                            //print($fields);

                         $ch = curl_init();
                         curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
                         //Authorization key from one signal 
                         curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic MDQ4ZGQ4MzktYjFiZi00ZjA0LTg4MjUtZmFiNTE0NzA1ZjMx'));
                         curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                         curl_setopt($ch, CURLOPT_HEADER, FALSE);
                          curl_setopt($ch, CURLOPT_POST, TRUE);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
                          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

                          $response1 = curl_exec($ch);
                          curl_close($ch);
                          return $response1;
                 }
                 
                 
                 $response = array();
	                $token = array();
	                $numbers = array();

                 $row_fcm = mysqli_fetch_array($result_data);
                 
                
                    // echo  $row_fcm['fcm_id'].'/n';
                       $token[]=$row_fcm['fcm_id']; 
                       $numbers[] = $row_fcm['p_mobile_no_1'];
                       
                       
                       $notice_name = 'Fess Details';
                       if($r_amount == 0)
                       {
                       $notice_content = "Thank You for paying all due " ;
                       }
                       else{
                            $notice_content = "Remaining Amount ".$r_amount;
                       }
                
                
                 
                 
            //   print_r($token);

                        $response = sendMessage($token,$notice_name,$notice_content);
                    	$return["allresponses"] = $response;
                     	$return = json_encode( $return);
                     	
                     	
                     	 if($checkbox != '' && $checkbox != Null && $checkbox == 'yes_sms_fees'  )
                {
                          
                                	$Textlocal = new Textlocal(false, false, 'Pr/NmR5gAEU-qPoFDu5kq505b5dPBTHslm5wmVLNZN');
                                	
                                $current_d = date('d-m-Y');

 
                                        //  	$numbers[] = $pmobile_1 ;
                                         	
                                         $full_name = $row_fcm['f_name'].' '.$row_fcm['l_name'];	
                                     	// print_r($numbers);
                                    //	$full_name = 'Rohan Naik';
                                    	$sender = "WISDOM";
                                	$message =  "Dear $full_name,%nWe have received fees of INR $sp_amount from you on $current_d.%nThank You,%nWisdom's Academy%n9321302424";

                                                //   	echo $message;


 
                            	$response = $Textlocal->sendSms($numbers, $message, $sender);
                                	print_r($response);
  
        
                       }
                   
                //   print($return);
        
       
       if($stmt)
       {
            echo "<script>
			window.location.href='add_fees.php';
			alert('SucessFully Added!!');
			</script>";	
       }else
       {
       	 echo "<script>
			window.location.href='add_fees.php';
			alert('Please Try Again!!');
			</script>";	

       }

   }
 ?>