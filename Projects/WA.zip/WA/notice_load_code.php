<?php

include('connection.php'); 

       

   $query12 = "SELECT `notice_id`, `notice_name`, `user_id`, `batch_id`, `notice_type`, `notice_content`, `disable_flag`, `added_date` FROM `fh_notice` WHERE disable_flag='0'";
             $info12=mysqli_query($conn,$query12);
                 $result_c=mysqli_num_rows($info12);
                 ?>
                  <thead>
                                            <tr>
                                                <th>User ID</th>
                                                <th>Batch ID</th>
                                                <th>Notice Name</th>
                                                <th>Notice Content </th>
                                                 <th>Action</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                        

          <?php      while($row = mysqli_fetch_assoc($info12))

                 {  ?>
                 	 <tr>

                           <td><?php echo $row['user_id']; ?></td>
                           
                           <td><?php echo $row['batch_id']; ?></td>
                           <td><?php echo $row['notice_name']; ?></td>
                           <td><?php echo $row['notice_content']; ?></td>
                           <td> <a id="delete_notice" data-id="<?php echo $row['notice_id']; ?>"href="javascript:void(0)"><i class="mdi mdi-delete"></i></a> </td>
                                                
                                            </tr>


 <?php
}
 ?>                
</tbody>
