<?php

include('connection.php'); 
 if(isset($_POST['batch_id']) && isset($_POST['subject_name']) &&  isset($_POST['test_date']))
  
{

          $batch_id =  $_POST['batch_id'];
           $subject_name = $_POST['subject_name'];
           $test_date= $_POST['test_date'];

   $query12 = "SELECT `test_id`, `batch_id` ,`test_name`, `subject`, `chapter`, `marks`, `test_date`, `from_time`, `to_time`, `disable_flag`, `added_date` FROM `fh_test` WHERE disable_flag = '0' AND subject ='$subject_name' AND batch_id ='$batch_id' AND test_date ='$test_date'";
                                             $info12=mysqli_query($conn,$query12);
                                                $result_c=mysqli_num_rows($info12);


                            

?>
                                    <option value=''>None</option>
  <?php                                  while($row = mysqli_fetch_assoc($info12))
                                   {  ?>
                    <option value='<?php echo $row["test_id"]; ?>'><?php echo $row["test_name"]; ?></option>
                         <?php        }
                                   ?>
<?php
}
else if(isset($_POST['batch_id']) && isset($_POST['subject_name']) )
{
	   $batch_id =  $_POST['batch_id'];
           $subject_name = $_POST['subject_name'];
        

   $query12 = "SELECT `test_id`, `batch_id` ,`test_name`, `subject`, `chapter`, `marks`, `test_date`, `from_time`, `to_time`, `disable_flag`, `added_date` FROM `fh_test` WHERE disable_flag = '0' AND subject ='$subject_name' AND batch_id ='$batch_id' ORDER BY test_id DESC";
                                             $info12=mysqli_query($conn,$query12);
                                                $result_c=mysqli_num_rows($info12);

?>
                                    <option value=''>None</option>
  <?php                                  while($row = mysqli_fetch_assoc($info12))
                                   {  ?>
                    <option value='<?php echo $row["test_id"]; ?>'><?php echo $row["test_name"]; ?></option>
                         <?php        }
                                   ?>

<?php }
 	