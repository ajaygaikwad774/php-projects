<?php
	
	$response = array();
	require_once 'connection.php';
	
	if (isset($_POST['assignment'])) {
		
		
		$assignment_id = mysqli_real_escape_string($conn,$_POST['assignment']);
$query = "UPDATE `fh_assignment` SET `disable_flag`='1' WHERE assignment_id='$assignment_id'";
		$stmt = mysqli_query($conn, $query );


		if ($stmt == TRUE ) {
			
			$response['status']  = 'success';
			$response['message'] = 'Assignment Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete Assignment ...';
		}
		echo json_encode($response);


	}
	?>