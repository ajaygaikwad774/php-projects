<?php 	 
     $token = array();


 $token[]="b9a2c906-09e1-44ee-829e-0a52980709c4";
    




function sendMessage($token){

        // $content = ["en" => 'English Message'];
        $headings=["en" => 'Pass2fit']; 

    $content = array(
    	// "title" =>"Attendance",
        "en" => "You're Attendance has been sucessfully Marked"
        );

    $fields = array(
    	//app id from one signal
        'app_id' => "69e4fa75-66e9-4e1a-9b70-7f859e4afd74",
        // device id from database

        'include_player_ids' => $token ,
        // 'included_segments' => array('All'),
        'data' => array("foo" => "bar"),
        'small_icon' => "http://onthefield.in/Pass2fit/assets/images/ic_stat_onesignal_default.png",
        'large_icon' => "http://onthefield.in/Pass2fit/assets/images/notification_icon1.png",
        //'big_picture'=>"http://onthefield.in/Pass2fit/assets/images/notification_icon2.png",
         'headings'=> $headings,

        'contents' => $content
    );

    $fields = json_encode($fields);
//print("\nJSON sent:\n");
//print($fields);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    //Authorization key from one signal 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic MDQ4ZGQ4MzktYjFiZi00ZjA0LTg4MjUtZmFiNTE0NzA1ZjMx'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

    $response1 = curl_exec($ch);
    curl_close($ch);
    return $response1;
}



//sendMessage($token);


$response = sendMessage($token);
$return["allresponses"] = $response;
$return = json_encode( $return);
// print("\n\nJSON received:\n");
// print($return);
// print("\n");


		// $stmt->execute(array(':pid'=>$pid));
		// $stmt1=mysqli_num_rows($stmt);
		
			//$response=array("status"=>"sucess","message"=>"gjhjhjh");
			$response12['status']  = 'success';
			$response12['message'] = 'Attendance Done';
			
		
		echo json_encode($response12);
	

?>