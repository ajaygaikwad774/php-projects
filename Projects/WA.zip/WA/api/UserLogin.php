<?php
require "connection.php";
// $userDetails = array();


$username = null;  
$password = null; 
$fcm_id = null;
$device_type = null;
$version_code=null;
$version_name=null;


if($_SERVER['REQUEST_METHOD']=='POST'){
	
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	 $fcm_id = $_POST['fcm_id'];
	// $device_type = $_POST['device_type'];
	// $version_code= $_POST['version_code'];
	// $version_name= $_POST['version_name'];
}


if($_SERVER['REQUEST_METHOD']=='GET')
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	$fcm_id = $_POST['fcm_id'];
// 	$device_type = $_POST['device_type'];
// 	$version_code= $_POST['version_code'];
// 	$version_name= $_POST['version_name'];

}

	
//To Get Todays date
	$Todays_date= date('Y-m-d');
	

	
	 
	 	$sql12 = "SELECT `user_id`, `f_name`, `l_name`, `email_id`, `gender` ,  `mobile_no`, `parent_name_1`, `parent_name_2`, `p_mobile_no_1`, `p_mobile_no_2`, `address`, `course_id`, `course_name`, `batch_id`, `batch_name`, `subject`,`fcm_id`  FROM `fh_user` WHERE `p_mobile_no_1` ='$username' AND `password`='$password' AND `disable_flag` ='0' AND `role` ='student' ";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
				        $user_id= $row['user_id'];
				        $f_name= $row['f_name'];
						$l_name = $row['l_name'];
						$full_name = $f_name.' '.$l_name;
				        $email_id = $row['email_id'];
						$mobile_no = $row['mobile_no'];
						$gender = $row['gender'];
				        $parent_name_1 = $row['parent_name_1'];
				        $parent_name_2 = $row['parent_name_2'];
				        $p_mobile_no_1 = $row['p_mobile_no_1'];
				        $p_mobile_no_2 = $row['p_mobile_no_2'];
				        $address = $row['address'];
				        $course_id = $row['course_id'];
				        $course_name = $row['course_name'];
				       
				        $batch_id = $row['batch_id'];
				        $batch_name = $row['batch_name'];
						$subject = $row['subject'];
						 $fcm_id1 = $row['fcm_id'];
				       
				      
				       
				        
				         if($parent_name_2==NULL || $parent_name_2==null)
				        {
				            $parent_name_2="-";
				        } else
				        {
				             $parent_name_2=$parent_name_2;
				        }
						
					
					
				          if($p_mobile_no_2==NULL || $p_mobile_no_2==null)
				        {
				            $p_mobile_no_2="-";
				        } else
				        {
				             $p_mobile_no_2=$p_mobile_no_2;
				        }
						
				        
				        if($fcm_id1==NULL || $fcm_id1==null)
				        {
				            $fcm_id="-";
				        } else
				        {
				            $fcm_id1=$fcm_id1;
				        }
				        
				        
				          
				        
			                     $userDetails=array(
								 "user_id"=> $user_id,
								 "name"=> $full_name,
								 "email_id"=> $email_id,
								 
							     "contact_no"=> $mobile_no,
                               
                               "address"=> $address,
                               "course_id"=> $course_id,
                               "course_name"=> $course_name,
                               "batch_id"=> $batch_id,
                               "batch_name"=> $batch_name,
								 "subject"=> $subject,
								  "fcm_id"=> $fcm_id1
								 
								);
	
		        }


                    if( $result12)
                   { 	
		        	// //update fcm id
	$sql = "UPDATE `fh_user` SET `fcm_id`='$fcm_id' WHERE `p_mobile_no_1` ='$username'  AND `password` ='$password'";
	
	$result = $conn->query($sql);
		}
// 		$response = array("response" => $userDetails);
		echo json_encode($userDetails);
		
	}
	else
	{
		$response = "failure";
		echo json_encode($response);
	}
	
	
	
?>