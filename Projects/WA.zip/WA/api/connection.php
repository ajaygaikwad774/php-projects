<?php 
$dbServername="localhost";
$dbUsername="wisdomacademy";
$dbPassword="wisdomacademy";
$dbName="wisdomacademy";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
// if($conn)
// {
//     echo "s";
// }
// else
// {
//     echo "n";
// }
?>