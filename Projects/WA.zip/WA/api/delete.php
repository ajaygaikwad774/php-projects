<?php

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $id = $_POST['id'];

    require_once("connect.php");
    
    $sql_query = "DELETE FROM `studentdetails`  WHERE id= '$id' ";
    
    if(mysqli_query($conn,$sql_query))
    {
        $response['success'] = true;
        $response['message'] = "Successfull";
    }
    else
    {
        $response['success'] = false;
        $response['message'] = "Failed";
     
    }
}
else
{
        $response['success'] = false;
        $response['message'] = "Error";
   
}

echo json_encode($response)

?>