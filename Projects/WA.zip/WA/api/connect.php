<?php

$conn = mysqli_connect("localhost","wisdomacademy","wisdomacademy","wisdomacademy");

// if($conn)
// {
//     echo "Success";
// }
// else
// {
//     echo "Failed";
// }


?>