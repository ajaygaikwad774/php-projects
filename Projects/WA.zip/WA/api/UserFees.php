<?php
require "connection.php";

$user_id = null;
 



if($_SERVER['REQUEST_METHOD']=='POST'){
	
    $user_id = $_POST['user_id'];
    

}


if($_SERVER['REQUEST_METHOD']=='GET')
{
    $user_id = $_GET['user_id'];
   

}

	

	 
	 	$sql12 = "SELECT `fees_id`, `user_id`, `username`, `batch_id`, `course_id`, `course_name`, `total_fees`, `discount_amount`, `paid_amount`, `due_amount` FROM `fh_fees` WHERE user_id ='$user_id' AND disable_flag = '0'";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
				        $username= $row['username'];
                        $course_name= $row['course_name'];
                        $total_fees= $row['total_fees'];
                        $discount_amount= $row['discount_amount'];
                        $paid_amount= $row['paid_amount'];
                        $due_amount= $row['due_amount'];

                        
				    
 
			                     $UserFees=array(
									 
                                 "username"=> $username ,
                                 "course_name"=> $course_name ,
                                 "total_fees"=> $total_fees ,
                                 "discount_amount"=> $discount_amount ,
                                 "paid_amount"=> $paid_amount ,
								 "due_amount"=> $due_amount
								 
							     
								 
								);
	
		        }
// 		$response = array($UserFees);
		
		echo json_encode($UserFees);
		
	}
	else
	{
		$response =  "failure";
		echo json_encode($response);
	}
	
	
	
?>