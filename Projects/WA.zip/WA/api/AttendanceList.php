<?php
require "connection.php";

$user_id = null;  



if($_SERVER['REQUEST_METHOD']=='POST'){
	
	
	$user_id = $_POST['user_id'];

}


if($_SERVER['REQUEST_METHOD']=='GET')
{
	$user_id = $_GET['user_id'];


}

	          $today_date = date("Y-m-d");
              $last_ten_days = date('Y-m-d', strtotime('-11 day', strtotime($today_date)));
        
	 
		$sql12 = "SELECT `attendance_flag` , date(`added_date`)as attendace_date FROM `fh_attendance` WHERE  user_id='$user_id' AND  Date(`added_date`) BETWEEN '$last_ten_days' AND '$today_date'  ORDER BY atten_id DESC";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
				        $attendance_flag= $row['attendance_flag'];
				        $attendace_date1= $row['attendace_date'];
						

						if ($attendance_flag == '0')
						{
                           $attendace1 = 'Present';
						}else if($attendance_flag == '1')
						{
							$attendace1 = 'Absent';
						}else
						{
							$attendace1 = '-';
						}
					 
						
						$AttendaceDate = date("d-m-Y", strtotime($attendace_date1));
 
			                     $attendanceDetails[]=array(
									 
								 "attendace"=> $attendace1 ,
								 "attendacedate"=> $AttendaceDate
								 
							     
								 
								);
	
		        }
// 		$response = array("response" => $attendanceDetails);
		
		echo json_encode($attendanceDetails);
		
	}
	else
	{
		$response = "failure";
		echo json_encode($response);
	}
	
	
	
?>