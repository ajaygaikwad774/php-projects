<?php
require "connection.php";


$batch_id = null;  



if($_SERVER['REQUEST_METHOD']=='POST'){
	
	
	$batch_id = $_POST['batch_id'];

}


if($_SERVER['REQUEST_METHOD']=='GET')
{
	$batch_id = $_GET['batch_id'];


}

	

	 
	 	$sql12 = "SELECT  `test_name`, `subject`, `chapter`, `marks`, `test_date`, `from_time`, `to_time` FROM `fh_test` WHERE batch_id ='$batch_id' AND disable_flag='0' ORDER BY test_id DESC";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
				        $test_name= $row['test_name'];
                        $subject= $row['subject'];
                         $chapter= $row['chapter'];
                        $marks= $row['marks'];
                        $test_date= $row['test_date'];
                        $from_time= $row['from_time'];
                         $to_time= $row['to_time'];
				       
						
				
						$TestDate = date("d-m-Y", strtotime($test_date));
 
			                     $TestDetails[]=array(
									 
                                 "test_name"=> $test_name ,
                                 "subject"=> $subject ,
                                 "chapter"=> $chapter ,
                                 "marks"=> $marks ,
                                 "test_date"=> $TestDate ,
								 "from_time"=> $from_time,
								 "to_time"=> $to_time
								 
							     
								 
								);
	
		        }
// 		$response = array("response" => $TestDetails);
		
		echo json_encode($TestDetails);
		
	}
	else
	{
		$response = "failure";
		echo json_encode($response);
	}
	
	
	
?>