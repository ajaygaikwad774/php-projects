<?php
require "connection.php";
// $attendanceDetails = array();


$batch_id = null;  



if($_SERVER['REQUEST_METHOD']=='POST'){
	
	
	$batch_id = $_POST['batch_id'];

}


if($_SERVER['REQUEST_METHOD']=='GET')
{
	$batch_id = $_GET['batch_id'];


}

	

	 
	 	$sql12 = "SELECT  `assignment_id` ,  `batch_id`, `assignment_name` , `assignment_content`, `assignment_image` , `assignment_submit_date` FROM `fh_assignment` WHERE `batch_id` ='$batch_id' AND `disable_flag` ='0' ORDER BY assignment_id DESC";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
					     $assignment_id= $row['assignment_id'];   
					     $batch_id= $row['batch_id'];
						 $assignment_name= $row['assignment_name'];
						 $assignment_content= $row['assignment_content'];
						 $assignment_image= $row['assignment_image'];
						 $assignment_submit_date = $row['assignment_submit_date'];
					
						
						 $submit_date = date("d-m-Y", strtotime($assignment_submit_date));
 
			                     $AssignmentDetails[]=array(
								
							      "assignment_id"=> $assignment_id ,
								 "batch_id"=> $batch_id ,
								 "assignment_name"=> $assignment_name ,
								 "assignment_content"=> $assignment_content ,
								

								 "submit_date"=> $submit_date
							
								);
	
		        }
// 		$response = array("response" => $AssignmentDetails);
		
		echo json_encode($AssignmentDetails);
		
	}
	else
	{
		$response ="failure";
		echo json_encode($response);
	}
	
	
	
?>