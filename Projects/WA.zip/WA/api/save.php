<?php

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $student_name = $_POST['student_name'];
    $school_name = $_POST['school_name'];
    $contact_no = $_POST['contact_no'];
    $student_std = $_POST['student_std'];
    
    require_once("connect.php");
    
    $sql_query = "INSERT INTO `studentdetails` (student_name, school_name, contact_no, student_std) VALUES ('$student_name','$school_name','$contact_no','$student_std')";
    
    if(mysqli_query($conn,$sql_query))
    {
        $response['success'] = true;
        $response['message'] = "Successfull";
    }
    else
    {
        $response['success'] = false;
        $response['message'] = "Failed";
     
    }
}
else
{
        $response['success'] = false;
        $response['message'] = "Error";
   
}

echo json_encode($response)

?>