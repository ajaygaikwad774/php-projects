<?php

header("Content-type:appliction/json");

require_once('connect.php');

$sql_query = mysqli_query($conn,"SELECT * FROM `studentdetails`");

$response = array();

while($row = mysqli_fetch_assoc($sql_query))
{
    array_push($response,
    array(
        'id' => $row['id'],
        'student_name' => $row['student_name'],
        'school_name' => $row['school_name'],
        'contact_no' => $row['contact_no'],
        'student_std' => $row['student_std'],
        'date' => $row['date'])
    );
    
}

echo json_encode($response)

?>