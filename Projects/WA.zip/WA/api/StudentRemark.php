<?php
require "connection.php";

$user_id = null;
 



if($_SERVER['REQUEST_METHOD']=='POST'){
	
    $user_id = $_POST['user_id'];
    

}


if($_SERVER['REQUEST_METHOD']=='GET')
{
    $user_id = $_GET['user_id'];
   

}

	

	 
	 	$sql12 = "SELECT `notice_name`,  `notice_content` FROM `fh_notice` WHERE user_id='$user_id' AND disable_flag='0' AND notice_type = 'Individual' ORDER BY notice_id DESC";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
				        // $notice_id= $row['notice_id'];
                        $notice_name= $row['notice_name'];
                      
                        $notice_content= $row['notice_content'];
                
			                     $UserNotice[]=array(
									 
                                 "notice_name"=> $notice_name ,
                                 "notice_content"=> $notice_content 
                                 
								);
	
		        }
	
		
		echo json_encode($UserNotice);
		
	}
	else
	{
		$response =  "failure";
		echo json_encode($response);
	}
	
	
	
?>