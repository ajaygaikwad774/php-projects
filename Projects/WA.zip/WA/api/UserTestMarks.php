<?php
require "connection.php";

$user_id = null;
$batch_id = null;  



if($_SERVER['REQUEST_METHOD']=='POST'){
	
    $user_id = $_POST['user_id'];
    $batch_id = $_POST['batch_id'];

}


if($_SERVER['REQUEST_METHOD']=='GET')
{
    $user_id = $_POST['user_id'];
    $batch_id = $_POST['batch_id'];


}

	

	 
	 	$sql12 = "SELECT fh_track_test.user_id, fh_track_test.batch_id, fh_track_test.obtained_marks, fh_track_test.total_marks, fh_track_test.remark , fh_test.test_name , fh_test.subject , fh_test.test_date FROM `fh_track_test` INNER JOIN `fh_test` ON fh_track_test.test_id = fh_test.test_id WHERE fh_track_test.user_id = '$user_id' AND fh_track_test.batch_id ='$batch_id' AND fh_track_test.disable_flag ='0' AND fh_test.disable_flag ='0' ORDER BY track_test_id DESC";
	 
	$result12 = $conn->query($sql12);
	if ($result12->num_rows > 0) 
	{
	
				// output data of each row
				while($row = $result12->fetch_assoc()) 
				{
				        $test_name= $row['test_name'];
                        $subject= $row['subject'];
                        $obtained_marks= $row['obtained_marks'];
                        $total_marks= $row['total_marks'];
                        $remark= $row['remark'];

                        $test_date= $row['test_date'];
                        
				       
						
				
						$TestDate = date("d-m-Y", strtotime($test_date));
 
			                     $UserTestMark[]=array(
									 
                                 "test_name"=> $test_name ,
                                 "subject"=> $subject ,
                                 "obtained_marks"=> $obtained_marks ,
                                 "total_marks"=> $total_marks ,
                                 "remark"=> $remark ,
								 "test_time"=> $TestDate
								 
							     
								 
								);
	
		        }
// 		$response = array("response" => $UserTestMark);
		
		echo json_encode($UserTestMark);
		
	}
	else
	{
		$response =  "failure";
		echo json_encode($response);
	}
	
	
	
?>