

<?php

//fetch.php

include('connection.php');


    
 if(isset($_POST['userid']))
{

 
         $userid = htmlspecialchars($_POST['userid']);


   $query = "SELECT `user_id`, `roll_no`, `f_name`, `l_name`, `email_id`, `user_name`, `password`, `role`, `gender`, `mobile_no`, `parent_name_1`, `parent_name_2`, `p_mobile_no_1`, `p_mobile_no_2`, `address`, `course_id`, `course_name`, `batch_id`, `batch_name`, `batch_time`, `subject`  FROM fh_user WHERE disable_flag='0' AND role = 'student' AND user_id ='$userid'";


$user_q = mysqli_query($conn,$query);
   $count = mysqli_num_rows($user_q);
   

$row=mysqli_fetch_assoc($user_q);
?>
<form  id="up_student"  method="POST" class="form-horizontal">
                                    <div class="form-body">
                                        <h3 class="box-title">Update Info</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">First Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="fname" required value="<?php echo $row['f_name'];?>" >
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                        </div> 
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Last Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="lname" required value="<?php echo $row['l_name'];?>">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                         </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Gender<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <select class="form-control custom-select" required name="gender">
                                                             <option value="None">Select Gender</option>
                                                             <?php 
                                                            if($row['gender'] == 'Male')
                                                             { ?>
                                                             	 <option value="Male" selected>Male</option>
                                                            <option value="Female">Female</option>

                                                           <?php  }
                                                          else if($row['gender'] == 'Female')
                                                            { ?>
                                                            	 <option value="Male">Male</option>
                                                            <option value="Female" selected>Female</option>

                                                          <?php  }	?>
                                                            
                                                           
                                                        </select>
                                                        <!-- <small class="form-control-feedback"> Select your gender. </small>--> 
                                                        </div> 
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Mobile No</label>
                                                    <div class="col-md-9">
                                                        <input type="text"   maxlength="10" class="form-control" name="mobile_no"  value="<?php  echo $row['mobile_no'];?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>

                                        <div class="row">
                                               <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Parent-1<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="pname_1" required value="<?php  echo $row['parent_name_1'];?>">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> --> 
                                                        </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                              <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Mobile-1<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" maxlength="10" name="pmobile_1" required value="<?php  echo $row['p_mobile_no_1'];?>">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small>  -->

                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>

                                        <div class="row">
                                               <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Parent-2</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="pname_2"  value="<?php  echo $row['parent_name_2'];?>">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small>  -->

                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                              <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Mobile-2</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control"  maxlength="10" name="pmobile_2" value="<?php  echo $row['p_mobile_no_2'];?>"  >
                                                        <!-- <small class="form-control-feedback"> This is inline help </small>  -->

                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                           
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Address <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" value="<?php echo $row['address']; ?>" name="address_1"  required >
                                                        <input type="hidden" class="form-control" value="<?php echo $row['user_id']; ?>" name="user_id"  required >
                                                    </div>
                                                </div>
                                            </div>
                                            
                                       
                                            
                                            <!--/span-->
                                        </div>
                                       
                                        <h3 class="box-title">Batch Details</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <!--/row-->
                                        <div class="row">

                                          
                                              <div class="col-md-6">
                                             <div class="form-group row">
                                            <label class="control-label text-right col-md-3">Batch<span style="color:red">*</span></label>
                                            <div class="col-md-9">
                                            <select class="select2 form-control custom-select" name="batch_info" id="b_filter" style="width: 100%; height:76px;">
                                                <option>None</option>
                                           <?php 

                                           $batch = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             $batch_data=mysqli_query($conn,$batch);
                                                $result_d=mysqli_num_rows($batch_data);
                                               
                                                    while($fetch_batch = mysqli_fetch_assoc($batch_data))
                                                    {  
                                                    	if($row['batch_id'] == $fetch_batch['batch_id'])
                                                    	{ ?>
                                                   <option selected value="<?php echo $fetch_batch['batch_name'].'-'.$fetch_batch['batch_id'].'-'.$fetch_batch['batch_time']; ?>"><?php echo $fetch_batch['batch_name']; ?></option>

                                                   <?php  	}else{

                                           ?>      
                                            <option value="<?php echo $fetch_batch['batch_name'].'-'.$fetch_batch['batch_id'].'-'.$fetch_batch['batch_time']; ?>"><?php echo $fetch_batch['batch_name']; ?></option>
                                           <?php } }?>
                                        </select>
                                    </div>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Roll No.<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="roll_no" required name="roll_no" class="form-control" value="<?php echo $row['roll_no']; ?>">
                                                    </div>
                                          </div>      </div>
                                      </div> 
                                    <hr>
                                    <div class="form-actions">
                                      
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                                                        <button type="submit" name="submit" class="btn btn-success">Update</button>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                          
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form> 
                        <script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
                          <script type="text/javascript">
                             $(".select2").select2();
                         </script>
                       
 <?php } else {  
                

        $user_id=mysqli_real_escape_string($conn,$_POST["user_id"]);
         $fname=mysqli_real_escape_string($conn,$_POST["fname"]);
      $lname=mysqli_real_escape_string($conn,$_POST["lname"]);
      $full_name = $fname.''.$lname;
       $gender=mysqli_real_escape_string($conn,$_POST["gender"]);
       $mobile_no=mysqli_real_escape_string($conn,$_POST["mobile_no"]);
        $pname_1=mysqli_real_escape_string($conn,$_POST["pname_1"]);
         $pmobile_1=mysqli_real_escape_string($conn,$_POST["pmobile_1"]);
          $pname_2=mysqli_real_escape_string($conn,$_POST["pname_2"]); 
          $pmobile_2=mysqli_real_escape_string($conn,$_POST["pmobile_2"]);
           $address_1=mysqli_real_escape_string($conn,$_POST["address_1"]);
            
             $roll_no = mysqli_real_escape_string($conn,$_POST["roll_no"]);

         

         $batch_data[] = (explode("-",$_POST['batch_info']));
         // print_r($batch_data);
         $batch_name = $batch_data[0][0];
         $batch_id = $batch_data[0][1];
         $batch_time = $batch_data[0][2];



   $query = "UPDATE `fh_user` SET `roll_no`='$roll_no',`f_name`='$fname',`l_name`='$lname', `gender`='$gender' , `mobile_no`='$mobile_no',`parent_name_1`='$pname_1',`parent_name_2`='$pname_2',`p_mobile_no_1`='$pmobile_1',`p_mobile_no_2`='$pmobile_2',`address`='$address_1',`batch_id`='$batch_id',`batch_name`='$batch_name' WHERE user_id='$user_id' AND disable_flag='0'";


$user_q = mysqli_query($conn,$query);

         

 } ?>                       