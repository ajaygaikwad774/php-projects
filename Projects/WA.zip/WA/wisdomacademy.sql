-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 04, 2019 at 02:28 AM
-- Server version: 5.6.39-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wisdomacademy`
--

-- --------------------------------------------------------

--
-- Table structure for table `fh_assignment`
--

CREATE TABLE `fh_assignment` (
  `assignment_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `assignment_name` varchar(255) NOT NULL,
  `assignment_content` varchar(255) NOT NULL,
  `assignment_image` varchar(255) NOT NULL,
  `assignment_submit_date` varchar(255) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `disable_flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_assignment`
--

INSERT INTO `fh_assignment` (`assignment_id`, `batch_id`, `assignment_name`, `assignment_content`, `assignment_image`, `assignment_submit_date`, `added_date`, `disable_flag`) VALUES
(1, 1, 'maths', 'sndjsdnjkndjknjks cnjcjksndkjcs kjndkjncksjcn scjnsdnckjnskjc njsdjcknsdcj ', '', '1-05-2019', '2019-04-29 04:41:05', 0),
(2, 1, 'science', 'sndjsdnjkndjknjks cnjcjksndkjcs kjndkjncksjcn scjnsdnckjnskjc njsdjcknsdcj ', '', '3-05-2019', '2019-04-29 04:41:38', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fh_attendance`
--

CREATE TABLE `fh_attendance` (
  `atten_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `user_full_name` varchar(255) NOT NULL,
  `attendance_flag` int(11) NOT NULL COMMENT '0=present,1=absent,2=holiday',
  `subject` varchar(255) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_attendance`
--

INSERT INTO `fh_attendance` (`atten_id`, `user_id`, `batch_id`, `user_full_name`, `attendance_flag`, `subject`, `added_date`) VALUES
(1, 1, 1, 'Rahul Yadav', 0, 'maths', '2019-04-28 03:27:05'),
(2, 1, 1, 'Rahul Yadav', 1, 'science', '2019-04-30 03:27:20');

-- --------------------------------------------------------

--
-- Table structure for table `fh_course`
--

CREATE TABLE `fh_course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `subjects` varchar(255) NOT NULL,
  `total_fees` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fh_fees`
--

CREATE TABLE `fh_fees` (
  `fees_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `total_fees` int(11) NOT NULL,
  `discount_amount` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `due_amount` int(11) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_fees`
--

INSERT INTO `fh_fees` (`fees_id`, `user_id`, `username`, `batch_id`, `course_id`, `course_name`, `total_fees`, `discount_amount`, `paid_amount`, `due_amount`, `payment_mode`, `disable_flag`, `added_date`) VALUES
(1, 1, 'Rahul Yadav', 1, 1, 'Demo', 3000, 100, 2900, 0, '', 0, '2019-04-29 06:23:50'),
(2, 2, 'Rohan', 1, 1, 'morning', 4000, 200, 3800, 0, 'sjdsjfb', 0, '2019-04-30 07:51:31'),
(3, 3, 'Rohan', 1, 1, 'morning', 4000, 200, 3800, 0, 'sjdsjfb', 0, '2019-04-30 07:52:52');

-- --------------------------------------------------------

--
-- Table structure for table `fh_imp_content`
--

CREATE TABLE `fh_imp_content` (
  `imp_id` int(11) NOT NULL,
  `imp_topic_name` varchar(255) NOT NULL,
  `imp_file` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fh_notice`
--

CREATE TABLE `fh_notice` (
  `notice_id` int(11) NOT NULL,
  `notice_name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'all or individual',
  `notice_type` varchar(255) NOT NULL,
  `notice_content` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_notice`
--

INSERT INTO `fh_notice` (`notice_id`, `notice_name`, `user_id`, `notice_type`, `notice_content`, `disable_flag`, `added_date`) VALUES
(1, 'Demo', 1, 'All', 'Demo Demo demo', 0, '2019-04-29 06:48:15'),
(2, 'Demo', 1, 'All', 'Demo 123 1234 1234 1234 ', 0, '2019-04-30 08:01:24');

-- --------------------------------------------------------

--
-- Table structure for table `fh_student_remark`
--

CREATE TABLE `fh_student_remark` (
  `remark_id` int(11) NOT NULL,
  `remark_name` int(11) NOT NULL,
  `description` int(11) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fh_test`
--

CREATE TABLE `fh_test` (
  `test_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `test_name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `chapter` varchar(255) NOT NULL,
  `marks` int(11) NOT NULL,
  `test_date` varchar(255) NOT NULL,
  `from_time` varchar(255) NOT NULL,
  `to_time` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_test`
--

INSERT INTO `fh_test` (`test_id`, `batch_id`, `test_name`, `subject`, `chapter`, `marks`, `test_date`, `from_time`, `to_time`, `disable_flag`, `added_date`) VALUES
(1, 1, 'DEMO TEST', 'MATHS', '3-5', 30, '25-05-2019', '8:00', '11:00', 0, '2019-04-29 05:17:07'),
(2, 1, 'TEST', 'HISTORY', '1-2', 20, '2-05-2019', '12:00', '2:00', 0, '2019-04-29 05:18:09');

-- --------------------------------------------------------

--
-- Table structure for table `fh_track_test`
--

CREATE TABLE `fh_track_test` (
  `track_test_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `obtained_marks` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_track_test`
--

INSERT INTO `fh_track_test` (`track_test_id`, `test_id`, `user_id`, `batch_id`, `obtained_marks`, `total_marks`, `remark`, `disable_flag`, `added_date`) VALUES
(1, 1, 1, 1, 25, 30, 'Good', 0, '2019-04-29 05:27:18'),
(2, 2, 1, 1, 18, 20, 'Good', 0, '2019-04-29 05:27:55');

-- --------------------------------------------------------

--
-- Table structure for table `fh_user`
--

CREATE TABLE `fh_user` (
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `parent_name_1` varchar(255) NOT NULL,
  `parent_name_2` varchar(255) NOT NULL,
  `p_mobile_no_1` varchar(255) NOT NULL,
  `p_mobile_no_2` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `disable_flag` int(11) NOT NULL DEFAULT '0',
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fcm_id` varchar(255) NOT NULL,
  `device_type` varchar(255) NOT NULL,
  `version_code` varchar(255) NOT NULL,
  `version_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_user`
--

INSERT INTO `fh_user` (`user_id`, `f_name`, `l_name`, `email_id`, `user_name`, `password`, `role`, `gender`, `mobile_no`, `parent_name_1`, `parent_name_2`, `p_mobile_no_1`, `p_mobile_no_2`, `address`, `course_id`, `course_name`, `batch_id`, `batch_name`, `subject`, `disable_flag`, `reg_date`, `fcm_id`, `device_type`, `version_code`, `version_name`) VALUES
(1, 'Rahul', 'yadav', 'rahul@gmail.com', 'W-rahul1', '12345', 'student', 'male', '12345', 'rahul ke papa', 'rahul ke papa', '12345', '12345', 'lan wjnwedjlwnnwenwdjk jnwjenjkwnkdjwedwe dwd wendlwenldewnldwdklwjdlkwjd wwelknklwjklwejkdkweld we', 1, 'full course', 1, 'morning', 'all', 0, '2019-04-29 03:06:22', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `studentdetails`
--

CREATE TABLE `studentdetails` (
  `id` int(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `student_std` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentdetails`
--

INSERT INTO `studentdetails` (`id`, `student_name`, `school_name`, `contact_no`, `student_std`, `date`) VALUES
(58, 'wisdom academy ', 'abc', '1234567890', '10', '2019-04-09 05:32:25'),
(44, 'Anjali sahu', 'St jude high school', '9321302424', 'tybbi ', '2019-04-07 13:45:26'),
(39, 'Aryan ', 'Eden', '8652089914', 'III', '2019-04-06 09:28:58'),
(40, 'yash g sawanat', 'eden gadran school', '9850008863', '10th\n', '2019-04-06 09:51:12'),
(65, 'Aryan Sonawane ', 'Eden high school ', '8652089914', '3rd std\n', '2019-04-11 18:45:35'),
(47, 'kuljit Singh dodiya', 'eden high school', '9833193204', '9th', '2019-04-08 16:24:08'),
(66, 'Aryan Sonawane ', 'Eden high school ', '8652089914', '3rd std\n', '2019-04-11 18:45:46'),
(59, 'Anjali Maurya', 'Yogiraj Shree Krishna Vidyalaya', '+919768643', '9th', '2019-04-09 05:52:02'),
(61, 'a', 'a', '+191932130', 'a', '2019-04-09 07:03:47'),
(62, 'GopalSharma', 'Eden high school', '9820562397', '9th', '2019-04-09 13:49:35'),
(63, 'GopalSharma', 'Eden high school', '9820562397', '10th', '2019-04-09 13:51:10'),
(64, 'logesh', 'eden high school', '9920051086', 'ten', '2019-04-10 06:44:23'),
(67, 'Testing ', 'yyyy', '12567894648', '10', '2019-04-12 11:41:47'),
(68, 'hs', 'idhd', '997', '7', '2019-04-12 11:45:45'),
(69, 'sayyedfurqan', 'st jude high school', '9619298895', '10th', '2019-04-14 14:57:57'),
(70, 'anjali maurya', 'yogiraj shree krishana vidhyalay', '9768643208', '9th', '2019-04-14 17:51:42'),
(71, 'Anjali Maurya\n', 'Yogiraj Shree Krishna Vidyalaya', '9768643208', '8th A \n', '2019-04-17 13:43:31'),
(72, 'Arjun Singh', 'edden', '7450083970', '9', '2019-04-20 14:28:38'),
(73, 'Aryan Sonawane ', 'Eden high school ', '8652089914', '4 rth', '2019-04-23 18:30:37'),
(74, 'Aryan Sonawane ', 'Eden high school ', '8652089914', '4 rth', '2019-04-23 18:30:45'),
(75, 'furquan', 'st jude', '9819612736', 'ssc', '2019-04-26 06:46:05'),
(76, 'Aditi  Sudesh. Katke', 'l.v.m', '9969479344', 'ten', '2019-04-26 18:36:55'),
(77, 'R Siva', 'ATC', '9865312030', '12', '2019-04-27 05:56:36'),
(78, 'govinda', 'sivaji', '7506115022', 'ix', '2019-04-27 20:23:39'),
(79, 'aravind', 'g.h.s.school', '7092094321', 'aravind', '2019-04-29 13:45:00'),
(80, 'ff', 'yxyc.com', '8', 'ufuf', '2019-04-30 05:17:09'),
(81, 'bxbx', 'bxh', '8758', 'hsys', '2019-04-30 05:43:57'),
(82, 'Rahul ', 'yyy', '3333333333', '5', '2019-04-30 05:44:54'),
(83, 'fur', 'hdjd', '5865', 'kfkf', '2019-04-30 05:49:19'),
(84, 'hxgxh', 'uxh', '5858', 'jvh', '2019-04-30 07:56:29'),
(85, 'jcv', 'hxhx', '9098', 'jcjc', '2019-04-30 09:34:55'),
(86, 'tghshshsh', 'yshshdhhdjd', '9597555646', '10000', '2019-04-30 11:00:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fh_assignment`
--
ALTER TABLE `fh_assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `fh_attendance`
--
ALTER TABLE `fh_attendance`
  ADD PRIMARY KEY (`atten_id`);

--
-- Indexes for table `fh_fees`
--
ALTER TABLE `fh_fees`
  ADD PRIMARY KEY (`fees_id`);

--
-- Indexes for table `fh_imp_content`
--
ALTER TABLE `fh_imp_content`
  ADD PRIMARY KEY (`imp_id`);

--
-- Indexes for table `fh_notice`
--
ALTER TABLE `fh_notice`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `fh_student_remark`
--
ALTER TABLE `fh_student_remark`
  ADD PRIMARY KEY (`remark_id`);

--
-- Indexes for table `fh_test`
--
ALTER TABLE `fh_test`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `fh_track_test`
--
ALTER TABLE `fh_track_test`
  ADD PRIMARY KEY (`track_test_id`);

--
-- Indexes for table `fh_user`
--
ALTER TABLE `fh_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `studentdetails`
--
ALTER TABLE `studentdetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fh_assignment`
--
ALTER TABLE `fh_assignment`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fh_attendance`
--
ALTER TABLE `fh_attendance`
  MODIFY `atten_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fh_fees`
--
ALTER TABLE `fh_fees`
  MODIFY `fees_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fh_imp_content`
--
ALTER TABLE `fh_imp_content`
  MODIFY `imp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fh_notice`
--
ALTER TABLE `fh_notice`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fh_student_remark`
--
ALTER TABLE `fh_student_remark`
  MODIFY `remark_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fh_test`
--
ALTER TABLE `fh_test`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fh_track_test`
--
ALTER TABLE `fh_track_test`
  MODIFY `track_test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fh_user`
--
ALTER TABLE `fh_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `studentdetails`
--
ALTER TABLE `studentdetails`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
