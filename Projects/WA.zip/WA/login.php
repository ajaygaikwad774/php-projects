<?php include "header.php";
                session_start();

?>
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
		<div id="loading_screen" ><div id="load" style="opacity:1;">
                        <img src='assets/images/loading.gif' width="150" height="150"  /></div></div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <section id="wrapper" class="login-register login-sidebar" style="background-image:url(assets/images/background/login-register2.jpg);">
        <div class="login-box card">
            <div class="card-body">
                           

                <form class="form-horizontal form-material" id="loginform"   method="POST" action="login_code.php">
                        
                    <a href="javascript:void(0)" class="text-center db"><img src="assets/images/large_t.png" alt="Home" /><br/></a>
                    <div class="form-group m-t-40">
                        <div class="col-xs-12">
                            <input class="form-control" type="text" name="username" required="" placeholder="Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" type="password" name="password" required="" placeholder="Password">
                        </div>
                    </div>
                    <!--<div class="form-group">-->
                    <!--    <div class="col-md-12">-->
                           
                    <!--        <a href="javascript:void(0)" id="to-recover" class="text-dark pull-right"><i class="fa fa-lock m-r-5"></i> Forgot Password?</a> </div>-->
                    <!--</div>-->
                     <?php
                    if(isset($_SESSION["errors"])){
                        $error = $_SESSION["errors"]; ?>
                <span class='alert-warning' ><?php echo $error ?></span>
                   <?php }
                ?>  
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" name="submit" type="submit">Log In</button>
                        </div>
                    </div>
                 
                </form>
                <!--<form class="form-horizontal" id="recoverform" action="recovery_code.php" method="POST">-->
                <!--    <div class="form-group ">-->
                <!--        <div class="col-xs-12">-->
                <!--            <h3>Recover Password</h3>-->
                <!--            <p class="text-muted">Enter your Email and instructions will be sent to you! </p>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="form-group ">-->
                <!--        <div class="col-xs-12">-->
                <!--            <input class="form-control" type="text" required="" placeholder="email" name="email_id">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="form-group text-center m-t-20">-->
                <!--        <div class="col-xs-12">-->
                <!--            <button type="submit" class="btn btn-primary btn-lg btn-block text-uppercase waves-effect waves-light" name="reset-password" >Reset</button>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</form>-->
            </div>
        </div>
    </section>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <?php include "footer.php";?>
</body>

</html>
<?php
    unset($_SESSION["errors"]);



?>
