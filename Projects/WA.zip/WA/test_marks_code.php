
<?php

//fetch.php

include('connection.php');

$test_id = $_POST['test_id'];

        $check_data = "SELECT fh_user.f_name,fh_user.l_name , fh_user.batch_name ,fh_user.user_name ,  fh_track_test.obtained_marks, fh_track_test.total_marks FROM `fh_track_test`INNER JOIN `fh_user` ON `fh_track_test`.`user_id` = `fh_user`.`user_id` WHERE fh_track_test.test_id = '$test_id' AND fh_track_test.disable_flag ='0'";

        $stat_data = mysqli_query($conn,$check_data);
                 $count = mysqli_num_rows($stat_data);

            if($count > 0)
              {  ?>
             <thead>
                                            <tr>
                                                <th>User Name</th>
                                                <th>Name</th>
                                                <th>Batch Name</th>
                                                <th>Obtain Marks</th>
                                                
                                                <th>Total Marks </th>
                                                
                                                
                                            </tr>
                                        </thead>
            <?php
            
 
                      while($fetch_data = mysqli_fetch_assoc($stat_data))
                                   {  ?>


                                     <tr>
                                                <td><?php echo $fetch_data['user_name']; ?></td>
                                                <td><?php echo $fetch_data["f_name"].' '.$fetch_data["l_name"]; ?></td>
                                                <td><?php echo $fetch_data["batch_name"]; ?></td>

                                                <td><?php echo $fetch_data["obtained_marks"]; ?></td>
                                               
                                                <td><?php echo $fetch_data["total_marks"]; ?></td>
                                                    
                                                
                                            </tr>


 
<?php }
}
 else
 {   

 if(isset($_POST['batch_id']) && isset($_POST['test_id']) && isset($_POST['subject_name']))
{
       $batch_id =  $_POST['batch_id'];
           $test_id = $_POST['test_id'];
      ?>
       <thead>
                                            <tr>
                                                <th>User Name</th>
                                                <th>Name</th>
                                                <th>test_name</th>
                                                <th>test_date</th>
                                                
                                                <th>Obtain Marks </th>
                                                 <th>Exam Marks</th>
                                                
                                            </tr>
                                        </thead>  
<?php 
    $query = "SELECT DISTINCT(fh_user.user_id ) as user_id, fh_user.f_name, fh_user.l_name, fh_user.user_name , fh_test.marks , fh_test.subject , fh_test.test_date FROM `fh_user` INNER JOIN `fh_test` ON `fh_user`.`batch_id` = `fh_test`.`batch_id` WHERE fh_user.disable_flag='0' AND fh_test.disable_flag='0' AND fh_test.batch_id = '$batch_id' AND fh_user.batch_id='$batch_id' AND fh_test.test_id='$test_id'";
  

$statement=mysqli_query($conn,$query);


while($row=mysqli_fetch_assoc($statement))
{
      $user_id = $row['user_id'];
?>
  <tr>
                                                <td><?php echo $row['user_name']; ?></td>
                                                <td><?php echo $row["f_name"].' '.$row["l_name"]; ?></td>
                                                <td><?php echo $row["subject"]; ?></td>
                                                <td><?php echo $row["test_date"]; ?></td>
                                               
                                                <td><div class="col-md-2">
                                                
                                                    <input type="text"  required  name="obtain_marks[<?php echo $user_id; ?>]" style="width: 50px;">
                                                    <input type="hidden" value="<?php echo $batch_id; ?>" name ='batch_id' >
                                                    <input type="hidden" value="<?php echo $test_id; ?>" name ='test_id' >
                                                    </div></td>
                                                    <td><div class="col-md-2">
                                                    
                                                    <input type="text"  required  readonly value="<?php echo $row["marks"]; ?>" name="total_marks" style="width: 50px;">
                                                    </div></td>
                                                
                                            </tr>
 
<?php
}
}elseif (isset($_POST['obtain_marks'])) {
//   print_r($_POST['obtain_marks']);

  $batch_id = $_POST['batch_id'];
  $test_id = $_POST['test_id'];
   $total_marks = $_POST['total_marks'];
  ?>


  <?php
                          
                          $response = array();
	                      $token = array();
	                      
	                      
	                          function sendMessage($token)
         {


        //   print_r($token);

        // $content = ["en" => 'English Message'];
                  $headings=["en" => "Exam Marks"]; 

                   $content = array(
                   	//  "title" =>$notice_name,
                       "en" => "Click Here!!!! "
                       );

                    $fields = array(
                    	//app id from one signal
                        'app_id' => "69e4fa75-66e9-4e1a-9b70-7f859e4afd74",
                        // device id from database

                        'include_player_ids' => $token ,
                        // 'included_segments' => array('All'),
                        'data' => array("foo" => "bar"),
                        'small_icon' => "https://www.appdid.com/WA//assets/images/small.png",
                         'large_icon' => "https://www.appdid.com/WA//assets/images/large.png",
                        //'big_picture'=>"http://onthefield.in/Pass2fit/assets/images/notification_icon2.png",
                          'headings'=> $headings,

                         'contents' => $content
                     );

                                $fields = json_encode($fields);
                            //print("\nJSON sent:\n");
                            //print($fields);

                         $ch = curl_init();
                         curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
                         //Authorization key from one signal 
                         curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic MDQ4ZGQ4MzktYjFiZi00ZjA0LTg4MjUtZmFiNTE0NzA1ZjMx'));
                         curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                         curl_setopt($ch, CURLOPT_HEADER, FALSE);
                          curl_setopt($ch, CURLOPT_POST, TRUE);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
                          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

                          $response1 = curl_exec($ch);
                          curl_close($ch);
                          return $response1;
                 }
       
       $today_date =  date("Y-m-d H:i:s");

               foreach ($_POST["obtain_marks"] as $key => $mark) {


                $query2 = "INSERT INTO `fh_track_test`(`test_id`, `user_id`, `batch_id`, `obtained_marks`, `total_marks` , `added_date` ) VALUES ('$test_id','$key' , '$batch_id' ,'$mark' , '$total_marks' , '$today_date') ";

                  $stat=mysqli_query($conn,$query2);
                 	$query_noti = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND role = 'student' AND user_id = '$key'";


	                        
  
 			                      	$result_data = mysqli_query($conn,$query_noti);
          
                 
                 
                 while($row_fcm = mysqli_fetch_array($result_data))
                 {
                
                    // echo  $row_fcm['fcm_id'].'/n';
                       $token[]=$row_fcm['fcm_id'];               
                
                 }
                 
            //   print_r($token);

                        $response = sendMessage($token);
                    	$return["allresponses"] = $response;
                     	$return = json_encode( $return);
                   
                 // print($return);
        
 			 
                
               }
              
                 header('Location:exam_marks.php');
           
}

}
?>
