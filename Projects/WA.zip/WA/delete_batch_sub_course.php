<?php
	
	$response = array();
	require_once 'connection.php';
	
	if (isset($_POST['batch_id'])) {
		
		
		$batch_id = mysqli_real_escape_string($conn,$_POST['batch_id']);
		$query = "UPDATE `fh_batch` SET `disable_flag`='1' WHERE batch_id = '$batch_id'";
		$stmt = mysqli_query($conn, $query );


		if ($stmt == TRUE ) {
			
			$response['status']  = 'success';
			$response['message'] = 'Batch Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete Batch ...';
		}
		echo json_encode($response);


	}else if(isset($_POST['course_id']))
	{

		$course_id = mysqli_real_escape_string($conn,$_POST['course_id']);
		$query = "UPDATE `fh_course` SET `disable_flag`='1' WHERE course_id='$course_id'";
		$stmt = mysqli_query($conn, $query );


		if ($stmt == TRUE ) {
			
			$response['status']  = 'success';
			$response['message'] = 'Batch Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete Batch ...';
		}
		echo json_encode($response);


	}else if(isset($_POST['subject_id']))
	{
          		$subject_id = mysqli_real_escape_string($conn,$_POST['subject_id']);
		$query = "UPDATE `fh_subject` SET `disable_flag`='1' WHERE subject_id ='$subject_id'";
		$stmt = mysqli_query($conn, $query );


		if ($stmt == TRUE ) {
			
			$response['status']  = 'success';
			$response['message'] = 'Batch Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete Batch ...';
		}
		echo json_encode($response);

	}