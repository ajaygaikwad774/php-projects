<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>
<?php include('navbar.php'); ?>
<?php include('connection.php'); ?>

<style type="text/css">
    [type=radio]:checked, [type=radio]:not(:checked) {
     position: static !important;
    /*left: -9999px;*/
     opacity: 1 !important; 
}
</style>


        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Student List</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Student List</li>
                    </ol>
                </div>
                <div>
                    <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">

               <?php
                                          $query12 = "SELECT DISTINCT(`batch_name`) as batch_name , `batch_id` FROM `fh_user` WHERE disable_flag ='0' AND role='student'";
                                             $info12=mysqli_query($conn,$query12);
                                                $result_c=mysqli_num_rows($info12);
                                                

               ?>
             
                

                           
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">Attendace</h4>
                                <!-- <div align="center">   -->
                                  <div class="row">
                                   <div class="col-lg-4 col-md-4">
                                   <select name="" id="multi_search_filter"  class="form-control selectpicker" data-style="form-control btn-secondary">
                                    <option value="">None</option>
                                   <?php
                                    
                                    while($row = mysqli_fetch_assoc($info12))
                                   {
                                    echo '<option value="'.$row["batch_name"].'">'.$row["batch_name"].'</option>'; 
                                   }
                                   ?>
                                   </select>
                                 </div>

                                 
                                 <div class="col-lg-4 col-md-4">
                                  <select  class="form-control selectpicker" id="test_mark_p" data-style="form-control btn-secondary">
                                  
                                   </select>
                                   
                                 </div>
                               </div>
                                 <br>
                         
                                   <form name="form1" method="GET">
                                <div class="table-responsive">
                                    <table class="table full-color-table full-info-table hover-table" id="student_table">
                                        <thead>
                                            <tr>
                                                <th>User Name</th>
                                                <th>Name</th>
                                                <th>Batch</th>
                                                
                                                <th>Subject</th>
                                                <th>Obtain Marks</th>
                                                 <th>Total Marks</th>
                                               
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                         
                                        </tbody>
                                    </table>
                                </div>
                                <button type="submit">Submit</button>
                            </form>
                            </div>
                        </div>
                    </div>
                   
              
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
              <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>


<script>
$(document).ready(function(){

 
 function load_data(query)
 {
  $.ajax({
   url:"test_marks_code.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
   
    $("#test_mark_p").html(data);
     alert(data);
   }
  })
 }

 $("#multi_search_filter").change(function(){
  var query = $('#multi_search_filter').val();
   alert(query);
  load_data(query);
});
 
});
</script>

</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>