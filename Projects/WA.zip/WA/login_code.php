<?php

                session_start();

include "connection.php";


if (isset($_POST["submit"])) 
{
$username=mysqli_real_escape_string($conn,$_POST['username']);
$password=mysqli_real_escape_string($conn,$_POST['password']);

$check="SELECT `user_id`, `f_name`, `l_name`, `email_id`, `role`, `disable_flag` FROM `fh_user` WHERE disable_flag = '0' AND user_name = '$username' AND password = '$password' AND role = 'admin'";
$check1=mysqli_query($conn,$check);
	if (mysqli_num_rows($check1)>0)
	{
				$fetch=mysqli_fetch_assoc($check1);
				$_SESSION["admin_id"]=$fetch["user_id"];
				$_SESSION["admin_name"]=$fetch["f_name"].' '.$fetch["l_name"];
				$_SESSION["role"]=$fetch["role"];
			
				$_SESSION['logged_in']="login";
				$_SESSION['flag']=$fetch["disable_flag"];
				$date=date("Y-m-d");

				if ($fetch["role"]=="admin")
				{
					

					  	if($fetch["disable_flag"] == "0"){

					header("Location:dashboard_admin.php");


                  }
                  else if ($fetch["disable_flag"] == "1") 
                  {


                    $_SESSION["errors"]=" Fitness centre has been deactivated by Admin ";
		

		              header("Location:index.php");

                  }

              
				}
			
	}
	else{

            $_SESSION["errors"]="Wrong username or password.";
		
	       
		header("Location:index.php");
	}

}

?>