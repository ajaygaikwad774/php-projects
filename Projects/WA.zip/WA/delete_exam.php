<?php
	
	$response = array();
	require_once 'connection.php';
	
	if (isset($_POST['exam_id'])) {
		
		
		$exam_id = mysqli_real_escape_string($conn,$_POST['exam_id']);
    $query = "UPDATE `fh_test` SET `disable_flag`='1' WHERE test_id='$exam_id'";
		$stmt = mysqli_query($conn, $query );


		if ($stmt == TRUE ) {
			
			$response['status']  = 'success';
			$response['message'] = 'Exam Details Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete Exam Details ...';
		}
		echo json_encode($response);


	}
	?>