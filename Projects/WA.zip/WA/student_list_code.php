
<?php

//fetch.php

include('connection.php');

$column = array(  'roll_no','f_name' ,'user_name', 'gender' ,'mobile_no', 'batch_name', 'l_name');

$query = "SELECT  `user_id` , `roll_no`, `f_name` , `l_name` ,`user_name`, `password`  , `gender` ,`mobile_no`, `batch_name` ,`p_mobile_no_1`, `p_mobile_no_2` , `role` , `disable_flag` FROM fh_user ";

if(isset($_POST['search']['value']))
{
 $query .= '
 WHERE roll_no LIKE "%'.$_POST['search']['value'].'%"
 OR f_name LIKE "%'.$_POST['search']['value'].'%" 
 OR gender LIKE "%'.$_POST['search']['value'].'%" 
 OR p_mobile_no_1 LIKE "%'.$_POST['search']['value'].'%" 
 OR p_mobile_no_2 LIKE "%'.$_POST['search']['value'].'%" 
 OR batch_name LIKE "%'.$_POST['search']['value'].'%" 
 OR l_name LIKE "%'.$_POST['search']['value'].'%" 
 ';
}


if(isset($_POST['order']))
{
 $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY user_id DESC ';
}

$query1 = '';

if($_POST['length'] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

 // echo $query;
$statement=mysqli_query($conn,$query);
// $statement = $conn->prepare($query);

 // $statement->execute();
                             
 // echo $number_filter_row = $statement->num_rows();
 $number_filter_row = mysqli_num_rows($statement);

$statement=mysqli_query($conn,$query . $query1);
 // $statement = $conn->prepare($query . $query1);

// $statement->execute();

// $result = $statement->fetchAll();


$data = array();

while($row=mysqli_fetch_assoc($statement))
{
 $sub_array = array();
 if($row['role'] == 'student' && $row['disable_flag'] == '0' )
 {
 $sub_array[] = $row['roll_no'];
 $sub_array[] = $row['f_name'].' '.$row['l_name'];
 $sub_array[] = $row['password'];
 $sub_array[] = $row['batch_name'];
 $sub_array[] = $row['mobile_no'];
 $sub_array[] = $row['p_mobile_no_1'];
 $sub_array[] = $row['p_mobile_no_2'];
 $sub_array[] = '<a id="delete_student" data-id="'.$row['user_id'].'" href="javascript:void(0)"><i class="mdi mdi-delete"></i></a> &nbsp &nbsp &nbsp <a href="update_student.php?userid='.$row['user_id'].' "><i class="mdi mdi-pencil"></i></a> ';

 $data[] = $sub_array;
}
}

function count_all_data($conn)
{
 $query = "SELECT * FROM fh_user";
 $statement=mysqli_query($conn,$query);
  return mysqli_num_rows($statement);
}

$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($conn),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);

echo json_encode($output);

?>
