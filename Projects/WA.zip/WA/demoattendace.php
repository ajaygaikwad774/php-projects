
<?php

//fetch.php

include('connection.php');

$column = array('f_name' ,'user_name', 'gender' ,'mobile_no', 'batch_name', 'l_name');

$query = "SELECT  `user_id` , `f_name` , `l_name` ,`user_name`, `gender` ,`mobile_no`, `batch_name` ,`p_mobile_no_1` , `role`  FROM fh_user ";

if(isset($_POST['search']['value']))
{
 $query .= '
 WHERE f_name LIKE "%'.$_POST['search']['value'].'%" 
 OR user_name LIKE "%'.$_POST['search']['value'].'%" 
 OR gender LIKE "%'.$_POST['search']['value'].'%" 
 OR mobile_no LIKE "%'.$_POST['search']['value'].'%" 
 OR batch_name LIKE "%'.$_POST['search']['value'].'%" 
 OR l_name LIKE "%'.$_POST['search']['value'].'%" 
 ';
}

if(isset($_POST['order']))
{
 $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY user_id DESC ';
}

$query1 = '';

if($_POST['length'] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

// echo $query;
$statement=mysqli_query($conn,$query);
// $statement = $conn->prepare($query);

 // $statement->execute();
                             
 // echo $number_filter_row = $statement->num_rows();
 $number_filter_row = mysqli_num_rows($statement);

$statement=mysqli_query($conn,$query . $query1);
 // $statement = $conn->prepare($query . $query1);

// $statement->execute();

// $result = $statement->fetchAll();


$data = array();

while($row=mysqli_fetch_assoc($statement))
{
 $sub_array = array();
 if($row['role'] == 'student' )
 {
 $sub_array[] = $row['user_name'];
 $sub_array[] = $row['f_name'].' '.$row['l_name'];
 $sub_array[] = $row['batch_name'];
 $sub_array[] = $row['mobile_no'];
 $sub_array[] = $row['gender'];
 $sub_array[] = $row['p_mobile_no_1'];
 $sub_array[] = ' <input type="checkbox" required value="single" name="styled_single_checkbox" class="custom-control-input"> <span class="custom-control-indicator"></span> </label>';
 
 $data[] = $sub_array;
}
}

function count_all_data($conn)
{
 $query = "SELECT * FROM fh_user";
 $statement=mysqli_query($conn,$query);
  return mysqli_num_rows($statement);
}

$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($conn),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);

echo json_encode($output);

?>
