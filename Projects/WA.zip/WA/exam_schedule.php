<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>

<?php include('navbar.php'); ?>
<?php include('connection.php'); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Exam Schedule</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Exam Schedule</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
         

                 <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 

                             <form  method="POST"   action="add_exam_details_code.php" >
              

                                   
              
                                         
                                        
                                          <div class="form-group">                                        
                                         <div class="row p-t-20">
                                            
                                             
                                            

                                            <!--/span-->
                                            <div class="col-md-3">
                                        <div class="form-group ">
                                            <label class="control-label">Batch<span style="color:red">*</span></label>

                  <select class="select2 form-control custom-select" name="batch" style="width: 100%; height:76px;">
                                            <option value="none">None</option>
                                      <?php

                       $batch_data = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             $batch_info=mysqli_query($conn,$batch_data);
                                                $result=mysqli_num_rows($batch_info);
          
                                    
                                    while($row_batch = mysqli_fetch_assoc($batch_info))
                                   {
                                    echo '<option value="'.$row_batch["batch_id"].'">'.$row_batch["batch_name"].'</option>'; 
                                   }
                                   ?>
                                        </select>
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <label class="control-label">Test Name<span style="color:red">*</span></label>
                                    <input type="text"  required class="form-control"  placeholder="Daily Weekly Test" name="test_name">
                                    <small class="form-control-feedback">  </small> </div>
                                    <!--<div class="col-md-3">  -->
                 <!--                     <div class="form-group ">-->
                 <!--                       <label class="control-label">Subject<span style="color:red">*</span></label>-->

                 <!-- <select class="select2 form-control custom-select" name="subject" style="width: 100%; height:76px;">-->
                 <!--                   <option value="">None</option>-->
                 <!-- <php-->
                 <!--$sub_query = "SELECT `subject_id`, `subject_name`, `subject_fees`, `disable_flag` FROM `fh_subject` WHERE disable_flag='0'";-->
                 <!--                            $sub_info=mysqli_query($conn,$sub_query);-->
                 <!--                               $result_sub=mysqli_num_rows($sub_info);-->
                    
                                     
          
                                     
                 <!--                   while($sub = mysqli_fetch_assoc($sub_info))-->
                 <!--                  { >-->
                 <!--             <option value="<php echo $sub['subject_name']?> "><php echo $sub['subject_name']></option> -->

                 <!--               <php-->
                 <!--                  }-->
                 <!--                  >-->
                 <!--                                       </select>-->
                                                     <!--</div>-->
                                                     
                                                     <div class="col-md-3">
                                    <label class="control-label">Subject Name<span style="color:red">*</span></label>
                                    <input type="text"  required class="form-control"  placeholder="Example Maths" name="subject">
                                    <small class="form-control-feedback">  </small> </div>
                                            
                                            <div class="col-md-3">  
                                                <div class="form-group ">
                                                    <label class="control-label">Chapter<span style="color:red">*</span></label>
                                                <input type="text"  class="form-control "  placeholder="Chapter Name " required  name="chapter_name">
                                                <div > <h4 class="form-control-feedback">  </h4></div>
                                                    <small class="form-control-feedback">  </small> </div>
                                            </div>
                                            <div class="col-md-3">  
                                                <div class="form-group ">
                                                    <label class="control-label">Marks<span style="color:red">*</span></label>
                                                <input type="text"  class="form-control  " required placeholder="Total Marks"  name="marks">
                                                <div > <h4 class="form-control-feedback">  </h4></div>
                                                    <small class="form-control-feedback">  </small> </div>
                                            </div> 
                                            <div class="col-md-3">  
                                                <div class="form-group ">
                                                    <label class="control-label">Date<span style="color:red">*</span></label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="datepicker-autoclose" required name="test_date" placeholder="mm/dd/yyyy">
                                                <span class="input-group-addon"><i class="icon-calender"></i></span> </div>
                                        </div> </div>
                                   

                                            <div class="col-md-2">  
                                                <div class="form-group ">
                                                    <label class="control-label">From Time<span style="color:red">*</span></label>
                                                <input type="text" class="form-control required " required placeholder="From Time"  name="from_time">
                                                <div > <h4 class="form-control-feedback">  </h4></div>
                                                    <small class="form-control-feedback">  </small> </div>
                                            </div> 
                                            <div class="col-md-2">  
                                                <div class="form-group ">
                                                    <label class="control-label"> To Time<span style="color:red">*</span></label>
                                                <input type="text" class="form-control required " required placeholder=" TO Time"  name="to_time">
                                                <div > <h4 class="form-control-feedback">  </h4></div>
                                                    <small class="form-control-feedback">  </small> </div>
                                            </div>  
                                          </div>
                                        </div>
                                          <div class="col-md-4">

                          
                          <button type="submit" name="exam_submit" class="btn btn-success">Submit</button>

                        </div> 
                                      
                                    </form>
                                    </div>


                          </div>
                        </div>

                           
    
     
                     <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 
                          <h4 class="card-title">Test List</h4> 
                     
               <!--  <br>
                             
                                 <div align="center">  
                     <input type="text" name="search" id="search" class="form-control" placeholder="Search UserName , Batch , Mobile Number  " />  
                </div>
                <br> -->

                    <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                   <th>Batch<br>Name</th>
                                                <th>Test<br>Name</th>
                                                <th>Subject</th>
                                                <th>Chapter</th>
                                                <th>Marks</th>
                                                <th>Test<br>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                       <!--  <tfoot>
                                            <tr>
                                                  <th>Batch<br>Name</th>
                                                <th>Test<br>Name</th>
                                                <th>Subject</th>
                                                <th>Chapter</th>
                                                <th>Marks</th>
                                                <th>Test<br>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot> -->
                                    </table>
                                </div>
                              <!-- 
                         <div class="table-responsive">
                                    <table class="table color-table primary-table" id="subject_table">
                                        <thead>
                                            <tr>
                                               <th>Batch<br>Name</th>
                                                <th>Test<br>Name</th>
                                                <th>Subject</th>
                                                <th>Chapter</th>
                                                <th>Marks</th>
                                                <th>Test<br>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                        </tbody>
                                    </table>
                                </div> -->

                             
            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
             <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>


 <script src="assets/plugins/datatables/JSZip-2.5.0/jszip.min.js"></script>
 <script src="assets/plugins/datatables/pdfmake-0.1.36/vfs_fonts.js"></script> 
                                      


    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

       <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/autofill/2.3.3/js/dataTables.autoFill.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>

   


<script type="text/javascript" language="javascript" >

        $(document).ready(function() {
      var table =  $('#example23').DataTable({
                "processing" : true,
                 "serverSide" : true,
                 "ordering": false,
                 "ajax" : {
                  url:"exam_list_code.php",
                 type:"POST"
                 },
              
                "order": [
                    [2, 'asc']
                ],
                responsive: true,
        destroy: true,
        dom: 'Bfrtip',
        buttons: [  
           
            
            {
                extend: 'excel',
                 title:'Exam Schedule',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4]
                }
            }, 
            
            {
                extend: 'copy',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4]
                }
            }, 
            
            {
                extend: 'csv',
                  title:'Exam Schedule',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4]
                }
            }  
            ],
        "pageLength": 20,

//         initComplete: function () {
      
//             this.api().columns([0,1,2,3,4]).every( function () {
//                 var column = this;
//                 var select = $('<select><option value="">Show all</option></select>')
//                     .appendTo( $(column.footer()).empty() )
//                     .on( 'change', function () {
//                         var val = $.fn.dataTable.util.escapeRegex(
//                             $(this).val()
//                         );
 
//                         column
//                             .search( val ? ''+val+'' : '', true, false )
//                             .draw();
//                     } );
 
//                 column.data().unique().sort().each( function ( d, j ) {
//                     select.append( '<option value="'+d+'">'+d+'</option>' )
//                 } );
//             } );

           
//               var r = $('#example23 tfoot tr');
//   r.find('th').each(function(){
//     $(this).css('padding', 8);
//   });
//   $('#example23 thead').append(r);
//   $('#search_0').css('text-align', 'center');
  
// $('#example23 tfoot tr').appendTo('#example23 thead');
//         }


                
            });
          
   

  $(document).on('click', '#delete_exam', function(e){

            var data;           
            var id = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(id);
            e.preventDefault();
        });

   function SwalDelete(id){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'delete_exam.php',
                    type: 'POST',
                    data: {exam_id:id},
                     dataType: 'json'
                   
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                     
                     table.ajax.reload();
                   
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
  });  
</script>


</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>