<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>

<?php include('navbar.php');  include('connection.php');?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Dashboard</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="card-group">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="m-b-0"><i class="mdi mdi-briefcase-check text-info"></i></h2>
                                    <?php

            $id = "SELECT count(roll_no) as roll_no FROM fh_user  WHERE disable_flag = '0' AND role = 'student'";
         $lid=mysqli_query($conn,$id);
             $fetch = mysqli_fetch_assoc($lid);
             
                                    ?>
                                    <h3 class=""><?php echo $fetch['roll_no']; ?></h3>
                                    <h6 class="card-subtitle">Total Student</h6></div>
                               
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="m-b-0"><i class="mdi mdi-alert-circle text-success"></i></h2>
                                      <?php
                                                 $today_date = date('Y-m-d');
            $today_att = "SELECT count(atten_id) as attendance_count FROM `fh_attendance` WHERE attendance_flag = '0' AND date(added_date) = '$today_date'";
         $result_att=mysqli_query($conn,$today_att);
             $fetch_att = mysqli_fetch_assoc($result_att);
             
                                    ?>
                                    <h3 class=""><?php echo $fetch_att['attendance_count']; ?></h3>
                                    <h6 class="card-subtitle">Today's Attendance</h6></div>
                                
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <h2 class="m-b-0"><i class="mdi mdi-wallet text-purple"></i></h2>
                                     <?php
                 $today_date = date("Y-m-d");
             $today_e = "SELECT count(`test_id`) as test_id, `batch_id`, `test_name`, `subject`, `chapter`, `marks`, `test_date`, `from_time`, `to_time`, `disable_flag`, `added_date` FROM `fh_test` WHERE date(added_date) = '$today_date' AND disable_flag ='0'";
         $result_e=mysqli_query($conn,$today_e);
             $fetch_e = mysqli_fetch_assoc($result_e);
             
                                    ?>
                                    <h3 class=""><?php echo $fetch_e['test_id']; ?></h3>
                                    <h6 class="card-subtitle">Today's Exam</h6></div>
                               
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                
                                <div class="col-12">
                                    <h2 class="m-b-0"><i class="mdi mdi-buffer text-warning"></i></h2>
                                     <?php
                 $today_date = date("Y-m-d");
             $today_e = "SELECT sum( `due_amount`) as r_amount FROM `fh_fees` WHERE disable_flag='0'";
         $result_e=mysqli_query($conn,$today_e);
             $fetch_e = mysqli_fetch_assoc($result_e);
             
                                    ?>
                                    <h3 class=""><?php echo $fetch_e['r_amount']; ?></h3>
                                    <h6 class="card-subtitle">Remainig Fees</h6></div>
                               
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-12 col-xlg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="d-flex flex-wrap">
                                            <div>
                                                <h4 class="card-title">Yearly Earning</h4>
                                            </div>
                                            <div class="ml-auto">
                                                <ul class="list-inline">
                                                    <!--<li>-->
                                                        <!--<h6 class="text-muted text-success"><i class="fa fa-circle font-10 m-r-10 "></i>Sales</h6> </li>-->
                                                    <li>
                                                        <h6 class="text-muted  text-info"><i class="fa fa-circle font-10 m-r-10"></i>Earning ($)</h6> </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div id="bar-chart" style="width:100%; height:400px;"></div>
                            
                    <!--</div>-->
                    <!--  <div class="col-lg-12">-->
                    <!--    <div class="card">-->
                    <!--        <div class="card-body">-->
                    <!--            <h4 class="card-title">Monthly Report</h4>-->
                    <!--            <div id="bar-chart" style="width:100%; height:400px;"></div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Column -->
                </div>
                
               
                
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
             <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>
 <!-- Chart JS -->
  <script src="assets/plugins/echarts/echarts-all.js"></script>
    
 <?php include "echarts.php";?> 
 
 <!--<script src="assets/plugins/echarts/echarts-init.js"></script>-->
</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>