<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>

<?php include('navbar.php'); ?>
<?php include('connection.php'); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Add Course</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Add Course</li>
                    </ol>
                </div>
                
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <?php
                 $query = "SELECT `subject_id`, `subject_name`, `subject_fees`, `disable_flag` FROM `fh_subject` WHERE disable_flag='0'";
                                             $info=mysqli_query($conn,$query);
                                                $result_c=mysqli_num_rows($info);
                    
                                     
            ?>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="card">
                        <div class="card-body"> 
                    <div class="container">

                               <form  method="POST" action="add_sub_batch_c_code.php"  enctype="multipart/form-data">
                                        <div class=" row">    
                                           
                                                <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Name <span style="color:red">*</span></label>
                                                    
                                                        <input type="text" class="form-control" name="course_name" placeholder="course_name" required >
                                                    
                                                </div>
                                              </div>
                                            
                                                 <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right">Standard<span style="color:red">*</span></label>
                                                     <div class="col-md-12">
                                       <select class="selectpicker" multiple required name="subject[]"  data-style="form-control btn-secondary">
                          
                                                           <?php
                                     
                                    while($row = mysqli_fetch_assoc($info))
                                   { ?>
                              <option value="<?php echo $row['subject_id']?> "><?php echo $row['subject_name']?></option> 

                                <?php
                                   }
                                   ?>
                                                        </select>
                                                       
                                                        </div>
                                                    </div>
                                                  </div>
                                                
                                           
                                             <div class="col-md-4">
                                           <button type="submit" class="btn btn-success"name="course_data" >Submit</button>
                                            </div>
                                            <!--/span-->
                                          </div>
                                          </form>
                                        </div>
                          

                           
    
     
            </div>
        </div>
    
                     <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 
                          <h4 class="card-title">Course List</h4> 
                              
                                <div class="table-responsive">
                                    <table class="table color-table muted-table">
                                        <thead>
                                            <tr>
                                                  <th>Course Name</th>
                                                
                                                <th>Subjects</th>
                                                <th>Total Fees</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                                                 
                                        </tbody>
                                    </table>
                                </div>
                         

                             
            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
              <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>
<script type="text/javascript">
  $(document).ready(function(){

 load_data();
 function load_data(query='')
 {
  $.ajax({
   url:"load_class_batch_course_code.php",
   method:"POST",
   data:{course_id:query},
   success:function(data)
   {
    $('tbody').html(data);
   }
  })
 }
 

  $(document).on('click', '#delete_course', function(e){

            var data;           
            var course_id = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(course_id);
            e.preventDefault();
        });

   function SwalDelete(course_id){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'delete_batch_sub_course.php',
                    type: 'POST',
                    data: {course_id:course_id},
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                    load_data();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }

  });
</script>

</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>