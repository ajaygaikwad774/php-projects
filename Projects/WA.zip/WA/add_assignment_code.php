<?php 

include('connection.php');

require('textlocal.class.php');

if (isset($_POST['add_assignment'])) 
{
   
   
    
// $numbers = array();


 $batch_id=mysqli_real_escape_string($conn,$_POST["batch_id"]);
	  $subject_name=mysqli_real_escape_string($conn,$_POST["subject_name"]);
    $assignment_name=mysqli_real_escape_string($conn,$_POST["assignment_name"]);
   $assignment_content=mysqli_real_escape_string($conn,$_POST["assignment_content"]);
   $assignment_date =mysqli_real_escape_string($conn,$_POST["assignment_date"]);
   
   echo $checkbox=mysqli_real_escape_string($conn,$_POST["check-box"]);
    
    
   

	   

	 if(is_uploaded_file($_FILES['image']['tmp_name']))
	 {
      $errors= array();
       $file_name = $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
        $ext = explode('.',$file_name);
      $file_ext=strtolower(end($ext));


       echo  $image_up = "images/".$file_name;
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152) {
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true) {

         move_uploaded_file($file_tmp,"images/".$file_name);
       
        
      }else{
         print_r($errors);
      }
   }
   else
     $image_up ='';
   {

	   $today_date =  date("Y-m-d H:i:s");

     $query = "INSERT INTO `fh_assignment`( `batch_id`, `subject`, `assignment_name`, `assignment_content`, `assignment_image`, `assignment_submit_date` , `added_date`) VALUES ('$batch_id','$subject_name','$assignment_name','$assignment_content', '$image_up' , '$assignment_date' , '$today_date')";
                                             $query_data=mysqli_query($conn,$query);
                                             
                                             
            $query_noti = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `p_mobile_no_1` , `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND role = 'student' AND batch_id = '$batch_id'";


 			                      	$result_data = mysqli_query($conn,$query_noti);

 	
                                             
                $response = array();
	                $token = array();
	                $numbers = array();
	             
               
                  function sendMessage($token)
         {


        //   print_r($token);

        // $content = ["en" => 'English Message'];
                  $headings=["en" => "Assignment"]; 

                   $content = array(
                   	//  "title" =>$notice_name,
                       "en" => "Click Here!!!!!"
                       );

                    $fields = array(
                    	//app id from one signal
                        'app_id' => "69e4fa75-66e9-4e1a-9b70-7f859e4afd74",
                        // device id from database

                        'include_player_ids' => $token ,
                        // 'included_segments' => array('All'),
                        'data' => array("foo" => "bar"),
                         'small_icon' => "https://www.appdid.com/WA//assets/images/small.png",
                         'large_icon' => "https://www.appdid.com/WA//assets/images/large.png",
                        //'big_picture'=>"http://onthefield.in/Pass2fit/assets/images/notification_icon2.png",
                          'headings'=> $headings,

                         'contents' => $content
                     );

                                $fields = json_encode($fields);
                            //print("\nJSON sent:\n");
                            //print($fields);

                         $ch = curl_init();
                         curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
                         //Authorization key from one signal 
                         curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic MDQ4ZGQ4MzktYjFiZi00ZjA0LTg4MjUtZmFiNTE0NzA1ZjMx'));
                         curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                         curl_setopt($ch, CURLOPT_HEADER, FALSE);
                          curl_setopt($ch, CURLOPT_POST, TRUE);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
                          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

                          $response1 = curl_exec($ch);
                          curl_close($ch);
                          return $response;
                 }
                 
                 
                 
                                              
                    if($query_data)
                    {
                        
                 while($row_fcm = mysqli_fetch_array($result_data))
                 {
                       if($row_fcm['fcm_id'] != ' ' && $row_fcm['fcm_id'] != Null)
                    {
                          $token[]=$row_fcm['fcm_id'];               
                    }
                    
                      if($row_fcm['p_mobile_no_1'] != ' ' && $row_fcm['p_mobile_no_1'] != Null)
                    {
                        
                
            $msg =  "Dear Rahul, \n  Assignment work for ".$assignment_date." is ". $subject_name." ".$assignment_name." \n Vishnu Sir - Wisdom Academy 932130242";
                    
                    //  $msg_data[] = array('number' => $row_fcm['p_mobile_no_1'] ,'text' => $msg ,'sender'=>'TXTLCL');
                     
                                    $data_a = array(
                                                'messages' => array(
                                                                 array(
                                                                     'number' => $row_fcm['p_mobile_no_1'],
                                                                     'text' => $msg
                                                                      ),
                                                                         )
                                                                    );
    
 
                    }
                    
                
                   
                 }
                 
                //   print_r($data_a);
                 $data = json_encode($data_a);
                 
                  $response = sendMessage($token);
                    	$return["allresponses"] = $response;
                     	$return = json_encode( $return);
                     	
     $qu = "SELECT `batch_id` , `p_mobile_no_1` , `f_name`, `batch_name` FROM `fh_user` WHERE disable_flag='0' AND batch_id = '$batch_id'";
     
     $r = mysqli_query($conn,$qu);
     
    $row = mysqli_fetch_array($r);
    
    $nr=mysqli_num_rows($r);
    
                 if($checkbox == 'yes_sms_assignment')
                {
   
//   for($i=1 ; $i<=count($r) ; $i++) 
while($row = mysqli_fetch_array($qu , MYSQL_ASSOC))
    {

$messages = array(
  
'sender' => "WISDOM",
'messages' => array(
array(
'number' => $row['p_mobile_no_1'],

'text' => rawurlencode("Dear ".$row['f_name'].",%nAssignment work for ".$assignment_date." is ".$assignment_content.".%n%nWisdom\'s Academy%n9321302424")
)
)  
);


$data = array(
'apikey' => 'Pr/NmR5gAEU-qPoFDu5kq505b5dPBTHslm5wmVLNZN',
'data' => json_encode($messages)
);



$ch = curl_init('https://api.textlocal.in/bulk_json/');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

echo $response;

                }
                
                      header('Location:add_assignment.php');
                }

                      
                    }else
                    {

                    }
   }
 }  
 elseif (isset($_POST['get_assignment'])) {
  ?>
    <?php
                                        
                       $query = "SELECT fh_assignment.assignment_id, fh_assignment.subject, fh_assignment.assignment_name,  fh_assignment.assignment_submit_date , fh_batch.batch_name  FROM `fh_assignment` INNER JOIN `fh_batch` ON `fh_assignment`.`batch_id` = `fh_batch`.`batch_id` WHERE fh_assignment.disable_flag = '0' ORDER BY fh_assignment.assignment_id DESC ";
                                             $info=mysqli_query($conn,$query);
                                                $info1=mysqli_num_rows($info);
                                                
                                                if ($info1>0)
                                                {
                                                    while($fetch=mysqli_fetch_assoc($info))
                                                    {  

                                                        $assignment_id = $fetch["assignment_id"];

                                                       $date_f = $fetch["assignment_submit_date"];

                                                        $newDate = date("d-m-Y", strtotime($date_f));
                                          ?>  
                                            <tr>
                                             
                                              <td><?php echo $fetch["subject"]; ?></td>
                                                <td><?php echo $fetch["assignment_name"]; ?></td>
                                                <td><?php echo $newDate; ?></td>
                                                 <td>  <a id="delete_assignment" data-id="<?php echo $assignment_id;?>" href="javascript:void(0)"><i class="mdi mdi-delete"></i></a></td>
                                                
                                             </tr>
                                          <?php 
                                      }
                                  }else
                                  {

                                    echo '<tr><td>No Data</td><tr> ';
                                  }
                                          ?>
                                         
<?php }

?>