<?php 
$dbServername="localhost";
$dbUsername="wisdomacademy";
$dbPassword="wisdomacademy";
$dbName="wisdomacademynew";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
// if($conn)
// {
//     echo "s";
// }
// else
// {
//     echo "n";
// }

date_default_timezone_set("Asia/Kolkata");
mysqli_set_charset($conn, "utf8");

?>