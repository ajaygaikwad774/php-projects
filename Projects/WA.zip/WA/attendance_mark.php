<?php
include('connection.php');
 if(isset($_POST["demo"]))
 {
              $batch_id = $_POST["batch_id"];
              $s_date = $_POST["s_date"];
              
         // print_r($_POST["demo"]);


                    $response = array();
	                $token = array();
               
                  function sendMessage($token)
         {


        //   print_r($token);

        // $content = ["en" => 'English Message'];
                  $headings=["en" => "Attendance"]; 

                   $content = array(
                   	//  "title" =>$notice_name,
                       "en" => "Attendance has been sucessfully marked."
                       );

                    $fields = array(
                    	//app id from one signal
                        'app_id' => "69e4fa75-66e9-4e1a-9b70-7f859e4afd74",
                        // device id from database

                        'include_player_ids' => $token ,
                        // 'included_segments' => array('All'),
                        'data' => array("foo" => "bar"),
                         'small_icon' => "https://www.appdid.com/WA//assets/images/small.png",
                         'large_icon' => "https://www.appdid.com/WA//assets/images/large.png",
                        //'big_picture'=>"http://onthefield.in/Pass2fit/assets/images/notification_icon2.png",
                          'headings'=> $headings,

                         'contents' => $content
                     );

                                $fields = json_encode($fields);
                            //print("\nJSON sent:\n");
                            //print($fields);

                         $ch = curl_init();
                         curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
                         //Authorization key from one signal 
                         curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic MDQ4ZGQ4MzktYjFiZi00ZjA0LTg4MjUtZmFiNTE0NzA1ZjMx'));
                         curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                         curl_setopt($ch, CURLOPT_HEADER, FALSE);
                          curl_setopt($ch, CURLOPT_POST, TRUE);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
                          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

                          $response1 = curl_exec($ch);
                          curl_close($ch);
                          return $response;
                 }
                 
                     //   print_r($token);

                      
                //  print($_POST["demo"]);
        
                              $today_date =  date("Y-m-d H:i:s");
                              $current_date =  date("Y-m-d");
                              
                            
                              
                   $query_check = "SELECT `atten_id` FROM `fh_attendance` WHERE  date(`attendance_date`) = '$s_date' AND batch_id='$batch_id' ";
                 
                 echo $s_date;
                 echo '<br>';

                 $attendance_check = mysqli_query($conn,$query_check);  
                  $count_att= mysqli_num_rows($attendance_check);
                  
                  
                   echo count."$count_att";
                     echo "<br>";
                  
               foreach ($_POST["demo"] as $key => $demo)
               {
                  
                       echo $key.'-'.$demo ; 
                       echo "<br>";
                       
                       echo count."$count_att";
                     echo "<br>";
                      
                   
                  
                  if($count_att > 0)
                 {
                     echo "update";
                     echo "<br>";
                     
                     $query12 = "UPDATE `fh_attendance` SET `attendance_flag`='$demo',`added_date`='$today_date' WHERE user_id ='$key' AND date(attendance_date)='$s_date'";
                     
                    
                     
                 }else{
                     
                     echo "insert";
                     echo "<br>";
                
                 $query12 = "INSERT INTO `fh_attendance`( `user_id`, `batch_id`, `attendance_flag` , `attendance_date` , `added_date`) VALUES ('$key','$batch_id','$demo', '$s_date' ,'$today_date' ) ";
     
                 }
                     
                
                  $stat=mysqli_query($conn,$query12);
                            
                    	$query_noti = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND role = 'student' AND user_id = '$key'";


	                        
  
 			                      	$result_data = mysqli_query($conn,$query_noti);
 			                      	
 			                      	  while($row_fcm = mysqli_fetch_array($result_data))
                 {
                
                   
                    if($row_fcm['fcm_id'] != ' ' && $row_fcm['fcm_id'] != Null)
                    {
                      $token[]=$row_fcm['fcm_id'];              
                    } 
                
                 }

 			 
               
             }     
    
    
    
                 
                  $response = sendMessage($token);
                    	$return["allresponses"] = $response;
                     	$return = json_encode( $return);
    
    
    	
 		  header("Location:add_attendance.php"); 	    

	    

 			     
               
 			    
 			

 }

 ?>