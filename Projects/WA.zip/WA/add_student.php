<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>
<?php include('navbar.php'); ?>

  <?php include('connection.php'); ?>


        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">New Student</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">New Student</li>
                    </ol>
                </div>
              
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
               
                            <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white">New Student</h4>
                            </div>
                            <div class="card-body">
                                <!-- action="add_student_code.php" -->
                                <form id="add_student" action="add_student_code.php"  method="POST" class="form-horizontal">
                                    <div class="form-body">
                                        <h3 class="box-title">Person Info</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">First Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="fname" required="" placeholder=" First Name">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                        </div> 
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Last Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="lname" required placeholder="Last Name">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                         </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Gender<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <select class="form-control custom-select" required name="gender">
                                                             <option value="None">Select Gender</option>
                                                            <option value="Male">Male</option>
                                                            <option value="Female">Female</option>
                                                        </select>
                                                        <!-- <small class="form-control-feedback"> Select your gender. </small>--> 
                                                        </div> 
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Mobile No</label>
                                                    <div class="col-md-9">
                                                        <input type="text" pattern="(7|8|9)\d{9}"   maxlength="10" class="form-control" name="mobile_no"  placeholder="Mobile No">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>

                                        <div class="row">
                                               <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Parent-1<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="pname_1" required placeholder="Parent Name">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> --> 
                                                        </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                              <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Mobile-1<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" pattern="(7|8|9)\d{9}"   maxlength="10" name="pmobile_1" required placeholder="Mobile Number">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small>  -->

                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>

                                        <div class="row">
                                               <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Parent-2</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="pname_2"  placeholder="Parent Name">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small>  -->

                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                              <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Mobile-2</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control"  pattern="(7|8|9)\d{9}"   maxlength="10" name="pmobile_2"   placeholder="Mobile Number">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small>  -->

                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                           
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Address 1 <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="address_1" placeholder="address_1" required >
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Address 2</label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="address_2" placeholder="Address" >
                                                    </div>
                                                </div>
                                            </div>
                                               <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">DOB <span style="color:red">*</span></label>
                                                    <div class="col-md-9 input-group">
                                                        <input type="text" class="form-control datepicker-autoclose" id="datepicker_f" required name="d_date" placeholder="YYYY-MM-DD">
                                                <span class="input-group-addon"><i class="icon-calender"></i></span> </div>
                                                    </div>
                                                </div>
                                           
                                      
                                       
                                            
                                            <!--/span-->
                                        </div>
                                        <h3 class="box-title">Course Details</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <!--/row-->
                                        <div class="row">

                                             <div class="col-md-6">
                                             <div class="form-group row">
                                            <label class="control-label text-right col-md-3">Course<span style="color:red">*</span></label>
                                            <div class="col-md-9">
                                            
                                         <select class="select2 form-control custom-select" id="course_select" required name="course_info" style="width: 100%; height:76px;"> 
                                         <option value="none">None</option> 
                                            <?php 

                                           $course = "SELECT `course_id`, `course_name`, `subjects`, `total_fees` FROM `fh_course` WHERE  disable_flag='0'";
                                             $course_data=mysqli_query($conn,$course);
                                                $result_co=mysqli_num_rows($course_data);
                                               
                                                    while($fetch_course = mysqli_fetch_assoc($course_data))
                                                    {  
                                           ?>     
                                            <option value="<?php echo $fetch_course['course_id'].'-'.$fetch_course['course_name'].'-'.$fetch_course['subjects']; ?>"><?php echo $fetch_course['course_name']; ?></option>
                                           <?php } ?>
                                        </select>
                                    </div>
                                    </div>
                                    </div>
                                              <div class="col-md-6">
                                             <div class="form-group row">
                                            <label class="control-label text-right col-md-3">Batch<span style="color:red">*</span></label>
                                            <div class="col-md-9">
                                              <select class="select2 form-control custom-select" required name="batch_info" id="batch_filter" style="width: 100%; height:76px;">    
                                                <option>None</option>
                                           <?php 

                                           $batch = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             $batch_data=mysqli_query($conn,$batch);
                                                $result_d=mysqli_num_rows($batch_data);
                                               
                                                    while($fetch_batch = mysqli_fetch_assoc($batch_data))
                                                    {  
                                           ?>     
                                            <option value="<?php echo $fetch_batch['batch_name'].'-'.$fetch_batch['batch_id'].'-'.$fetch_batch['batch_time']; ?>"><?php echo $fetch_batch['batch_name']; ?></option>
                                           <?php } ?>
                                        </select>
                                    </div>
                                    </div>
                                    </div>
                                    <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Roll No.<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="roll_no" required name="roll_no" class="form-control">
                                                    </div>
                                                </div>
                                            </div>

                                    <!--  <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Roll No<span style="color:red">*</span></label>
                                                    <div class="col-md-6">
                                                    <input type="text"  required name="roll number" class="form-control">
                                                    </div>
                                                </div>
                                            </div> -->
                                            
                                            
                                        </div>
                                        <h3 class="box-title">Fees Details</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Course fees<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="coursefeesinput" required name="course_fees" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Discount<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id="discount_amt" required name="discount" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        
                                       <div class="row">
                                      
                                                  
                                                  <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Payment Type <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                       
                                     <select class="select2 form-control custom-select" name="payment_type" id="p_t_filter" required style="width: 100%; height:76px;"> 
                                      <option  > None </option>
                                      <option value ='0' >Full Payment </option>
                                      <option value ='1' >Installment Payment </option>
                                      
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                             <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Installments <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                       
                                     <select class="select2 form-control custom-select" name="no_inst"  id="no_installment" required style="width: 100%; height:76px;"> 
                                     <option > None </option>
                                      <option value="1">1</option>
                                      <option value="2">2</option>
                                      <option value="3">3</option>
                                      <option value="4">4</option>
                                      <option value="5">5</option>
                                     
                                      
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                             <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Installment Date <span style="color:red">*</span></label>
                                                    <div class="col-md-9 input-group">
                                                        <input type="text" class="form-control datepicker-autoclose" id="datepicker-autoclose"  name="installment_date" placeholder="YYYY-MM-DD">
                                                <span class="input-group-addon"><i class="icon-calender"></i></span> </div>
                                                    </div>
                                                </div>
                                                  
                                                  </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Final Amount<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id='final_amount' required name="f_amount" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Paid Amount<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" id='paid_amount' required name="p_amount" class="form-control">
                                                        <input type="hidden" id='send_install'  name="send_install_val" >
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                       <div class="col-md-6">
                                                <div class="form-group row">
                                                 <label class="control-label text-right col-md-3">Remaining Amount</label>
                                                   <div class="col-md-9">
                                                        <input type="text" required id="remaining_amount" pattern="^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$" name="r_amount" class="form-control">
                                                    </div> 
                                            </div>
                                            <!--/span-->
                                        </div>
                                         <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Do you want to send sms? <span style="color:red">*</span>
                                                    <input type="checkbox"  name="check-box" value="yes_sms_student" >
                                                    </label>
                                                    
                                            
                                                    
                                                </div>
                                              </div>
                                        <!--/row-->
                                    </div>
                                    <hr>
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                                                        <button type="submit" id="a_submit" name="assubmit" class="btn btn-success">Submit</button>
                                                        <button type="button" class="btn btn-inverse">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6"> </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       
                  
                  
           <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
   
   
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>

    <script type="text/javascript">
        $(document).ready(function(){


 $("#discount_amt").keyup(function(){
  var discount_amt = $('#discount_amt').val();
   var course_amt = $('#coursefeesinput').val();
   
   var final_amt = course_amt - discount_amt ;
    // alert(paid_amt);
     $('#final_amount').val(final_amt);
       
        
        
        
});

 $("#paid_amount").keyup(function(){
  var final_amt = $('#final_amount').val();
  
  var paid_amt = $('#paid_amount').val();
  var remainig_amt = final_amt - paid_amt ;
    // alert(remainig_amt);
     $('#remaining_amount').val(remainig_amt);
  
});


 $("#no_installment").change(function(){

    var no_installment = $('#no_installment').val();
    var final_amt = $('#final_amount').val();
     var   paid_amount  = Math.round(final_amt /  no_installment) ;
      var   instal_send = paid_amount ;
      $('#send_install').val(instal_send);
         $('#paid_amount').val(paid_amount);
         
   var remainig_amt = final_amt - paid_amount ;
    // alert(remainig_amt);
     $('#remaining_amount').val(remainig_amt);
  
        
 
});

 $("#p_t_filter").change(function(){

    var p_t = $('#p_t_filter').val();
    // alert(p_t);
    if(p_t == '0')
    {
          $("#no_installment").prop("disabled", true);
          $("#datepicker-autoclose").prop("disabled", true);
           var final_amt = $('#final_amount').val();
    
         $('#paid_amount').val(final_amt);
         
          var remainig_amt = 0  ;
    // alert(remainig_amt);
     $('#remaining_amount').val(remainig_amt);
         
        
    }
    else if(p_t == '1')
    {
          $("#no_installment").prop("disabled", false);
           $("#datepicker-autoclose").prop("disabled", false);
              var remainig_amt = 0  ;
    // alert(remainig_amt);
     $('#remaining_amount').val(remainig_amt);
          
    }
        
 
});

 });
    </script>



    <script type="text/javascript">
$(document).ready(function(){

 
   
 function load_fees(query)
 {
  $.ajax({
   url:"add_student_code.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
  //  alert(data);
    $('#coursefeesinput').val(data);
   }
  })
 }



 $("#course_select").change(function(){
  var query = $('#course_select').val();

  
  $('#discount_amt').val("");
 
 $('#remaining_amount').val("");

  $('#final_amount').val("");
  $('#paid_amount').val("");
   load_fees(query);
});

 function unique_id(batch_data)
 {
     $.ajax({
   url:"add_student_code.php",
   method:"POST",
   data:{batch_data:batch_data},
   success:function(data)
   {
  //  alert(data);
    $('#roll_no').val(data);
   }
  })

 }


 $("#batch_filter").change(function(){
  var batch_data = $('#batch_filter').val();
    // alert(batch_data);
  if(batch_data == 'None')
  {
      $('#roll_no').val(" ");
  }
  else
  {
    unique_id(batch_data);

  }

   
  
 
});

  // $("#a_submit").click(function(){
//   $( '#add_student' ).submit(function(e) {
//   	e.preventDefault();
//   $.ajax({
//                         type: "POST",
//                         url: "add_student_code.php",
//                         data: $('#add_student').serialize(),
//                         cache: false,
//                         success: function (data) {
                        	

//                           $('#add_student select[class="select2"]').val('');
                         
//                          $('#add_student')[0].reset();
//                             swal("Success!", "Student  has been Added.", "success");
                          
//                         },
//                         error: function() {
//                         	e.preventDefault();
//                              alert('Error occurs!');
//                          }
//                     });
//   });

});


  
    </script>
    
</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>