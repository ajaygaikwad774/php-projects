<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
 include('header.php'); ?>

<?php include('navbar.php'); ?>
<?php include('connection.php'); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Add Subject</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Add Subject</li>
                    </ol>
                </div>
             
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="card">
                        <div class="card-body"> 
                    <div class="container">

                               <form  method="POST"  action="add_sub_batch_c_code.php"  enctype="multipart/form-data">
                                             <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label text-right ">Name <span style="color:red">*</span></label>
                                                   
                                                        <input type="text" class="form-control" name="subject_name" placeholder="Example V,VI" required >
                                                    
                                                </div>
                                            </div>
                                           <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label class="control-label text-right ">Fees<span style="color:red">*</span></label>
                                                    
                                                        <input type="text" class="form-control" name="subject_fees" placeholder=" Fees" required >
                                                   
                                                </div>
                                            </div>
                                             <div class="col-md-4">
                                           <button type="submit" class="btn btn-success" name="subject_data">Submit</button>
                                            </div>
                                          </div>
                                            <!--/span-->
                                        </form>
                                        </div>
                          

                           
    
     
            </div>
        </div>
    
                     <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 
                          <h4 class="card-title">Standard List</h4> 
                              <div class="table-responsive">
                                    <table class="table color-table muted-table">
                                        <thead>
                                            <tr>
                                                <th>Standard Name</th>
                                                
                                                <th>Fees</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                         
                                        </tbody>
                                    </table>
                                </div>
                         

                             
            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
            <?php $Current_year = date('Y'); ?>
            <!-- ============================================================== -->
            <footer class="footer"> © <?php echo $Current_year; ?> Appdid by themedesigner.in </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>
 <script type="text/javascript">
  $(document).ready(function(){

 load_data();
 function load_data(query='')
 {
  $.ajax({
   url:"load_class_batch_course_code.php",
   method:"POST",
   data:{subject_id:query},
   success:function(data)
   {
    $('tbody').html(data);
   }
  })
 }
 

  $(document).on('click', '#delete_subject', function(e){

            var data;           
            var subject_id = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(subject_id);
            e.preventDefault();
        });

   function SwalDelete(subject_id){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'delete_batch_sub_course.php',
                    type: 'POST',
                    data: {subject_id:subject_id},
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                    load_data();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
 });   
</script>


</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>