
<?php

//fetch.php

include('connection.php');


if(isset($_POST['query']))
{

 $batch_id = $_POST['query'];

 $today_date = date("Y-m-d");


  if($_POST['choose_date'] == '')
  {
      
 $choose_date = date('Y-m-d');
  }
  else
  {
 $choose_date = $_POST['choose_date'];
  }



    $query_atten = "SELECT DISTINCT(fh_user.user_id) FROM fh_attendance INNER JOIN fh_user ON fh_attendance.batch_id = fh_user.batch_id WHERE  fh_user.disable_flag='0' AND fh_user.role='student' AND fh_attendance.batch_id ='$batch_id' AND date(fh_attendance.attendance_date) ='$choose_date'   ";


$check_atten = mysqli_query($conn,$query_atten);
   $count_atten= mysqli_num_rows($check_atten);

  if($count_atten > 0)
  {

      //attendance already mark

    $query = "SELECT fh_user.user_id,fh_user.roll_no, fh_user.f_name, fh_user.l_name, fh_user.user_name, fh_user.mobile_no, fh_user.p_mobile_no_1 , fh_user.batch_name, fh_user.subject , fh_fees.due_amount , fh_attendance.attendance_flag FROM `fh_user` INNER JOIN `fh_attendance` ON fh_user.user_id = fh_attendance.user_id INNER JOIN fh_fees ON fh_attendance.user_id = fh_fees.user_id WHERE fh_user.disable_flag='0' AND fh_user.role = 'student' AND fh_user.batch_id ='$batch_id' AND fh_attendance.batch_id='$batch_id' AND date(fh_attendance.attendance_date) ='$choose_date' ";




$statement=mysqli_query($conn,$query);

?>
 <thead>
                                            <tr>
                                                <th>Roll NO</th>
                                                <th>Name</th>
                                                <th>Batch</th>
                                                <th>Mobile No</th>
                                                <th>Parent No</th>
                                                <th>Subject</th>
                                                <th>Due Fees</th>
                                                <th>Present<br><input type="radio" name="group4" value="0" onclick="selectAll(form1)"></th>
                                                  <th>Absent <br><input type="radio" name="group4" value="1" onclick="selectAll(form1)"></th>
                                                   <th>Holiday <br><input type="radio" name="group4" value="2" onclick="selectAll(form1)"></th>
                                                
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                         
 <tr>
<?php
while($row=mysqli_fetch_assoc($statement))
{
     $user_id = $row["user_id"];
?>
 
                                              <td><?php echo $row['roll_no']; ?></td>
                                                <td><?php echo $row["f_name"].' '.$row["l_name"]; ?></td>
                                                <td><?php echo $row["batch_name"]; ?></td>
                                                <td><?php echo $row["mobile_no"]; ?></td>
                                                <td><?php echo $row["p_mobile_no_1"];?></td>
                                                <td><?php echo $row["subject"]; ?></td>
                                                <td><?php echo $row["due_amount"]; ?></td>
                                                <?php if($row["attendance_flag"] == '0') { ?>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="0" checked="checked">
                                                 
                                                </td>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="1" >
                                                 
                                                </td>
                                               <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="2" >
                                                 
                                                </td>
                                                <?php } elseif ($row["attendance_flag"] == '1') {
                                                  ?>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="0" >
                                                 
                                                </td>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="1" checked="checked">
                                                 
                                                </td>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="1" >
                                                 
                                                </td>
                                                
                                                
                                               <?php } elseif($row["attendance_flag"] == '2') { ?>
                                               
                                               
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="0" >
                                                 
                                                </td>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="1" >
                                               
                                                 <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="2" checked="checked">
                                                 
                                                </td>
                                               <?php } ?>
                                            </tr>
 
<?php
   } ?>
                                           </tbody>


 <?php }else
  {


  $query12 = "SELECT fh_user.user_id,fh_user.roll_no, fh_user.f_name, fh_user.l_name, fh_user.user_name, fh_user.mobile_no, fh_user.p_mobile_no_1 , fh_user.batch_name, fh_user.subject , fh_fees.due_amount ,fh_user.batch_id FROM `fh_user` INNER JOIN `fh_fees` ON `fh_user`.`user_id`=`fh_fees`.`user_id` WHERE fh_user.disable_flag='0' AND fh_user.role = 'student' AND fh_user.batch_id ='$batch_id' ORDER BY fh_user.roll_no ASC";




$stat=mysqli_query($conn,$query12);
 ?>
  <thead>
                                            <tr>
                                                <th>Roll No</th>
                                                <th>Name</th>
                                                <th>Batch</th>
                                                <th>Mobile No</th>
                                                <th>Parent No</th>
                                                <th>Subject</th>
                                                <th>Due Fees</th>
                                              
                                              
                                                <th>Present<br><input type="radio" name="group4" value="0" onclick="selectAll(form1)"></th>
                                                  <th>Absent <br><input type="radio" name="group4" value="1" onclick="selectAll(form1)"></th>
                                                   <th>Holiday <br><input type="radio" name="group4" value="2" onclick="selectAll(form1)"></th>      
                                            </tr>
                                        </thead>
                                        <tbody>
                                         
<?php
while($row=mysqli_fetch_assoc($stat))
{
     $user_id = $row["user_id"];
?>
  <tr>
                                              <td><?php echo $row['roll_no']; ?></td>
                                                <td><?php echo $row["f_name"].' '.$row["l_name"]; ?></td>
                                                <td><?php echo $row["batch_name"]; ?></td>
                                                <td><?php echo $row["mobile_no"]; ?></td>
                                                <td><?php echo $row["p_mobile_no_1"];?></td>
                                                <td><?php echo $row["subject"]; ?></td>
                                                <td><?php echo $row["due_amount"]; ?></td>
                                                
                                                  <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="0" >
                                                 
                                                </td>
                                                <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="1" >
                                               
                                                 <td>  <input type="radio" name="demo[<?php echo $user_id ; ?>]" value="2" >
                                                 
                                                </td>
                                        
                                            </tr>
 
<?php
}

?>


                        </tbody>

 <?php  }






}else 
{


}


?>