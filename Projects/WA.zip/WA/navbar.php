<?php
se
?>
      <body class="fix-header fix-sidebar card-no-border">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <!-- ============================================================== -->
        <!-- Main wrapper - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <div id="main-wrapper">

            
         <header class="topbar">
                <nav class="navbar top-navbar navbar-expand-md navbar-light">
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-header">
                        <a class="navbar-brand" href="dashboard_admin.php">
                            <!-- Logo icon --><b>
                                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                                <!-- Dark Logo icon -->
                                <img src="assets/images/logo-icon_t.png" alt="homepage" class="dark-logo" />
                                <!-- Light Logo icon -->
                                <img src="assets/images/logo-light-icon_t.png" alt="homepage" class="light-logo" />
                            </b>
                            <!--End Logo icon -->
                            <!-- Logo text --><span>
                             <!-- dark Logo text -->
                             <img src="assets/images/logo-text_t.png" alt="homepage" class="dark-logo" />
                             <!-- Light Logo text -->    
                             <img src="assets/images/logo-light-text_t.png" class="light-logo" alt="homepage" /></span> </a>
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-collapse">
                        <!-- ============================================================== -->
                        <!-- toggle and nav items -->
                        <!-- ============================================================== -->
                        <ul class="navbar-nav mr-auto mt-md-0">
                            <!-- This is  -->
                            <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                            <li class="nav-item m-l-10"> <a class="nav-link sidebartoggler hidden-sm-down text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                           
                        </ul>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <ul class="navbar-nav my-lg-0">
                           
                            <!-- ============================================================== -->
                            <!-- Profile -->
                            <!-- ============================================================== -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/walogoo_t.png" alt="user" class="profile-pic" /></a>
                                <div class="dropdown-menu dropdown-menu-right scale-up">
                                    <ul class="dropdown-user">
                                        <li>
                                            <div class="dw-user-box">
                                                <div class="u-img"><img src="assets/images/walogoo_t.png" alt="user"></div>
                                                <div class="u-text">
                                                    <h4>Wisdom Admin</h4>
                                                    <p class="text-muted">info@appdid.com</p></div>
                                                    <!--<a href="pages-profile.html" class="btn btn-rounded btn-danger btn-sm">View Profile</a>-->
                                            </div>
                                        </li>
                                       
                                        <li role="separator" class="divider"></li>
                                        <li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>

      <aside class="left-sidebar">
                <!-- Sidebar scroll-->
                <div class="scroll-sidebar">
                   
                    <!-- Sidebar navigation-->
                    <nav class="sidebar-nav">
                        <ul id="sidebarnav">
                            <li class="nav-devider"></li>
                            <!-- <li class="nav-small-cap">PERSONAL</li> -->
                            
                            <li> <a class="has-arrow waves-effect waves-dark" href="dashboard_admin.php" aria-expanded="false" style="background-color:#fff;}" ><i class="mdi mdi-bullseye"></i><span class="hide-menu">Dashboard</span></a>
                                
                            </li>
                            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-account"></i><span class="hide-menu">Student</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="add_student.php">Add Student</a></li>
                                    <li><a href="student_list.php">Student list</a></li>
                                     <!--<li><a href="update_student.php">Update list</a></li>-->
                                  
                                    
                                </ul>
                            </li>

                            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-calendar-check"></i><span class="hide-menu">Attendance</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="add_attendance.php">Attendance</a></li>
                                   
                                    
                                </ul>
                               
                            </li>
                            
                             <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-cash-usd"></i><span class="hide-menu">Fees</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="add_fees.php">Fees</a></li>
                                   
                                    
                                </ul>
                               
                            </li>
                           

                          
                            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-clipboard-text "></i><span class="hide-menu">Exam </span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="exam_schedule.php">Exam Schedule</a></li>
                                    <li><a href="exam_marks.php">Exam Marks</a></li>
                                </ul>
                            </li>

                             <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi  mdi-library-books"></i><span class="hide-menu">Assignment</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="add_assignment.php">Assignment</a></li>
                                    <!-- <li><a href="app-email-detail.html">Notice</a></li> -->
                                    <!-- <li><a href="app-compose.html">Batch Notice</a></li> -->
                                </ul>
                            </li>
                            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-bell-ring"></i><span class="hide-menu">Notice</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="notice.php">Notice</a></li>
                                   
                                </ul>
                            </li>

                            <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-database-plus"></i><span class="hide-menu">Add</span></a>
                                <ul aria-expanded="false" class="collapse">
                                     <li><a href="add_course.php">Add Course</a></li>
                                    <li><a href="add_subject.php">Add Standard</a></li>
                                    <li><a href="add_batch.php">Add Batch</a></li>
                                </ul>
                            </li>



                          <!--   <li> <a class="has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-email"></i><span class="hide-menu">Subscription</span></a>
                                <ul aria-expanded="false" class="collapse">
                                	 <li><a href="app-email.html">Add Subscription Package</a></li>
                                    <li><a href="app-email.html">Cantact To Admin</a></li>
                                    <li><a href="app-email-detail.html">Subscriber Details</a></li>
                                    <li><a href="app-compose.html">Add Batch</a></li>
                                </ul>
                            </li> -->
                            
                        </ul>
                    </nav>
                    <!-- End Sidebar navigation -->
                </div>
                <!-- End Sidebar scroll-->
            </aside>