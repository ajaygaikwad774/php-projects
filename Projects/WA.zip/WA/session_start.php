<?php
session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
?>
