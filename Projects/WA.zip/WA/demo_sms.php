       <?php      	
                                 	
                                 require('textlocal.class.php');
 
 
                                
                                  
 
 
                                	$Textlocal = new Textlocal(false, false, 'Pr/NmR5gAEU-qPoFDu5kq505b5dPBTHslm5wmVLNZN');
                                	
                                
 
                                         	$numbers[] = 9967077027 ;
                                         	
                                         	
	print_r($numbers);
//	$full_name = 'Rohan Naik';
                                    	$sender = 'WISDOM';
                                	$message = rawurlencode("Dear ".$fname.",%nThank You for your Registration.%nLogin id :".$pmobile_1."%nPassword :".$password."%nBest Wishes,%nWisdom Academy%n9321302424");
	echo $message;


 
                            	$response = $Textlocal->sendSms($numbers, $message, $sender);
                                	print_r($response);
  
        	
        
  
        	
  ?>