<?php 
include('connection.php');

   require('textlocal.class.php');

if(isset($_POST['batch_id']) && !isset($_POST['user_id']))
{
  if($_POST['batch_id'] =='All')
  {
      
  
	
$query = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `batch_name` FROM `fh_user` WHERE disable_flag='0' AND role = 'student'";



}
elseif (isset($_POST['batch_id'])) 
{


	 $batch_id=mysqli_real_escape_string($conn,$_POST["batch_id"]);

	  $query = "SELECT `user_id` , `roll_no`, `f_name`, `l_name` , `batch_name` FROM `fh_user` WHERE disable_flag='0' AND batch_id='$batch_id' AND role = 'student' ORDER BY roll_no ASC";
	
}

				$query_fetch = mysqli_query($conn,$query);
   				$count = mysqli_num_rows($query_fetch);  ?>

          <option> None</option>

   <?php				while($fetch = mysqli_fetch_assoc($query_fetch))
                                                    {  
                                           ?>     
                                            <option value="<?php echo $fetch['user_id']; ?>"><?php echo $fetch['roll_no'].'-'.$fetch['f_name'].' '.$fetch['l_name'].' ('.$fetch['batch_name'].' )'; ?></option>
                                           <?php } 

  }
  elseif(isset($_POST['batch_id']) && isset($_POST['submit']) ) 
  {
  

	 $batch_id=mysqli_real_escape_string($conn,$_POST["batch_id"]);
	 $user_id=mysqli_real_escape_string($conn,$_POST["user_id"]);
  $notice_name=mysqli_real_escape_string($conn,$_POST["notice_name"]);
   $notice_content=mysqli_real_escape_string($conn,$_POST["notice_content"]);

   echo   $checkbox=mysqli_real_escape_string($conn,$_POST["check-box"]);
       $user_id;

       $today_date =  date("Y-m-d H:i:s");
       
	 if($batch_id == 'All')
	  {
	      echo "All1";

	  	$query_one = "INSERT INTO `fh_notice`( `notice_name`, `user_id`, `batch_id`, `notice_type`, `notice_content` , `added_date`) VALUES ('$notice_name' , 'All' , 'All' ,'All' , '$notice_content' , '$today_date')";
		$stmt = mysqli_query($conn, $query_one );

	  	$query_noti = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `p_mobile_no_1` ,  `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND role = 'student'";


	  }
	  elseif ( $batch_id != 'All' && $user_id =='None')
	  {
	       echo "single batch";

	  	$query_two = "INSERT INTO `fh_notice`( `notice_name`, `user_id`, `batch_id`, `notice_type`, `notice_content` , `added_date`) VALUES ('$notice_name' , 'All' , '$batch_id' ,'individual' , '$notice_content' , '$today_date')";
		$stmt = mysqli_query($conn, $query_two );

	  $query_noti = "SELECT `user_id` , `roll_no`, `f_name`, `l_name` , `p_mobile_no_1` , `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND batch_id='$batch_id' AND role = 'student' ORDER BY roll_no ASC";

	  }	
	  	elseif ($user_id !='' OR $user_id != Null)
	  {
        	echo "user";
          	
	   	$query_three = "INSERT INTO `fh_notice`( `notice_name`, `user_id`, `batch_id`, `notice_type`, `notice_content` , `added_date`) VALUES ('$notice_name' , '$user_id' , '$batch_id' ,'individual' , '$notice_content'  , '$today_date')";
		$stmt = mysqli_query($conn, $query_three );

		$query_noti = "SELECT  `user_id` , `roll_no`, `f_name`, `l_name` , `p_mobile_no_1` , `batch_name` , `fcm_id` FROM `fh_user` WHERE disable_flag='0' AND role = 'student' AND user_id = '$user_id'";


	  }
  
 				$result_data = mysqli_query($conn,$query_noti);

 				if( $stmt && $result_data)
 			{
 				    

	       function sendMessage($token , $notice_name , $notice_content)
         {


        //   print_r($token);

        // $content = ["en" => 'English Message'];
                  $headings=["en" => $notice_name]; 

                   $content = array(
                   	//  "title" =>$notice_name,
                       "en" => $notice_content
                       );

                    $fields = array(
                    	//app id from one signal
                        'app_id' => "69e4fa75-66e9-4e1a-9b70-7f859e4afd74",
                        // device id from database

                        'include_player_ids' => $token ,
                        // 'included_segments' => array('All'),
                        'data' => array("foo" => "bar"),
                         'small_icon' => "https://www.appdid.com/WA//assets/images/small.png",
                         'large_icon' => "https://www.appdid.com/WA//assets/images/large.png",
                        //'big_picture'=>"http://onthefield.in/Pass2fit/assets/images/notification_icon2.png",
                          'headings'=> $headings,

                         'contents' => $content
                     );

                                $fields = json_encode($fields);
                            //print("\nJSON sent:\n");
                            //print($fields);

                         $ch = curl_init();
                         curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
                         //Authorization key from one signal 
                         curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic MDQ4ZGQ4MzktYjFiZi00ZjA0LTg4MjUtZmFiNTE0NzA1ZjMx'));
                         curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                         curl_setopt($ch, CURLOPT_HEADER, FALSE);
                          curl_setopt($ch, CURLOPT_POST, TRUE);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
                          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

                          $response1 = curl_exec($ch);
                          curl_close($ch);
                          return $response;
                 }
                 
                 
                 $response = array();
	                $token = array();
	                 $numbers_1 = array();
	                 
                 
                      	$Textlocal = new Textlocal(false, false, 'Pr/NmR5gAEU-qPoFDu5kq505b5dPBTHslm5wmVLNZN');
                         
 
                 while($row_fcm = mysqli_fetch_array($result_data))
                 {
                
                     if($row_fcm['fcm_id'] != ' ' && $row_fcm['fcm_id'] != Null)
                    {
                       $token[]=$row_fcm['fcm_id'];               
                    }   
                    
                      if($row_fcm['p_mobile_no_1'] != ' ' && $row_fcm['p_mobile_no_1'] != Null && $checkbox == 'yes_sms_notice')
                    {
                        
                      
                     	
                      
                      
                     echo   $full_name = $row_fcm['f_name'].' '.$row_fcm['l_name'];
                                        
                        echo     $numbers[]=$row_fcm['p_mobile_no_1'];  
                         
                         
                           
                           	$sender = "WISDOM";
                           
                           	
                                
                           	
                           	echo 'demo';
                           	
                           	
                        echo   	$message ="Dear $full_name,%n $notice_content%n%nWisdom's Academy%n9321302424";
                         
 
                        	$response = $Textlocal->sendSms($numbers, $message, $sender);
                           
                            		
                            		
                            	
        
                    }
                
                
                 }
                 
                 
                 
                 
              //print_r($data);
               if($row_fcm['fcm_id'] != ' ' && $row_fcm['fcm_id'] != Null)
                    {

                        $response = sendMessage($token , $notice_name , $notice_content);
                    	$return["allresponses"] = $response;
                     	$return = json_encode( $return);
                    }
                    
                    
                
                  


		if ($stmt == TRUE ) {
		
			$response12['status']  = 'success';
			$response12['message'] = 'Attendance Done';
			// $response12['user_id'] = $user;
		} else {
			$response12['status']  = 'error';
			$response12['message'] = 'Unable to Mark Attendance ...';
			// $response12['user_id'] = $user;
		}
		 json_encode($response12);
	}
	else{
		$response1['status']  = 'error';
			$response1['message'] = 'Something Went Wrong Please Contact TO Provider ...';
					 json_encode($response12);
	}
}

?>