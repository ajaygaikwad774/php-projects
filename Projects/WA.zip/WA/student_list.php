<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>
<?php include('navbar.php'); ?>

        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Student List</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Student List</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">

                 <div class="card-group">
                    <div class="card">
                        <div class="card-body">

                            <div class="table-responsive m-t-40">
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                 <th>Roll No</th>
                                                 <th>Name</th>
                                                 
                                                 <th>Password</th>
                                                    
                                                    <th>Batch</th>
                                                    <th>Conatct No </th>
                                                    <th>Parent No 1</th>
                                                    <th>Parent No 2</th>
                                                    <th>Delete</th>
                                            </tr>
                                        </thead>
                                      
                                    </table>
                                </div>

            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
             <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>


 <script src="assets/plugins/datatables/JSZip-2.5.0/jszip.min.js"></script>
 <script src="assets/plugins/datatables/pdfmake-0.1.36/vfs_fonts.js"></script> 
                                      


    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

       <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/autofill/2.3.3/js/dataTables.autoFill.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>



<script type="text/javascript" language="javascript" >

        $(document).ready(function() {

    var table =  $('#example23').DataTable({
                "processing" : true,
                "ordering": false,
                 "serverSide" : true,
                 "ajax" : {
                  url:"student_list_code.php",
                 type:"POST"
                 },
                // "columnDefs": [{
                //     "visible": false,
                //     "targets": 2
                // }],
                "order": [
                    [2, 'asc']
                ],
                responsive: true,
        destroy: true,
        dom: 'Bfrtip',
        buttons: [  
           
            
            {
                extend: 'excel',
                 title:'Student List',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5 , 6]
                }
            }, 
            
            {
                extend: 'copy',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5 , 6]
                }
            }, 
            
            {
                extend: 'csv',
                  title:'Student List',
                exportOptions: {
                columns: [ 0, 1, 2, 3, 4 , 5 , 6]
                }
            }  
            ],
        "pageLength": 20,


                
            });
      

   

  $(document).on('click', '#delete_student', function(e){

            var data;           
            var id = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(id);
            e.preventDefault();
        });

   function SwalDelete(id){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'delete_student.php',
                    type: 'POST',
                    data: {student_id:id},
                     dataType: 'json'
                   
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                    
                        table.ajax.reload();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }

 }); 
 
</script>

</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>