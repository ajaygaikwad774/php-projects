<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>
<?php include('navbar.php'); ?>
 <?php include('connection.php'); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Fees</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Fees</li>
                    </ol>
                </div>
              
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">


                 <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 


                      <form  method="POST">
                           <div class="row"> 
                           
                           <div class="col-md-6">

                              <h5 class="">Select Batch</h5>
                                        
                                      
                                        <select class="select2 form-control custom-select" id="batch_filter" name="batch_id" style="width: 100%; height:76px;">
                                            <option >None</option>
                                            <option value="All">All</option>
                                             <?php 

                                           $batch = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             $batch_data=mysqli_query($conn,$batch);
                                                $result_d=mysqli_num_rows($batch_data);
                                               
                                                    while($fetch_batch = mysqli_fetch_assoc($batch_data))
                                                    {  
                                           ?>     
                                            <option value="<?php echo $fetch_batch['batch_id']; ?>"><?php echo $fetch_batch['batch_name']; ?></option>
                                           <?php } ?>
                                        </select>
                                    </div>
                                 
                           
                               <div class="col-md-6">

                              <h5 class="">Students</h5>
                                                     
                                    <select class="select2 form-control custom-select" id="student_s" name="user_id" style="width: 100%; height:76px;">
                                                     
                                                <option value="">None</option>
                                                          
                                                        </select>
                                                       
                                                       
                                                  </div>
                                            </div>
                          </form>

                           
    
     
            </div>
        </div>
    </div>
                     <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 
                                   
                    <div class="card-body">
                                
                                  <div id="form_show">
                                    <h3 class="box-title">Fees Details</h3>
                                        <hr class="m-t-0 m-b-40">
                                      </div>
                               
                              
                            </div>


                             
            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
              <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>
    
   
     

       <script type="text/javascript">

$(document).ready(function(){
 function unique_id(batch_id)
 {
     $.ajax({
   url:"notice_code.php",
   method:"POST",
   data:{batch_id:batch_id},
   success:function(data)
   {
    // alert(data);
    $('#student_s').html(data);
   }
  })

 }


 $("#batch_filter").change(function(){
  var batch_id = $('#batch_filter').val();
   // alert(batch_id);
  if(batch_id == 'None')
  {
      $('#student_s').val(" ");
  }
  else
  {
    unique_id(batch_id);

  }
 
});

  function studentid(student_id,update_fees='')
 {
     $.ajax({
   url:"update_fees_code.php",
   method:"POST",
   data:{update_fees:update_fees,userid:student_id},
   success:function(data)
   {
    // alert(data);
  $('#form_show').html(data);
   }
  })

 }


 $("#student_s").change(function(){
  var student_id = $('#student_s').val();
   // alert(batch_id);
   var update_fees =' ';
  
  
    studentid(student_id,update_fees);

  
 
});



      $( document ).ajaxComplete(function() {
  
  

 $("#p_amount").keyup(function(){
  var f_amount = $('#f_amount').val();
   var p_amount = $('#p_amount').val();
   var paid_amount = $('#paid_amount').val();
   
  var p_amt = Number(p_amount)+Number(paid_amount) ;
   var final_amt = f_amount - p_amount - paid_amount ;
  
//alert(final_amt);
     $('#final_amount').val(final_amt);
      $('#sp_amount').val(p_amt);

     $('#d_amount').replaceWith($('<span id="d_amount">' +  final_amt + '</span>'));
 
});

 $("#update_submit").click(function(){
 //  $( '#update_submit' ).submit(function() {
  $.ajax({
                        type: "POST",
                        url: "update_fees_code.php",
                        data: $('#update_d').serialize(),
                        cache: false,
                        success: function (data) {
                          // alert(data);
                          var student_id = $('#student_s').val();
                          var update_fees =' ';
                           studentid(student_id,update_fees);
                            swal("Success!", "Your Fees  has been Added.", "success");
                          
                        }
                    });
  });


 });

 });     
    </script>


</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>