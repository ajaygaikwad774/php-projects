<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>


<?php include('navbar.php'); ?>
<?php include('connection.php'); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Add Assignment</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Add Assignment</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <?php
                 $query = "SELECT `subject_id`, `subject_name`, `subject_fees`, `disable_flag` FROM `fh_subject` WHERE disable_flag='0'";
                                             $info=mysqli_query($conn,$query);
                                                $result_c=mysqli_num_rows($info);
                    
                                     
            ?>
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="card">
                        <div class="card-body"> 
                    <div class="container">

        <form  method="POST" action="add_assignment_code.php"  enctype="multipart/form-data">
                                        <div class=" row"> 

                                            <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Batch Name <span style="color:red">*</span></label>
                                                    <div>
                                            
                          <select class="select2 form-control custom-select" name="batch_id" id="batch_filter" required style="width: 100%; height:76px;"> 
                            <option>None</option>
                                           <?php 

                                           $batch = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             $batch_data=mysqli_query($conn,$batch);
                                                $result_d=mysqli_num_rows($batch_data);
                                               
                                                    while($fetch_batch = mysqli_fetch_assoc($batch_data))
                                                    {  
                                           ?>     
                                            <option value="<?php echo $fetch_batch['batch_id']; ?>"><?php echo $fetch_batch['batch_name']; ?></option>
                                           <?php } ?>
                                        </select>
                                    </div>
                                    </div>
                                    </div>

                                                 <div class="col-md-6">
                              <!--                     <div class="form-group ">-->
                              <!--                      <label class="control-label text-right">Subject<span style="color:red">*</span></label>-->
                              <!--                       <div class="col-md-12">-->
                                    
                              <!--       <select class="select2 form-control custom-select" name="subject_name" id="subject_filter" required style="width: 100%; height:76px;"> -->
                              <!--        <option>None</option>-->
                              <!--                             <php-->
                                     
                              <!--      while($row = mysqli_fetch_assoc($info))-->
                              <!--     { ?>-->
                              <!--<option value="<php echo $row['subject_name']?> "><php echo $row['subject_name']?></option> -->

                              <!--  <php-->
                              <!--     }-->
                              <!--     ?>-->
                              <!--                          </select>-->
                                                       
                              <!--                          </div>-->
                              <!--                      </div>-->
                                
                                    <label class="control-label">Subject Name<span style="color:red">*</span></label>
                                    <input type="text"  required class="form-control"  placeholder="Example Maths" name="subject_name">
                                    <small class="form-control-feedback">  </small> </div>
                                                  
                                    
                                           
                                                <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Assignment Name <span style="color:red">*</span></label>
                                                    
                                                        <input type="text" class="form-control" name="assignment_name" placeholder="Assignment Name" required >
                                                    
                                                </div>
                                              </div>
                                               <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Submit Date <span style="color:red">*</span></label>
                                               <div class="col-md-9">
                                                <input type="text" class="form-control" id="datepicker-autoclose" required name="assignment_date" placeholder="yyyy-mm-dd">
                                                </div>
                                        </div>
                                        </div> 

                                               <div class="col-md-12">
                                       <div class="form-group ">
                                                    <label class="control-label text-right ">Assignment Content <span style="color:red">*</span></label>
                                         <div class="col-md-12">
                                            <textarea rows="7" style="min-width: 100%" name="assignment_content"></textarea>
                                         </div>
                                     </div>
                                     

                                                <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Assignment image <span style="color:red">*</span></label>
                                                    
                                            <input type="file" class="form-control" name="image"   >
                                                    
                                                </div>
                                              </div>
                                              
                                              
                                              <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Do you want to send sms? <span style="color:red">*</span>
                                                    <input type="checkbox"  name="check-box" value="yes_sms_assignment" >
                                                    </label>
                                                    
                                            
                                                    
                                                </div>
                                              </div>
                                           
                                              </div>
                                           
                                             <div class="col-md-4">
                                              <div class="form-group ">
                                           <button type="submit" class="btn btn-success"name="add_assignment" >Submit</button>
                                         </div>
                                            </div>
                                            <!--/span-->
                                          </div>
                                          </form>
                                        </div>
                          

                           
    
     
            </div>
        </div>
    
                     <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 
                          <h4 class="card-title">Course List</h4> 
                              
                                <div class="table-responsive">
                                    <table class="table color-table muted-table">
                                        <thead>
                                            <tr>
                                                  <!-- <th>I</th> -->
                                                  <th>Subject</th>
                                                <th>Assignment Name</th>
                                                <th>Submit Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        </tbody>
                                    </table>
                                </div>
                         

                             
            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
              <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>

<script type="text/javascript">
  $(document).ready(function(){

 load_data();
 function load_data(query='')
 {
  $.ajax({
   url:"add_assignment_code.php",
   method:"POST",
   data:{get_assignment:query},
   success:function(data)
   {
    $('tbody').html(data);
   }
  })
 }
 


  $(document).on('click', '#delete_assignment', function(e){

            var data;           
            var id = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(id);
            e.preventDefault();
        });

   function SwalDelete(id){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'delete_assignment.php',
                    type: 'POST',
                    data: {assignment:id},
                     dataType: 'json'
                   
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                    load_data();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
  });  
</script>

  
</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>