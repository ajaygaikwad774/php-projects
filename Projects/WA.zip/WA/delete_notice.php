<?php
 
include('connection.php');

if (isset($_POST['notice_id'])) {
		
		
		$notice_id = mysqli_real_escape_string($conn,$_POST['notice_id']);
		$query = "UPDATE `fh_notice` SET `disable_flag`='1' WHERE notice_id='$notice_id'";
		$stmt = mysqli_query($conn, $query );


		if ($stmt == TRUE ) {
			
			$response['status']  = 'success';
			$response['message'] = 'Batch Deleted Successfully ...';
		} else {
			$response['status']  = 'error';
			$response['message'] = 'Unable to delete Batch ...';
		}
		echo json_encode($response);


	}

	?>