

                                        
<?php
include('connection.php');
 
                 if(isset($_POST['batch_id']))
                 {      
                                        
                    $query12 = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                               $info12=mysqli_query($conn,$query12);
                                 $result_c=mysqli_num_rows($info12);
                                                
                                                if ($result_c>0)
                                                {
                                                    while($fetch=mysqli_fetch_assoc($info12))
                                                    {  

                                                        $batch_id = $fetch["batch_id"];
                                          ?>  
                                            <tr>
                                              <td><?php echo $fetch["batch_name"]; ?></td>
                                                <td><?php echo $fetch["batch_time"]; ?></td>
                                                <td>  <a id="delete_batch" data-id="<?php echo $batch_id;?>" href="javascript:void(0)"><i class="mdi mdi-delete"></i></a></td>
                                                
                                             </tr>
                                          <?php 
                                      }
                                  }else
                                  {

                                    echo '<tr><td>No Data</td><tr> ';
                                  }

      }else if (isset($_POST['course_id'])) 
      {
      	?>
      	     <?php
                                        
                     $query = "SELECT `course_id`, `course_name`, `subjects`, `total_fees`, `disable_flag`, `added_date` FROM `fh_course` WHERE disable_flag='0'";
                                             $info=mysqli_query($conn,$query);
                                                $info1=mysqli_num_rows($info);
                                                
                                                if ($info1>0)
                                                {
                                                    while($fetch=mysqli_fetch_assoc($info))
                                                    {  

                                                        $course_id = $fetch["course_id"];
                                          ?>  
                                            <tr>
                                              <td><?php echo $fetch["course_name"]; ?></td>
                                                <td><?php echo $fetch["subjects"]; ?></td>
                                                <td><?php echo $fetch["total_fees"]; ?></td>
                                                <td> <a  id="delete_course" data-id="<?php echo $course_id;?>" href="javascript:void(0)"><i class="mdi mdi-delete"></i></a></td>
                                                
                                             </tr>
                                          <?php 
                                      }
                                  }else
                                  {

                                    echo '<tr><td>No Data</td><tr> ';
                                  }
                                          ?>


    <?php   } else if (isset($_POST['subject_id'])) {     ?> 

                                <?php
                                        
                                          $query = "SELECT `subject_id`, `subject_name`, `subject_fees`, `disable_flag` FROM `fh_subject`  WHERE disable_flag='0'";
                                             $info=mysqli_query($conn,$query);
                                                $info1=mysqli_num_rows($info);
                                                
                                                if ($info1>0)
                                                {
                                                    while($fetch=mysqli_fetch_assoc($info))
                                                    {  

                                                        $subject_id = $fetch["subject_id"];
                                          ?>  
                                            <tr>
                                              <td><?php echo $fetch["subject_name"]; ?></td>
                                               <td><?php echo $fetch["subject_fees"]; ?></td>
                                                <td><a  id="delete_subject" data-id="<?php echo $subject_id;?>" href="javascript:void(0)"><i class="mdi mdi-delete"></i></a></td>
                                                
                                             </tr>
                                          <?php 
                                      }
                                  }else
                                  {

                                    echo '<tr><td>No Data</td><tr> ';
                                  }
                                          ?>
                                                         
                                         

                                        <?php }
                                        else{

                                        	header('Location:logout.php');

                                        }  ?>
                                         
