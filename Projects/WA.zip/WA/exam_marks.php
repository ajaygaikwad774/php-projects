<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>

<?php include('navbar.php'); ?>
<?php include('connection.php'); ?>
<style type="text/css">
    [type=radio]:checked, [type=radio]:not(:checked) {
     position: static !important;
    /*left: -9999px;*/
     opacity: 1 !important; 
}
</style>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Exam Marks</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Exam Marks</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
              <?php
                 $query12 = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                         $info12=mysqli_query($conn,$query12);
                     $result_c=mysqli_num_rows($info12);
               ?>
                

                           
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title"></h4>
                                 <div class="row">  
                                    <div class="col-md-6">
                                           <div class="form-group row">
                                               <label class="control-label text-right col-md-3">Batch</label>
                                                    <div class="col-md-9">
                                          
                              <select class="select2 form-control custom-select" name="select" id="batch_filter" required style="width: 100%; height:76px;">   
                                    <option value="">None</option>
                                   <?php
                                    
                                    while($row = mysqli_fetch_assoc($info12))
                                   {
                                    echo '<option value="'.$row["batch_id"].'">'.$row["batch_name"].'</option>'; 
                                   }
                                   ?>
                                   </select>
                                                        </div> 
                                                </div>
                                            </div>
                                          
                                              <?php
                 $query = "SELECT DISTINCT `subject` FROM `fh_test` WHERE disable_flag = '0'";
                                             $info=mysqli_query($conn,$query);
                                                $result_c=mysqli_num_rows($info);
                    
                                     
            ?>

                                <div class="col-md-6">
                                                  
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Subject</label>
                                                    <div class="col-md-9">
                   
                <select class="select2 form-control custom-select" name="select" id="subject_filter" required style="width: 100%; height:76px;"> 
                                    <option value="">None</option>
                                                           <?php
                                     
                                    while($row12 = mysqli_fetch_assoc($info))
                                   { ?>
                              <option value="<?php echo $row12['subject']?> "><?php echo $row12['subject']?></option> 

                                <?php
                                   }
                                   ?>
                                                        </select>
                                                       
                                                        </div>
                                                    </div>
                                                  </div>

                                        <div class="col-md-6">  
                                                <div class="form-group row ">
                                                    <label class="control-label text-right col-md-3">Date<span style="color:red">*</span></label>
                                               <div class="col-md-9">
                                                <input type="text" class="form-control" id="datepicker_f" required name="test_date" placeholder="mm/dd/yyyy">
                                                </div>
                                        </div>
                                        </div> 
                                     <div class="col-md-6">
                                                  
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3">Test Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                     
                                                          <select class="select2 form-control custom-select" id="select" style="width: 100%; height:76px;">
                                                     
                                                <option value="">None</option>
                                                          
                                                        </select>
                                                       
                                                        </div>
                                                    </div>
                                                  </div>
                               </div>
                             </div>
                           </div>

                  <div class="card">
                            <div class="card-body">
           
              
                                   <form name="form1" action="test_marks_code.php" method="POST">
                                <div class="table-responsive">
                                    <table class="table full-color-table full-info-table hover-table" id="test_table">
                                        <thead>
                                            <tr>
                                                <th>User Name</th>
                                                <th>Name</th>
                                                <th>test_name</th>
                                                <th>test_date</th>
                                                
                                                <th>Obtain Marks </th>
                                                 <th>Exam Marks</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                         
                                        </tbody>
                                    </table>

                                  <input type="hidden" name="batch_id" id="batch_id_put">
                                </div>
                                
                                <button type="submit" class="btn btn-success" >Submit</button>
                            </form>
                            </div>
                        </div>
                    </div>
                   
              
</div>
</div>

            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
             <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>


<script>
$(document).ready(function(){
    
    
    
    
    
 $("#batch_filter").change(function(){
      
    
    var batch_id = $('#batch_filter').val();

//   alert(batch_id);
    $('#batch_id_put').val(batch_id);

});

 // load_data();
 
 function load_data(batch_id,subject_name,test_date)
 {
  $.ajax({
   url:"exam_marks_code.php",
   method:"POST",
  
   data:{batch_id:batch_id,subject_name:subject_name,test_date:test_date},
    
   success : function(data)
   {
    // alert(data);
    // alert("ok");
    $('#select').html(data);
   }
  })
 }


 $("#datepicker-autoclose").change(function(){
  var subject_name = $('#subject_filter').val();
  var batch_id = $('#batch_filter').val();
var test_date = $('#datepicker-autoclose').val();

//   alert(batch_id);
    $('#batch_id_put').val(batch_id);
  load_data(batch_id,subject_name,test_date);
});
 
});
</script>

<script>
$(document).ready(function(){

 // load_data();
 
 function load_sub_data(batch_id,subject_name)
 {
  $.ajax({
   url:"exam_marks_code.php",
   method:"POST",
  
   data:{batch_id:batch_id,subject_name:subject_name},
    
   success : function(data)
   {
    // alert(data);
    // alert("ok");
    $('#select').html(data);
   }
  })
 }


 $("#subject_filter").change(function(){
  var subject_name = $('#subject_filter').val();
  var batch_id = $('#batch_filter').val();

  load_sub_data(batch_id,subject_name);
});
 
});
</script>

</script>

<script>
$(document).ready(function(){

 // load_data();
 
 function load_test_data(batch_id,test_id,subject_name)
 {
  $.ajax({
   url:"test_marks_code.php",
   method:"POST",
  
   data:{batch_id:batch_id,test_id:test_id,subject_name:subject_name},
    
   success : function(data)
   {
    // alert(data);
    // alert("ok");
    $('#test_table').html(data);
   }
  })
 }


 $("#select").change(function(){
  var test_id = $('#select').val();
  // alert(test_id);
  var batch_id = $('#batch_filter').val();
  var subject_name = $('#subject_filter').val();

  load_test_data(batch_id,test_id,subject_name);
});
 
});
</script>


</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>