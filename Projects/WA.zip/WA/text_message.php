<?php


                             
                        //     $numbers_1 = array(9967077027, 9967077027 );
                        //      $num_P = array_unique($numbers_1);
                             
                        // print_r($num_P);
                           	
                        //   	//  require('textlocal.class.php');
                           	 
                        //   	$Textlocal = new Textlocal(false, false, 'oCOwzFtQc/Q-o0r96SFhDkZZei7vdG1s0foS1vf3Xo');
 
                        //             //   	$numbers = array(9967077027 , 9967856357);
                        //               	$sender = 'TXTLCL';
                                       	
                        //               	if($checkbox == 'yes_sms_assignment')
                        //               	{
                                       	    
                        //              	$message = 'Assignment SMS';
                                     	
                                     	
                        //               	}
                        //               	else if($checkbox == 'yes_sms_student')
                        //               	{
                                       	    
                        //               	    	$message = 'Password = '.$password;
                                       	    
                        //               	}else if($checkbox == 'yes_sms_notice')
                        //               	{
                                       	    
                        //               	 echo   	$message = 'Notice SMS';
                                       	    
                        //               	}else if($checkbox == 'yes_sms_fees')
                        //               	{
                        //               	    	$message = 'Fees';
                                       	    
                        //               	}
                                       	
                        //         	$response = $Textlocal->sendSms($num_P, $message, $sender);
                                //  	print_r($response);
                                //   echo   $response['balance'];
                                // echo     $response['num_messages'];
                                    
                                    // 	header('Location:notice.php');
?>
        