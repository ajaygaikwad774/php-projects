 <?php $Current_year = date('Y'); ?>
            <!-- ============================================================== -->
            <footer class="footer"> © <?php echo $Current_year; ?>  Developed by Appdid  </footer>