<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>
<?php include('navbar.php'); ?>
 <?php include('connection.php'); ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Notice</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Notice</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">


                 <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 


                      <form name="" action="notice_code.php" method="POST">
                           <div class="row"> 
                           <div class="col-md-3">
                           </div> 
                           <div class="col-md-6">

                                        <h5 class="">Select Batch</h5>
                                        
                                      
                                        <select class="select2 form-control custom-select" id="batch_filter" name="batch_id" style="width: 100%; height:76px;">
                                            <option value="All">All</option>
                                             <?php 

                                           $batch = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             $batch_data=mysqli_query($conn,$batch);
                                                $result_d=mysqli_num_rows($batch_data);
                                               
                                                    while($fetch_batch = mysqli_fetch_assoc($batch_data))
                                                    {  
                                           ?>     
                                            <option value="<?php echo $fetch_batch['batch_id']; ?>"><?php echo $fetch_batch['batch_name']; ?></option>
                                           <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                           </div> 
                                   
                                    </div>
                              
                              <div class="row"> 
                           <div class="col-md-3">
                           </div> 
                               <div class="col-md-6">
                                                  
                                <h5 class="m-t-30 m-b-10">Students</h5>
                                         
                                                     
                                    <select class="select2 form-control custom-select" id="student_s" name="user_id" style="width: 100%; height:76px;">
                                                     
                                                <option value="">None</option>
                                                          
                                                        </select>
                                                       
                                                        <!-- </div> -->
                                                    <!-- </div> -->
                                                  </div>
                                                  <div class="col-md-2">
                           </div> 
                                                </div>
                              <div class="row"> 
                           <div class="col-md-3">
                           </div> 
                               <div class="col-md-6">
                                        <h5 class="m-t-30 m-b-10">Notice Name</h5>
                                         
                                            <input type="text" class="form-control"  required name="notice_name" >
                                         </div>

                                      <div class="col-md-2">
                           </div> 
                                 </div>

                                <div class="row"> 
                           <div class="col-md-3">
                           </div> 
                               <div class="col-md-6">
                                        <h5 class="m-t-30 m-b-10">Content</h5>
                                         
                                        
                                    <textarea rows="7" style="width: 100%;" name='notice_content'></textarea>
                                       
                                     </div>
                                      <div class="col-md-2">
                           </div> 
                                 </div>
                                  <div class="row"> 
                           <div class="col-md-3">
                           </div> 
                                 
                                  <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Do you want to send sms? <span style="color:red">*</span>
                                                    <input type="checkbox"  name="check-box" value="yes_sms_notice" >
                                                    </label>
                                                    
                                            
                                                    
                                                </div>
                                              </div>
                                              </div>
                                 <br>
                                  <div class="row"> 
                           <div class="col-md-4">
                           </div> 
                               <div class="col-md-4">

                            <button class="btn btn-info btn-md  text-uppercase waves-effect waves-light" name="submit" type="submit">Submit</button>
                        </div> 
                          
                          </div>

                          </form>

                           
    
     
            </div>
        </div>
    </div>
                     <div class="card-group">
                    <div class="card">
                        <div class="card-body"> 
                   <form name="form1" action="test_marks_code.php" method="POST">
                                <div class="table-responsive">
                                    <table class="table full-color-table full-info-table hover-table" id="notice_table">
                                       
                                        
                                    </table>

                                  <input type="hidden" name="batch_id" id="batch_id_put">
                                </div>
                               
                            </form>


                             
            </div>
        </div>
    </div>
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
             <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>
    
   
     

       <script type="text/javascript">

$(document).ready(function(){
 function unique_id(batch_id)
 {
     $.ajax({
   url:"notice_code.php",
   method:"POST",
   data:{batch_id:batch_id},
   success:function(data)
   {
    // alert(data);
    $('#student_s').html(data);
   }
  })

 }


 $("#batch_filter").change(function(){
  var batch_id = $('#batch_filter').val();
   // alert(batch_id);
  if(batch_id == 'None')
  {
      $('#student_s').val(" ");
  }
  else
  {
    unique_id(batch_id);

  }
 
});
});

</script>

<script>
$(document).ready(function(){

  load_test_data();
 
 function load_test_data(batch_id='')
 {
  $.ajax({
   url:"notice_load_code.php",
   method:"POST",
  
   data:{batch_id:batch_id},
    
   success : function(data)
   {
    // alert(data);
    // alert("ok");
    $('#notice_table').html(data);
   }
  })
 }

 $(document).on('click', '#delete_notice', function(e){

            var data;           
            var notice_id = $(this).data('id');
            //var productId = $(this).data('id');
            SwalDelete(notice_id);
            e.preventDefault();
        });

   function SwalDelete(notice_id){
        
        swal({
            title: 'Are you sure?',
            text: "It will be deleted permanently!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            showLoaderOnConfirm: true,
              
            preConfirm: function() {
              return new Promise(function(resolve) {
                   
                 $.ajax({
                    url: 'delete_notice.php',
                    type: 'POST',
                    data: {notice_id:notice_id},
                    dataType: 'json'
                 })
                 .done(function(response){
                    swal('Deleted!', response.message, response.status);
                    load_test_data();
                 })
                 .fail(function(){
                    swal('Oops...', 'Something went wrong with ajax !', 'error');
                    
                 });
              });
            },
            allowOutsideClick: false              
        }); 
        
    }
 });   
</script>

 
});
</script>



</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>