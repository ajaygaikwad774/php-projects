
<?php

//fetch.php

include('connection.php');

$column = array('fh_user.batch_name' ,'fh_test.test_name', 'fh_test.subject' ,'fh_test.chapter', 'fh_test.test_date', 'fh_user.from_time');


 $today_date = date('Y-m-d');
$days_ago = date('Y-m-d', strtotime('-5 days',strtotime($today_date)));

$query = "SELECT DISTINCT(fh_test.test_id) as test_id , fh_test.batch_id, fh_test.test_name, fh_test.subject, fh_test.chapter, fh_test.marks, fh_test.test_date, fh_test.from_time, fh_test.to_time,fh_user.batch_name , fh_test.disable_flag FROM `fh_test` INNER JOIN `fh_user` ON fh_test.batch_id =fh_user.batch_id  ";
// AND fh_test.added_date > '$days_ago'
// echo $_POST['search']['value'];
// echo  $_POST ['search'] ['value'];
// print_r($_POST['order']);
if(isset($_POST['search']['value']) )
{

 $query .= '
 WHERE fh_user.batch_name LIKE "%'.$_POST['search']['value'].'%"  
 OR fh_test.test_name LIKE "%'.$_POST['search']['value'].'%" 
 OR fh_test.subject LIKE "%'.$_POST['search']['value'].'%" 
 OR fh_test.chapter LIKE "%'.$_POST['search']['value'].'%" 
 OR fh_test.test_date LIKE "%'.$_POST['search']['value'].'%" 
 OR fh_test.from_time LIKE "%'.$_POST['search']['value'].'%" 
 
 ';
}

 $query .= 'AND fh_test.disable_flag ="0"';
if(isset($_POST['order']))
{
//  $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
// }
// else
// {
  $query .= 'ORDER BY test_id DESC ';
}

$query1 = '';

if($_POST['length'] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

 // echo $query;
$statement=mysqli_query($conn,$query);
// $statement = $conn->prepare($query);

 // $statement->execute();
                             
 // echo $number_filter_row = $statement->num_rows();
 $number_filter_row = mysqli_num_rows($statement);

$statement=mysqli_query($conn,$query . $query1);
 // $statement = $conn->prepare($query . $query1);

// $statement->execute();

// $result = $statement->fetchAll();


$data = array();

while($fetch=mysqli_fetch_assoc($statement))
{
 $sub_array = array();
 if ($fetch["disable_flag"] == '0') 
 {
 $sub_array[] =$fetch["batch_name"];
$sub_array[] =$fetch["test_name"];
$sub_array[] =$fetch["subject"]; 
$sub_array[] =$fetch["chapter"]; 
$sub_array[] =$fetch["marks"];
$sub_array[] =$fetch["test_date"];
$sub_array[] =$fetch["from_time"].' To '.$fetch["to_time"];
$sub_array[] ='<a id="delete_exam" data-id="'.$fetch["test_id"].'" href="javascript:void(0)"><i class="mdi mdi-delete"></i></a>';

 $data[] = $sub_array;
}
}

function count_all_data($conn)
{
 $query = "SELECT * FROM fh_test";
 $statement=mysqli_query($conn,$query);
  return mysqli_num_rows($statement);
}

$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($conn),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);

echo json_encode($output);

?>
