<?php 
include('connection.php');
 if(isset($_POST['batch_data']))
 {


  $batch_name=mysqli_real_escape_string($conn,$_POST["batch_name"]);
  $batch_time=mysqli_real_escape_string($conn,$_POST["batch_time"]);
    
   $query12 = "INSERT INTO `fh_batch` ( `batch_name`, `batch_time`) VALUES ('$batch_name' , '$batch_time')";
    $info12=mysqli_query($conn,$query12);
   if($info12)
   {
       header('Location:add_batch.php');
   }else
   {

   }


 }
 else if (isset($_POST['subject_data']))
 {

 	 $subject_name=mysqli_real_escape_string($conn,$_POST["subject_name"]);
  $subject_fees=mysqli_real_escape_string($conn,$_POST["subject_fees"]);
    
   $query12 = "INSERT INTO `fh_subject`(`subject_name`, `subject_fees`) VALUES ('$subject_name','$subject_fees')";
    $info12=mysqli_query($conn,$query12);
   if($info12)
   {
       header('Location:add_subject.php');
   }else
   {

   }

 }
 else if (isset($_POST['course_data']))
 {
    
 	 $course_name=mysqli_real_escape_string($conn,$_POST["course_name"]);
 // echo  $subject=mysqli_real_escape_string($conn,$_POST["subject"]);


  $sum =0;

  


  foreach ($_POST["subject"] as $id) {
  	
   // echo $id.'-' ;
  $query = "SELECT `subject_id`, `subject_name`, `subject_fees`, `disable_flag` FROM `fh_subject` WHERE subject_id = '$id'";
  $info=mysqli_query($conn,$query);
  $fetch=mysqli_fetch_assoc($info);  
           $fetch['subject_fees'];
              $sum = $sum + $fetch['subject_fees'];   

                     $get_sub[] = $fetch["subject_name"];
  }

              $subjects_g = implode(" , " , $get_sub);             


  // echo $sum;
  $today_date =  date("Y-m-d H:i:s");
    
   $query12 = "INSERT INTO `fh_course`(`course_name`, `subjects`, `total_fees`, `added_date`) VALUES ('$course_name','$subjects_g' , '$sum' , '$today_date')";
    $info12=mysqli_query($conn,$query12);
   if($info12)
   {
        header('Location:add_course.php');
   }else
   {

   }

 }
?>