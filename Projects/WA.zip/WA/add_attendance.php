<?php 

session_start();
if (isset($_SESSION["admin_id"]) && isset($_SESSION["admin_name"]) && $_SESSION["role"] == 'admin' && $_SESSION['logged_in'] == 'login' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
      include('header.php'); ?>
      <?php include('navbar.php'); ?>
<?php include('connection.php'); ?>

<style type="text/css">
    [type=radio]:checked, [type=radio]:not(:checked) {
     position: static !important;
    /*left: -9999px;*/
     opacity: 1 !important; 
}
</style>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">Attendance</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Attendance</li>
                    </ol>
                </div>
               
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
              <?php
            $query12 = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                    $info12=mysqli_query($conn,$query12);
                     $result_c=mysqli_num_rows($info12);



                                             //      $query12 = "SELECT `batch_id`, `batch_name`, `batch_time`, `disable_flag` FROM `fh_batch` WHERE disable_flag='0'";
                                             // $info12=mysqli_query($conn,$query12);
                                             //    $result_c=mysqli_num_rows($info12);
                                                

               ?>
                

                           
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">Attendace Mark</h4>
                                <div class="row">
                                 <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Batch Name <span style="color:red">*</span></label>
                                                   

                                   
                                    

                               <select class="select2 form-control custom-select" name="select" id="multi_search_filter" style="width: 100%; height:76px;"> 
                                    <option value="">None</option>
                                   <?php
                                    
                                    while($row = mysqli_fetch_assoc($info12))
                                   {
                                    echo '<option value="'.$row["batch_id"].'">'.$row["batch_name"].'</option>'; 
                                   }
                                   ?>
                                   </select>
                                
                               </div>
                             </div>

                                 <div class="col-md-6">
                                                   <div class="form-group ">
                                                    <label class="control-label text-right ">Date<span style="color:red">*</span></label>
                                     <div class="input-group">
                                                <input type="text" class="form-control datepicker-autoclose" id="datepicker_f" required name="s_date" placeholder="YYYY-MM-DD">
                                                <span class="input-group-addon"><i class="icon-calender"></i></span> </div>
                               </div>
                             </div>
                              
                           
                                 <br>
                                  <div class="col-md-12">
                                 <div align="center " > 
                                 
                     <input type="text" name="search" id="search" class="form-control" placeholder="Search UserName , Batch , Mobile Number  " />
                     </div>  
                </div>
              </div>
            </div>
          </div>
        </div>
                 

          <div class="card">
                            <div class="card-body">


                                   <form name="form1" action="attendance_mark.php" method="POST">
                                <div class="table-responsive">
                                    <table class="table full-color-table full-info-table hover-table" id="student_table">
                                        <thead>
                                            <tr>
                                                <th>Roll No</th>
                                                <th>Name</th>
                                                <th>Batch</th>
                                                <th>Mobile No</th>
                                                <th>Parent No</th>
                                                <th>Subject</th>
                                                <th>Due Fees</th>
                                               
                                                 <th>Present<br><input type="radio" name="group4" value="0" onclick="selectAll(form1)"></th>
                                                  <th>Absent <br><input type="radio" name="group4" value="1" onclick="selectAll(form1)"></th>
                                                   <th>Holiday <br><input type="radio" name="group4" value="2" onclick="selectAll(form1)"></th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                         
                                        </tbody>
                                    </table>

                                  <input type="hidden" name="batch_id" id="batch_id_put">
                                   <input type="hidden" name="s_date" id="s_date_put">
                                </div>
                                <button type="submit">Submit</button>
                            </form>
                            </div>
                        </div>
                    </div>
                   
              
</div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
                   <!-- footer -->
             <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>

<script type="text/javascript">
  
      $(document).ready(function(){  
           $('#search').keyup(function(){  
                search_table($(this).val());  
           });  
           function search_table(value){  
                $('#student_table tr').each(function(){  
                     var found = 'false';  
                     $(this).each(function(){  
                          if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0)  
                          {  
                               found = 'true';  
                          }  
                     });  
                     if(found == 'true')  
                     {  
                          $(this).show();  
                     }  
                     else  
                     {  
                          $(this).hide();  
                     }  
                });  
           }  
           
           
      });  


</script>




<script type="text/javascript" language="javascript" >

$(document).ready(function(){

 
 function load_data(query,choose_date='')
 {
  $.ajax({
   url:"attendance_code.php",
   method:"POST",
   data:{query:query,choose_date:choose_date},
   success:function(data)
   {
    $('#student_table').html(data);
   }
  })
 }

// $("#multi_search_filter").change(function(){
//   var query = $('#multi_search_filter').val();
//  var choose_date = $('#datepicker_f').val();
//   $('#batch_id_put').val(query);
//     $('#s_date_put').val(choose_date);
//   load_data(query,choose_date);
// });

 $("#datepicker_f").change(function(){
  var query = $('#multi_search_filter').val();
  var choose_date = $('#datepicker_f').val();
  // alert(query);
   $('#batch_id_put').val(query);
     $('#s_date_put').val(choose_date);
  load_data(query,choose_date);
});
 
});
</script>
<script type="text/javascript">
       function selectAll(form1) {
  
  var check = document.getElementsByName("group4"),
        radios = document.form1.elements;
      
        
        
  //If the first radio is checked
    if (check[0].checked) {
  
        for( i = 0; i < radios.length; i++ ) {
            
      //And the elements are radios
            if( radios[i].type == "radio" ) {
        
        //And the radio elements's value are 1
                if (radios[i].value == 0 ) {
          //Check all radio elements with value = 1
                    radios[i].checked = true;
                }
        
            }//if
      
        }//for
    
  //If the second radio is checked
    } else  if (check[1].checked) {
    
        for( i = 0; i < radios.length; i++ ) {
            
      //And the elements are radios
            if( radios[i].type == "radio" ) {
        
        //And the radio elements's value are 0
                if (radios[i].value == 1  ) {
  
          //Check all radio elements with value = 0
                    radios[i].checked = true;
  
                }
        
            }//if
      
        }//for
    
    }else  if (check[2].checked) {
    
        for( i = 0; i < radios.length; i++ ) {
            
      //And the elements are radios
            if( radios[i].type == "radio" ) {
        
        //And the radio elements's value are 0
                if (radios[i].value == 2 ) {
  
          //Check all radio elements with value = 0
                    radios[i].checked = true;
  
                }
        
            }//if
      
        }//for
    
    };//if//if
  return null;
}
    
</script>

<script type="text/javascript">
  
</script>


</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>