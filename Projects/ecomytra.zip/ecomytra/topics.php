<?php
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 30px;">
			<center>
				<h1 class="title">Blogs</h1>
				<img src="images/underline.png" style="width:300px;">
			</center>
				<br><br>
			<?php
				$cat2="select *from category where not TITLE='No Category'";
				$catres2=mysqli_query($conn, $cat2);
				if(mysqli_num_rows($catres2)==0){
			?>
				<center><h3>No Articles Available</h3></center>
			<?php					
				}
				while($catrow2=mysqli_fetch_array($catres2)){
			?>
			<a href="blog?topic=<?php echo $catrow2['ID'];?>">
				  <div class="col-sm-6 text-center" style="padding: 10px;">
					<div style="background-color: #f0f0f0; padding: 10px; min-height:300px; padding-top:80px;">
				  	<img src="<?php echo $siteurl.$catrow2['IMAGE']; ?>" style="width: 100px; margin: auto; float: none;" class="img-responsive">
				  	<h3><?php echo $catrow2['TITLE']; ?></h3>
				  </div>
				</div>
			</a>
			<?php
				}
			?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>