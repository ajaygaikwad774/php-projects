<?php 
	include 'components/header.php';
	$promo="select *from promobanner";
	$promores=mysqli_query($conn, $promo);	
	$promobanner=array();
	$counter=0;
	$promobanner[0]['TITLE']="";
	$promobanner[0]['DEFAULTIMAGE']="";
	$promobanner[0]['IMAGE']="";
	$promobanner[0]['LINK']="";
	$promobanner[1]['TITLE']="";
	$promobanner[1]['DEFAULTIMAGE']="";
	$promobanner[1]['IMAGE']="";
	$promobanner[1]['LINK']="";
	$promobanner[2]['TITLE']="";
	$promobanner[2]['DEFAULTIMAGE']="";
	$promobanner[2]['IMAGE']="";
	$promobanner[2]['LINK']="";

	while($promorow=mysqli_fetch_array($promores)){
		$promobanner[$counter]['TITLE']=$promorow['TITLE'];
		$promobanner[$counter]['DEFAULTIMAGE']=$promorow['DEFAULTIMAGE'];
		$promobanner[$counter]['IMAGE']=$promorow['IMAGE'];
		$promobanner[$counter]['LINK']=$promorow['LINK'];
		$counter++;
	}
?>
<main>
	<div class="front-page-banner">

	<div id="myCarousel" class="carousel slide" data-ride="carousel">
		  <!-- Indicators 
		  <ol class="carousel-indicators">
		    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		    <li data-target="#myCarousel" data-slide-to="1"></li>
		  </ol>-->
		  <!-- Wrapper for slides -->
		  <div class="carousel-inner">
		  	<?php
		  		$sliderquery="select *from frontpageslider";
		  		$sliderres=mysqli_query($conn, $sliderquery);
		  		$counter=0;
		  		while($sliderrow=mysqli_fetch_array($sliderres)){
		  	?>
		    <div class="item <?php if($counter==0){ echo "active"; } ?>">
		      <img src="<?php echo $sliderrow['IMAGE']; ?>">
		      <div class="carousel-caption">
		      	<?php 
		      		if($sliderrow['CONTENTALIGNMENT']=="Left"){
				       	echo "<div class='align-left'>";
		      		}elseif($sliderrow['CONTENTALIGNMENT']=="Right"){
				       	echo "<div class='align-right'>";
		      		}elseif($sliderrow['CONTENTALIGNMENT']=="Center"){
				       	echo "<div class='align-center'>";
		      		}
		      		echo $sliderrow['CONTENT'];
		      	?>
			    </div>
		      </div>
		    </div>

		  	<?php
		  		$counter++;
	  		}
		  	?>
		  </div>

		  <!-- Left and right controls -->
		  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left"></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#myCarousel" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right"></span>
		    <span class="sr-only">Next</span>
		  </a>
		</div>
	
	</div>

	<div class="clearfix"></div>

	<div class="container-fluid" style="padding-top: 50px;">
		<div class="col-sm-6">
			<h1 class="title">About Organic Products</h1><br><br>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</div>
	<?php /*	
		<center>
			<h1 class="title">Featured Products</h1>
			<img src="images/underline.png" style="width:300px;">
			<h4 class="subtitle">Lorem ipsum dolor sit amet</h4>
		</center><br><br>
		<?php 
			$featured="select *from product where ISENABLED='true' and IS_FEATURED='yes' order by ID desc";
			$featuredres=mysqli_query($conn, $featured);
			$featuredproduct=array();
			$counter=0;

			for($i=0; $i<5; $i++){
				$featuredproduct[$i]['ID']="";
				$featuredproduct[$i]['TITLE']="";
				$featuredproduct[$i]['IMAGE']="";
				$featuredproduct[$i]['PRICE']="";
				$featuredproduct[$i]['DPRICE']="";
			}
			while($featuredrow=mysqli_fetch_array($featuredres)){
				$featuredproduct[$counter]['ID']=$featuredrow['ID'];
				$featuredproduct[$counter]['TITLE']=$featuredrow['TITLE'];
				$featuredproduct[$counter]['IMAGE']=$featuredrow['IMAGE'];
				$featuredproduct[$counter]['PRICE']=$featuredrow['PRICE'];
				$featuredproduct[$counter]['DPRICE']=$featuredrow['DISCOUNTPRICE'];
				$counter++;
			}
		?>
		<div class="clearfix"></div>
		<div class="col-sm-6">
			<div class="col-sm-6">
				<a href="product-detail?product=<?php echo $featuredproduct[0]['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$featuredproduct[0]['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $featuredproduct[0]['TITLE']; ?>
							</td>
							<?php
								if(trim($featuredproduct[0]['DPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $featuredproduct[0]['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $featuredproduct[0]['DPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $featuredproduct[0]['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
			</div>
			<div class="col-sm-6">
				<a href="product-detail?product=<?php echo $featuredproduct[1]['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$featuredproduct[1]['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $featuredproduct[1]['TITLE']; ?>
							</td>
							<?php
								if(trim($featuredproduct[1]['DPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $featuredproduct[1]['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $featuredproduct[1]['DPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $featuredproduct[1]['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
			</div>
		</div> */ ?>
		<div class="col-sm-6" style="padding: 10px;">
			<a href="<?php if($promobanner[0]['LINK']!=""){ echo $promobanner[0]['LINK']; }else{ echo "#"; } ?>">
			<div class="small-banner" style="cursor:pointer; background-image: url('<?php if(trim($promobanner[0]['IMAGE'])!=""){
					echo $siteurl.$promobanner[0]['IMAGE'];
			}else{				
					echo $siteurl.$promobanner[0]['DEFAULTIMAGE'];
			}

			 ?>');">
			</div>
			</a>
		</div>
	</div>
	<div class="container-fluid">
		<div class="col-sm-6" style="padding: 10px;">
			<a href="<?php if($promobanner[1]['LINK']!=""){ echo $promobanner[1]['LINK']; }else{ echo "#"; } ?>">
			<div class="small-banner" style="cursor:pointer; background-image: url('<?php if(trim($promobanner[1]['IMAGE'])!=""){
					echo $siteurl.$promobanner[1]['IMAGE'];
			}else{				
					echo $siteurl.$promobanner[1]['DEFAULTIMAGE'];
			}

			 ?>');">
			</div>
			</a>
		</div>
		<div class="col-sm-6" style="padding: 10px;">
			<h1 class="title">About Ecomytra</h1><br><br>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</div>
		<?php /*
		<div class="col-sm-6">
			<div class="col-sm-6">
				<a href="product-detail?product=<?php echo $featuredproduct[2]['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$featuredproduct[2]['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $featuredproduct[2]['TITLE']; ?>
							</td>
							<?php
								if(trim($featuredproduct[2]['DPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $featuredproduct[2]['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $featuredproduct[2]['DPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $featuredproduct[2]['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
			</div> 
			<div class="col-sm-6">
				<a href="product-detail?product=<?php echo $featuredproduct[3]['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$featuredproduct[3]['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $featuredproduct[3]['TITLE']; ?>
							</td>
							<?php
								if(trim($featuredproduct[3]['DPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $featuredproduct[3]['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $featuredproduct[3]['DPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $featuredproduct[3]['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
			</div>
		</div> */ ?>
	</div>

	<div class="clearfix"></div>

	<div style="background-color: #efefef; padding-top: 50px; padding-bottom: 50px; margin-top: 70px;">
		<div class="container-fluid">
			<center>
				<h1 class="title">Product of the Month </h1>
				<img src="images/underline.png" style="width:300px;">
			</center>
				<br><br>	
				<?php 
					$deal="select *from dealoftheday";
					$dealres=mysqli_query($conn, $deal);
					$dealrow=mysqli_fetch_array($dealres);
				?>
			<div class="col-sm-6">
				<div style="background-color: #fff; padding: 20px; margin-bottom: 50px;">
					<?php
						echo $dealrow['CONTENT'];
					?>
					<br>
					<a href="<?php echo $dealrow['LINK']; ?>">
						<button class="btn btn-default"><?php echo $dealrow['BTNTEXT']; ?></button>
					</a>
				</div>
			</div>
			<div class="col-sm-6">
				<center>
					<img src="<?php if(trim($dealrow['IMAGE'])!=""){ echo $siteurl.$dealrow['IMAGE']; } ?>" class="img-responsive">
				</center>
			</div>
		</div>
	</div>

	<div class="clearfix"></div>

	<div class="container-fluid" style="margin-top: 50px;">
		<center>
			<h1 class="title">Our Bestsellers</h1>
			<img src="images/underline.png" style="width:300px;">
			<h4 class="subtitle">Lorem Ipsum Dolor Sit Amet</h4>
		</center>
		<br>
		<br>
		<?php
			$trending="select *from product where ISENABLED='true' and IS_TRENDING='yes' order by ID desc";
			$trendingres=mysqli_query($conn, $trending);
			if(mysqli_num_rows($trendingres)==0){
		?>
		<center><h3>No Products Available</h3></center>
		<?php
			}
			while($trendingrow=mysqli_fetch_array($trendingres)){
		?>
		<div class="col-sm-3" style="padding-bottom: 20px;">
			<a href="product-detail?product=<?php echo $trendingrow['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$trendingrow['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $trendingrow['TITLE']; ?>
							</td>
							<?php
								if(trim($trendingrow['DISCOUNTPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $trendingrow['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $trendingrow['DISCOUNTPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $trendingrow['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
		</div>
		<?php
			}
		?>
	</div>

		<?php
			if($promobanner[2]['IMAGE']!=""){
		?>

	<div class="clearfix" style="margin-bottom: 80px;"></div>

	<a href="<?php if($promobanner[2]['LINK']!=""){ echo $promobanner[2]['LINK']; }else{ echo "#"; } ?>">
		<div class="full-width-banner" style="background-image: url('<?php if(trim($promobanner[2]['IMAGE'])!=""){
					echo $siteurl.$promobanner[2]['IMAGE'];
			}else{				
					echo $siteurl.$promobanner[2]['DEFAULTIMAGE'];
			}

			 ?>');">
		</div>
	</a>
	<?php
		}
	?>
	<?php
		$testimonials="select *from testimonial";
		$tquery=mysqli_query($conn, $testimonials);
		if(mysqli_num_rows($tquery)!=0){

	?>
	<div class="clearfix" style="margin-bottom: 80px;"></div>
		<center>
			<h1 class="title">What People Say About Our Products?</h1>
			<img src="images/underline.png" style="width:300px;">			
			<h4 class="subtitle">Lorem ipsum dolor sit</h4>
		</center>


	<div class="testimonials">
	<?php
		$n=mysqli_num_rows($tquery);
	?>
		<div class="col-md-8 col-center m-auto">
			<div id="testimonialCarousel" style="overflow-x: hidden;" class="carousel slide" data-ride="carousel">
				<!-- Carousel indicators -->
				<ol class="carousel-indicators">
					<?php
						for($i=0; $i<$n; $i++){
					?>
					<li data-target="#testimonialCarousel" data-slide-to="<?php echo $i; ?>" <?php if($i==0){ ?> class="active" <?php } ?>></li>
					<?php
						}
					?>
				</ol>   
				<!-- Wrapper for carousel items -->
				<div class="carousel-inner">
					<?php
						$counter=0;
						while($trow=mysqli_fetch_array($tquery)){
					?>
						<div class="item carousel-item <?php if($counter==0){ echo "active";} ?>">
							<div class="img-box"><img src="<?php echo $trow['PIC']; ?>"></div>
							<p class="testimonial"><?php echo $trow['COMMENT']; ?></p>
							<p class="overview"><b><?php echo $trow['AUTHOR']; ?></b></p>
						</div>
					<?php
							$counter++;
						}
					?>
				</div>
				<!-- Carousel controls -->
				<a class="carousel-control left carousel-control-prev" href="#testimonialCarousel" data-slide="prev">
					<i class="fa fa-angle-left"></i>
				</a>
				<a class="carousel-control right carousel-control-next" href="#testimonialCarousel" data-slide="next">
					<i class="fa fa-angle-right"></i>
				</a>
			</div>
		</div>
	</div>
	<?php

	}	
	?>
	<div class="clearfix"></div>

	<div class="container-fluid front-page-blog">
		<center>
			<h1 class="title">Latest Articles</h1>
			<img src="images/underline.png" style="width:300px;">			
			<h4 class="subtitle">Lorem ipsum dolor sit</h4>
		</center>
		<br><br>
		<?php
			$articles="select *from article where ISENABLED='true' order by ID desc limit 3";
			$articleres=mysqli_query($conn, $articles);
			if(mysqli_num_rows($articleres)==0){
		?>
		<center><h3>No Articles Available</h3></center>
		<?php
			}
			while($articlerow=mysqli_fetch_array($articleres)){
		?>
		<div class="col-sm-4">
			<div class="image" style="background-image: url('<?php echo $siteurl.$articlerow['PHOTO']; ?>');">
			</div>
			<h4><?php echo $articlerow['TITLE']; ?></h4>
			<div class="blog-body">
				<?php
					echo substr($articlerow['CONTENT'], 0, 200).".... ";
				?>
			</div>
			<button class="btn btn-default" onclick="location.assign('article?post=<?php echo $articlerow['ID']; ?>')">Read More</button>
		</div>

		<?php
			}
		?>
	</div>
</main>
<?php include 'components/footer.php'; ?>