<?php
	$siteurl="https://www.amraenterprises.com//ecomytra/";
	$hostname="localhost";
	$dbname="ecomytra";
	$dbuser="ajaysharma";
	$dbpassword="ajaysharma";
	$conn=mysqli_connect($hostname, $dbuser, $dbpassword, $dbname);

		function generateNumericOTP() {
			$generator = "1357902468";	
			$result = "";
		    for ($i = 1; $i <= 6; $i++) { 
		        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
		    } 		
		    return $result;	
		}


	$pg=1;
	if(isset($_GET['pg']) && is_numeric($_GET['pg'])){
		$pg=$_GET['pg'];
	}	
?>