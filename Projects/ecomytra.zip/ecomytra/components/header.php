<?php
	require 'components/connection.php';
	include 'cartlib.php';
	$contactinfoquery="select *from contact";
	$contactinfores=mysqli_query($conn, $contactinfoquery);
	$contactinforow=mysqli_fetch_array($contactinfores);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ecomytra</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>


	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">	
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" href="images/ecomytra.ico">
	<meta name="theme-color" content="#a5ce3a"/>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>


	<script type="text/javascript">
		function rateThisProduct(obj){
			var rate=parseInt(obj.getAttribute("data-rate"));
			var product=parseInt(obj.getAttribute("data-product"));
			var xhttp=new XMLHttpRequest();
			xhttp.onreadystatechange=function(){
	          if(xhttp.readyState==4 && xhttp.status==200){
	          	if(xhttp.responseText=="success"){
	          		document.getElementById("ratingresponse").innerHTML="Submitted!!!";
	          		var editablerating=document.getElementById("editablerating");
	          		var stars=editablerating.children;
	          		for(var i=0; i<stars.length; i++){
	          			stars[i].className="fa fa-star";
	          		}
	          		for(var i=0; i<rate; i++){
	          			stars[i].className="fa fa-star rated";
	          		}
	          	}
	          }
			};
			xhttp.open("GET", "httppages/updateproductrating.php?product="+product+"&rate="+rate, true);
			xhttp.send();		
		}

		function addToCartAsync(obj){
			var productid=parseInt(obj.getAttribute("data-product"));
			var qty=parseInt(document.getElementById("itemcount").value);
			if(qty>=1){
				var xhttp=new XMLHttpRequest();
				xhttp.onreadystatechange=function(){
		          if(xhttp.readyState==4 && xhttp.status==200){
		          	if(xhttp.responseText=="success"){
							var xhttp2=new XMLHttpRequest();
							xhttp2.onreadystatechange=function(){
					          if(xhttp2.readyState==4 && xhttp2.status==200){
							    document.getElementById("cartitemcount").innerHTML=xhttp2.responseText;
							    $('#cartModal').modal();
					          }
							};
							xhttp2.open("GET", "httppages/getcartitemscount.php?", true);
							xhttp2.send();					
		          	}
		          }
				};
				xhttp.open("GET", "httppages/addtocart.php?product="+productid+"&qty="+qty, true);
				xhttp.send();					
			}else{
				alert("Quantity must be greater than zero");
			}
		}
	</script>
    <style>
    .navbar-nav>li>a{
        font-size:14px !important;
    }
        
    </style>

</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top navbar-large-screen" role="navigation">
<?php /*	<div class="container-fluid" style="padding-top: 7px; background-color: #a5ce3a; padding-bottom: 7px;">
		<div class="col-sm-6" style="padding-top: px;">
			<strong><span style="font-size: 18px;" class="fa fa-phone"></span> &nbsp; <a href="tel: <?php echo $contactinforow['PHONE1']; ?>"><?php echo $contactinforow['PHONE1']; ?></a></strong></div>
			<div class="col-sm-6 text-right">
				<?php 
					if(isset($_COOKIE['usertype'])){
				?>
				<span class="glyphicon glyphicon-user" style="font-size: 18px;"></span> <a href="logout">Log Out</a>
				<?php						
						if($_COOKIE['usertype']=="user"){
							$isuserenabled="select *from user where ID=".$_COOKIE['user']." and ISENABLED='true'";
							$isuserenabledres=mysqli_query($conn, $isuserenabled);
							if(mysqli_num_rows($isuserenabledres)==0){
								echo "<script>location.assign('logout');</script>";
							}
				?>
					&nbsp; | &nbsp; <a href="update-profile">My Profile</a>
					&nbsp; | &nbsp; <a href="order-history">My Orders</a>
				<?php
						}
					}else{
				?>
				<span class="glyphicon glyphicon-user" style="font-size: 18px;"></span> <a href="login">Log In</a>&nbsp; |&nbsp; <a href="signup">Sign Up</a>
				<?php 
					}
				?>
			</div>
	</div> */ ?>
   	<div class="container-fluid">
		<div class="navbar-header">
			<div class="navbar-brand" style="  transform: translateX(-50%); left: 50%; position: absolute;">
				<a href="./">
		    		<img src="images/ecomytra.png" style="width:170px !important; margin-top:-10px;">	
		    	</a>
		    </div>
	    </div>
		<ul class="nav navbar-nav">
			<li><a href="./">Home</a></li>
			<li><a href="./categories">Store</a></li>
			<li><a href="./about">About Us</a></li>
			<li><a href="./media">Media</a></li>
			<?php
				if(isset($_COOKIE['usertype'])){
					if($_COOKIE['usertype']=="user"){
			?>
			<li><a href="./contact">Contact Us</a></li>
			<?php 
					}
				}
			?>
		</ul>
		<ul class="nav navbar-nav navbar-right">
<?php /*			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">Product Categories <span class="caret"></span>
				<ul class="dropdown-menu">
					<?php
						$cat="select *from product_category";
						$catres=mysqli_query($conn, $cat);
						while ($catrow=mysqli_fetch_array($catres)) {
							if($catrow['TITLE']=="No Category"){
								continue;
							}
					?>
	          			<li><a href="products?cat=<?php echo $catrow['ID']; ?>"><?php echo $catrow['TITLE']; ?></a></li>
					<?php
						}
					?>
		        </ul>
				</a>
			</li> */ ?>
			<?php
				if(!isset($_COOKIE['usertype'])){
					if(!$_COOKIE['usertype']=="user"){
			?>
			<li><a href="./contact">Contact Us</a></li>
			<?php 
					}
				}
			?>
			<li><a href="./checkout" style="background-color: #f0f0f0;"><i class="glyphicon glyphicon-shopping-cart"></i> Cart (<span id="cartitemcount"><?php echo getCartItemsCount(); ?></span> items)</a></li>
			<?php 
				if(isset($_COOKIE['usertype'])){
					if($_COOKIE['usertype']=="user"){
						$isuserenabled="select *from user where ID=".$_COOKIE['user']." and ISENABLED='true'";
						$isuserenabledres=mysqli_query($conn, $isuserenabled);
						if(mysqli_num_rows($isuserenabledres)==0){
							echo "<script>location.assign('logout');</script>";
						}
			?>
			<li>
				<a href="update-profile">My Profile</a>
			</li>
			<li>
				<a href="order-history">My Orders</a>
			</li>
				<?php
						}
			?>
			<li>
				<a href="logout">
					<span class="glyphicon glyphicon-user"></span>
					Log Out
				</a>
			</li>
			<?php
					}else{
				?>
			<li>
				<a href="login">
					Log In
				</a>
			</li>
				<?php 
					}
				?>
			<?php 
	    					/*
				if(getCartItemsCount()!=0){					
    				if(isset($_COOKIE['usertype'])){
	    				if($_COOKIE['usertype']=="user"){
			?>
			<li>
				<a href="updatepages/emptycart">Reset Cart</a>
			</li>
			<?php 
	    				}
    				}
				}
			*/
			?>
		</ul>
<?php /*		
	    <form class="navbar-form navbar-right" method="get" action="search">
	    	<div class="input-group">
	    		<input type="text" required placeholder="Search Products Here" class="form-control" name="keyword" style="border-radius: 0px !important;">
	    		<div class="input-group-btn">
	    			<button class="btn btn-default" style="padding: 7px 15px !important; border-radius: 0px;"><i class="glyphicon glyphicon-search"></i></button>
	    		</div>
	    	</div>
	    </form> */ ?>
	</div>
</nav>

<nav class="navbar-small-screen navbar-fixed-top navbar navbar-inverse">
   	<div class="container-fluid">
		<div class="navbar-header">
			<div class="navbar-brand" style="width: 100%;">
				<div class="drawerOpener">
					<span class="glyphicon glyphicon-menu-hamburger"></span>
				</div>
				<a href="./">
		    		<img src="images/ecomytra.png" style="width:170px !important; margin-top:-10px;">	
		    	</a>
		    </div>
	    </div>
<?php /*	    <form class="navbar-form navbar-right" method="get" action="search">
	    	<div class="input-group">
	    		<input type="text" placeholder="Search Products Here" class="form-control" name="keyword" required style="border-radius: 0px !important;">
	    		<div class="input-group-btn">
	    			<button class="btn btn-default" style="padding: 7px 15px !important; border-radius: 0px;"><i class="glyphicon glyphicon-search"></i></button>
	    		</div>
	    	</div>
	    </form> */ ?>
	    <br>
	</div>	
</nav>
<div class="drawer">
	<div class="drawerCloser">
		<span class="glyphicon glyphicon-remove"></span>
	</div>
	<div class="row">
<?php /*	<strong><span style="font-size: 18px;" class="fa fa-phone"></span> &nbsp; <a href="tel: <?php echo $contactinforow['PHONE1']; ?>"><?php echo $contactinforow['PHONE1']; ?></a></strong></div>
		<hr> */ ?>
	<?php 
		if(isset($_COOKIE['usertype'])){
	?>
		<span class="glyphicon glyphicon-user" style="font-size: 18px;"></span> <a href="logout">Log Out</a>
	<?php						
			if($_COOKIE['usertype']=="user"){
				$isuserenabled="select *from user where ID=".$_COOKIE['user']." and ISENABLED='true'";
				$isuserenabledres=mysqli_query($conn, $isuserenabled);
				if(mysqli_num_rows($isuserenabledres)==0){
					echo "<script>location.assign('logout');</script>";
				}
	?>
		&nbsp; | &nbsp; <a href="update-profile">My Profile</a>
	<?php
			}
		}else{
	?>
	<span class="glyphicon glyphicon-user" style="font-size: 18px;"></span> 
	<a href="login">Log In</a>
	<?php
		}
	?>
	<hr>
	<div style="line-height: 30px; font-size: 16px;">
		<a href="./">Home</a><br>
<?php #		<a href="categories">Product Categories</a><br> ?>
		<a href="categories">Store</a><br>
		<a href="checkout">Checkout (<?php echo getCartItemsCount(); ?> Items)</a><br>
		<?php
			if(isset($_COOKIE['usertype']) && $_COOKIE['usertype']=="user"){
		?>
		<a href="order-history">My Orders</a><br>
		<?php
			}
		?>
		<?php 
			if(getCartItemsCount()!=0){					
		?>
			<a href="updatepages/emptycart">Reset Cart</a><br>
		<?php 
			}
		?>
		<a href="media">Media</a><br>
		<a href="about">About Us</a><br>
		<a href="contact">Contact Us</a>
	</div>
	</div>
</div>
	<div class="scrollup" id="scrollup">
		<span class="glyphicon glyphicon-chevron-up"></span>
	</div>
	<script type="text/javascript">
		$(document).scroll(
			function(){
				if($(document).scrollTop()>300){
						$(".scrollup").show();
				}else{
					$(".scrollup").hide();
				}
			}
		);

		$(document).ready(
			function(){		
				$("#scrollup").click(
					function(){
						$("html, body").animate(
							{scrollTop: 0},
							500
						);
						return false;
					}
				);

				$(".drawerOpener").click(
					function(){
						$(".drawer").animate(
							{
								width: 250
							},
							200
						);
					}
				);

				$(".drawerCloser").click(
					function(){
						$(".drawer").animate(
							{
								width: 0
							},
							200
						);
					}
				);
			}
		);
	</script>


<div class="page">
