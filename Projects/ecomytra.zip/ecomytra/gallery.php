<?php
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 30px; padding-bottom: 100px;">
			<center>
				<h1 class="title">Gallery</h1>
				<img src="images/underline.png" style="width:300px;">
			</center>
			<br><br>
			<?php 
			            $query="select *from galleryimage limit 10 offset ".(($pg-1)*10);
				   		$res=mysqli_query($conn, $query);
				   		if(mysqli_num_rows($res)==0){
		    ?>
		                <center>
		                    <h3>No Images Found</h3>
		                    <a href="mediatopics">Click here to go back to Media Page</a>
		                </center>
		    <?php
				   		}
						while ($row=mysqli_fetch_array($res)) {
			?>
					<div class="col-sm-4" style="padding: 10px;">
					<a data-fancybox="gallery" data-caption="<?php echo $row['DESCRIPTION']; ?>" href="<?php echo $siteurl.$row['IMAGE']; ?>">
						<img src="<?php echo $siteurl.$row['IMAGE']; ?>" class="img-responsive thumbnail">
					</a>
						<center>
							<h4><?php echo $row['DESCRIPTION']; ?></h4>
						</center>
						<br>						
					</div>
			<?php
						}
			?>
			<div class="clearfix"></div><br><br>
		<center>
			<ul class="pagination pagination-sm">
			<?php
				$totalrowsQuery="select *from galleryimage";
				$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
				$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
				for($i=1; $i<($totalRowsRowCount/10)+1 && $totalRowsRowCount>10; $i++){
			?>
				  <li><a href="gallery?pg=<?php echo $i; ?>" 
				  	<?php 
				  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
				  			{
				  	?> style="background-color: #a5ce3a; color: #000;" 
				  	<?php 
				  			} 
				  	?>><?php echo $i; ?></a></li>
			<?php
				}
			?>
			</ul>

		</center>			
	</div>
</main>
<?php
	include 'components/footer.php';
?>