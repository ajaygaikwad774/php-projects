<?php
	include '../components/cartlib.php';
	resetCart();
	header("Location: ../checkout");
?>