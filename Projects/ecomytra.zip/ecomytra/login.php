<?php
	session_start();
	unset($_SESSION['reset_request_email']);
	if(isset($_COOKIE['usertype'])){
		if($_COOKIE['usertype']=="admin"){
			header("Location: admin/dashboard");
		}elseif($_COOKIE['usertype']=="user"){
			header("Location: update-profile");
		}
	}
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 50px; padding-bottom: 50px;">
		<div class="account-form col-sm-5">
			<center><h2><strong>User Log In</strong></h2></center>
			<center>
				<?php
					if(isset($_GET['msg'])){
						echo "<div class='errormsg'>";
						echo $_GET['msg'];
						echo "</div>";
					}
				?>
			</center>

			<br>
			<form method="post" action="postpages/userlogin.php">
			  <div class="form-group">
			    <label for="email"><span class="glyphicon glyphicon-envelope"></span> Email address:</label>
			    <input type="email" placeholder="Email Address" required class="form-control" id="email" name="email">
			  </div>
			  <div class="form-group">
			    <label for="pwd"><span class="glyphicon glyphicon-lock"></span> Password:</label>
			    <input type="password" name="password" placeholder="Password" required class="form-control" id="pwd">
			  </div>
			  <button type="submit" class="btn btn-default">Log In</button>
			  <br><br>
			  Not registered yet? <a href="signup">Sign Up Here.</a>
			  <br>
			  Don't remember your password? <a href="resetpassword">Reset Here.</a>
			</form>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>