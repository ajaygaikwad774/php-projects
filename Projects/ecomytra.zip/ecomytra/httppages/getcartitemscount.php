<?php
	include '../components/cartlib.php';
	echo getCartItemsCount();
?>