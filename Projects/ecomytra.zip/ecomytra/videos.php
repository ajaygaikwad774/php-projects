<?php
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 30px; padding-bottom: 100px;">
			<center>
				<h1 class="title">Videos</h1>
				<img src="images/underline.png" style="width:300px;">
			</center>
			<br><br>
			<?php 
			            $query="select *from videos limit 6 offset ".(($pg-1)*6);
				   		$res=mysqli_query($conn, $query);
				   		if(mysqli_num_rows($res)==0){
		    ?>
		                <center><h3>No Video Found</h3>
		                <a href="mediatopics">Click here to go back to Media Page</a></center>
		    <?php
				   		}
						while ($row=mysqli_fetch_array($res)) {
			?>
					<div class="col-sm-4" style="padding: 10px;">
						<iframe width="100%" height="300" src="<?php
							$temp=explode("/", $row['LINK']);
						 echo "https://youtube.com/embed/".$temp[count($temp)-1]; 

						 ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
						</iframe><br>
						<h3><?php echo $row['TITLE']; ?></h3>
						<br>						
					</div>
			<?php
						}
			?>
			<div class="clearfix"></div><br><br>
		<center>
			<ul class="pagination pagination-sm">
			<?php
				$totalrowsQuery="select *from videos";
				$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
				$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
				for($i=1; $i<($totalRowsRowCount/6)+1 && $totalRowsRowCount>6; $i++){
			?>
				  <li><a href="videos?pg=<?php echo $i; ?>" 
				  	<?php 
				  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
				  			{
				  	?> style="background-color: #a5ce3a; color: #000;" 
				  	<?php 
				  			} 
				  	?>><?php echo $i; ?></a></li>
			<?php
				}
			?>
			</ul>

		</center>			
	</div>
</main>
<?php
	include 'components/footer.php';
?>