<?php
	if(!isset($_GET['post']) || !is_numeric($_GET['post'])){
		header("Location: blog");
	}	
	include 'components/header.php';

	$articles="select *from article where ISENABLED='true' and ID=".$_GET['post'];
	$articleres=mysqli_query($conn, $articles);
?>
<main>
	<div class="container-fluid">
	<?php
		if(mysqli_num_rows($articleres)==0){
	?>
		<center>
			<br><br><br>
			<h2>Article Not Found</h2>
			<a href="blog">Click here to go back on the blog page</a>
		</center>
	<?php
		}else{
			$articlerow=mysqli_fetch_array($articleres);
	?>
		<div class="blog-cover" style="background-image: url('<?php echo $siteurl.$articlerow['PHOTO']; ?>');">
		</div>	
		<br>
		<h1>
			<?php echo $articlerow['TITLE']; ?>
		</h1><br>
		<?php 
			echo $articlerow['CONTENT'];
		?>
		<br>
		<button class="btn btn-default" onclick="location.assign('blog')">Back to Blogs Page</button>
	</div>
	<div class="clearfix"></div>
	<div class="container-fluid blog-page-blog" style="padding-top: 50px;">
		<h1>Related Articles:</h1><br><br>

		<?php
			$q="select *from article where ISENABLED='true' and CATEGORY=".$articlerow['CATEGORY']." and not ID=".$articlerow['ID']." order by ID desc limit 3";
			$rs=mysqli_query($conn, $q);
			if(mysqli_num_rows($rs)==0){
		?>
			<center><h3>No Articles Available</h3></center>
		<?php
			}
			while($rw=mysqli_fetch_array($rs)){
		?>
		<div class="col-sm-4">
			<div class="image" style="background-image: url('<?php echo $siteurl.$rw['PHOTO']; ?>');">
			</div>
			<h4><?php echo $rw['TITLE']; ?></h4>
			<div class="blog-body">
				<?php
					echo substr($rw['CONTENT'], 0, 200).".... ";
				?>				
			</div>
			<button class="btn btn-default" onclick="location.assign('article?post=<?php echo $rw['ID']; ?>')">Read More</button>
		</div>
		<?php
			}
		?>
	<?php			
		}
	?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>