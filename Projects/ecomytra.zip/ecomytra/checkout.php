<?php
	session_start();
	use Razorpay\Api\Api;

	include 'components/header.php';

	if(isset($_COOKIE['usertype']) && $_COOKIE['usertype']=="user"){
    	$query="select *from user where ID=".$_COOKIE['user'];
    	$res=mysqli_query($conn, $query);
    	$row=mysqli_fetch_array($res);	
    	if(trim($row['CONTACT'])=="" || trim($row['DOB'])=="" || trim($row['GENDER'])=="" || trim($row['PINCODE'])=="" || trim($row['STREETADDR1'])=="" || trim($row['STREETADDR2'])=="" || trim($row['LANDMARK'])=="" || trim($row['CITY'])=="" || trim($row['STATE'])=="" || trim($row['ADDRESSTYPE'])==""){
    		echo "<script>location.assign('update-profile?msg=Please complete your profile information before proceeding for checkout.');</script>";
    	}
	}
?>
<script>
	function updateCart(){
		var xhttp=new XMLHttpRequest();
		xhttp.onreadystatechange=function(){
          if(xhttp.readyState==4 && xhttp.status==200){
          	var cartitems=JSON.parse(xhttp.responseText);
          	for(var i=0; i<cartitems.length; i++){
          		if(parseInt(document.getElementById("item-quantity-"+cartitems[i].product).value)>=1){
		          	cartitems[i].quantity=parseInt(document.getElementById("item-quantity-"+cartitems[i].product).value);          			
          		}
          	}
          	location.assign("updatepages/updatecart.php?json="+JSON.stringify(cartitems));
          }
		};
		xhttp.open("GET", "postpages/getcartitemjson.php", true);
		xhttp.send();
	}
</script>

<script>
	function emptyCart(){
		var xhttp=new XMLHttpRequest();
		xhttp.open("GET", "updatepages/emptycart.php", true);
		xhttp.send();
	}
</script>
<main>
	<div class="container-fluid" style="padding-top: 50px; padding-bottom: 50px;">
		<center>
			<h1>
				<strong>Shopping Cart</strong>
			</h1><br>
		</center>
		<?php
			if(getCartItemsCount()==0){
		?>
		<center><h3>Shopping cart is empty</h3></center>
		<?php
			}else{				
				$cartitems=getCartItems();
		?>

		<br>
		<div class="clearfix"></div>
		<div class="table-responsive shopping-cart">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Product Image</th>
						<th>Product Name</th>
						<th>Quantity</th>
						<th>Price</th>
						<th>Total</th>
						<th>Weight</th>
						<th>Remove</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$totalpayable=0;
						$totalweight=0;
						for($i=0; $i<count($cartitems); $i++){
							$q="select *from product where ID=".$cartitems[$i]['product'];
							$rs=mysqli_query($conn, $q);
							$rw=mysqli_fetch_array($rs);
							$totalweight+=$cartitems[$i]['sweight']*$cartitems[$i]['quantity'];
					?>	
					<tr>
						<td><?php echo $i+1; ?></td>
						<td><a href="product-detail?product=<?php echo $rw['ID']; ?>"><img src="<?php echo $siteurl.$rw['IMAGE']; ?>"></a></td>
						<td><strong><a href="product-detail?product=<?php echo $rw['ID']; ?>"><?php echo $rw['TITLE']; ?></a></strong></td>
						<td>
							<input type="number" min="1" id="item-quantity-<?php echo $rw['ID']; ?>" data-product="<?php echo $rw['ID']; ?>" value="<?php echo $cartitems[$i]['quantity']; ?>">
						</td>
						<td>Rs. <?php echo $cartitems[$i]['product_price']; ?>/-</td>
						<td>Rs. <?php echo $cartitems[$i]['product_price']*$cartitems[$i]['quantity']; $totalpayable+=$cartitems[$i]['product_price']*$cartitems[$i]['quantity']; ?>/-</td>
						<td><?php echo $cartitems[$i]['sweight']; ?></td>
						<td><a href="updatepages/removefromcart.php?product=<?php echo $rw['ID']; ?>">Remove this Item</a></td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
			<div class="clearfix"></div>
			<center>
				<button class="btn btn-default" onclick="updateCart()">Update Cart</button>
			</center>
			<div class="clearfix"></div>
			<div class="pull-right" style="width: 200px;">
				<?php 
					$subtotal=$totalpayable;
				?>
				<h4><strong>Subtotal - </strong> Rs. <?php echo $subtotal; ?>/-</h4>
				<?php
					$deliverycharge=0;
					if($totalpayable>=3000){
						$deliverycharge=0;
					}elseif($row['STATE']=="Maharashtra"){
						if($totalweight>=6){
							$deliverycharge=28;
						}elseif($totalweight>5){
							$deliverycharge=30;
						}elseif($totalweight>4){
							$deliverycharge=32;
						}elseif($totalweight>3){
							$deliverycharge=35;
						}elseif($totalweight>2){
							$deliverycharge=40;
						}elseif($totalweight>1){
							$deliverycharge=40;
						}

					}elseif($row['STATE']!="Maharashtra"){
						if($totalweight>=6){
							$deliverycharge=55;
						}elseif($totalweight>5){
							$deliverycharge=58;
						}elseif($totalweight>4){
							$deliverycharge=61;
						}elseif($totalweight>3){
							$deliverycharge=65;
						}elseif($totalweight>2){
							$deliverycharge=70;
						}elseif($totalweight>1){
							$deliverycharge=70;
						}
					}

					$totalpayable+=$deliverycharge;
				?>
				<h4><strong>Shipping - </strong> Rs. <?php echo $deliverycharge."/-"; ?></h4>
				<h4><strong>Total - </strong> Rs. <?php echo $totalpayable."/-"; ?></h4><br><br>
<?php
	if(!isset($_COOKIE['usertype']) || $_COOKIE['usertype']!="user"){
?>
<button class="btn btn-default" onclick="location.assign('login?msg=Please Log In First')">Pay Now</button>
<?php
	}
	else{
	    
	$amount=$totalpayable;
	require 'config.php';
	require('razorpay-php/Razorpay.php');

	//create razorpay order

	$api = new Api($keyId, $keySecret);

	//
	// We create an razorpay order using orders api
	// Docs: https://docs.razorpay.com/docs/orders
	//
	$orderData = [
	    'receipt'         => uniqid(),
	    'amount'          => $amount * 100, // 2000 rupees in paise
	    'currency'        => 'INR',
	    'payment_capture' => 1 // auto capture
	];

	$razorpayOrder = $api->order->create($orderData);

	$razorpayOrderId = $razorpayOrder['id'];

	$_SESSION['razorpay_order_id'] = $razorpayOrderId;

	$displayAmount = $amount = $orderData['amount'];

	if ($displayCurrency !== 'INR')
	{
	    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
	    $exchange = json_decode(file_get_contents($url), true);

	    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
	}

	$checkout = 'automatic';

	if (isset($_GET['checkout']) and in_array($_GET['checkout'], ['automatic', 'manual'], true))
	{
	    $checkout = $_GET['checkout'];
	}

	$data = [
	    "key"               => $keyId,
	    "amount"            => $amount,
	    "name"              => "Ecomytra",
	    "description"       => "",
	    "image"             => "",
	    "prefill"           => [
	    "name"              => $row['NAME'],
	    "email"             => $row['EMAIL'],
	    "contact"           => $row['CONTACT'],
	    ],
	    "notes"             => [
	    "address"           => "",
	    "merchant_order_id" => "MO".uniqid(),
	    ],
	    "theme"             => [
	    "color"             => "#a5ce3a"
	    ],
	    "order_id"          => $razorpayOrderId,
	];

	if ($displayCurrency !== 'INR')
	{
	    $data['display_currency']  = $displayCurrency;
	    $data['display_amount']    = $displayAmount;
	}
	$json = json_encode($data);
?>
			<form action="postpages/postpayment.php" method="POST">
			  <script
			    src="https://checkout.razorpay.com/v1/checkout.js"
			    data-key="<?php echo $data['key']?>"
			    data-amount="<?php echo $data['amount']?>"
			    data-currency="INR"
			    data-name="<?php echo $data['name']?>"
			    data-image="<?php echo $data['image']?>"
			    data-description="<?php echo $data['description']?>"
			    data-prefill.name="<?php echo $data['prefill']['name']?>"
			    data-prefill.email="<?php echo $data['prefill']['email']?>"
			    data-prefill.contact="<?php echo $data['prefill']['contact']?>"
			    data-notes.shopping_order_id="SO".niqid()
			    data-order_id="<?php echo $data['order_id']?>"
			    <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
			    <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
			  >
			  </script>
			  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
			  <input type="text" name="myorderid" value="<?php echo $data['order_id']?>" style="visibility: hidden;">
			  <input type="text" name="totalpaid" value="<?php echo $totalpayable; ?>" style="visibility: hidden;">
			  <input type="text" name="shippingcharge" value="<?php echo $deliverycharge; ?>" style="visibility: hidden;">
			  <input type="hidden" name="shopping_order_id" value="3456">
			</form>
		</div>
	<?php
		}
	}
	?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>