<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
	require 'components/connection.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Gallery Images</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
		<form method="post" action="postpages/addgalleryimage.php" enctype="multipart/form-data">
			<div class="form-group">
				<label for="image">Add Gallery Image:</label>
				<input type="file" name="image" required id="image">
			</div>
			<div class="form-group">
			 	<label for="description">
			 		Image Description:
			 	</label>
			    <input type="text" placeholder="Enter Image Description" class="form-control" id="description" required name="description">			
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%;">Add Image</button>
			</center>
		</form>
	</div>
	<br>
	<hr>
	<center><h2>Manage Images</h2></center>
	<br>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Pic</th>
						<th>Description</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>
				</thead>
				<tbody>
					<?php
			            $query="select *from galleryimage limit 20 offset ".(($pg-1)*20);
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							$counter++;
					?>
					<tr>
						<td><?=$counter+(($pg-1)*20); ?></td>
						<td><img src="<?=$siteurl.$row['IMAGE']; ?>" style="width: 150px;"></td>
						<td><?=$row['DESCRIPTION']; ?></td>
						<td>
							<a href="editgalleryimage?id=<?php echo $row['ID']; ?>">Edit</a>
						</td>
						<td>
							<a href="deletepages/deletegalleryimage.php?id=<?php echo $row['ID']; ?>">Delete</a>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
		<div class="clearfix"></div>
		<br><br>
	<center>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from galleryimage";
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="galleryimages?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>
</div>
</main>
<?php
	include 'components/footer.php'
?>