<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
    require("components/connection.php");	
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Category Banners</strong></h1>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr> 
		<br>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<form class="col-sm-5" method="post" action="postpages/addcategorybanner.php" enctype="multipart/form-data">
			<div class="form-group">
				<label for="image">Add Banner Image:</label>
				<input type="file" name="image" required id="image">
			</div>
			<div class="form-group">
				<label for="category">Select Product Category:</label>
				<select class="form-control" name="category">
				    <?php
				        $q="select *from product_category where not TITLE='No Category'";
				        $rs=mysqli_query($conn, $q);
				        while($rw=mysqli_fetch_array($rs)){
				    ?>
				    <option value="<?php echo $rw['ID']; ?>"><?php echo $rw['TITLE']; ?></option>
				    <?php
				        }
				    ?>
				</select>
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%;">Add/Update</button>
			</center>
		</form>
		<div class="col-sm-1">&nbsp;</div>
		<div class="col-sm-6">
            <?php
                $bq="select *from catpromobanner";
                $bqrs=mysqli_query($conn, $bq);
                if(mysqli_num_rows($bqrs)==0){
            ?>
            <center>
                <h3>No Banner Added Yet</h3>
            </center>
            <?php
                }else{
            ?>
		    <div class="table-responsive">
		        <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Category</th>
                            <th>Banner Image</th>
                        </tr>
                    </thead>		        
                    <tbody>
                        <?php
                            $counter=0;
                            while($bqrw=mysqli_fetch_array($bqrs)){
                                $counter++;
                                $catq="select *from product_category where ID=".$bqrw['PRODUCTCAT'];
                                $catrs=mysqli_query($conn, $catq);
                                $catrw=mysqli_fetch_array($catrs);
                        ?>
                        <tr>
                            <td><?php echo $counter; ?></td>
                            <td><?php echo $catrw['TITLE']; ?></td>
                            <td><img src="<?php echo $siteurl.$bqrw['IMAGE']; ?>" style="width:200px;"></td>
                        </tr>
                        <?php
                            }
                        
                        ?>
                    </tbody>
		        </table>
		    </div>
		    <?php 
                }
            ?>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php'
?>