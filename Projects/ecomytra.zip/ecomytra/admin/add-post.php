<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
	require 'components/connection.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Add New Post</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
			<button class="btn btn-default" onclick="location.assign('manage-posts')">Article List</button>			
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
		<form method="post" action="postpages/addpost.php" enctype="multipart/form-data">
			<div class="form-group">
			 	<label for="title">
			 		Post Title:
			 	</label>
			    <input type="text" placeholder="Enter Post Title" class="form-control" id="title" required name="title">			
			</div>
			<div class="form-group">
				<label for="image">Add Post Image:</label>
				<input type="file" name="image" required id="image">
			</div>
			<div class="form-group">
			 	<label for="description">
			 		Post Description:
			 	</label>
			    <textarea id="description" placeholder="Enter Post Description" name="description" rows="8" required class="form-control"></textarea>		
			</div>
			<div class="form-group">
				<label for="category">Select Post Category:</label>
				<select class="form-control" name="category">
					<?php
						$q="select *from category";
						$rs=mysqli_query($conn, $q);
						while ($rw=mysqli_fetch_array($rs)) {
							echo "<option value='".$rw['ID']."'>".$rw['TITLE']."</option>";
						}
					?>
				</select>
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%;">Create Post</button>
			</center>
		</form>
	</div>
</main>
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>

<?php
	include 'components/footer.php'
?>