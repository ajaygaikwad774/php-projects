<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }

   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$title=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['title']));
   		$link=$_POST['link'];
         $query="insert into videos(TITLE, LINK) values('$title', '$link')";
         $res=mysqli_query($conn, $query);

   		header("Location:../videos?msg=Video Added Successfully");
   }
?>