<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }

   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$category=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['category']));
            $salt=date('dmYHis');
            $target_dir="../uploads/banners/";
            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
            $uploadok=1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                   
                  $chk="select *from catpromobanner where PRODUCTCAT=$category";
                  $chkres=mysqli_query($conn, $chk);
                  if(mysqli_num_rows($chkres)==0){
                      $query="insert into catpromobanner(PRODUCTCAT, IMAGE) values($category, 'admin/uploads/banners/".$salt.basename($_FILES['image']['name'])."')";
                      $res=mysqli_query($conn, $query);                      
                  }else{
                      $query="update catpromobanner set IMAGE='admin/uploads/banners/".$salt.basename($_FILES['image']['name'])."' where PRODUCTCAT=$category";
                      $res=mysqli_query($conn, $query);                      
                     }
               }
   		}

   		header("Location:../catbanners?msg=Banner Updated Successfully");
   }
?>