<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }

   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$title=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['title']));
   		$type=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['type']));
         $query="";
         $salt=date('dmYHis');
   		if($type=="Product"){
            $target_dir="../uploads/categories/";
            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
            $uploadok=1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                  $query="insert into product_category(TITLE, IMAGE) values('$title', 'admin/uploads/categories/".$salt.basename($_FILES['image']['name'])."')";
                  $res=mysqli_query($conn, $query);
               }
            }

   		}elseif($type=="Post"){
            $target_dir="../uploads/categories/";
            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
            $uploadok=1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                  $query="insert into category(TITLE, IMAGE) values('$title', 'admin/uploads/categories/".$salt.basename($_FILES['image']['name'])."')";
                  $res=mysqli_query($conn, $query);
               }
            }
         }

   		header("Location:../categories?msg=Category Added Successfully");
   }
?>