<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$author=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['name']));
   		$comment=mysqli_real_escape_string($conn, $_POST['comment']);

         $query="insert into testimonial(AUTHOR, COMMENT) values('$author', '$comment')";
         mysqli_query($conn, $query);
         $salt=date('dmYHis');
         
         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
            $target_dir="../uploads/testimonials/";
            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
            $uploadok=1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                  $query="update testimonial set PIC='admin/uploads/testimonials/".$salt.basename($_FILES['image']['name'])."' where ID=".mysqli_insert_id($conn);
                  $res=mysqli_query($conn, $query);
               }
            }            
         }
     		header("Location:../manage-testimonials?msg=Testimonial Added Successfully");
   }
?>