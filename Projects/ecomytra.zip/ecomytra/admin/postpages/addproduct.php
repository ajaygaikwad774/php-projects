<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$title=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['title']));
   		$description=mysqli_real_escape_string($conn, $_POST['description']);
         $price=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['price']));
         $dprice=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['dprice']));
         $pweight=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['pweight']));
         $sweight=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['sweight']));
         $category=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['category']));
         $showonbanner="no";
         $salt=date('dmYHis');
         $target_dir="../uploads/products/";
         $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
         $uploadok=1;
         $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
         $check = getimagesize($_FILES["image"]["tmp_name"]);
         if($check!==false){
            if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
               $query="insert into product(TITLE, IMAGE, DESCRIPTION, PRICE, DISCOUNTPRICE, IS_SLIDER, CATEGORY, CREATE_DATE, PRDWEIGHT, SHPWEIGHT) values('$title', 'admin/uploads/products/".$salt.basename($_FILES['image']['name'])."', '$description', '$price', '$dprice', '$showonbanner', $category, '".date('d-m-Y')."', '$pweight', '$sweight')";
               $res=mysqli_query($conn, $query);
            }
         }
  		header("Location:../add-product?msg=Product Added Successfully");
   }
?>