<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	include 'components/connection.php';
?> 
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Contact Form Messages</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
		</center>
		<hr>

		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<div class="table-responsive">

			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Name</th>
						<th>Email</th>
						<th>Contact</th>
						<th>Message</th>
						<th>DATE</th>
						<th>Delete</th>
					</tr>
				</thead>
				<tbody>
					<?php
			            $query="select *from contactform order by ID desc limit 20 offset ".($pg-1)*20;
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							$counter++;
					?>
					<tr>
						<td><?=$counter; ?></td>
						<td><?=$row['NAME']; ?></td>
						<td><?=$row['EMAIL']; ?></td>
						<td><?=$row['CONTACT']; ?></td>
						<td><?=$row['MESSAGE']; ?></td>
						<td><?=$row['CREATE_DATE']; ?></td>
						<td>
							<a href="deletepages/deletecontactformmessage.php?id=<?php echo $row['ID']; ?>">Remove</a>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
						
		</div>
	<center>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from contactform";
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="contact-form?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>
		
	</div>
</main>
<?php
	include 'components/footer.php';
?>