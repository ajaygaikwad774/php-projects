<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Welcome Admin!!!</strong></h1>
		</center>
		<hr>
		<div class="clearfix"></div><br>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('add-product')">
			<span class="glyphicon glyphicon-plus-sign"></span>
			<h4>Add New Product</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('add-post')">
			<span class="glyphicon glyphicon-plus-sign"></span>
			<h4>Add New Post</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('users')">
			<span class="glyphicon glyphicon-user"></span>
			<h4>Manage Users</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('manage-products')">
			<span class="glyphicon glyphicon-list-alt"></span>
			<h4>Manage Products</h4>
		</div>
		<div class="clearfix"></div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('manage-posts')">
			<span class="glyphicon glyphicon-list-alt"></span>
			<h4>Manage Posts</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('manage-orders')">
			<span class="glyphicon glyphicon-list-alt"></span>
			<h4>Manage Orders</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('manage-testimonials')">
			<span class="glyphicon glyphicon-certificate"></span>
			<h4>Testimonials</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('manage-contact-info')">
			<span class="glyphicon glyphicon-earphone"></span>
			<h4>Contact Info</h4>
		</div>
		<div class="clearfix"></div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('contact-form')">
			<span class="glyphicon glyphicon-envelope"></span>
			<h4>Contact Form</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('slider')">
			<span class="glyphicon glyphicon-picture"></span>
			<h4>Front Slider</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('socialmedia')">
			<span class="fa fa-facebook"></span>
			<h4>Social Media Links</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('banners')">
			<span class="glyphicon glyphicon-tags"></span>
			<h4>Manage Promo Banners</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('catbanners')">
			<span class="glyphicon glyphicon-tags"></span>
			<h4>Manage Category Banners</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('comments')">
			<span class="glyphicon glyphicon-comment"></span>
			<h4>Manage User Comments</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('videos')">
			<span class="glyphicon glyphicon-film"></span>
			<h4>Manage YouTube Videos</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('galleryimages')">
			<span class="glyphicon glyphicon-picture"></span>
			<h4>Manage Gallery Images</h4>
		</div>
		<div class="col-sm-3 text-center home-opt" onclick="location.assign('../logout')">
			<span class="glyphicon glyphicon-off"></span>
			<h4>Log Out</h4>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>