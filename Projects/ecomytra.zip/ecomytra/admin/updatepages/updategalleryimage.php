<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id']) && is_numeric($_GET['id'])){
   		$description=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['description']));
         $query="update galleryimage set DESCRIPTION='$description' where ID=".$_GET['id'];
   		$res=mysqli_query($conn, $query);
         $salt=date('dmYHis');
         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
            $target_dir="../uploads/galleryimages/";
            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
            $uploadok=1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                  $query="update galleryimage set IMAGE='admin/uploads/galleryimages/".$salt.basename($_FILES['image']['name'])."' where ID=".$_GET['id'];
                  $res=mysqli_query($conn, $query);
               }
            }
         }

   		header("Location:../editgalleryimage?id=".$_GET['id']."&msg=Image Updated Successfully");
   }
?>