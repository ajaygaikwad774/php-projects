<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST"){
   		$phone1=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['contact1']));
         $phone2=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['contact2']));
         $email1=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email1']));
         $email2=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email2']));
         $address=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['address']));
         $googlemaps=mysqli_real_escape_string($conn, $_POST['maplink']);

         $query="select *from contact";
         $res=mysqli_query($conn, $query);
         if(mysqli_num_rows($res)!=0){
            $query="update contact set PHONE1='$phone1', PHONE2='$phone2', EMAIL1='$email1', EMAIL2='$email2', ADDRESS='$address', GOOGLEMAPS='$googlemaps'";
            mysqli_query($conn, $query);
         }else{            
            $query="insert into contact(PHONE1, PHONE2, EMAIL1, EMAIL2, ADDRESS, GOOGLEMAPS) values('$phone1', '$phone2', '$email1', '$email2', '$address', '$googlemaps')";
            mysqli_query($conn, $query);
         }   
     		header("Location:../manage-contact-info?msg=Contact Info Updated Successfully");
   }
?>