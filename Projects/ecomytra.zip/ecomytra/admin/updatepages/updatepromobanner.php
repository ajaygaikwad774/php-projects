<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}
	require '../components/connection.php';
	if($_SERVER['REQUEST_METHOD']=="POST" && isset($_GET['banner']) && is_numeric($_GET['banner'])){
		$banner=$_GET['banner'];
   		$link=mysqli_real_escape_string($conn, $_POST['link']);
   		$salt=date('dmYHis');
		if($banner==1){
	         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
	            $target_dir="../uploads/banners/";
	            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
	            $uploadok=1;
	            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	            $check = getimagesize($_FILES["image"]["tmp_name"]);
	            if($check!==false){
	               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
	                  $query="update promobanner set IMAGE='admin/uploads/banners/".$salt.basename($_FILES['image']['name'])."' where TITLE='topright'";
	                  $res=mysqli_query($conn, $query);
	               }
	            }
	         }
        $query="update promobanner set LINK='$link' where TITLE='topright'";
        $res=mysqli_query($conn, $query);

		}elseif($banner==2){
	         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
	            $target_dir="../uploads/banners/";
	            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
	            $uploadok=1;
	            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	            $check = getimagesize($_FILES["image"]["tmp_name"]);
	            if($check!==false){
	               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
	                  $query="update promobanner set IMAGE='admin/uploads/banners/".$salt.basename($_FILES['image']['name'])."' where TITLE='topleft'";
	                  $res=mysqli_query($conn, $query);
	               }
	            }
	         }
        $query="update promobanner set LINK='$link' where TITLE='topleft'";
        $res=mysqli_query($conn, $query);

		}elseif($banner==3){
	         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
	            $target_dir="../uploads/banners/";
	            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
	            $uploadok=1;
	            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	            $check = getimagesize($_FILES["image"]["tmp_name"]);
	            if($check!==false){
	               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
	                  $query="update promobanner set IMAGE='admin/uploads/banners/".$salt.basename($_FILES['image']['name'])."' where TITLE='bottom'";
	                  $res=mysqli_query($conn, $query);
	               }
	            }
	         }
        $query="update promobanner set LINK='$link' where TITLE='bottom'";
        $res=mysqli_query($conn, $query);
		}

		header("Location: ../banners?msg=Banner Updated Successfully");
	}
?>