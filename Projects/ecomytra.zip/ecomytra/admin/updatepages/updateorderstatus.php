<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['order']) && is_numeric($_GET['order'])){
   		$status=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['status']));
         $query="update orders set ORDERSTATUS='$status' where ID=".$_GET['order'];
   		$res=mysqli_query($conn, $query);
   		header("Location:../manage-orders?order=".$_GET['order']."&msg=Order Status Updated Successfully");
   }
?>