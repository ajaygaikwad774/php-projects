<?php
  if(!isset($_COOKIE['usertype'])){
    header("Location: ../../login?msg=Please Log In First");
  }
  elseif($_COOKIE['usertype']!="admin"){
    header("Location: ../../login?msg=Please Log In First");
  }
    require("../components/connection.php");

	if($_SERVER['REQUEST_METHOD']=="POST"){
   		$content=mysqli_real_escape_string($conn, $_POST['description']);
   		$link=mysqli_real_escape_string($conn, $_POST['link']);
        $btntext=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['btntext']));

        $q="select *from dealoftheday";
        $rs=mysqli_query($conn, $q);

        if(mysqli_num_rows($rs)==0){
         $query="insert into dealoftheday(CONTENT, LINK, BTNTEXT) values('$content', '$link','$btntext')";
         mysqli_query($conn, $query);

        }else{

         $query="update dealoftheday set CONTENT='$content', LINK='$link', BTNTEXT='$btntext'";
         mysqli_query($conn, $query);
        }
         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
            $target_dir="../uploads/banners/";
            $salt=date('dmYHis');
            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
            $uploadok=1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if($check!==false){
               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
                  $query="update dealoftheday set IMAGE='admin/uploads/banners/".$salt.basename($_FILES['image']['name'])."'";
                  $res=mysqli_query($conn, $query);
               }
            }
         }
     	header("Location:../banners?&msg=Deal of the Day Section Updated Successfully");
	}
?>