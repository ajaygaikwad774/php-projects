<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }
   require("../components/connection.php");   
   if($_SERVER["REQUEST_METHOD"] == "POST"){
   		$fb=mysqli_real_escape_string($conn, $_POST['fb']);
         $insta=mysqli_real_escape_string($conn, $_POST['insta']);
         $twitter=mysqli_real_escape_string($conn, $_POST['twitter']);
         $linkedin=mysqli_real_escape_string($conn, $_POST['linkedin']);

         if($fb==""){
         	$fb="https://facebook.com";
         }
         if($insta==""){
         	$insta="https://instagram.com";
         }
         if($twitter==""){
         	$twitter="https://twitter.com";
         }
         if($linkedin==""){
         	$linkedin="https://linkedin.com";
         }

         $query="update socialmedia set LINK='$fb' where TITLE='facebook'";
         mysqli_query($conn, $query);
         $query="update socialmedia set LINK='$insta' where TITLE='instagram'";
         mysqli_query($conn, $query);
         $query="update socialmedia set LINK='$twitter' where TITLE='twitter'";
         mysqli_query($conn, $query);
         $query="update socialmedia set LINK='$linkedin' where TITLE='linkedin'";
         mysqli_query($conn, $query);

         header("Location: ../socialmedia?msg=Social Links Updated Successfully");
   }
?>