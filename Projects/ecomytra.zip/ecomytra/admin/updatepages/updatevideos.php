<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id']) && is_numeric($_GET['id'])){
   		$title=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['title']));
         $link=$_POST['link'];
         $query="update videos set TITLE='$title', LINK='$link' where ID=".$_GET['id'];
   		$res=mysqli_query($conn, $query);

   		header("Location:../editvideos?id=".$_GET['id']."&msg=Video Updated Successfully");
   }
?>