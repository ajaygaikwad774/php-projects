<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	if(!isset($_GET['user']) || !is_numeric($_GET['user'])){
		header("Location: ./users");
	}
	include 'components/header.php';
    require("components/connection.php");	
    $query="select *from user where ID=".$_GET['user'];
    $res=mysqli_query($conn, $query);
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>User Profile</strong></h1>
			<a href="users">Go to User List</a><br><br><br>
		</center>
		<?php
			if(mysqli_num_rows($res)==0){
		?>
			<center>
				<br><br><br>
				<h2>User Not Found</h2>
				<a href="./users">Click here to go back on the users page</a>
				<br><br>
			</center>
		<?php
			}else{
				$row=mysqli_fetch_array($res);
		?>
		<div class="col-sm-6" style="margin: auto; float: none;">
			<div class="list-group">
				<div class="list-group-item">
					<div class="profile-pic" style="background-image: url('<?php echo $siteurl.$row['PIC']; ?>');">
					</div>					
				</div>
				<?php if($row['ISENABLED']=="false"){ ?>
				<div class="list-group-item text-center">
					<strong>
						<span style="color: #dd0000;">
							This user is blocked.
						</span>
					</strong>
				</div>
				<?php } ?>
				<div class="list-group-item">
				  <center><h3><span class="glyphicon glyphicon-user"></span> Personal Info</h3></center>
				</div>
				<div class="list-group-item">
				    <label><span class="glyphicon glyphicon-user"></span> Name:</label>
				    <span class="pull-right">
						<?php echo $row['NAME']; ?>					
					</span>
				</div>
				<div class="list-group-item">
				    <label><span class="glyphicon glyphicon-envelope"></span> Email address:</label>
				    <span class="pull-right">
						<?php echo $row['EMAIL']; ?>					
					</span>
				</div>
				<div class="list-group-item">
				    <label><span class="glyphicon glyphicon-phone"></span> Contact Number:</label>
				    <span class="pull-right">
						<?php echo $row['CONTACT']; ?>					
					</span>
				</div>
				<div class="list-group-item">
				    <label><span class="glyphicon glyphicon-calendar"></span> Birth Date:</label>
				    <span class="pull-right">
						<?php echo $row['DOB']; ?>					
					</span>
				</div>
				<div class="list-group-item">
				    <label><span class="glyphicon glyphicon-user"></span> Gender:</label>
				    <span class="pull-right">
						<?php echo ucfirst($row['GENDER']); ?>					
					</span>
				</div>
				<div class="list-group-item">
				  <center><h3><span class="glyphicon glyphicon-map-marker"></span> Delivery Location</h3></center>
				</div>
				<div class="list-group-item">
					<strong>Street Address Line 1: </strong>
				    <span class="pull-right">
						<?=$row['STREETADDR1']; ?>
					</span>
				</div>
				<div class="list-group-item">
					<strong>Street Address Line 2: </strong>
				    <span class="pull-right">
						<?=$row['STREETADDR2']; ?>
					</span>
				</div>
				<div class="list-group-item">
					<strong>Landmark: </strong>
				    <span class="pull-right">
						<?=$row['LANDMARK']; ?>
					</span>
				</div>
				<div class="list-group-item">
					<strong>City: </strong>
				    <span class="pull-right">
						<?=$row['CITY']; ?>
					</span>
				</div>
				<div class="list-group-item">
					<strong>State: </strong>
				    <span class="pull-right">
						<?=$row['STATE']; ?>
					</span>
				</div>
				<div class="list-group-item">
					<strong>Pin Code: </strong>
				    <span class="pull-right">
						<?=$row['PINCODE']; ?>
					</span>
				</div>
				<div class="list-group-item">
					<strong>Address Type: </strong>
				    <span class="pull-right">
						<?=$row['ADDRESSTYPE']; ?>
					</span>
				</div>
			</div>
		<?php
			}
		?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>