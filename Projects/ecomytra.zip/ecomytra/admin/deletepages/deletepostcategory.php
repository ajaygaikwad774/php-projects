<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}

   require("../components/connection.php");
   if(isset($_GET['id'])){
  		$query="update article set CATEGORY=0 where CATEGORY=".$_GET['id'];
   		mysqli_query($conn, $query);
   		$query="delete from category where ID=".$_GET['id'];
   		mysqli_query($conn, $query);
   		header("Location: ../categories?msg=Post Category Removed");
   }
?>