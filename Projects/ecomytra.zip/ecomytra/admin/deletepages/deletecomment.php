<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}

   require("../components/connection.php");
   if(isset($_GET['comment']) && is_numeric($_GET['comment'])){
  		$query="delete from comment where ID=".$_GET['comment'];
   		mysqli_query($conn, $query);
   		header("Location:../comments?msg=Comment Removed Successfully");
   }
?>