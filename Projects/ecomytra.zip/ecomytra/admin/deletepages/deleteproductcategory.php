<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}
   require("../components/connection.php");
   if(isset($_GET['id'])){
  		$query="update product set CATEGORY=0 where CATEGORY=".$_GET['id'];
   		mysqli_query($conn, $query);
   		$query="delete from product_category where ID=".$_GET['id'];
   		mysqli_query($conn, $query);
   		header("Location:../categories?msg=Product Category Removed");
   }
?>