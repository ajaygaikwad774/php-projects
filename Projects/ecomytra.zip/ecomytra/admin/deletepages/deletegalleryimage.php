<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}

   require("../components/connection.php");
   if(isset($_GET['id']) && is_numeric($_GET['id'])){
  		$query="delete from galleryimage where ID=".$_GET['id'];
   		mysqli_query($conn, $query);
   		header("Location:../galleryimages?msg=Image Removed Successfully");
   }
?>