<?php
	$siteurl="https://www.amraenterprises.com//ecomytra/";
	$hostname="localhost";
	$dbname="ecomytra";
	$dbuser="ajaysharma";
	$dbpassword="ajaysharma";

	$conn=mysqli_connect($hostname, $dbuser, $dbpassword, $dbname);

	$pg=1;
	if(isset($_GET['pg']) && is_numeric($_GET['pg'])){
		$pg=$_GET['pg'];
	}	

?>