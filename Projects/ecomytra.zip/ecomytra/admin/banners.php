<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
    require("components/connection.php");	
	$promo="select *from promobanner";
	$promores=mysqli_query($conn, $promo);	
	$promobanner=array();

	$promobanner[0]['TITLE']="";
	$promobanner[0]['DEFAULTIMAGE']="";
	$promobanner[0]['IMAGE']="";
	$promobanner[0]['LINK']="";
	$promobanner[1]['TITLE']="";
	$promobanner[1]['DEFAULTIMAGE']="";
	$promobanner[1]['IMAGE']="";
	$promobanner[1]['LINK']="";
	$promobanner[2]['TITLE']="";
	$promobanner[2]['DEFAULTIMAGE']="";
	$promobanner[2]['IMAGE']="";
	$promobanner[2]['LINK']="";

	$counter=0;
	while($promorow=mysqli_fetch_array($promores)){
		$promobanner[$counter]['TITLE']=$promorow['TITLE'];
		$promobanner[$counter]['DEFAULTIMAGE']=$promorow['DEFAULTIMAGE'];
		$promobanner[$counter]['IMAGE']=$promorow['IMAGE'];
		$promobanner[$counter]['LINK']=$promorow['LINK'];
		$counter++;
	}
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Promo Banners</strong></h1>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr> 
		<br>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div>
		<div class="col-sm-4" style="padding: 10px;">
			<h2>Promo Banner 1</h2>
			<h4>(Home Page - Top Right)</h4>
			<form method="post" action="updatepages/updatepromobanner.php?banner=1" enctype="multipart/form-data">
				<div class="form-group">
					<label for="image">Banner Image:</label>
					<img style="max-width:100px;" src="<?php if(trim($promobanner[0]['IMAGE'])!=""){ echo $siteurl.$promobanner[0]['IMAGE']; } ?>" class="img-responsive"><br>
					<input type="file" name="image" id="image">
				</div>
				<div class="form-group">
				 	<label for="link">
				 		Link:
				 	</label>
				    <input style="max-width: 250px;" type="text" placeholder="Enter Target Link" class="form-control" value="<?php if($promobanner[0]['LINK']!=""){ echo $promobanner[0]['LINK']; } ?>" id="link" name="link">			
				</div>				
				<button class="btn btn-default">
					Update
				</button>
			</form>
		</div>
		<div class="col-sm-4" style="padding: 10px;">
			<h2>Promo Banner 2</h2>
			<h4>(Home Page - Top Left)</h4>			
			<form method="post" action="updatepages/updatepromobanner.php?banner=2"  enctype="multipart/form-data">
				<div class="form-group">
					<label for="image">Banner Image:</label>
					<img style="max-width:100px;" src="<?php if(trim($promobanner[1]['IMAGE'])!=""){ echo $siteurl.$promobanner[1]['IMAGE']; } ?>" class="img-responsive"><br>
					<input type="file" name="image" id="image">
				</div>
				<div class="form-group">
				 	<label for="link">
				 		Link:
				 	</label>
				    <input style="max-width: 250px;" type="text" placeholder="Enter Target Link" class="form-control" value="<?php if($promobanner[1]['LINK']!=""){ echo $promobanner[1]['LINK']; } ?>" id="link" name="link">			
				</div>				
				<button class="btn btn-default">
					Update
				</button>
			</form>
		</div>
		<div class="col-sm-4" style="padding: 10px;">
			<h2>Promo Banner 3</h2>
			<h4>(Home Page - Bottom)</h4>						
			<form method="post" action="updatepages/updatepromobanner.php?banner=3"  enctype="multipart/form-data">
				<div class="form-group">
					<label for="image">Banner Image:</label>
					<img style="max-width:100px;" src="<?php if(trim($promobanner[2]['IMAGE'])!=""){ echo $siteurl.$promobanner[2]['IMAGE']; } ?>" class="img-responsive"><br>
					<input type="file" name="image" id="image">
				</div>
				<div class="form-group">
				 	<label for="link">
				 		Link:
				 	</label>
				    <input style="max-width: 250px;" type="text" placeholder="Enter Target Link" class="form-control" value="<?php if($promobanner[2]['LINK']!=""){ echo $promobanner[2]['LINK']; } ?>" id="link" name="link">			
				</div>				
				<button class="btn btn-default">
					Update
				</button>
			</form>
		</div>
		<div class="clearfix"></div>
		<div class="col-sm-6" style="margin-top: 60px;">
			<h2>Deal of the Day Section</h2><br>
			<?php
				$query="select *from dealoftheday";
				$res=mysqli_query($conn, $query);
				$row=mysqli_fetch_array($res);
			?>
			<form method="post" action="updatepages/dealoftheday.php" enctype="multipart/form-data">
				<div class="form-group">
				 	<label for="description">
				 		Write Description:
				 	</label>
				    <textarea id="description" placeholder="Enter Post Description" name="description" rows="8" required class="form-control"><?php echo $row['CONTENT'] ?></textarea>		
				</div>
				<div class="form-group">
					<label for="image">Add Image:</label>
					<img src="<?php if(trim($row['IMAGE'])!=""){ echo $siteurl.$row['IMAGE']; } ?>" class="img-responsive" style="max-width: 150px;"><br>
					<input type="file" name="image" id="image">
				</div>
				<div class="form-group">
				 	<label for="link">
				 		Add Target Link:
				 	</label>
				    <input type="text" placeholder="Enter Target Link" class="form-control" id="link" required name="link" value="<?php echo $row['LINK']; ?>">			
				</div>
				<div class="form-group">
				 	<label for="btntext">
				 		Read More Button Text:
				 	</label>
				    <input type="text" placeholder="Enter Button Text" class="form-control" id="btntext" required name="btntext" value="<?php echo $row['BTNTEXT']; ?>">			
				</div>
				<center>
					<button class="btn btn-default" style="width: 100%;">Update Section</button>
				</center>

			</form>
		</div>
	</div>
</main>
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>
<?php
	include 'components/footer.php'
?>