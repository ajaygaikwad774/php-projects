<?php
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$name=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['name'])));
   		$email=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email'])));
   		$contact=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['contact'])));
   		$message=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['message'])));
		$isError=false;
		$errMsg="";

		if($name=="" || $email=="" || $contact=="" || $message==""){
			$isError=true;
			$errMsg="All fields are compulsory"; 
		}

		//email validation
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) { 
		} 
		else { 
			$isError=true;
			$errMsg="Please enter a valid email address"; 
		} 
		//contact validation
		if(!is_numeric($contact) || strlen($contact)!=10){
			$isError=true;
			$errMsg="Contact number must be a 10 digit number"; 			
		}

		if(!$isError){
			//create new user
			$query="insert into contactform(EMAIL, CONTACT, NAME, MESSAGE, CREATE_DATE) values('$email', '$contact', '$name', '$message', '".date('d-m-Y')."')";
			mysqli_query($conn, $query);
			header("Location: ../contact?msg=Thank you for contacting us. Your message has been sent to us successfully.");
		}else{
			header("Location: ../contact?msg=$errMsg");
		}
   }
 ?>