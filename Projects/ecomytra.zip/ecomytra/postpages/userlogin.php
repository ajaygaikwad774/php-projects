<?php
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$email=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email']));
   		$password=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['password']));
         $query="select *from user where EMAIL='$email' and PASSWORD='$password'";
         $res=mysqli_query($conn, $query);
         if(mysqli_num_rows($res)==0){
            header("Location: ../login?msg=Invalid Email Address or Password");
         }else{
            $row=mysqli_fetch_array($res);
            if($row['ISENABLED']=="true"){
               if($row['TYPE']=="user"){
                  setcookie("usertype", "user", time()+86400, "/");
                  setcookie("user", $row['ID'], time()+86400, "/");
                  header("Location:../update-profile");
               }elseif($row['TYPE']=="admin"){
                  setcookie("usertype", "admin", time()+86400, "/");
                  setcookie("user", $row['ID'], time()+86400, "/");
                  header("Location:../admin/dashboard");
               }
            }else{
                  header("Location:../login?msg=Your Account has been disabled for some reasons. Kindly contact the website administrator.");               
            }
         }
   }
?>