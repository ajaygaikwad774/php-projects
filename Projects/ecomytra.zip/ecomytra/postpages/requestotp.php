<?php
   session_start();
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$email=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email'])));
   		$otp=generateNumericOTP();
		$isError=false;
		$errMsg="";

		if($email==""){
			$isError=true;
			$errMsg="Please Enter your Email Address"; 
		}

		//email validation
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) { 
		} 
		else { 
			$isError=true;
			$errMsg="Please enter a valid email address"; 
		} 

		if(!$isError){
			//if account with provided email already exists
			$q="select *from user where EMAIL='$email' and ISENABLED='true'";
			$rs=mysqli_query($conn, $q);
			if(mysqli_num_rows($rs)==0){
				$isError=true;
				$errMsg="Account with provided email address does not exist"; 			
			}
		}

		if(!$isError){
			//create new user
			$query="update user set OTP='$otp' where EMAIL='$email'";
			mysqli_query($conn, $query);

			//email functionality

            /*
                PHP Mailing
            */
            $message="<h3>Greetings from Ecomytra!<br><br> Your <strong>one time password</strong> for password reset is:<br><strong><h2> $otp </h2></strong><br><br>Best Regards,<br> Team Ecomytra";
                      
            $to=$email;
            $subject="Ecomytra: OTP Verification";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: <info@ecomytra.com>' . "\r\n";
            $headers .= "Reply-To: info@ecomytra.com\r\n";
            $headers .= "Return-Path: info@ecomytra.com\r\n";
            mail($to,$subject,$message,$headers);

			$_SESSION['reset_request_email']=$email;

			header("Location: ../verifyotp?msg=We have mailed you the OTP on your provided email address");
		}else{
			header("Location: ../resetpassword?msg=$errMsg");
		}
   }
 ?>