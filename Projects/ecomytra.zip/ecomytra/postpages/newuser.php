<?php
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$name=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['name'])));
   		$email=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email'])));
   		$contact=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['contact'])));
   		$password=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['password'])));
		$isError=false;
		$errMsg="";

		if($name=="" || $email=="" || $contact=="" || $password==""){
			$isError=true;
			$errMsg="All fields are compulsory"; 
		}

		//email validation
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) { 
		} 
		else { 
			$isError=true;
			$errMsg="Please enter a valid email address"; 
		} 
		//contact validation
		if(!is_numeric($contact) || strlen($contact)!=10){
			$isError=true;
			$errMsg="Contact number must be a 10 digit number"; 			
		}
		//password validation
		if(strlen($password)<6){
			$isError=true;
			$errMsg="Please select a password of at least 6 characters length"; 			
		}

		if(!$isError){
			//if account with provided email already exists
			$q="select *from user where EMAIL='$email'";
			$rs=mysqli_query($conn, $q);
			if(mysqli_num_rows($rs)!=0){
				$isError=true;
				$errMsg="Account with provided email address already exists"; 			
			}
		}

		if(!$isError){
			//create new user
			$query="insert into user(EMAIL, CONTACT, NAME, PASSWORD, CREATE_DATE) values('$email', '$contact', '$name', '$password', '".date('d-m-Y')."')";
			mysqli_query($conn, $query);
			header("Location: ../login?msg=Your account has been created successfully. Please log in here.");
		}else{
			header("Location: ../signup?msg=$errMsg");
		}
   }
 ?>