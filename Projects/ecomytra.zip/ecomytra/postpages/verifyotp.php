<?php
   session_start();
	if(!isset($_SESSION['reset_request_email'])){
		header("Location: login");
	}

   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$otp=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['otp'])));
   		$email=$_SESSION['reset_request_email'];
		$isError=false;
		$errMsg="";

		if($otp==""){
			$isError=true;
			$errMsg="Please Enter OTP"; 
		}

		if(!$isError){
			$q="select *from user where EMAIL='$email' and OTP='$otp' and ISENABLED='true'";
			$rs=mysqli_query($conn, $q);
			if(mysqli_num_rows($rs)==0){
				$isError=true;
				$errMsg="Invalid OTP."; 		
				unset($_SESSION['reset_request_email']);
				header("Location: ../login?msg=$errMsg");
			}else{
	            $row=mysqli_fetch_array($rs);
				unset($_SESSION['reset_request_email']);
               if($row['TYPE']=="user"){
                  setcookie("usertype", "user", time()+86400, "/");
                  setcookie("user", $row['ID'], time()+86400, "/");
                  header("Location:../update-profile");
               }elseif($row['TYPE']=="admin"){
                  setcookie("usertype", "admin", time()+86400, "/");
                  setcookie("user", $row['ID'], time()+86400, "/");
                  header("Location:../admin/dashboard");
               }
           }
		}else{
			header("Location: ../verifyotp?msg=$errMsg");
		}
   }
 ?>