<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="user"){
		header("Location: login?msg=Please Log In First");
	}
	include 'components/header.php';
	$query="select *from orders where USER=".$_COOKIE['user']." order by ID desc limit 20 offset ".(($pg-1)*20);
	$res=mysqli_query($conn, $query);
?>
<main>
	<div class="container-fluid" style="padding-top: 30px; padding-bottom: 50px;">
	<?php
		if(isset($_GET['order']) && is_numeric($_GET['order'])){
	?>
		<center>
			<h1><strong>Order Details</strong></h1>
			<a href="order-history">Go back to order list</a>
		</center>
		<hr>
		<div class="clearfix"></div><br>
		<?php
			$orderdetails="select *from orders where ID=".$_GET['order']." and USER=".$_COOKIE['user'];
			$orderdetailsres=mysqli_query($conn, $orderdetails);
			if(mysqli_num_rows($orderdetailsres)==0){
		?>
			<center><h3>No Order Found</h3></center>
		<?php
			}else{
				$orderdetailsrow=mysqli_fetch_array($orderdetailsres);

				$orderdata=json_decode($orderdetailsrow['ORDERJSON'], true);
		?>
		<label>Order ID - </label> <?=$orderdetailsrow['ORDERID']; ?><br>
		<label>Order Date - </label> <?=$orderdetailsrow['ORDER_DATE']; ?><br>
		<label>Order Status - </label> <?=ucfirst($orderdetailsrow['ORDERSTATUS']); ?><br>
		<h4><strong>Order Delivery Address - </strong></h4>
		<strong>Street Address Line 1 - </strong><?=$orderdetailsrow['STREETADDR1']; ?><br>
		<strong>Street Address Line 2 - </strong><?=$orderdetailsrow['STREETADDR2']; ?><br>
		<strong>Landmark - </strong><?=$orderdetailsrow['LANDMARK']; ?><br>
		<strong>City - </strong><?=$orderdetailsrow['CITY']; ?><br>
		<strong>State - </strong><?=$orderdetailsrow['STATE']; ?><br>
		<strong>Pin Code - </strong><?=$orderdetailsrow['PINCODE']; ?><br>
		<strong>Address Type - </strong><?=$orderdetailsrow['ADDRESSTYPE']; ?><br>

		<div class="clearfix"></div><br>

		<div class="table-responsive shopping-cart">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Product Image</th>
						<th>Product Name</th>
						<th>Quantity</th>
						<th>Price</th>
						<th>Total</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$totalpayable=0;
						for($i=0; $i<count($orderdata); $i++){
							$q="select *from product where ID=".$orderdata[$i]['product'];
							$rs=mysqli_query($conn, $q);
							$rw=mysqli_fetch_array($rs);
					?>	
					<tr>
						<td><?php echo $i+1; ?></td>
						<td><img src="<?php echo $siteurl.$rw['IMAGE']; ?>"></td>
						<td><strong><?php echo $rw['TITLE']; ?></strong></td>
						<td>
							<?php echo $orderdata[$i]['quantity']; ?>
						</td>
						<td>Rs. <?php echo $orderdata[$i]['product_price']; ?>/-</td>
						<td>Rs. <?php echo $orderdata[$i]['product_price']*$orderdata[$i]['quantity']; $totalpayable+=$orderdata[$i]['product_price']*$orderdata[$i]['quantity']; ?>/-</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>		
			<div class="text-right">
				<h4><strong>Subtotal - </strong><?php echo "Rs. ".($orderdetailsrow['TOTALPAID']-$orderdetailsrow['SHIPPINGCHARGE'])."/-"; ?></h4>
				<h4><strong>Shipping - </strong><?php echo "Rs. ".$orderdetailsrow['SHIPPINGCHARGE']."/-"; ?></h4>
				<h4><strong>Total Paid - </strong><?php echo "Rs. ".$orderdetailsrow['TOTALPAID']."/-"; ?></h4>
			</div>
		<?php
			}
		?>
	<?php
		}else{
	?>
		<center>
			<h1><strong>My Orders</strong></h1>
			<a href="./">Go back to home page</a>
		</center>
		<hr>
		<div class="clearfix"></div><br>
		<?php 
			if(mysqli_num_rows($res)==0){
		?>
		<center><h3>No Orders Found</h3></center>
		<?php
			}else{
		?>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Order Date</th>
						<th>Order Status</th>
						<th>Details</th>
					</tr>
				</thead>
				<tbody>
				<?php
					$counter=(($pg-1)*20);
					while($row=mysqli_fetch_array($res)){
						$counter++;
				?>
					<tr>
						<td><?=$counter; ?></td>
						<td><?=$row['ORDER_DATE']; ?></td>
						<td>
							<?=$row['ORDERSTATUS']; ?>
						</td>
						<td>
							<a href="order-history?order=<?php echo $row['ID']; ?>">View Details</a>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
	<?php
		}
	}
	
	if(!isset($_GET['order'])){
	?>
		<center>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from orders where USER=".$_COOKIE['user'];
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="order-history?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>
		</center>
		<?php 
	}   
	?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>