<?php 
	if(!isset($_GET['keyword'])){
		header("Location: ./");
	}		
	include 'components/header.php';
   	$keyword=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_GET['keyword'])));
   	$counter=0;
?>
<main> 
	<div class="container-fluid" style="padding-top: 50px;">
		<h3><strong>Showing Results for:</strong> <?php echo $_GET['keyword']; ?></h3>
		<hr> 
		<?php
			$query="select *from product where (TITLE like '%$keyword%' or CATEGORY in( select ID from product_category where TITLE like '%$keyword%')) and ISENABLED='true'";
			$res=mysqli_query($conn, $query);
			$counter+=mysqli_num_rows($res);
			if($counter>0){
		?>
		<h4>Showing <?=$counter; ?> <?php if($counter==1){ echo "match"; }else{ ?> matches
			<?php } ?></h4>
		<br>
		<?php
			}else{
		?>
			<h4><strong>Sorry, we couldn't find any matches for <?php echo $_GET['keyword']; ?></strong></h4>
		<?php
			}
			while($productrow=mysqli_fetch_array($res)){
		?>
		<div class="col-sm-3" style="padding-bottom: 20px;">
			<a href="product-detail?product=<?php echo $productrow['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$productrow['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $productrow['TITLE']; ?>
							</td>
							<?php
								if(trim($productrow['DISCOUNTPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $productrow['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $productrow['DISCOUNTPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $productrow['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
		</div>		
		<?php
			}
		?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>