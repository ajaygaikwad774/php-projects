<?php
	include 'components/header.php';
?>

<main>
	<div class="about-page-banner">

		<div id="myCarousel" class="carousel slide" data-ride="carousel">
		  <!-- Indicators -->
		  <ol class="carousel-indicators">
<!--		    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		    <li data-target="#myCarousel" data-slide-to="1"></li> -->
		  </ol>

		  <!-- Wrapper for slides -->
		  <div class="carousel-inner">
		    <div class="item active">
		      <img src="images/about-us.jpg">
		      <div class="carousel-caption">
<!--		       	<div class="align-left"> -->
			        <h1>About Us</h1>
			        <h3>Lorem Ipsum Dolor Sit Amet</h3><br>
<!--			        <button class="btn btn-default">Shop Now</button>
			    </div> -->
		      </div>
		    </div>

<!--		    <div class="item">
		      <img src="images/banner-background-1.png">
		      <div class="carousel-caption">
		       	<div class="align-left">
			        <h1>Lorem Ipsum</h1>
			        <h3>Lorem Ipsum Dolor Sit Amet</h3><br>
			        <button class="btn btn-default">Shop Now</button>
			    </div>
		      </div>
		    </div>
-->
		  </div>

		  <!-- Left and right controls -->
<!--		  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left"></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#myCarousel" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right"></span>
		    <span class="sr-only">Next</span>
		  </a> -->
		</div>
	
	</div>

	<div class="clearfix"></div>

	<div class="container-fluid" style="padding-top: 50px;">
		<center>
			<h1 class="title">Lorem Ipsum Dolor</h1>
			<img src="images/underline.png" style="width:300px;">
			<h4 class="subtitle">Lorem ipsum dolor sit amet</h4>
		</center><br><br>
		<div class="clearfix"></div>
		<center>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</center>
	</div>

	<div class="clearfix"></div>

	<div style="background-color: #efefef; padding-top: 50px; padding-bottom: 40px; margin-top: 70px;">
		<div class="container-fluid">
			<center>
				<div class="col-sm-4 feature" style="padding: 10px;">
					<span class="fa fa-certificate"></span>
					<h3><strong>Our Vision</strong></h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua.
					</p>
				</div>
				<div class="col-sm-4 feature" style="padding: 10px;">
					<span class="fa fa-balance-scale" style=" padding-left: 13px;"></span>
					<h3><strong>Our Mission</strong></h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua.
					</p>
				</div>
				<div class="col-sm-4 feature" style="padding: 10px;">
					<span class="fa fa-angellist"></span>
					<h3><strong>Why Choose Us?</strong></h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua.
					</p>
				</div>
			</center>
		</div>
	</div>

	<div class="clearfix"></div>
	<div class="container-fluid" style="padding-top: 50px;">
		<div class="col-sm-6">
			<h1>Lorem Ipsum Dolor</h1><br>
			<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse.
			</p>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat.
			</p>
		</div>
		<div class="col-sm-6" style="padding: 30px 10px;"> 
			<img src="images/team.jpg" class="img-responsive">
		</div>
	</div>

	<div class="clearfix"></div>

	<div style="background-color: #efefef; padding-top: 50px; padding-bottom: 50px; margin-top: 70px;">
		<div class="container-fluid">
			<center>
				<h1 class="title">Our Team</h1>
				<img src="images/underline.png" style="width:300px;">
				<h4 class="subtitle">Lorem ipsum dolor sit amet</h4>
			</center><br><br>
			<div class="clearfix"></div>
			<center>
				<div class="col-sm-4 team-members">
					<img src="images/user.png">
					<h3><strong>Mr. John Theil</strong></h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua.
					</p>
				</div>
				<div class="col-sm-4 team-members">
					<img src="images/user-female.png">
					<h3><strong>Mr. Merrisa Sanberg</strong></h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua.
					</p>					
				</div>
				<div class="col-sm-4 team-members">
					<img src="images/user.png">
					<h3><strong>Mr. Steven Smith</strong></h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua.
					</p>					
				</div>
			</center>
		</div>
	</div>

	<div class="clearfix"></div>

	<div class="container-fluid front-page-blog" style="padding-top: 50px;">
		<center>
			<h1 class="title">Latest Articles</h1>
			<img src="images/underline.png" style="width:300px;">			
			<h4 class="subtitle">Lorem ipsum dolor sit</h4>
		</center>
		<br><br>
		<?php
			$articles="select *from article where ISENABLED='true' order by ID desc limit 3";
			$articleres=mysqli_query($conn, $articles);
			if(mysqli_num_rows($articleres)==0){
		?>
		<center><h3>No Articles Available</h3></center>
		<?php
			}
			while($articlerow=mysqli_fetch_array($articleres)){
		?>
		<div class="col-sm-4">
			<div class="image" style="background-image: url('<?php echo $siteurl.$articlerow['PHOTO']; ?>');">
			</div>
			<h4><?php echo $articlerow['TITLE']; ?></h4>
			<div class="blog-body">
				<?php
					echo substr($articlerow['CONTENT'], 0, 200).".... ";
				?>
			</div>
			<button class="btn btn-default" onclick="location.assign('article?post=<?php echo $articlerow['ID']; ?>')">Read More</button>
		</div>

		<?php
			}
		?>
	</div>

</main>
<?php
	include 'components/footer.php';
?>