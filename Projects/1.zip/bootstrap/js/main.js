$(document).ready(function() {
	//Sticky Header
	$(function() {
		//caches a jQuery object containing the header element
		var header = $(".header");
		$(window).scroll(function() {
			var scroll = $(window).scrollTop();
			if (scroll >= 20) {
				header.addClass("stickyHeader");
			} else {
				header.removeClass("stickyHeader");
			}
		});
	});
	
	
	/*------------------------
	    Brand Slider
	--------------------------- */    
	$('.brand-slider').slick({
	  infinite: true,
	  slidesToShow: 1,
	  slidesToScroll: 1,
	  dots: true,
	  arrows: true,
	  mobileFirst:true,
	  draggable: true,
	  autoplay: true,
	  autoplaySpeed: 2000,
// 	  prevArrow: '<div class="slick-prev"> <i class="glyphicon glyphicon-circle-arrow-left" aria-hidden="true"></i> </div>',
//       nextArrow: '<div class="slick-next"> <i class="glyphicon glyphicon-circle-arrow-right" aria-hidden="true"></i> </div>',
	  responsive: [
		{
	      breakpoint: 1600,
	      settings: {
	        slidesToShow: 5,
	      }
	    },
		{
	      breakpoint: 1400,
	      settings: {
	        slidesToShow: 4,
	      }
	    },
	    {
	      breakpoint: 1200,
	      settings: {
	        slidesToShow: 4,
	      }
	    },
	    {
	      breakpoint: 700,
	      settings: {
	        slidesToShow: 2,
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 1,
	      }
	    }
	  ]
  });


});


