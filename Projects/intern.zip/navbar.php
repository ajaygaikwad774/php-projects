  
      <body class="fix-header ">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <!-- ============================================================== -->
        <!-- Main wrapper - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <div id="main-wrapper">

            
         <header class="topbar">
                <nav class="navbar top-navbar navbar-expand-md navbar-light">
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-header" style="width:0px!important;">
                        <a class="navbar-brand" href="dashboard_admin.php">
                            <!-- Logo icon --><b>
                                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                                <!-- Dark Logo icon alt="homepage" -->
                                <img src="assets/images/logo-icon.png"  class="dark-logo" style="padding-left: 15px;" />
                                <!-- Light Logo icon -->
                                <img src=""  class="light-logo" />
                            </b>
                            <!--End Logo icon -->
                            <!-- Logo text --><span>
                             <!-- dark Logo text -->
                             <img src="" alt="" class="dark-logo" />
                             <!-- Light Logo text -->    
                             <img src="" class="light-logo"  /></span> 
                             <span style="color: #ffffff;font-size:24px;font-weight:bold;">Appdid Infotech</span>
                         </a>
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-collapse">
                        <!-- ============================================================== -->
                        <!-- toggle and nav items -->
                        <!-- ============================================================== -->
                        <ul class="navbar-nav mr-auto mt-md-0">
                           
                            
                           
                        </ul>
                        <ul class="navbar-nav mr-auto mt-md-0">
                           
                            
                           
                        </ul>
                        <ul class="navbar-nav mr-auto mt-md-0">
                           
                         
                           
                        </ul>

                        <ul class="navbar-nav mr-auto mt-md-0">
                            
                              <a href="add_student.php" style="margin-right:20px;" class="btn btn-rounded btn-danger btn-sm">Add Student</a> 
                            <a href="project_details.php" class="btn btn-rounded btn-danger btn-sm">Project Details</a>
                           

                           
                        </ul>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <ul class="navbar-nav my-lg-0">
                           
                            <!-- ============================================================== -->
                            <!-- Profile -->
                            <!-- ============================================================== -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/users/1.jpg" alt="user" class="profile-pic" /></a>
                                <div class="dropdown-menu dropdown-menu-right scale-up">
                                    <ul class="dropdown-user">
                                        <li>
                                            <!-- <div class="dw-user-box"> -->
                                                <!-- <div class="u-img"><img src="assets/images/users/1.jpg" alt="user"></div>
                                                <div class="u-text"> -->
                                                    <!-- <h4>Steave Jobs</h4> -->
                                                    <!-- <p class="text-muted">varun@gmail.com</p> -->
                                                  <!--   <a href="project_details.php" class="btn btn-rounded btn-danger btn-sm">Project Details</a></div> -->
                                            <!-- </div> -->
                                        </li>
                                       
                                        <!-- <li role="separator" class="divider"></li> -->
                                        <li><a href="logout_code.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
</div>
     <!--  <aside class=
     "left-sidebar">
                
                End Sidebar scroll
            </aside> -->