<?php

                session_start();

include "connection.php";


if (isset($_POST["submit"])) 
{
 echo $username=mysqli_real_escape_string($conn,$_POST['username']);
 echo $password=mysqli_real_escape_string($conn,$_POST['password']);

$check="SELECT `id`, `username`, `password`, `disabled` FROM `hh_de_login` WHERE `disabled`='0' AND `username` = '$username' AND `password` ='$password'";
$check1=mysqli_query($conn,$check);
	if (mysqli_num_rows($check1)>0)
	{
				$fetch=mysqli_fetch_assoc($check1);
				$_SESSION["admin_id"]=$fetch["id"];
				

				
					

					  	if($fetch["disabled"] == "0")
					  	{

					header("Location:add_student.php");


                         }
                      else if ($fetch["disabled"] == "1") 
                     {


                    $_SESSION["errors"]=" Account has been deactivated by Admin ";
		

		              header("Location:login.php");

                  }

              
				
			
	}
	else{

            $_SESSION["errors"]="Wrong username or password.";
		
	       
		header("Location:login.php");
	}

}

?>