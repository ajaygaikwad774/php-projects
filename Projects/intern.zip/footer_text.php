 <?php $Current_year = date('Y'); ?>
            <!-- ============================================================== -->
            <footer class="footer"  style="left:0px!important;"> © <?php echo $Current_year; ?>Developed by Appdid  </footer>