<?php 
 session_start();
if (isset($_SESSION["admin_id"]) && $_SESSION["admin_id"] == '1213' ) 
{
        // $user_id = $_SESSION["admin_id"];
        // $full_name = $_SESSION["admin_name"];
       include('header.php'); ?>
       <?php include('navbar.php'); ?>

  <?php include('connection.php'); ?>


        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
          <div class="page-wrapper" style="padding-top:30px!important;margin-left:0px!important;" >
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor">New Student</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Project Details</li>
                    </ol>
                </div>
              
            </div> -->
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
               
                            <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white">Project Details</h4>
                            </div>
                            <div class="card-body">
                                <!-- action="add_student_code.php" -->
                                <form id="add_student" action="project_d_code.php"  method="POST" class="form-horizontal" enctype="multipart/form-data">
                                    <div class="form-body">
                                        <h3 class="box-title">Project Details</h3>
                                        <hr class="m-t-0 m-b-40">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Project Id<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="project_id" required="" placeholder="Project Id">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                        </div> 
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Group id<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="batch_id" required="" placeholder="Batch_id">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                        </div> 
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Project Name<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" name="p_name" required placeholder="Project Name">
                                                        <!-- <small class="form-control-feedback"> This is inline help </small> -->
                                                         </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                           
                                           <div class="col-md-10">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Project Short  Description<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                          <textarea cols="50" rows="4" name="p_s_details" required=""></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                           
                                            <div class="col-md-10">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Project Description<span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                          <textarea cols="50" rows="4" name="p_details" required=""></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>

                                            

                                        <!--/row-->
                                        <div class="row">
                                           
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Logo <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="file" class="form-control" name="logo"  required accept="image/*" >
                                                    </div>
                                                </div>
                                            </div>
                                           
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">SS <span style="color:red">*</span> </label>
                                                    <div class="col-md-9">
                        <input id="my_id" type="file" class="form-control" required="" multiple name="image[]" accept="image/*" >
                                                    </div>
                                                </div>
                                            </div>

                                             <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">Zip File <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="file" class="form-control" required name="zip_file"  >
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="control-label text-left col-md-3">APK File <span style="color:red">*</span></label>
                                                    <div class="col-md-9">
                                                        <input type="file" class="form-control" required=""  name="apk_file"  >
                                                    </div>
                                                </div>
                                            </div>
                                             
                                            
                                            
                                        </div>
                                        
                                    
                                    <div class="form-actions">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                                                        <button type="submit" id="a_submit" name="assubmit" class="btn btn-success">Submit</button>
                                                        <button type="button" class="btn btn-inverse">Cancel</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6"> </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       
                  
                  
           <?php include('footer_text.php') ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
   
   
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<?php include('footer.php') ?>

    <script type="text/javascript">
       $('input#my_id').change(function(){
    var files = $(this)[0].files;
    if(files.length > 6 || files.length < 6 ){
      var input = $("input#my_id");
    var fileName = input.val();
    
    if(fileName) { // returns true if the string is not empty
        input.val('');
    }
        alert("you can select  6 files.");

    }else{
        // alert("correct, you have selected less than 6 files");
    }
});
 


  
    </script>
    
</body>

</html>
<?php   
    
} else 
{
 session_unset();
    session_destroy();
    header("Location:login.php");
} ?>