<?php 
 include('connection.php');
// if(isset($_POST['query']))
// {
 $project_id=mysqli_real_escape_string($conn,$_POST["project_id"]);
   
	$batch_id=mysqli_real_escape_string($conn,$_POST["batch_id"]);
	 $p_name=mysqli_real_escape_string($conn,$_POST["p_name"]);

	 $p_details=mysqli_real_escape_string($conn,$_POST["p_details"]);

   $p_s_details=mysqli_real_escape_string($conn,$_POST["p_s_details"]);
	 
   

$p_d = 'images/'.$batch_id;
 
if(is_dir($p_d))
  {  
  

}else
{
   mkdir('images/'.$batch_id);   
}
 // logo
$path = 'images/'.$batch_id;

  if(is_uploaded_file($_FILES['logo']['tmp_name']))
  {
    // echo "photo";
if(is_dir($path))
  {



  }
else
  {

    mkdir($path);
 
  }
          $filename  = $_FILES['logo']['name'];
        $extension= pathinfo($filename,PATHINFO_EXTENSION);
            $target_path = $path.'/';  
  $logo = $target_path.'logo_'.$p_name.'.'.$extension;  
// echo $photo =$fname.$g_id; 
  
move_uploaded_file($_FILES['logo']['tmp_name'], $logo);


}else 
{
  $logo = '0';
}


//zip

$path_z = 'images/'.$batch_id.'/file';

  if(is_uploaded_file($_FILES['zip_file']['tmp_name']))
  {
    // echo "photo";
if(is_dir($path_z))
  {



  }
else
  {

    mkdir($path_z);
 
  }

          $filename  = $_FILES['zip_file']['name'];
        $extension= pathinfo($filename,PATHINFO_EXTENSION);
            $target_path = $path_z.'/';  
  $zip_file = $target_path.'p_name'.$batch_id.'.'.$extension;  
// echo $photo =$fname.$g_id; 
  
move_uploaded_file($_FILES['zip_file']['tmp_name'], $zip_file);


}else 
{
  $zip_file = '0';
}

//apk

$path_apk = 'images/'.$batch_id.'/file';

  if(is_uploaded_file($_FILES['apk_file']['tmp_name']))
  {
    // echo "photo";
if(is_dir($path_apk))
  {



  }
else
  {

    mkdir($path_apk);
 
  }
          $filename  = $_FILES['apk_file']['name'];
        $extension= pathinfo($filename,PATHINFO_EXTENSION);
            $target_path = $path_apk.'/';  
  $apk_file = $target_path.$p_name.'.'.$extension;  
// echo $photo =$fname.$g_id; 
  
move_uploaded_file($_FILES['apk_file']['tmp_name'], $apk_file);


}else 
{
  $apk_file = '0';
}



 // ss
   $images_arr = array();
 $ccount =count(array_filter($_FILES["image"]['name']));

//print_r($_FILES["image"]['name']);
     if($ccount == 0)
      {

         $file1 = '0';
          $file2 = '0';
          $file3 = '0';
          $file4 = '0';
          $file5 = '0';
           $file6 = '0';
           

       } else
       {

        $ss_d = 'images/'.$batch_id.'/ss';
 
if(is_dir($ss_d))
  {  
  

}else
{
   mkdir($ss_d);   
}
   

  for($j=0; $j < $ccount; $j++)
{  
    

     $filename = $_FILES["image"]['name']["$j"]; 
    $source_img = $_FILES["image"]["tmp_name"]["$j"];

  $size = $_FILES['image']['size']["$j"];
 $max_size = 509715;

 //if size grater then compress

 if($size >= $max_size )
 {
      // echo "max";

   $filename = $_FILES["image"]['name']["$j"]; 
    $source_img = $_FILES["image"]["tmp_name"]["$j"];


 require_once("vendor/autoload.php");
require_once("vendor/tinify/tinify/lib/Tinify/Exception.php");
require_once("vendor/tinify/tinify/lib/Tinify/ResultMeta.php");
require_once("vendor/tinify/tinify/lib/Tinify/Result.php");
require_once("vendor/tinify/tinify/lib/Tinify/Source.php");
require_once("vendor/tinify/tinify/lib/Tinify/Client.php");
require_once("vendor/tinify/tinify/lib/Tinify.php");

\Tinify\setKey("bLmJDbbb0Zmnmf4szCC7DCtpghYYmjmV");


$kind = isset($_GET['kind']) ? $_GET['kind'] : '';
$path = 'www.'.$_SERVER['SERVER_NAME'];

 $filename = $_FILES['image']['name']["$j"];
      $extension= pathinfo($filename,PATHINFO_EXTENSION);
              
              //setting file path
              $i=$j+1;
              $extra ="image".$i."-";
             
              $name2 =$extra.$batch_id. ".".$extension;

$extension = strtolower(substr($name2, strpos($name2, '.') + 1));
$type = $_FILES['image']['type']["$j"];
$size = $_FILES['image']['size']["$j"];
$max_size = 309715;
$tmp_name = $_FILES['image']['tmp_name']["$j"];

        $source = \Tinify\fromFile($tmp_name);
        $source->toFile('images/'.$batch_id.'/ss/'.$name2);
           $images_arr[] = 'images/'.$batch_id.'/ss/'.$name2;

} 

else if ( $size <= $max_size)
{



   $filename = $_FILES["image"]['name']["$j"]; 
    $source_img = $_FILES["image"]["tmp_name"]["$j"];

 $filename = $_FILES['image']['name']["$j"];
      $extension= pathinfo($filename,PATHINFO_EXTENSION);
              
              //setting file path
              $i=$j+1;
              $extra ="images".$i."-";
              // echo $extra;
              $name1 = 'images/'.$batch_id.'/ss/';
              //assigning a unique name to the image to avoid duplication
              // $uniquesavename=time().uniqid(rand());
              //concatinating the file path and name with the extension 
              $name2 =$name1.$extra.$batch_id.".".$extension;

$extension = strtolower(substr($name2, strpos($name2, '.') + 1));

echo $tmp_name = $_FILES['image']['tmp_name']["$j"];

           $images_arr[] =$name2;


move_uploaded_file($tmp_name, $name2);

    
     
 // }

}
}
            

 if (count($images_arr) == 1)
 {
          $file1 = $images_arr[0];
          $file2 = '0';
          $file3 = '0';
          $file4 = '0';
          $file5 = '0';
           $file6 = '0';
     }elseif (count($images_arr) == 2) {
         $file1 = $images_arr[0];
         $file2 = $images_arr[1];       
          $file3 = '0';
          $file4 = '0';
           $file5 = '0';
            $file6 = '0';
     } elseif (count($images_arr) == 3)
     {
         $file1 = $images_arr[0];
         $file2 = $images_arr[1];
          $file3 = $images_arr[2];
          $file4 = '0';
           $file5 = '0';
            $file6 = '0';
     } elseif (count($images_arr) == 4)
     {
          $file1 = $images_arr[0];
         $file2 = $images_arr[1];
          $file3 = $images_arr[2];
          $file4 = $images_arr[3];
           $file5 = '0';
            $file6 = '0';
     } elseif (count($images_arr) == 5)
     {
          $file1 = $images_arr[0];
         $file2 = $images_arr[1];
          $file3 = $images_arr[2];
          $file4 = $images_arr[3];
           $file5 = $images_arr[4];
            $file6 = '0';
     } 
     elseif (count($images_arr) == 5)
     {
          $file1 = $images_arr[0];
         $file2 = $images_arr[1];
          $file3 = $images_arr[2];
          $file4 = $images_arr[3];
           $file5 = $images_arr[4];
           $file6 = $images_arr[5];
     } 


}
 
      
          $add_student = "INSERT INTO `intern_project_details`(`intern_project_id`,`intern_batch_id`, `intern_project_name`, `intern_project_descp`, `intern_project_logo`, `intern_project_screen_shots_1`, `intern_project_screen_shots_2`, `intern_project_screen_shots_3`, `intern_project_screen_shots_4`, `intern_project_screen_shots_5`, `intern_project_screen_shots_6`, `intern_project_zip_file`, `intern_project_apk`) VALUES ('$project_id',$batch_id','$p_name','$p_details','$logo','$file1','$file2','$file3','$file4', '$file5', '$file6','$zip_file','$apk_file')";
         $add_s=mysqli_query($conn,$add_student);


 
?>