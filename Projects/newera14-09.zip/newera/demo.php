
<ul id="products">
  <li data-id="1" data-name="Product 1" data-price="10.00">
    <input type="text" /><br />
    <button>Add to cart</button>
  </li>
  <li data-id="2" data-name="Product 2" data-price="15.00">
    <input type="text" /><br />
    <button>Add to cart</button>
  </li>
  <li data-id="3" data-name="Product 3" data-price="20.00">
    <input type="text" /><br />
    <button>Add to cart</button>
  </li>
</ul>
 <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>

<script >

// 	function addToCart(products){
//      let product = [];
//     if(localStorage.getItem('products')){
//         products = JSON.parse(localStorage.getItem('products'));
//     }

//      product.push(products);
//     localStorage.setItem('product', JSON.stringify(products));
// }


// function addToCart(product) {
	
// 	 let products = [product];

// 	  console.log(products);
//     // Retrieve the cart object from local storage
//     if (localStorage && localStorage.getItem('cart')) {
//         var cart = JSON.parse(localStorage.getItem('cart'));            
    
//         cart.products.push(product);
//            console.log(cart.products.push(product));
//         localStorage.setItem('cart', JSON.stringify(cart));
//     } 
// }


function addToCart(product,pid) {
   if (localStorage) {

    var json = localStorage.getItem('cart') || '{"products":[]}';
    var cart = JSON.parse(json);
 
    cart.products.push(product);

    localStorage.setItem('cart', JSON.stringify(cart));
     var data_v = localStorage.getItem('cart');
    var cart = JSON.parse(json);
    console.log(cart['products']);
     // localStorage.clear();
 

   }

  // window.location = "html/cart.html"
}

$('button').on('click', function(e) {
   var li = $(this).parent();

    var quantity = $(li).find('input[type=text]').val();


    var product = {};
    product.id = $(li).attr('data-id');
     var pid = product.id;
    product.name = $(li).attr('data-name');
    product.price = $(li).attr('data-price');
    product.quantity = quantity;
     
  addToCart(product ,pid);
});


// $('button').on('click', function(e) {
//     var li = $(this).parent();

//     var quantity = $(li).find('input[type=text]').val();

//     // // Ensure a valid quantity has been entered
//     // if (!isValidInteger(quantity) === true) {
//     //     alert('Please enter a valid quantity');
//     //     return;
//     // }

//     var product = {};
//     product.id = $(li).attr('data-id');
//     product.name = $(li).attr('data-name');
//     product.price = $(li).attr('data-price');
//     product.quantity = quantity;
     
//     addToCart(product);
// });

</script>