<?php 
 
function getAllCategories()
{
	global $conn; 
	
	$allCategories = "SELECT * FROM fh_categories WHERE cIsVisible = 1 ORDER BY cPosition";
	
	$allCategoriesRows = mysqli_query($conn, $allCategories);
	 
	while ($categoriesRow = mysqli_fetch_array($allCategoriesRows))
	{
		$cId = $categoriesRow['cId']; 
		$cName = $categoriesRow['cName'];
		
		$allSubCategoriesRows = mysqli_query($conn, "SELECT * FROM fh_subcategories WHERE sIsVisible = 1 AND scId = $cId ORDER BY sPosition");
		$hasRow = mysqli_num_rows($allSubCategoriesRows);
		
		if($hasRow <= 0){
                     ?>
	<li><ul><li><?php echo $cName; ?></li>
                  
   <?php
		}else{
			?>
		<li><ul><li><?php echo $cName; ?></li>
                  
		<?php	
			while ($SubCategoriesRow = mysqli_fetch_array($allSubCategoriesRows))
			{
				$sId = $SubCategoriesRow['sId']; 
				$sName = $SubCategoriesRow['sName'];
		?>
		<!-- ?cId=<php echo $cId;?>&sId=<php echo $sId;?> -->
		<li><a href="shop.php"><?php echo $sName; ?></a>
		</li> 
		<?php		
				
			}				
			?>
            </ul>
        </li>
			<?php

		}		
	}
	
}
function getAllCategoriesFooter()
{
	global $conn; 
	
	$allCategories = "SELECT * FROM fh_categories WHERE cIsVisible = 1 ORDER BY cPosition";
	
	$allCategoriesRows = mysqli_query($conn, $allCategories);
	
	while ($categoriesRow = mysqli_fetch_array($allCategoriesRows)){
		$cId = $categoriesRow['cId']; 
		$cName = $categoriesRow['cName'];
		echo "<li><a href='shop.php'>$cName</a></li>";
	}
}
function categoriesName()
{
	global $conn; 
	if(isset($_GET['cId']) && $_GET['cId']!=""){
		$categoriesId = $_GET['cId'];
		
		$categoriesNameQuery = "SELECT * FROM fh_categories WHERE cId = $categoriesId ";
		
		$allCategoriesRows = mysqli_query($conn, $categoriesNameQuery);
		$allCategoriesRow = mysqli_fetch_array($allCategoriesRows);
		$cName = $allCategoriesRow['cName'];

		echo "$cName";
	}
}
function subCategoriesSlider()
{
	global $conn; 
	if(isset($_GET['cId']) && $_GET['cId']!=""){
		$categoriesId = $_GET['cId'];
		
		$subCategoriesQuery = "SELECT * FROM fh_subcategories WHERE sIsVisible = 1 AND scId = $categoriesId ORDER BY sPosition";
		
		$allSubCategoriesRows = mysqli_query($conn, $subCategoriesQuery);
		
		while ($SubCategoriesRow = mysqli_fetch_array($allSubCategoriesRows)){
			$sId = $SubCategoriesRow['sId']; 
			$sName = $SubCategoriesRow['sName'];
			$sImage = $SubCategoriesRow['sImage'];

			echo "<div class='owl-item'>";
			echo "<div class='popular_category d-flex flex-column align-items-center justify-content-center'>";
			echo "<div class='popular_category_image'><a href='products.php?cId=$categoriesId&sId=$sId'><img src='img_sub_cat/$sImage'></a></div>";
			echo "<div class='popular_category_text'><a href='products.php?cId=$categoriesId&sId=$sId'>$sName</a></div>";
			echo "</div>";
			echo "</div>";
		}	
	}
}
function categoriesSlider()
{
	global $conn;
		
	$categoriesQuery = "SELECT * FROM fh_categories WHERE cIsVisible = 1 ORDER BY cPosition";
	
	$allCategoriesRows = mysqli_query($conn, $categoriesQuery);
	
	while ($CategoriesRow = mysqli_fetch_array($allCategoriesRows)){
		$cId = $CategoriesRow['cId']; 
		$cName = $CategoriesRow['cName'];
		$cImage = $CategoriesRow['cImage'];

		echo "<div class='bestsellers_item discount'>";
			echo "<a href='products.php?cId=$cId'><div class='d-flex flex-row align-items-center justify-content-center'>";
				echo "<div class='char_content'>";
					echo "<div class='char_title'><h3>$cName</h3></div>";
				echo "</div>";
			echo "</div></a>";
		echo "</div>";
	}	
}
function chairCategoriesSlider()
{
	global $conn; 
		
	$subCategoriesQuery = "SELECT * FROM fh_subcategories WHERE sIsVisible = 1 AND scId = 1 ORDER BY sPosition";
	
	$allSubCategoriesRows = mysqli_query($conn, $subCategoriesQuery);
	
	while ($SubCategoriesRow = mysqli_fetch_array($allSubCategoriesRows)){
		$sId = $SubCategoriesRow['sId']; 
		$sName = $SubCategoriesRow['sName'];
		$sImage = $SubCategoriesRow['sImage'];

		echo "<div class='owl-item'>";
		echo "<div class='popular_category d-flex flex-column align-items-center justify-content-center'>";
		echo "<div class='popular_category_image'><a href='products.php?cId=1&sId=$sId'><img src='img_sub_cat/$sImage'></a></div>";
		echo "<div class='popular_category_text'><a href='products.php?cId=1&sId=$sId'>$sName</a></div>";
		echo "</div>";
		echo "</div>";
	}	
}
function getProductBySubCategories2()
{
	global $conn; 
	
	echo "<div class='product_grid'>";
		echo "<div class='product_grid_border'></div>";
		
			$sId = 1;
			$cId = 1;
			if(isset($_GET['sId']) && $_GET['sId']!=""){
				$sId = $_GET['sId'];
			}
			if(isset($_GET['cId']) && $_GET['sId']!=""){
				$cId = $_GET['cId'];
			}
			// define how many results you want per page
			$results_per_page = 10;
			// find out the number of results stored in database
			$sql="SELECT * FROM fh_products WHERE pSubCategoriesId = $sId  AND pIsVisible = 1";
			$result = mysqli_query($conn, $sql);
			
			$number_of_products = mysqli_num_rows($result);
			if($number_of_products==0){
				echo "<h4 style='padding:20px;'>No products where found in this category....</h4>";
			}
			// determine number of total pages available
			$number_of_pages = ceil($number_of_products/$results_per_page);
			// determine which page number visitor is currently on
			if (!isset($_GET['page'])) {
				$page = 1;
			} else {
				$page = $_GET['page'];
			}
			// determine the sql LIMIT starting number for the results on the displaying page
			$this_page_first_result = ($page-1)*$results_per_page;
			// retrieve selected results from database and display them on page
			$sql="SELECT * FROM fh_products WHERE pSubCategoriesId = $sId AND pIsVisible = 1 ORDER BY pPosition LIMIT " . $this_page_first_result . "," .  $results_per_page;
			$result = mysqli_query($conn, $sql);
			while($productsRow = mysqli_fetch_array($result)) {
				$pId = $productsRow['pId'];
				$pCode = $productsRow['pCode'];
				$pName = $productsRow['pName'];
				$pPrice = $productsRow['pPrice'];
				$pOurPrice = $productsRow['pOurPrice'];
				$pImage = $productsRow['pImage'];
				$pWarranty = $productsRow['pWarranty'];
				$pHasFreeDelivery = $productsRow['pHasFreeDelivery'];
				
				echo "<!-- Product Item -->";
				echo "<div class='product_item is_new'>";
					echo "<div class='product_border'></div>";
					echo "<div class='product_image d-flex flex-column align-items-center justify-content-center'><a href='item.php?cId=$cId&sId=$sId&pId=$pId'><img src='img_product/$pImage'></a></div>";
					echo "<div class='product_content'>";
						echo "<div class='product_price'><a href='item.php?cId=$cId&sId=$sId&pId=$pId'>$pOurPrice INR<span>$pPrice INR</span></a></div>";
						echo "<div class='product_name'><div><a href='item.php?cId=$cId&sId=$sId&pId=$pId' tabindex='0'>$pName</a></div></div>";
						echo "<div><div><a>$pWarranty year warranty</a></div></div>";
					echo "</div>";
					echo "<a href='products.php?cId=$cId&sId=$sId&page=$page&addId=$pId'><div class='product_fav'><i class='fas fa-heart'></i></div></a>";
					echo "<ul class='product_marks'>";
						echo "<li class='product_mark'>";
						if($pHasFreeDelivery==1)
						{
							echo "<img src='images/char_1.png'>";
						}
						echo "</li>";
					echo "</ul>";
				echo "</div>";
			}
			
		// display the links to the pages
		echo "</div>";
		echo "<div class='shop_page_nav d-flex flex-row'>";
			echo "<ul class='page_nav d-flex flex-row'>";
				for ($page=1;$page<=$number_of_pages;$page++) {
					echo "<a href='products.php?cId=$cId&sId=$sId&page=$page'><li>$page</li></a>";
				}
			echo "</ul>";
		echo "</div>";
}
function getProductCount(){
	global $conn; 
		
	if(isset($_GET['sId']) && $_GET['sId']!=""){
		$sId = $_GET['sId'];
		
		$productsQuery = "SELECT pId FROM fh_products WHERE pSubCategoriesId = $sId AND pIsVisible = 1 ORDER BY pPosition";
		
		$productsRows = mysqli_query($conn, $productsQuery);
		
		$count_products = mysqli_num_rows($productsRows);
		
		echo "$count_products";
		
	}
}
function getRecent(){
	global $conn; 
	
	if(isset($_COOKIE["recentItem"])) 
	{
		$recentItems = $_COOKIE["recentItem"];
		$recentItemsList = $recentItems;

		$length = strlen($recentItems);
		$lastIndex = $length-1;
		$lastChar = $recentItems[$lastIndex];
		if($lastChar==",")
		{
			$recentItemsList = substr_replace($recentItems ,"", -1);
		}

		$recentQuery = "SELECT * FROM fh_products WHERE pId IN ($recentItemsList) ";
		
		$recentRows = mysqli_query($conn, $recentQuery);
		while($productsRow = mysqli_fetch_array($recentRows)) {
			$pCode = $productsRow['pCode'];
			$pName = $productsRow['pName'];
			$pPrice = $productsRow['pPrice'];
			$pOurPrice = $productsRow['pOurPrice'];
			$pImage = $productsRow['pImage'];
			
			echo "<div class='owl-item'>";
				echo "<div class='viewed_item discount d-flex flex-column align-items-center justify-content-center text-center'>";
					echo "<div class='viewed_image'><img src='img_product/$pImage' alt=''></div>";
					echo "<div class='viewed_content text-center'>";
						echo "<div class='viewed_price'><span>&#8377; $pPrice </span> &#8377; $pOurPrice</div>";
						echo "<div class='viewed_name'><a href='#'>$pCode - $pName</a></div>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
		}
	}
	else
	{
		echo "<div class='owl-item'>";
			echo "<p>no recent products</p>";
		echo "</div>";
	}
}



	

?>
