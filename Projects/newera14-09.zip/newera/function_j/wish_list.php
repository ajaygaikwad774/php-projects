<?php
// $sName = $_GET['sName'];
require_once("connection.php");

          function loadwishlist()
          {
            global $conn; 
         $w_p_query ="SELECT `w_id`, `user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `color_code`, `total_price`, `product_image`, `isvisiable`, `added_date` FROM `fh_wishlist` WHERE isvisiable='1'";
         $w_p_details = mysqli_query($conn,$w_p_query);
           $w_item_count = mysqli_num_rows($w_p_details);

          if($w_item_count > 0)
           { 
     while ($wishlist_fetch_details = mysqli_fetch_array($w_p_details))
            {
                 $w_id = $wishlist_fetch_details['w_id'];
                 $p_name = $wishlist_fetch_details['product_name'];
                 $u_id = $wishlist_fetch_details['user_id']; 
                $us_name = $wishlist_fetch_details['user_name'];
                $color_code = $wishlist_fetch_details['color_code'];
                 $per_unit_price = $wishlist_fetch_details['per_unit_price'];
                 // $quantity_s_p = $wishlist_fetch_details['quantity_s'];
                $total_price_p = $wishlist_fetch_details['total_price'];
                 $product_image = $wishlist_fetch_details['product_image'];
             
             $wishlist_data[] = $wishlist_fetch_details;
         }
     }else
     {
        
        $wishlist_data = "No Data Found";
     }
     return $wishlist_data;
    }
?>