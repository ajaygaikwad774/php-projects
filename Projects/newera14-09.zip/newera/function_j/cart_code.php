<?php
// $sName = $_GET['sName'];
require_once("connection.php");

         $cart_p_query ="SELECT `cart_id`, `user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `quantity_s`, `color_code`, `total_price`, `product_image`, `isvisiable`, `added_date` FROM `fh_cart` WHERE isvisiable='1' ";
         $cart_p_details = mysqli_query($conn,$cart_p_query);
           $cart_item_count = mysqli_num_rows($cart_p_details);
           $cart_total_amount=0;
          if($cart_item_count > 0)
           { 
     while ($cart_fetch_details = mysqli_fetch_array($cart_p_details))
            {
                 $cart_id = $cart_fetch_details['cart_id'];
                 $p_name = $cart_fetch_details['product_name'];
                 $u_id = $cart_fetch_details['user_id']; 
                $us_name = $cart_fetch_details['user_name'];
                $color_code = $cart_fetch_details['color_code'];
                 $per_unit_price = $cart_fetch_details['per_unit_price'];
                 $quantity_s_p = $cart_fetch_details['quantity_s'];
                $total_price_p = $cart_fetch_details['total_price'];
                 $product_image = $cart_fetch_details['product_image'];
                 $cart_total_amount+=$total_price_p;
             
             $cart_data[] = $cart_fetch_details;
         }
     }else
     {
        
        $cart_d ="No Data Found";
     }

?>