<?php
        
 // Product
     	 function AllProduct()
     	{
           
        global $conn;
     	
         $query_0 ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`, `pPrice`, `pOurPrice`,`pImage` FROM `fh_products` WHERE pIsVisible ='1'";
         $P_data = mysqli_query($conn,$query_0);
         $count_p = mysqli_num_rows($P_data);
          if($count_p > 0)
          {

                 while ($SubCategoriesRow = mysqli_fetch_array($P_data))
            {
                
                 $product_details[] = $SubCategoriesRow;
             
            } 

           }else  
           {
                $product_details = "NO Data";
           } 

            return $product_details;

            }

             function SingleProduct($pid)
            {

             global $conn;

            	 $query_0 ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`, `pPrice`, `pOurPrice` FROM `fh_products` WHERE pIsVisible ='1'  AND pCode = '$pid'";
         $P_data = mysqli_query($conn,$query_0);

                 while ($SubCategoriesRow = mysqli_fetch_array($P_data))
            {
                
                 $s_product_details[] = $SubCategoriesRow;
             
            } 
             return $s_product_details;


            }
               

               function insertcartProduct($userid="",$username="",$pCode,$pName,$pOurPrice,$p_quantity="1",$color_code,$total_price,$product_image)
            {

             global $conn;

                  $query_cart_c ="INSERT INTO `fh_cart`( `user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `quantity_s`, `color_code`, `total_price`, `product_image`) VALUES ('$userid','$username','$pCode' ,'$pName','$pOurPrice','$p_quantity','$color_code','$total_price','$product_image' )";
                     $i_cart_data = mysqli_query($conn,$query_cart_c);

             return $i_cart_data;


            }



            //cart


             function AllCartProduct()
        {
           
        global $conn;
        
          $query_cart_c ="SELECT  * FROM `fh_cart` WHERE isvisiable = '1'";
         $all_d = mysqli_query($conn,$query_cart_c);
       $cart_count = mysqli_num_rows($all_d);
       if($cart_count > 0)
       {
       // $cart_quantity = mysqli_fetch_array($all_d);

                 while ($cart_da = mysqli_fetch_array($all_d))
            {
                
                 $cart_All_data[] = $cart_da;
             
            }

        }else
        {
             $cart_All_data[] ="No Data Found";
        }

    
            return $cart_All_data;



            }


       //       function SingleCartProduct($pid)
       //  {
           
       //  global $conn;
        
       //    $single_cart ="SELECT  * FROM `fh_cart` WHERE `isvisiable` = '1' AND  `product_id` = '$pid'";
       //   $single_d_a= mysqli_query($conn,$single_cart);
       // $s_cart_count = mysqli_num_rows($single_d_a);
       // if($s_cart_count > 0)
       // {
       // // $cart_quantity = mysqli_fetch_array($all_d);

       //           $cart_da = mysqli_fetch_array($single_d_a);
        
                
       //           $cart_single_data[] = $cart_da;
             
       //      }
       //  else
       //  {
       //       $cart_single_data[] ="No Data Found";
       //  }

    
       //      return $cart_single_data;



       //      }

            
    


        
?>