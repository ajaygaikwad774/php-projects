<?php
// $sName = $_GET['sName'];
require_once("connection.php");

          function hub_img()
          {
            global $conn; 
        
			$data_img = "SELECT `hp_id`, `slider`, `hp_1`, `hp_2`, `hp_3`, `shop_1`, `added_date` FROM `fh_homepage` order by hp_id DESC";
              $stmp_img = mysqli_query($conn, $data_img);
			   $item_count = mysqli_num_rows($stmp_img);

          if($item_count > 0)
			  
			  {
				  
			  $row_img=mysqli_fetch_array($stmp_img);
			  $slider_img = $row_img['slider'];
			  $hp_1 = $row_img['hp_1'];
			  $hp_2 = $row_img['hp_2'];
			  $hp_3 = $row_img['hp_3'];
			  $shop_1 = $row_img['shop_1'];
			
          
           
     while ($wishlist_fetch_details = mysqli_fetch_array($w_p_details))
            {
                 $w_id = $wishlist_fetch_details['w_id'];
                 $p_name = $wishlist_fetch_details['product_name'];
                 $u_id = $wishlist_fetch_details['user_id']; 
                $us_name = $wishlist_fetch_details['user_name'];
                $color_code = $wishlist_fetch_details['color_code'];
                 $per_unit_price = $wishlist_fetch_details['per_unit_price'];
                 // $quantity_s_p = $wishlist_fetch_details['quantity_s'];
                $total_price_p = $wishlist_fetch_details['total_price'];
                 $product_image = $wishlist_fetch_details['product_image'];
             
             $wishlist_data[] = $wishlist_fetch_details;
         }
     }else
     {
        
        $wishlist_data = "No Data Found";
     }
     return $wishlist_data;
    }
?>