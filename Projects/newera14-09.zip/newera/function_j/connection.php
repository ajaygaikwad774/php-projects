<?php

defined("DB_HOST") ? null : define("DB_HOST", "localhost");
defined("DB_USER") ? null : define("DB_USER", "root");
defined("DB_PASS") ? null : define("DB_PASS", "");
defined("DB_NAME") ? null : define("DB_NAME", "eshop");
 // define("DB_USER_TBL", "fh_users");
$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);
// if($conn)
// {
// 	echo "s";
// }else{
// 	echo "n";
// }
    
    $home_page="http://localhost/newera/";

require_once("functions.php");
require_once("cart_code.php");
 require_once("Product.php");
  require_once("wish_list.php");
 


?>