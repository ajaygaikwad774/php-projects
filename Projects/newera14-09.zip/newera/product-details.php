<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
         <?php require_once('_header_f/navbar.php'); ?>
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Product Details</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Product Details Area Start -->
          <?php 
          if(isset($_GET['pId']))
     { 
        $pId = $_GET['pId']; 
        // $sId_d = $_GET['sId'];
        // $sName = $_GET['sName'];
         $P_query_d ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`, `pPrice`, `pOurPrice`, `pQuantityDiscountPrice`, `pDeliveryCost`, `pGstRate`, `pWarranty`, `pDeliveryTime`, `pColour`, `pSeatMaterial`, `pBackMaterial`, `pDimension`, `pStatus`, `pPaymentCode`, `pFeaturesCode`, `pWarrantyCode`, `pDeliveryCode`, `pImage`, `pPosition`, `pIsVisible`, `pHasFreeDelivery`, `pDescription`, `pKeyword` FROM `fh_products` WHERE pCode ='$pId' AND pIsVisible='1' ";
         $p_deatails = mysqli_query($conn,$P_query_d);

              while ($Pro_details = mysqli_fetch_array($p_deatails))
            {
                 $sId = $Pro_details['pSubCategoriesId'];
                 $pOurPrice = $Pro_details['pOurPrice']; 
                $pName = $Pro_details['pName'];
                 $pCode = $Pro_details['pCode'];
                 $pPrice = $Pro_details['pPrice'];
                 $pImage = $Pro_details['pImage'];
                $pOurPrice = $Pro_details['pOurPrice'];
                 $pDescription = $Pro_details['pDescription'];
                 $pDeliveryCode = $Pro_details['pDeliveryCode'];
                  $pFeaturesCode = $Pro_details['pFeaturesCode'];
                 $pPaymentCode = $Pro_details['pPaymentCode'];  
                 $pWarrantyCode = $Pro_details['pWarrantyCode'];

                   $m_image[] = explode(",",$pImage);
     //print_r($m_image);
            for ($i=0; $i < count($m_image) ; $i++) { 
                
                    $m_image_1 = $m_image[$i][0];
              $m_image_2 = $m_image[$i][1];
             $m_image_3  = $m_image[$i][2]; 

                   }       
                    
?>
        <div class="product-details-area pt-80 pb-75">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-12">
                        <div class="single-product-image product-image-slider fix">
                            <div class="p-image"><img id="zoom1" src="<?php echo $m_image_1; ?>" alt="" data-zoom-image="img/product/20.jpg"></div>
                            <div class="p-image"><img src="<?php echo $m_image_2; ?>" alt=""></div>
                            <div class="p-image"><img src="<?php echo $m_image_3; ?>" alt=""></div>
                            <!-- <div class="p-image"><img src="assets/img/product/15.jpg" alt=""></div>
                            <div class="p-image"><img src="assets/img/product/35.jpg" alt=""></div> -->
                        </div>
                        <div class="single-product-thumbnail product-thumbnail-slider float-left" id="gallery_01">
                            <div class="p-thumb"><img src="<?php echo $m_image_1; ?>" alt=""></div>
                            <div class="p-thumb"><img src="<?php echo $m_image_2; ?>" alt=""></div>
                            <div class="p-thumb"><img src="<?php echo $m_image_3; ?>" alt=""></div>
                          <!--   <div class="p-thumb"><img src="assets/img/product/details/4.jpg" alt=""></div>
                            <div class="p-thumb"><img src="assets/img/product/details/5.jpg" alt=""></div> -->
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-12">
                        <div class="p-d-wrapper">
                            <h1><?php echo $pName; ?></h1>
                            <div class="p-rating-review">
                                <div class="product-rating">
                                    <i class="fa fa-star color"></i>
                                    <i class="fa fa-star color"></i>
                                    <i class="fa fa-star color"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <span>1 review</span>
                                <a href="#" class="scroll-down">Add your review</a>
                            </div>
                            <span class="p-d-price"style="text-decoration: line-through;">Price:<?php echo $pPrice ?></span>
                            <span class="p-d-price" style="font-size:2em;">Our Price:<?php echo $pOurPrice ?></span>
                            <span class="model-stock">In stock <span><span>SKU</span>24-MB01</span></span>
                            <div class="qty-cart-add">
                                <label for="qty">qty</label>
                                <input type="number" value="1" id="qty">
                                <a data-id="<?php echo $pCode; ?>">Add to cart</a>
                            </div>
                            <div class="p-d-buttons">
                                <a href="wishlist.html">Add to wish list</a>
                                <a href="#">Add to compare</a>
                                <a href="#">Email</a>
                            </div>
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container scroll-area">
                <div class="p-d-tab-container">
                    <div class="p-tab-btn">
                        <div class="nav" role="tablist">
                            <a class="active" href="#tab1" data-toggle="tab" role="tab" aria-selected="true" aria-controls="tab1">Details</a>
                            <a href="#tab2" data-toggle="tab" role="tab" aria-selected="false" aria-controls="tab2">Features</a>
                            <a  href="#tab3" data-toggle="tab" role="tab" aria-selected="true" aria-controls="tab3">Warranty</a>
                            <a href="#tab4" data-toggle="tab" role="tab" aria-selected="false" aria-controls="tab4">Payment</a>

                        </div>
                    </div>
                    <div class="p-d-tab tab-content">
                        <div class="tab-pane active show fade" id="tab1" role="tabpanel">
                            <div class="tab-items">
                                <div class="p-details-list">
                                    <p><?php echo $pDescription; ?></p>
                                    <span>Zippered main compartment.</span>
                                    <span>Front zippered pocket.</span>
                                    <span>Side mesh pocket.</span>
                                    <span>Cell phone pocket on strap.</span>
                                    <span>Adjustable shoulder strap and top carry handle.</span>
                                </div>
                            </div>
                        </div>

                         <div class="tab-pane show fade" id="tab2" role="tabpanel">
                            <div class="tab-items">
                                <div class="p-details-list">
                                    <p><?php echo $pFeaturesCode; ?></p>
                                    <span>Zippered main compartment.</span>
                                    <span>Front zippered pocket.</span>
                                    <span>Side mesh pocket.</span>
                                    <span>Cell phone pocket on strap.</span>
                                    <span>Adjustable shoulder strap and top carry handle.</span>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane show fade" id="tab3" role="tabpanel">
                            <div class="tab-items">
                                <div class="p-details-list">
                                    <p><?php echo $pWarrantyCode; ?></p>
                                    <span>Zippered main compartment.</span>
                                    <span>Front zippered pocket.</span>
                                    <span>Side mesh pocket.</span>
                                    <span>Cell phone pocket on strap.</span>
                                    <span>Adjustable shoulder strap and top carry handle.</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="tab-pane show fade" id="tab3" role="tabpanel">
                            <div class="tab-items">
                                <div class="p-details-list">
                                    <p><?php echo $pPaymentCode; ?></p>
                                    <span>Zippered main compartment.</span>
                                    <span>Front zippered pocket.</span>
                                    <span>Side mesh pocket.</span>
                                    <span>Cell phone pocket on strap.</span>
                                    <span>Adjustable shoulder strap and top carry handle.</span>
                                </div>
                            </div>
                        </div>
                        
                       <!--  <div class="tab-pane fade scroll-area" id="tab4" role="tabpanel">
                            <div class="tab-items">
                                <div class="p-review-wrapper">
                                    <div class="section-title title-style-2 text-center"><h2><span>Customer Reviews</span></h2></div>
                                    <h2>Newthemes</h2>
                                    <div class="p-tab-contents">
                                        <div class="p-tab-ratings">
                                            <div class="p-single-rating">
                                                <span>Quality</span>
                                                <div class="product-rating">
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                </div>
                                            </div>
                                            <div class="p-single-rating">
                                                <span>Price</span>
                                                <div class="product-rating">
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <div class="p-single-rating">
                                                <span>Value</span>
                                                <div class="product-rating">
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-rating-info">
                                            <span>Newthemes</span>
                                            <span>Review by <span>Newthemes</span></span>
                                            <span>Posted on 2/19/18</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="submit-review-wrapper">
                                    <h3>You're reviewing:</h3>
                                    <h4>Strive Shoulder Pack</h4>
                                    <div class="submit-rating-container">
                                        <div class="submit-rating-title"><h4>your rating</h4></div>
                                        <div class="submit-rating-wrapper">
                                            <div class="submit-single-rating">
                                                <span>price</span>
                                                <div class="rating-number">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <div class="submit-single-rating">
                                                <span>value</span>
                                                <div class="rating-number">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <div class="submit-single-rating">
                                                <span>quality</span>
                                                <div class="rating-number">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <form action="#" method="post" class="rating-form">
                                        <div class="rating-form-box">
                                            <label for="r-name" class="important">Nickname</label>
                                            <input type="text" placeholder="" id="r-name">
                                        </div>
                                        <div class="rating-form-box">
                                            <label for="r-summary" class="important">Summary</label>
                                            <input type="text" placeholder="" id="r-summary">
                                        </div>
                                        <div class="rating-form-box">
                                            <label for="r-review" class="important">Review</label>
                                            <textarea name="review" id="r-review" cols="30" rows="10"></textarea>
                                        </div>
                                        <button>Submit Review</button>
                                    </form>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Product Details Area End -->
        <!-- Related Products Area Start -->
        <div class="related-products-area text-center">
            <div class="container">
                <div class="section-title title-style-2">
                    <h2><span>Related Products</span></h2>
                </div>
            </div>
             <?php 
          if(isset($_GET['pId']))
          { 
               $pId = $_GET['pId']; 
               $P_query_d1 ="SELECT `pSubCategoriesId` FROM `fh_products` WHERE pCode ='$pId'";
               $p_deatails1 = mysqli_query($conn,$P_query_d1);
               $Pro_details1 = mysqli_fetch_array($p_deatails1);
               $sId1 = $Pro_details1['pSubCategoriesId'];
          }?>
            <div class="container">
                <div class="custom-row">
                    <div class="related-product-carousel owl-carousel carousel-style-one">

                    <?php 
                          if(isset($sId1))
                          { 
                               
                               $P_query_d11 ="SELECT `pName`, `pPrice`, `pOurPrice` FROM `fh_products` WHERE pSubCategoriesId ='$sId1'";
                               $p_deatails11 = mysqli_query($conn,$P_query_d11);
                               while($Pro_details11 = mysqli_fetch_array($p_deatails11)){

                                 $pName1 = $Pro_details11['pName'];
                                 $pPrice1 = $Pro_details11['pPrice'];
                                 $pOurPrice1 = $Pro_details11['pOurPrice'];
                          ?>   
                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.php?pId=<?php echo $pCode;?>">
                                        <img class="primary-image" src="assets/img/product/1.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/2.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName1;?></a></h4>
                                    <div class="product-price"><span>₹<?php echo $pPrice1;?></span></div>
                                </div>
                            </div>
                        </div>
                    <?php }}?>
                       <!--  <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.html">
                                        <img class="primary-image" src="assets/img/product/3.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/4.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.html">Strive Shoulder Pack</a></h4>
                                    <div class="product-price"><span>$32.00</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.html">
                                        <img class="primary-image" src="assets/img/product/5.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/6.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="product-details.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price"><span>$38.00</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.html">
                                        <img class="primary-image" src="assets/img/product/7.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/8.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.html">Wayfarer Messenger Bag</a></h4>
                                    <div class="product-price"><span>$40.00</span></div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Related Products Area End -->
        <!-- Upsell Products Area Start -->
        <div class="upsell-products-area text-center pt-70 pb-80">
            <div class="container">
                <div class="section-title title-style-2">
                    <h2><span>upsell products</span></h2>
                </div>
            </div>
            <div class="container">
                <div class="custom-row">
                    <div class="related-product-carousel owl-carousel carousel-style-one">
         <?php        
                $query_0 ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`,`pOurPrice` , `pPrice` FROM `fh_products` WHERE pIsVisible ='1' AND pSubCategoriesId order by pId desc limit 0,4";
                $P_data = mysqli_query($conn,$query_0);
                $count_p = mysqli_num_rows($P_data);
                if($count_p > 0)
                {
                 while ($SubCategoriesRow = mysqli_fetch_array($P_data))
                {
                 $sId = $SubCategoriesRow['pSubCategoriesId'];
                 $pOurPrice = $SubCategoriesRow['pOurPrice']; 
                 $pName = $SubCategoriesRow['pName'];
                 $pCode = $SubCategoriesRow['pCode'];
                 $pPrice = $SubCategoriesRow['pPrice'];
             
               ?> 

                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.php?pId=<?php echo $pCode;?>">
                                        <img class="primary-image" src="assets/img/product/9.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/10.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName;?></a></h4>
                                    <div class="product-price"><span>₹<?php echo $pPrice;?></span></div>
                                </div>
                            </div>
                        </div>

                    <?php } }?>
                       <!--  <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.html">
                                        <img class="primary-image" src="assets/img/product/19.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/20.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="product-details.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price"><span>$38.00</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.html">
                                        <img class="primary-image" src="assets/img/product/13.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/14.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.html">Strive Shoulder Pack</a></h4>
                                    <div class="product-price"><span>$32.00</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.html">
                                        <img class="primary-image" src="assets/img/product/22.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/21.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.html">Wayfarer Messenger Bag</a></h4>
                                    <div class="product-price"><span>$40.00</span></div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
         <?php  } } ?>
        <!-- Upsell Products Area End -->
	    <!-- Footer Area Start -->
	  <?php require_once('_header_f/footer.php'); ?>
      <script type="text/javascript">
           $(".qty-cart-add a").on('click', function()
      {
           
        $quantity = $('#qty').val();
        alert($quantity);
    $product_id = $(this).attr("data-id");
    alert($product_id);
     cartadd($product_id,$quantity);
    }); 
      </script>
    </body>
</html>