<?php

	//$pIsVisible = 0;
	//$pHasFreeDelivery=0;
	
	require("func/config_admin.php");
	
	if(isset($_POST['submit']))
	{
		
     $current_date = date('Y-m-d') ;
	 $demo = rand(1,10000);
	             $randm_a = $current_date.$demo;
		
		//getting the image from the field
        // $image_folder = "../product_image/";
        $img_folder = "images/hub_page/";
		//image one
	     $file_extension_1 = pathinfo($_FILES["image2"]["name"], PATHINFO_EXTENSION);
	echo    $pImageName_1 = $img_folder.'home_page_ad_'.$randm_a.'.'.$file_extension_1;
		$pImage_tmp_1 = $_FILES['image2']['tmp_name'];
	 move_uploaded_file($pImage_tmp_1,'../'."$pImageName_1");
	 
	     $img_folder = "images/hub_page/";
		//image one
	     $file_extension_2 = pathinfo($_FILES["image3"]["name"], PATHINFO_EXTENSION);
echo	    $pImageName_2 = $img_folder.'home_page_ad_'.$randm_a.'.'.$file_extension_2;
		$pImage_tmp_2 = $_FILES['image3']['tmp_name'];
	 move_uploaded_file($pImage_tmp_2,'../'."$pImageName_2");

	     $img_folder = "images/hub_page/";
         //image two
		$file_extension_3 = pathinfo($_FILES["image4"]["name"], PATHINFO_EXTENSION);
	 echo   $pImageName_3 = $img_folder.'home_page_ad_'.$randm_a.'.'.$file_extension_3;
		$pImage_tmp_3 = $_FILES['image4']['tmp_name'];
	 move_uploaded_file($pImage_tmp_3,'../'."$pImageName_3");


		//Shop Page images
		$file_extension_4 = pathinfo($_FILES["image5"]["name"], PATHINFO_EXTENSION);
	echo    $pImageName_4 = $img_folder.'shop_page.'.$file_extension_4;
		$pImage_tmp_4 = $_FILES['image5']['tmp_name'];
 	move_uploaded_file($pImage_tmp_4,'../'."$pImageName_4");
	

    $allowTypes = array('jpg','png','jpeg','gif');
    
	  $img_folder = "images/hub_page/";
    $images_arr = array();
    foreach($_FILES['images']['name'] as $key=>$val){
        $image_name = $_FILES['images']['name'][$key];
        $tmp_name   = $_FILES['images']['tmp_name'][$key];
        $size       = $_FILES['images']['size'][$key];
        $type       = $_FILES['images']['type'][$key];
        $error      = $_FILES['images']['error'][$key];
        
        // File upload path
        $fileName = basename($_FILES['images']['name'][$key]);
        $targetFilePath = '../'.$img_folder . $fileName;
		
		$targetFile = $img_folder . $fileName;
        
        // Check whether file type is valid
        $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
        if(in_array($fileType, $allowTypes)){    
            // Store images on the server
            if(move_uploaded_file($_FILES['images']['tmp_name'][$key],$targetFilePath)){
           echo $targetFile;
echo"<br>";		   
			  $images_arr[] = $targetFile;
            }
        }
    }
	
	 print_r($images_arr);
	 $List = implode(', ', $images_arr);
   //    $pImageName_1.','.$pImageName_2.','.$pImageName_3.','.$pImageName_4;
		// $pImageName = $pImageName_1.','.$pImageName_2.','.$pImageName_3.','.$pImageName_4;

	$insert_product_query = "INSERT INTO `fh_homepage`(`slider`, `hp_1`, `hp_2`, `hp_3`, `shop_1`) VALUES ('$List',' $pImageName_1',' $pImageName_2',' $pImageName_3',' $pImageName_4')";
              $stmp = mysqli_query($conn, $insert_product_query);
		// if($stmp) {
		// 	echo "<script>alert('product Has been inserted!')</script>";
		// 	echo "<script>window.open('index.php?view_products','_self')</script>";
		// }
	}
	header('Location:hub_page.php');
?>