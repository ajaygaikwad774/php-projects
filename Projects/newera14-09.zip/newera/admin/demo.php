
<!DOCTYPE html>
<html lang="en">

<head>

   
   
    <link rel="stylesheet" href="./assets/dropify/dist/css/dropify.min.css">

</head>
<?php 

?>

 <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">File Upload1</h4>
                                <label for="input-file-now">Your so fresh input file — Default version</label>
                                <input type="file" id="input-file-now" class="dropify" />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">File Upload2</h4>
                                <label for="input-file-now-custom-1">You can add a default value</label>
                                <input type="file" id="input-file-now-custom-1" class="dropify" data-default-file="../assets/plugins/dropify/src/images/test-image-1.jpg" />
                            </div>
                        </div>
                    </div>
                </div>
</html>
<script src="./assets/js/jquery.3.2.1.min.js"></script>
<script src="./assets/dropify/dist/js/dropify.min.js"></script>
<script type="text/javascript">
    $("document").ready(function(){

      // Basic
        $('.dropify').dropify();

        // Translated
        $('.dropify-fr').dropify({
            messages: {
                default: 'Glissez-déposez un fichier ici ou cliquez',
                replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                remove: 'Supprimer',
                error: 'Désolé, le fichier trop volumineux'
            }
        });

        // Used events
        var drEvent = $('#input-file-events').dropify();

        drEvent.on('dropify.beforeClear', function(event, element) {
            return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
        });

        drEvent.on('dropify.afterClear', function(event, element) {
            alert('File deleted');
        });

        drEvent.on('dropify.errors', function(event, element) {
            console.log('Has Errors');
        });

        var drDestroy = $('#input-file-to-destroy').dropify();
        drDestroy = drDestroy.data('dropify')
        $('#toggleDropify').on('click', function(e) {
            e.preventDefault();
            if (drDestroy.isDropified()) {
                drDestroy.destroy();
            } else {
                drDestroy.init();
            }
        });
        });

    </script>