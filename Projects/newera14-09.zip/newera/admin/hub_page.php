
<?php
			$data_img = "SELECT `id`, `slider1`, `slider2`, `slider3`, `slider4`, `slider5`, `hp_1`, `hp_2`, `hp_3`, `shop_1`, `b1`, `b2`, `b3`, `modified_date` FROM `fh_homepage` WHERE 1";
              $stmp_img = mysqli_query($conn, $data_img);
              $row_img = mysqli_fetch_array($stmp_img);
			 // $row_img=mysqli_fetch_assoc($stmp_img);
			  $slider_img1 = $row_img['slider1'];
			  $slider_img2 = $row_img['slider2'];
			  $slider_img3 = $row_img['slider3'];
			  $slider_img4 = $row_img['slider4'];
			  $slider_img5 = $row_img['slider5'];
			  $hp_1 = $row_img['hp_1'];
			  $hp_2 = $row_img['hp_2'];
			  $hp_3 = $row_img['hp_3'];
			  $shop_1 = $row_img['shop_1'];
			  $banner1= $row_img['b1'];
			  $banner2= $row_img['b2'];
			  $banner3= $row_img['b3'];

			  if($slider_img1=='-'){
                 $slider_img1='';
			  }else{
                 $slider_img1=$home_page.$slider_img1;
			  }

			  if($slider_img2=='-'){
                 $slider_img2='';
			  }else{
                 $slider_img2=$home_page.$slider_img2;
			  }

			  if($slider_img3=='-'){
                 $slider_img3='';
			  }else{
                 $slider_img3=$home_page.$slider_img3;
			  }

			  if($slider_img4=='-'){
                 $slider_img4='';
			  }else{
                 $slider_img4=$home_page.$slider_img4;
			  }

			  if($slider_img5=='-'){
                 $slider_img5='';
			  }else{
                 $slider_img5=$home_page.$slider_img5;
			  }

			  if($hp_1=='-'){
                 $hp_1='';
			  }else{
                 $hp_1=$home_page.$hp_1;
			  }

			  if($hp_2=='-'){
                 $hp_2='';
			  }else{
                 $hp_2=$home_page.$hp_2;
			  }

			  if($hp_3=='-'){
                 $hp_3='';
			  }else{
                 $hp_3=$home_page.$hp_3;
			  }

			  if($shop_1=='-'){
                 $shop_1='';
			  }else{
                 $shop_1=$home_page.$shop_1;
			  }

			  if($banner1=='-'){
                 $banner1='';
			  }else{
                 $banner1=$home_page.$banner1;
			  }

			  if($banner2=='-'){
                 $banner2='';
			  }else{
                 $banner2=$home_page.$banner2;
			  }

			  if($banner3=='-'){
                 $banner3='';
			  }else{
                 $banner3=$home_page.$banner3;
			  }
			  
			  
			?>    


<h3 class="page-title"><b>Slider Images</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
			
	<form action="upload.php" method="POST" enctype="multipart/form-data"> 

    <div class="row">
      <div class="col-sm-12">
        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Slider1</label>
          <input type="file" name="image1" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $slider_img1; ?>">
          <span>(Image size 1920*705)</span>
        </div>

        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Slider2</label>
          <input type="file" name="image2" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $slider_img2; ?>" multiple id="fileToUpload">
          <span>(Image size 1920*705)</span>
        </div>

        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Slider3</label>
          <input type="file" name="image3" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $slider_img3; ?>" multiple id="fileToUpload">
          <span>(Image size 1920*705)</span>
        </div>

        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Slider4</label>
          <input type="file" name="image4" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $slider_img4; ?>" multiple id="fileToUpload">
          <span>(Image size 1920*705)</span>
        </div>

        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Slider5</label>
          <input type="file" name="image5" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $slider_img5; ?>" multiple id="fileToUpload">
          <span>(Image size 1920*705)</span>
        </div>

        
      </div>
    </div>
		<br/>
    <center>
		<input type="submit" class="btn btn-primary" name="insert_slider" value="Insert Slider Images"/>
    </center>
    <br/>
	</form>
          <!-- END TABLE STRIPED -->
		</div>
	</div>
</div>


<h3 class="page-title"><b>Ads Images</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
			
	<form action="upload.php" method="POST" enctype="multipart/form-data"> 

    <div class="row">
      <div class="col-sm-12">
       



<div class="col-sm-4">
          <label for="input-file-now-custom-1">Image1</label>
          <input type="file" name="image1" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $hp_1; ?>" id="fileToUpload">
          <span>(Image size 370*213)</span>
        </div>

        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Image2</label>
          <input type="file" name="image2" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $hp_2; ?>" id="fileToUpload">
           <span>(Image size 370*213)</span>
        </div>
        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Image3</label>
          <input type="file" name="image3" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $hp_3; ?>" id="fileToUpload">
          <span>(Image size 370*213)</span>
        </div> 
        <div class="col-sm-4">
          <label for="input-file-now-custom-1">Shop Page</label>
          <input type="file" name="image4" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $shop_1; ?>" id="fileToUpload">
          <span>(Image size 870*255)</span>
        </div>

</div>
    </div>
		<br/>
    <center>
		<input type="submit" class="btn btn-primary" name="insert_ads" value="Insert Ads Images"/>
    </center>
    <br/>
	</form>
          <!-- END TABLE STRIPED -->
		</div>
	</div>
</div>        

<h3 class="page-title"><b>Banner Images</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">

	<form action="upload.php" method="POST" enctype="multipart/form-data"> 

    <div class="row">
      <div class="col-sm-12">



		<div class="col-sm-4" >
          <h4 class="title">Image 1</h4>
                     <div class="text-center">
                        <input type="file" name="image1" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $banner1; ?>" >
                        
                         <span>(Image size 270*394)</span>
                        </div>
		                </div>
		

		<div class="col-sm-4">
			
				<h4 class="title">Image 2</h4>
                        <div class="text-center">
                        <input type="file" name="image2" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $banner2; ?>" >
                        
                       <span>(Image size 570*394)</span>
                      </div>
		    </div>
		

		<div class="col-sm-4">
			
				<h4 class="title">Image 3</h4>
                       <div class="text-center">
                        <input type="file" name="image3" id="input-file-now-custom-1" class="dropify" data-default-file="<?php echo $banner3; ?>" >
                        
                        <span>(Image size 270*394)</span>
                      </div>
		    </div>

 

    </div>
    </div>
		<br/>
    <center>
		<input type="submit" class="btn btn-primary" name="insert_banner" value="Insert Banner Images"/>
    </center>
    <br/>
	</form>
          <!-- END TABLE STRIPED -->
		</div>
	</div>
</div>        