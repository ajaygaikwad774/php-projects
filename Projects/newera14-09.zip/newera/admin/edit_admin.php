<h3 class="page-title"><b>Edit and Update the products</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">

<?php 


if(isset($_GET['edit_admin'])){

	$aId = $_GET['edit_admin']; 
	
	$get_ad = "select * from fh_admin where aId='$aId'";
	
	$run_admin = mysqli_query($conn, $get_ad); 
	
	$row_ad = mysqli_fetch_array($run_admin);
		
		$aId = $row_ad['aId'];
		$aEmail = $row_ad['aEmail'];
		$aUsername = $row_ad['aUsername'];
		$aPassword = $row_ad['aPassword'];
		$aActive = $row_ad['aActive'];
		$aForget = $row_ad['aForget'];
		$aContact = $row_ad['aContact'];
}
		
?>



	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table class="table table-striped">
			<tr>
				<td align="right"><b>aId:</b></td>
				<td><?php echo $aId;?></td>
			</tr>			
			<tr>
				<td align="right"><b>aEmail:</b></td>
				<td><input type="email" name="aEmail" size="60" value="<?php echo $aEmail;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>aUsername:</b></td>
				<td><input type="text" name="aUsername" size="60" value="<?php echo $aUsername;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>aPassword:</b></td>
				<td><input type="text" name="aPassword" size="60" value="<?php echo $aPassword;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>aActive:</b></td>
				<td><input type="text" name="aActive" size="60" value="<?php echo $aActive;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>aForget:</b></td>
				<td><input type="text" name="aForget" size="60" value="<?php echo $aForget;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>aContact:</b></td>
				<td><input type="text" name="aContact" size="60" value="<?php echo $aContact;?>"/></td>
			</tr>
			
			
			<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="update_admin" value="Update Admin Now"/></td>
			</tr>
		
		</table>
	
	
	</form>
 
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php 

	if(isset($_POST['update_admin'])){
	
		//getting the text data from the fields
		
		$update_id = $aId;	
		$aEmail = $_POST['aEmail'];
		$aUsername = $_POST['aUsername'];
		$aPassword = $_POST['aPassword'];
		$aActive = $_POST['aActive'];
		$aForget = $_POST['aForget'];
		$aContact = $_POST['aContact'];
	
		$update_admin_query = "update fh_admin set aEmail='$aEmail',aUsername='$aUsername',aPassword='$aPassword',aActive='$aActive',aForget='$aForget',aContact='$aContact' where aId='$update_id'";

		$updated_admin = mysqli_query($conn, $update_admin_query);

		if($updated_admin){

		echo "<script>alert('Admin Has been updated!')</script>";
		echo "<script>window.open('index.php?view_admin','_self')</script>";

		}
	}
?>