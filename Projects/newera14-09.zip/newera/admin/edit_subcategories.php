<h3 class="page-title"><b>Update SubCategories</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<?php 
if(isset($_GET['edit_subcategories'])){

	$sId = $_GET['edit_subcategories']; 
	
	$get_subcat = "select * from fh_subcategories where sId='$sId'";
	
	$run_subcat = mysqli_query($conn, $get_subcat); 
	
	$row_subcat = mysqli_fetch_array($run_subcat);
	
		$sId = $row_subcat['sId'];
		$scId = $row_subcat['scId'];
		$sParentCategories = $row_subcat['sParentCategories'];
		$sName = $row_subcat['sName']; 
		$sImage = $row_subcat['sImage'];
		$sPosition = $row_subcat['sPosition']; 
		$sIsVisible = $row_subcat['sIsVisible'];
}	
?>

	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" class="table table-striped">
			<tr>
				<td align="right"><b>SubCategory id:</b></td>
				<td><?php echo $sId;?></td>
			</tr>
			<tr>
				<td align="right"><b>SubCategory name:</b></td>
				<td><input type="text" name="subcategory_name" value="<?php echo $sName;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>Category Id:</b></td>
				<td>
				<select name="subcategory_scId" >
					
					<?php 
						$get_cats = "select * from fh_categories";

						$run_cats = mysqli_query($conn, $get_cats);

						while ($row_cats = mysqli_fetch_array($run_cats)){

							$cId = $row_cats['cId']; 
							$cName = $row_cats['cName'];
							
							if($cId==$scId)
							{echo "<option selected='selected' value='$cId'>$cId => $cName</option>";}
							else
							{echo "<option value='$cId'>$cId => $cName</option>";}
						}	
					?>
				</select>&nbsp;&nbsp;&nbsp;<?php echo $scId;?>
				</td>
			</tr>
			<tr>
				<td align="right"><b>Category name:</b></td>
				<td>
				<select name="subcategory_sParentCategories" >
					
					<?php 
						$get_cats = "select * from fh_categories";

						$run_cats = mysqli_query($conn, $get_cats);

						while ($row_cats = mysqli_fetch_array($run_cats)){

							$cId = $row_cats['cId']; 
							$cName = $row_cats['cName'];
							if($cId==$scId)
							{echo "<option selected='selected' value='$cName'>$cId => $cName</option>";}
							else
							{echo "<option value='$cName'>$cId => $cName</option>";}
						}	
					?>
				</select>&nbsp;&nbsp;&nbsp;<?php echo $sParentCategories;?>
				</td>
			</tr>
			
			<tr>
				<td align="right"><b>SubCategory image:</b></td>
				<td><input type="file" name="subcategory_image" /><br><img src="../img_sub_cat/<?php echo $sImage; ?>" width="60" height="60"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>SubCategory position:</b></td>
				<td><input type="text" name="subcategory_position" value="<?php echo $sPosition;?>"/></td>
			</tr>
			<tr>
				<td align="right"><b>SubCategory isVisible:</b></td>
				<td><input type="checkbox" name="subcategory_isVisible" value="Yes" checked/>&nbsp;&nbsp;&nbsp;<?php echo $sIsVisible;?></td>
			</tr>
			
			<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="update_subcategories" value="Update SubCategories Now"/></td>
			</tr>
		
		</table>
	</form>
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php 

	if(isset($_POST['update_subcategories'])){
		
		$update_id = $sId;
		
		$subcategory_isVisible = 0;
		
		//getting the text data from the fields
		$subcategory_scId= $_POST['subcategory_scId'];
		$subcategory_sParentCategories= $_POST['subcategory_sParentCategories'];
		$subcategory_name = $_POST['subcategory_name'];
		$subcategory_position = $_POST['subcategory_position'];
		
		if(isset($_POST['subcategory_isVisible']) && $_POST['subcategory_isVisible'] == 'Yes'){
			$subcategory_isVisible=1;
		}
		
		if($_FILES['subcategory_image']['name'] == "") {
			$subcategory_image = $sImage;
		}
		else
		{
			$subcategory_image = $_POST['subcategory_image'];
			
			//getting the image from the field
			$subcategory_image = $_FILES['subcategory_image']['name'];
			$subcategory_image_tmp = $_FILES['subcategory_image']['tmp_name'];
			
			move_uploaded_file($subcategory_image_tmp,"../img_sub_cat/$subcategory_image");
		}
		
		
	
		 $update_subcategories_query = "update fh_subcategories set scId='$subcategory_scId',sParentCategories='$subcategory_sParentCategories',sName='$subcategory_name',sImage='$subcategory_image',sPosition='$subcategory_position',sIsVisible='$subcategory_isVisible' where sId='$update_id'";
		 
		 $updated_subcategories = mysqli_query($conn, $update_subcategories_query);
		 
		 if($updated_subcategories){
		 
		 echo "<script>alert('subcategories Has been updated!')</script>";
		 echo "<script>window.open('index.php?view_subcategories','_self')</script>";
		 
		 }
	}
?>