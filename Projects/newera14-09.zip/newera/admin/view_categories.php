<h3 class="page-title"><b>View, Edit and Delete Categories</b>&nbsp;&nbsp;&nbsp;<a href="index.php?add_categories" class="btn btn-primary" role="button">Add Categories</a></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<table class="table table-striped"> 

	<tr>
		<th>Category ID</th>
		<th>Category Name</th>
		<th>Category Image</th>
		<th>Category Position</th>
		<th>Category IsVisible</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php 
	
	$get_cat = "select * from fh_categories order by cPosition";
	
	$run_cat = mysqli_query($conn, $get_cat); 
	
	while ($row_cat=mysqli_fetch_array($run_cat)){
		
		$cId = $row_cat['cId'];
		$cName = $row_cat['cName'];
		$cImage = $row_cat['cImage'];
		$cPosition = $row_cat['cPosition'];
		$cIsVisible = $row_cat['cIsVisible'];
	
	?>
	<tr align="center">
		<td><?php echo $cId;?></td>
		<td><?php echo $cName;?></td>
		<td><?php echo $cImage;?><br><img src="../img_cat/<?php echo $cImage; ?>" width="60" height="60"/></td>
		<td><?php echo $cPosition;?></td>
		<td><?php echo $cIsVisible;?></td>
		<td><a href="index.php?edit_categories=<?php echo $cId; ?>">Edit</a></td>
		<td><a href="index.php?delete_categories=<?php echo $cId;?>">Delete</a></td>
	
	</tr>
	<?php } ?>




</table>
				</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>