<!-- <?php
//require_once("func/config_admin.php");
//$todate=date('Y-m-d h:i:s');
//if($_FILES['file']['name'] != ''){
   // $test = explode('.', $_FILES['file']['name']);
   // $extension = end($test);    
   // $name = 'img_'.date('Y_m_d_h_i_s').'.'.$extension;

   // $location = 'uploads/'.$name;
   // move_uploaded_file($_FILES['file']['tmp_name'], $location);

  //  $sql = "INSERT INTO `fh_banners`(`category`, `banner_title`, `img_url`, `adding_date`) VALUES ('Banner Image','image1','$location','$todate')";
   // $result = mysqli_query($conn,$sql);
  //  if($result>0){
  //   echo 'success';
  //  }else{
  //   echo 'failed';
  //  }

    
//}

?> -->


<?php


    
    require("func/config_admin.php");
    
    if(isset($_POST['insert_slider']))
    {
        
        //getting the image from the field
        $image_folder = "../product_image/";
        $img_folder = "images/hub_page/";
       if($_FILES['image1']['name'] != ""){ 
          // echo "hi1";
             //image one
         $file_extension_1 = pathinfo($_FILES["image1"]["name"], PATHINFO_EXTENSION);
        $pImageName_1 = $img_folder.'slider_1'.'.'.$file_extension_1;
        $pImage_tmp_1 = $_FILES['image1']['tmp_name'];
        move_uploaded_file($pImage_tmp_1,'../'."$pImageName_1");
          
       }else{
          $pImageName_1 ="-";
       }

       if($_FILES['image2']['name'] != ""){ 

             //image one
         $file_extension_2 = pathinfo($_FILES["image2"]["name"], PATHINFO_EXTENSION);
        $pImageName_2 = $img_folder.'slider_2'.'.'.$file_extension_2;
        $pImage_tmp_2 = $_FILES['image2']['tmp_name'];
        move_uploaded_file($pImage_tmp_2,'../'."$pImageName_2");
          
       }else{
          $pImageName_2 ="-";
       }

        if($_FILES['image3']['name'] != ""){ 

             //image one
         $file_extension_3 = pathinfo($_FILES["image3"]["name"], PATHINFO_EXTENSION);
        $pImageName_3 = $img_folder.'slider_3'.'.'.$file_extension_3;
        $pImage_tmp_3 = $_FILES['image3']['tmp_name'];
        move_uploaded_file($pImage_tmp_3,'../'."$pImageName_3");
          
       }else{
          $pImageName_3 ="-";
       }

       if($_FILES['image4']['name'] != ""){ 

             //image one
         $file_extension_4 = pathinfo($_FILES["image4"]["name"], PATHINFO_EXTENSION);
        $pImageName_4 = $img_folder.'slider_4'.'.'.$file_extension_4;
        $pImage_tmp_4 = $_FILES['image4']['tmp_name'];
        move_uploaded_file($pImage_tmp_4,'../'."$pImageName_4");
          
       }else{
          $pImageName_4 ="-";
       }

       if($_FILES['image5']['name'] != ""){ 

             //image one
         $file_extension_5 = pathinfo($_FILES["image5"]["name"], PATHINFO_EXTENSION);
        $pImageName_5 = $img_folder.'slider_5'.'.'.$file_extension_5;
        $pImage_tmp_5 = $_FILES['image5']['tmp_name'];
        move_uploaded_file($pImage_tmp_5,'../'."$pImageName_5");
          
       }else{
          $pImageName_5 ="-";
       }

       $query="UPDATE `fh_homepage` SET `slider1`='$pImageName_1',`slider2`='$pImageName_2',`slider3`='$pImageName_3',`slider4`='$pImageName_4',`slider5`='$pImageName_5' WHERE 1";
       
        $stmp = mysqli_query($conn, $query);
        if($stmp) {
         echo "<script>alert('product Has been inserted!')</script>";
         echo "<script>window.open('index.php','_self')</script>";
        }

    }else  if(isset($_POST['insert_ads']))
    {
        
        //getting the image from the field
        $image_folder = "../product_image/";
        $img_folder = "images/hub_page/";
       if($_FILES['image1']['name'] != ""){ 
         //  echo "hi1";
             //image one
         $file_extension_1 = pathinfo($_FILES["image1"]["name"], PATHINFO_EXTENSION);
        $pImageName_1 = $img_folder.'ads_1'.'.'.$file_extension_1;
        $pImage_tmp_1 = $_FILES['image1']['tmp_name'];
        move_uploaded_file($pImage_tmp_1,'../'."$pImageName_1");
          
       }else{
          $pImageName_1 ="-";
       }

       if($_FILES['image2']['name'] != ""){ 

             //image one
         $file_extension_2 = pathinfo($_FILES["image2"]["name"], PATHINFO_EXTENSION);
        $pImageName_2 = $img_folder.'ads_2'.'.'.$file_extension_2;
        $pImage_tmp_2 = $_FILES['image2']['tmp_name'];
        move_uploaded_file($pImage_tmp_2,'../'."$pImageName_2");
          
       }else{
          $pImageName_2 ="-";
       }

        if($_FILES['image3']['name'] != ""){ 

             //image one
         $file_extension_3 = pathinfo($_FILES["image3"]["name"], PATHINFO_EXTENSION);
        $pImageName_3 = $img_folder.'ads_3'.'.'.$file_extension_3;
        $pImage_tmp_3 = $_FILES['image3']['tmp_name'];
        move_uploaded_file($pImage_tmp_3,'../'."$pImageName_3");
          
       }else{
          $pImageName_3 ="-";
       }

       if($_FILES['image4']['name'] != ""){ 

             //image one
         $file_extension_4 = pathinfo($_FILES["image4"]["name"], PATHINFO_EXTENSION);
        $pImageName_4 = $img_folder.'ads_4'.'.'.$file_extension_4;
        $pImage_tmp_4 = $_FILES['image4']['tmp_name'];
        move_uploaded_file($pImage_tmp_4,'../'."$pImageName_4");
          
       }else{
          $pImageName_4 ="-";
       }


       
       $query="UPDATE `fh_homepage` SET `hp_1`='$pImageName_1',`hp_2`='$pImageName_2',`hp_3`='$pImageName_3',`shop_1`='$pImageName_4' WHERE 1";
       
        $stmp = mysqli_query($conn, $query);
        if($stmp) {
         echo "<script>alert('product Has been inserted!')</script>";
         echo "<script>window.open('index.php','_self')</script>";
        }
        

    }else if(isset($_POST['insert_banner'])){
        //getting the image from the field
        $image_folder = "../product_image/";
        $img_folder = "images/hub_page/";
       if($_FILES['image1']['name'] != ""){ 
          
             //image one
         $file_extension_1 = pathinfo($_FILES["image1"]["name"], PATHINFO_EXTENSION);
        $pImageName_1 = $img_folder.'b_1'.'.'.$file_extension_1;
        $pImage_tmp_1 = $_FILES['image1']['tmp_name'];
        move_uploaded_file($pImage_tmp_1,'../'."$pImageName_1");
          
       }else{
          $pImageName_1 ="-";
       }

       if($_FILES['image2']['name'] != ""){ 

             //image one
         $file_extension_2 = pathinfo($_FILES["image2"]["name"], PATHINFO_EXTENSION);
        $pImageName_2 = $img_folder.'b_2'.'.'.$file_extension_2;
        $pImage_tmp_2 = $_FILES['image2']['tmp_name'];
        move_uploaded_file($pImage_tmp_2,'../'."$pImageName_2");
          
       }else{
          $pImageName_2 ="-";
       }

        if($_FILES['image3']['name'] != ""){ 

             //image one
         $file_extension_3 = pathinfo($_FILES["image3"]["name"], PATHINFO_EXTENSION);
        $pImageName_3 = $img_folder.'b_3'.'.'.$file_extension_3;
        $pImage_tmp_3 = $_FILES['image3']['tmp_name'];
        move_uploaded_file($pImage_tmp_3,'../'."$pImageName_3");
          
       }else{
          $pImageName_3 ="-";
       }

    $query="UPDATE `fh_homepage` SET `b1`='$pImageName_1',`b2`='$pImageName_2',`b3`='$pImageName_3' WHERE 1";
       
        $stmp = mysqli_query($conn, $query);
        if($stmp) {
         echo "<script>alert('product Has been inserted!')</script>";
         echo "<script>window.open('index.php','_self')</script>";
        }
    }