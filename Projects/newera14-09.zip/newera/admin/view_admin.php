<h3 class="page-title"><b>View, Edit and Delete Admin</b>&nbsp;&nbsp;&nbsp;<a href="index.php?add_admin" class="btn btn-primary" role="button">Add Admin</a></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<table class="table table-striped"> 

	<tr>
		<th>Admin ID</th>
		<th>Admin Email</th>
		<th>Admin Username</th>
		<th>Admin Password</th>
		<th>Admin Active</th>
		<th>Admin Forget</th>
		<th>Admin Contact</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php 
	
	$get_admin = "select * from fh_admin";
	
	$run_admin = mysqli_query($conn, $get_admin); 
	
	while ($row_admin=mysqli_fetch_array($run_admin)){
		
		$aId = $row_admin['aId'];
		$aEmail = $row_admin['aEmail'];
		$aUsername = $row_admin['aUsername'];
		$aPassword = $row_admin['aPassword'];
		$aActive = $row_admin['aActive'];
		$aForget = $row_admin['aForget'];
		$aContact = $row_admin['aContact'];
	
	?>
	<tr align="center">
		<td><?php echo $aId;?></td>
		<td><?php echo $aEmail;?></td>
		<td><?php echo $aUsername;?></td>
		<td><?php echo $aPassword;?></td>
		<td><?php echo $aActive;?></td>
		<td><?php echo $aForget;?></td>
		<td><?php echo $aContact;?></td>
		<td><a href="index.php?edit_admin=<?php echo $aId; ?>">Edit</a></td>
		<td><a href="index.php?delete_admin=<?php echo $aId;?>">Delete</a></td>
	
	</tr>
	<?php } ?>




</table>
				</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>