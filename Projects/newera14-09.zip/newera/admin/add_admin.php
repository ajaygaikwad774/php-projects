<h3 class="page-title"><b>Add new Categories</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" class="table table-striped">
			<tr>
				<td align="right"><b>aEmail:</b></td>
				<td><input type="email" name="aEmail" size="60" required/></td>
			</tr>
			<tr>
				<td align="right"><b>aUsername:</b></td>
				<td><input type="text" name="aUsername" size="60" required/></td>
			</tr>
			<tr>
				<td align="right"><b>aPassword:</b></td>
				<td><input type="text" name="aPassword" size="60" required/></td>
			</tr>
			<tr>
				<td align="right"><b>aActive:</b></td>
				<td><input type="text" name="aActive" size="60" required/></td>
			</tr>
			<tr>
				<td align="right"><b>aForget:</b></td>
				<td><input type="text" name="aForget" size="60" required/></td>
			</tr>
			<tr>
				<td align="right"><b>aContact:</b></td>
				<td><input type="text" name="aContact" size="60" required/></td>
			</tr>
			
			
			<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="insert_admin" value="Insert Admin Now"/></td>
			</tr>
		
		</table>
	</form>
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php 

	if(isset($_POST['insert_admin'])){
		
		$aEmail = $_POST['aEmail'];
		$aUsername = $_POST['aUsername'];
		$aPassword = $_POST['aPassword'];
		$aActive = $_POST['aActive'];
		$aForget = $_POST['aForget'];
		$aContact = $_POST['aContact'];
		
	
		$insert_admin_query = "insert into fh_admin (aEmail,aUsername,aPassword,aActive,aForget,aContact) values ('$aEmail','$aUsername','$aPassword','$aActive','$aForget','$aContact')";

		if(mysqli_query($conn, $insert_admin_query)){

		echo "<script>alert('admin Has been inserted!')</script>";
		echo "<script>window.open('index.php?view_admin','_self')</script>";

		}
	}
?>