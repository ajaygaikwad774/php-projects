<?php  
	
	if(isset($_GET['delete_categories'])){
	
	$delete_id = $_GET['delete_categories'];
	
	$delete_pro = "delete from fh_categories where cId='$delete_id'"; 
	
	$run_delete = mysqli_query($conn, $delete_pro); 
	
	if($run_delete){
	
	echo "<script>alert('A categories has been deleted!')</script>";
	echo "<script>window.open('index.php?view_categories','_self')</script>";
	}
	
	}
?>