<?php  
	
	if(isset($_GET['delete_admin'])){
	
		$delete_id = $_GET['delete_admin'];
		
		$delete_admin = "delete from admin where aId='$delete_id'"; 
		
		$run_delete = mysqli_query($conn, $delete_admin); 
		
		if($run_delete){
			
			echo "<script>alert('Admin is deleted!')</script>";
			echo "<script>window.open('index.php?view_admin','_self')</script>";
		}
	
	}
?>