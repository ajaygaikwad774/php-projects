<style type="text/css">
	.btn-file {
    position: relative;
    overflow: hidden;
    vertical-align: middle;
}
.btn-file>input {
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 100%;
    margin: 0;
    font-size: 23px;
    cursor: pointer;
    filter: alpha(opacity=0);
    opacity: 0;
    direction: ltr;
}
.fileinput {
    display: inline-block;
    margin-bottom: 9px;
}
.fileinput .form-control {
    display: inline-block;
    padding-top: 7px;
    padding-bottom: 5px;
    margin-bottom: 0;
    vertical-align: middle;
    cursor: text;
}
.fileinput .thumbnail {
    display: inline-block;
    margin-bottom: 10px;
    overflow: hidden;
    text-align: center;
    vertical-align: middle;
    max-width: 250px;
    box-shadow: 0 10px 30px -12px rgba(0, 0, 0, .42), 0 4px 25px 0 rgba(0, 0, 0, .12), 0 8px 10px -5px rgba(0, 0, 0, .2);
}
.fileinput .thumbnail.img-circle {
    border-radius: 50%;
    max-width: 100px;
}
.fileinput .thumbnail>img {
    max-height: 100%;
    width: 100%;
  }

.fileinput .thumbnail>img {
    height: 150px !important;
    width: 250px !important;
  }    
.fileinput .btn {
    vertical-align: middle;
}
.fileinput-exists .fileinput-new, .fileinput-new .fileinput-exists {
    display: none;
}
.fileinput-inline .fileinput-controls {
    display: inline;
}
.fileinput-filename {
    display: inline-block;
    overflow: hidden;
    vertical-align: middle;
}
.form-control .fileinput-filename {
    vertical-align: bottom;
}
.fileinput.input-group {
    display: table;
}
.fileinput.input-group>* {
    position: relative;
    z-index: 2;
}
.fileinput.input-group>.btn-file {
    z-index: 1;
}
.fileinput-new.input-group .btn-file, .fileinput-new .input-group .btn-file {
    border-radius: 0 4px 4px 0;
}
.fileinput-new.input-group .btn-file.btn-sm, .fileinput-new .input-group .btn-file.btn-sm, .fileinput-new.input-group .btn-file.btn-xs, .fileinput-new .input-group .btn-file.btn-xs, .fileinput-new.input-group .btn-group-sm>.btn-file.btn, .fileinput-new .input-group .btn-group-sm>.btn-file.btn {
    border-radius: 0 3px 3px 0;
}
.fileinput-new.input-group .btn-file.btn-lg, .fileinput-new .input-group .btn-file.btn-lg, .fileinput-new.input-group .btn-group-lg>.btn-file.btn, .fileinput-new .input-group .btn-group-lg>.btn-file.btn {
    border-radius: 0 6px 6px 0;
}
.form-group.has-warning .fileinput .fileinput-preview {
    color: #ff9800;
}
.form-group.has-warning .fileinput .thumbnail {
    border-color: #ff9800;
}
.form-group.has-error .fileinput .fileinput-preview {
    color: #f44336;
}
.form-group.has-error .fileinput .thumbnail {
    border-color: #f44336;
}
.form-group.has-success .fileinput .fileinput-preview {
    color: #4caf50;
}
.form-group.has-success .fileinput .thumbnail {
    border-color: #4caf50;
}
.input-group-addon:not(:first-child) {
    border-left: 0;
}
.thumbnail {
    border: 0 none;
    border-radius: 4px;
    padding: 0;
}

</style>


<h3 class="page-title"><b>Hub Page Images</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
			<?php
			$data_img = "SELECT `hp_id`, `slider`, `hp_1`, `hp_2`, `hp_3`, `shop_1`, `added_date` FROM `fh_homepage` order by hp_id DESC";
              $stmp_img = mysqli_query($conn, $data_img);
              $row_img = mysqli_fetch_array($stmp_img,MYSQLI_ASSOC);
			 // $row_img=mysqli_fetch_assoc($stmp_img);
			  $slider_img = $row_img['slider'];
			  $hp_1 = $row_img['hp_1'];
			  $hp_2 = $row_img['hp_2'];
			  $hp_3 = $row_img['hp_3'];
			  $shop_1 = $row_img['shop_1'];
			  
			?>
	<form action="" method="POST" enctype="multipart/form-data"> 
		
		<table align="center" class="table table-striped">
		<tr>
				<td align="right"><b>Sliders:</b></td>
				<td><input type="file" name="images[]" value="<?php echo $slider_img ?>" multiple id="fileToUpload"></td>
			</tr>
			<tr>
				<td align="right"><b>Image1:</b></td>
				<td><input type="file" name="image2" value="<?php echo $hp_1 ?>" id="fileToUpload"></td>
			</tr>
			<tr>
				<td align="right"><b>Image2:</b></td>
				<td><input type="file" name="image3" value="<?php echo $hp_2 ?>" id="fileToUpload"></td>
			</tr>
			<tr>
				<td align="right"><b>Image3:</b></td>
				<td><input type="file" name="image4" value="<?php echo $hp_3 ?>" id="fileToUpload"></td>
			</tr>
		<tr>
				<td align="right"><b>Shop Page:</b></td>
			 	<td><input type="file" name="image5" value="<?php echo $shop_1 ?>" id="fileToUpload"></td>
		</tr>
		<!--	<tr>
				<td align="right"><b>pImage2:</b></td>
				<td><input type="file" name="image6" id="fileToUpload"></td>
			</tr>
			<tr>
				<td align="right"><b>pImage3:</b></td>
				<td><input type="file" name="image7" id="fileToUpload"></td>
			</tr> -->
		<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="insert_hub" value="Insert Hub Images"/></td>
			</tr>
		</table>

	</form>
          <!-- END TABLE STRIPED -->
		</div>
	</div>
</div>


<script src="./assets/js/jquery.3.2.1.min.js"></script>
<script src="./assets/js/plugins/jasny-bootstrap.min.js"></script>
<script type="text/javascript">
    $("document").ready(function(){
     // $(".fileinput").removeClass('fileinput-new');
     // $(".fileinput").addClass('fileinput-exists');

    // $('.fileinput').fileinput('clear');

     $("#i1").change(function(){
        var fi = document.getElementById('i1');
        if (fi.files.length > 0) {      // FIRST CHECK IF ANY FILE IS SELECTED.
           
            for (var i = 0; i <= fi.files.length - 1; i++) {
                var fileName, fileExtension, fileSize, fileType, dateModified;

                // FILE NAME AND EXTENSION.
                fileName = fi.files.item(i).name;
                fileExtension = fileName.replace(/^.*\./, '');
                 fileSize = fi.files.item(i).size;
                if (fileExtension == 'png' || fileExtension == 'jpg' || fileExtension == 'jpeg') {
                   if(fileSize<=2560000){
                    readImageFile(fi.files.item(i));  
                   // alert("image file selected"+fileSize);  
                   }else{
                     alert("image file no more than 2.5mb");  
                     //$("#i1").val(''); 
                     $('.fileinput').fileinput('reset');
                   }         
                }else{
                    alert("image file only allowed");  
                    //$("#i1").val(''); 
                    $('.fileinput').fileinput('reset');
                }
                
            }
        }
      
     });
    });

    // GET THE IMAGE WIDTH AND HEIGHT USING fileReader() API.
            function readImageFile(file) {
                var reader = new FileReader(); // CREATE AN NEW INSTANCE.

                reader.onload = function (e) {
                    var img = new Image();      
                    img.src = e.target.result;

                    img.onload = function () {
                        var w = this.width;
                        var h = this.height;
                       // alert(w+"/"+h);
                        if(w == 270 && h == 394 ){
                                alert("Image size allows"); 
                                
                                var form_data = new FormData();
                                    form_data.append("file",file);
                                    $.ajax({
                                      url:'upload.php',
                                      method:'POST',
                                      data:form_data,
                                      contentType:false,
                                      cache:false,
                                      processData:false,
                                      beforeSend:function(){
                                       // $('#msg').html('Loading......');
                                      },
                                      success:function(data){
                                        console.log(data);
                                        alert(data);
                                       // $('#msg').html(data);
                                      }
                                    });

                        }else {
                                alert("Image size should be 270*394");  
                                //$("#i1").val(''); 
                                $('.fileinput').fileinput('clear');
                        }
                    }
                };
                reader.readAsDataURL(file);
            }
</script>

<h3 class="page-title"><b>Banner Images</b></h3>
	<div class="row">
		<div class="col-md-12">
		<div class="panel">	
		<div class="col-md-4 col-sm-4">
      
      <?php 
      $data_img1 = "SELECT `id`, `category`, `banner_title`, `img_url`, `adding_date` FROM `fh_banners` WHERE category='Banner Image'";
              $stmp_img1 = mysqli_query($conn, $data_img1);
              $row_img1 = mysqli_fetch_array($stmp_img1,MYSQLI_ASSOC);

              $img_url11=$row_img1['img_url'];

              
      ?>        
			<!-- TABLE STRIPED -->
			
				<h4 class="title">Image 1</h4>
                     <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                        <div class="fileinput-new thumbnail">
                          <img src="./assets/img/image_placeholder.jpg" alt="...">
                        </div>
                        <div class="fileinput-preview fileinput-exists thumbnail">
                           <img src="<?php echo "./".$img_url11;?>" alt="...">
                        </div>
                        <div>
                          <span class="btn btn-rose btn-round btn-file">
                            <span class="fileinput-new">Select image</span>
                            <span class="fileinput-exists">Change</span>
                            <input type="file" name="i1" id="i1" />
                          </span>
                          <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                        </div>
                         <span>(Image size 270*394)</span>
                      </div>
		                </div>
		

		<div class="col-md-4 col-sm-4">
			
				<h4 class="title">Image 2</h4>
                     <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                        <div class="fileinput-new thumbnail">
                          <img src="./assets/img/image_placeholder.jpg" alt="..." height="100" width="200">
                        </div>
                        <div class="fileinput-preview fileinput-exists thumbnail"></div>
                        <div>
                          <span class="btn btn-rose btn-round btn-file">
                            <span class="fileinput-new">Select image</span>
                            <span class="fileinput-exists">Change</span>
                            <input type="file" name="..." />
                          </span>
                          <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                        </div>
                        <span>(Image size 570*394)</span>
                      </div>
		    </div>
		

		<div class="col-md-4 col-sm-4">
			
				<h4 class="title">Image 3</h4>
                     <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                        <div class="fileinput-new thumbnail">
                          <img src="./assets/img/image_placeholder.jpg" alt="..." height="100" width="200">
                        </div>
                        <div class="fileinput-preview fileinput-exists thumbnail"></div>
                        <div>
                          <span class="btn btn-rose btn-round btn-file">
                            <span class="fileinput-new">Select image</span>
                            <span class="fileinput-exists">Change</span>
                            <input type="file" name="..." value="./assets/img/full-screen-image-3.jpg" />
                          </span>
                          <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                        </div>
                         <span>(Image size 270*394)</span>
                      </div>
		    </div>

        

     </div>		    		
    </div>
    </div>


<?php


	
	require("func/config_admin.php");
	
	if(isset($_POST['insert_hub']))
	{
		
     $current_date = date('Y-m-d') ;
	 $demo = rand(1,10000);
	             $randm_a = $current_date.$demo;
		
		//getting the image from the field
        // $image_folder = "../product_image/";
        $img_folder = "images/hub_page/";
		//image one
	     $file_extension_1 = pathinfo($_FILES["image2"]["name"], PATHINFO_EXTENSION);
	    $pImageName_1 = $img_folder.'home_page_ad_1'.$randm_a.'.'.$file_extension_1;
		$pImage_tmp_1 = $_FILES['image2']['tmp_name'];
	 move_uploaded_file($pImage_tmp_1,'../'."$pImageName_1");
	 
	     $img_folder = "images/hub_page/";
		//image one
	     $file_extension_2 = pathinfo($_FILES["image3"]["name"], PATHINFO_EXTENSION);
	    $pImageName_2 = $img_folder.'home_page_ad_2'.$randm_a.'.'.$file_extension_2;
		$pImage_tmp_2 = $_FILES['image3']['tmp_name'];
	 move_uploaded_file($pImage_tmp_2,'../'."$pImageName_2");

	     $img_folder = "images/hub_page/";
         //image two
		$file_extension_3 = pathinfo($_FILES["image4"]["name"], PATHINFO_EXTENSION);
	    $pImageName_3 = $img_folder.'home_page_ad_3'.$randm_a.'.'.$file_extension_3;
		$pImage_tmp_3 = $_FILES['image4']['tmp_name'];
	 move_uploaded_file($pImage_tmp_3,'../'."$pImageName_3");

    $img_folder = "images/hub_page/";
	
		$file_extension_4 = pathinfo($_FILES["image5"]["name"], PATHINFO_EXTENSION);
	    $pImageName_4 = $img_folder.'shop_page.'.$file_extension_4;
		$pImage_tmp_4 = $_FILES['image5']['tmp_name'];
 	move_uploaded_file($pImage_tmp_4,'../'."$pImageName_4");
	

    $allowTypes = array('jpg','png','jpeg','gif');
    
	  $img_folder = "images/hub_page/";
    $images_arr = array();
    foreach($_FILES['images']['name'] as $key=>$val){
        $image_name = $_FILES['images']['name'][$key];
        $tmp_name   = $_FILES['images']['tmp_name'][$key];
        $size       = $_FILES['images']['size'][$key];
        $type       = $_FILES['images']['type'][$key];
        $error      = $_FILES['images']['error'][$key];
        
        // File upload path
        $fileName = basename($_FILES['images']['name'][$key]);
        $targetFilePath = '../'.$img_folder . $fileName;
		
		$targetFile = $img_folder . $fileName;
        
        // Check whether file type is valid
        $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
        if(in_array($fileType, $allowTypes)){    
            // Store images on the server
            if(move_uploaded_file($_FILES['images']['tmp_name'][$key],$targetFilePath)){
            $targetFile;
//echo"<br>";		   
			  $images_arr[] = $targetFile;
            }
        }
    }
	
	// print_r($images_arr);
	 $List = implode(', ', $images_arr);
   //    $pImageName_1.','.$pImageName_2.','.$pImageName_3.','.$pImageName_4;
		// $pImageName = $pImageName_1.','.$pImageName_2.','.$pImageName_3.','.$pImageName_4;

	$insert_product_query = "INSERT INTO `fh_homepage`(`slider`, `hp_1`, `hp_2`, `hp_3`, `shop_1`) VALUES ('$List',' $pImageName_1',' $pImageName_2',' $pImageName_3',' $pImageName_4')";
              $stmp = mysqli_query($conn, $insert_product_query);
		// if($stmp) {
		// 	echo "<script>alert('product Has been inserted!')</script>";
		// 	echo "<script>window.open('index.php?view_products','_self')</script>";
		// }
	}
//	header('Location:hub_page.php');
?>


	<script src="./assets/js/plugins/jasny-bootstrap.min.js"></script>
