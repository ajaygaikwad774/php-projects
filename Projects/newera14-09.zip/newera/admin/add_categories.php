<h3 class="page-title"><b>Add new Categories</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" class="table table-striped">
			
			<tr>
				<td align="right"><b>Category name:</b></td>
				<td><input type="text" name="category_name" size="60" required/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Category image:</b></td>
				<td><input type="file" name="category_image" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Category position:</b></td>
				<td><input type="text" name="category_position" required/></td>
			</tr>
			<tr>
				<td align="right"><b>Category isVisible:</b></td>
				<td><input type="checkbox" name="category_isVisible" value="Yes" checked/></td>
			</tr>
			
			<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="insert_categories" value="Insert Categories Now"/></td>
			</tr>
		
		</table>
	</form>
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php 

	if(isset($_POST['insert_categories'])){
		$category_isVisible = 0;
		//getting the text data from the fields
		$category_name = $_POST['category_name'];
		$category_image = $_POST['category_image'];
		$category_position = $_POST['category_position'];
		
		if(isset($_POST['category_isVisible']) && $_POST['category_isVisible'] == 'Yes'){
			$category_isVisible=1;
		}
		
		//getting the image from the field
		$category_image = $_FILES['category_image']['name'];
		$category_image_tmp = $_FILES['category_image']['tmp_name'];
		
		move_uploaded_file($category_image_tmp,"../img_cat/$category_image");
	
		 $insert_categories_query = "insert into fh_categories (cName,cImage,cPosition,cIsVisible) values ('$category_name','$category_image','$category_position','$category_isVisible')";
		 
		 if(mysqli_query($conn, $insert_categories_query)){
		 
		 echo "<script>alert('Product Has been inserted!')</script>";
		 echo "<script>window.open('index.php?view_categories','_self')</script>";
		 
		 }
	}
?>