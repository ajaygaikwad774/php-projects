<?php  
	if(isset($_GET['delete_products'])){
	
		$delete_id = $_GET['delete_products'];
		
		$delete_pro = "delete from fh_products where pId='$delete_id'"; 
		
		if(mysqli_query($conn, $delete_pro)){
			echo "<script>alert('A products has been deleted!')</script>";
			echo "<script>window.open('index.php?view_products','_self')</script>";
		}
	}
?>