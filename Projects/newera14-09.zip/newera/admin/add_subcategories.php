<h3 class="page-title"><b>Add new SubCategories</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" class="table table-striped">
			
			<tr>
				<td align="right"><b>SubCategory name:</b></td>
				<td><input type="text" name="subcategory_name" size="60" required/></td>
			</tr>
			<tr>
				<td align="right"><b>Category Id:</b></td>
				<td>
				<select name="subcategory_scId" >
					<option>Select a Category with Id</option>
					<?php 
						$get_cats = "select * from fh_categories";

						$run_cats = mysqli_query($conn, $get_cats);

						while ($row_cats = mysqli_fetch_array($run_cats)){

							$cId = $row_cats['cId']; 
							$cName = $row_cats['cName'];
						
							echo "<option value='$cId'>$cId => $cName</option>";
						}	
					?>
				</select>
				</td>
			</tr>
			<tr>
				<td align="right"><b>Category name:</b></td>
				<td>
				<select name="subcategory_sParentCategories" >
					<option>Select a Category</option>
					<?php 
						$get_cats = "select * from fh_categories";

						$run_cats = mysqli_query($conn, $get_cats);

						while ($row_cats = mysqli_fetch_array($run_cats)){

							$cId = $row_cats['cId']; 
							$cName = $row_cats['cName'];
						
							echo "<option value='$cName'>$cId => $cName</option>";
						}	
					?>
				</select>
				</td>
			</tr>
			
			<tr>
				<td align="right"><b>SubCategory image:</b></td>
				<td><input type="file" name="subcategory_image" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>SubCategory position:</b></td>
				<td><input type="text" name="subcategory_position" required/></td>
			</tr>
			<tr>
				<td align="right"><b>SubCategory isVisible:</b></td>
				<td><input type="checkbox" name="subcategory_isVisible" value="Yes" checked/></td>
			</tr>
			
			<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="insert_subcategories" value="Insert SubCategories Now"/></td>
			</tr>
		
		</table>
	</form>
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php 

	if(isset($_POST['insert_subcategories'])){
		$subcategory_isVisible = 0;
		
		//getting the text data from the fields
		$subcategory_scId= $_POST['subcategory_scId'];
		$subcategory_sParentCategories= $_POST['subcategory_sParentCategories'];
		$subcategory_name = $_POST['subcategory_name'];
		$subcategory_image= $_POST['subcategory_image'];
		$subcategory_position = $_POST['subcategory_position'];
		if(isset($_POST['subcategory_isVisible']) && $_POST['subcategory_isVisible'] == 'Yes'){
			$subcategory_isVisible=1;
		}
		
		//getting the image from the field
		$subcategory_image = $_FILES['subcategory_image']['name'];
		$subcategory_image_tmp = $_FILES['subcategory_image']['tmp_name'];
		
		move_uploaded_file($subcategory_image_tmp,"../img_sub_cat/$subcategory_image");
	
		 $insert_subcategories_query = "insert into fh_subcategories (scId,sParentCategories,sName,sImage,sPosition,sIsVisible) values ('$subcategory_scId','$subcategory_sParentCategories','$subcategory_name','$subcategory_image','$subcategory_position','$subcategory_isVisible')";
		 
		 if(mysqli_query($conn, $insert_subcategories_query)){
		 
		 echo "<script>alert('subcategories Has been inserted!')</script>";
		 echo "<script>window.open('index.php?view_subcategories','_self')</script>";
		 
		 }
	}
?>