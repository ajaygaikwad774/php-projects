<h3 class="page-title"><b>View newsletter</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<table class="table table-striped"> 

	<tr>
		<th>nId</th>
		<th>nEmail</th>
		<th>nStatus</th>
		<th>nTime</th>
	</tr>
	<?php 
	
	$get_newsletter = "select * from fh_newsletter order by nStatus limit 0,100";
	
	$run_newsletter = mysqli_query($conn, $get_newsletter); 
	
	while ($row_newsletter=mysqli_fetch_array($run_newsletter)){
		
		$nId = $row_newsletter['nId'];
		$nEmail = $row_newsletter['nEmail'];
		$nStatus = $row_newsletter['nStatus'];
		$nTime = $row_newsletter['nTime'];
	
	?>
	<tr align="center">
		<td><?php echo $nId;?></td>
		<td><?php echo $nEmail;?></td>
		<td><?php echo $nStatus;?></td>
		<td><?php echo $nTime;?></td>
	</tr>
	<?php } ?>




</table>
				</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>