<?php require_once("func/config_admin.php");?>
<?php require_once("inc_ad/header_ad.php");?>
<?php
session_start();
$myusername = $_SESSION['login_user'];
$sql = "SELECT * FROM fh_admin WHERE aUsername = '$myusername'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$aUsername = $row['aUsername'];
$count = mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row

if($count != 1) {
	header("location: login.php");
}
?>

<body>


<div class="wrapper">
    <?php require_once("inc_ad/navbar_ad.php");?>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
								<p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
  <!--                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-lg hidden-md"></b>
									<p class="hidden-lg hidden-md">
										5 Notifications
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li> -->
                        <li>
                           <a href="">
                                <i class="fa fa-search"></i>
								<p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="">
                               <p>Hello <?php echo $_SESSION['login_user'] ?></p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
										Dropdown
										<b class="caret"></b>
									</p>

                              </a>
                             <!-- <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>-->
                        </li>
                        <li>
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <?php
				
				
					if(isset($_GET["add_categories"]))
					{
						include("add_categories.php");
					}
					if(isset($_GET["view_categories"]))
					{
						include("view_categories.php");
					}
					if(isset($_GET["edit_categories"]))
					{
						include("edit_categories.php");
					}
					if(isset($_GET["delete_categories"]))
					{
						include("delete_categories.php");
					}
					
					if(isset($_GET["hub_page"]))
					{
						include("hub_page.php");
					}
					
					
					
					if(isset($_GET["add_subcategories"]))
					{
						include("add_subcategories.php");
					}
					if(isset($_GET["view_subcategories"]))
					{
						include("view_subcategories.php");
					}
					if(isset($_GET["edit_subcategories"]))
					{
						include("edit_subcategories.php");
					}
					if(isset($_GET["delete_subcategories"]))
					{
						include("delete_subcategories.php");
					}
					
					
					if(isset($_GET["view_products"]))
					{
						include("view_products.php");
					}
					if(isset($_GET["add_products"]))
					{
						include("add_products.php");
					}
					if(isset($_GET["edit_products"]))
					{
						include("edit_products.php");
					}
					if(isset($_GET["delete_products"]))
					{
						include("delete_products.php");
					}
					

					if(isset($_GET["add_admin"]))
					{
						include("add_admin.php");
					}
					if(isset($_GET["view_admin"]))
					{
						include("view_admin.php");
					}
					if(isset($_GET["edit_admin"]))
					{
						include("edit_admin.php");
					}
					if(isset($_GET["delete_admin"]))
					{
						include("delete_admin.php");
					}


					if(isset($_GET["view_newsletter"]))
					{
						include("view_newsletter.php");
					}
					
					
					if(isset($_GET["view_codes"]))
					{
						include("codes.php");
					}
				?>	
            </div>
        </div>
<?php require_once("inc_ad/footer_ad.php");?>