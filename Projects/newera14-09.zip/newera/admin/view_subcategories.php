<h3 class="page-title"><b>View, Edit and Delete SubCategories</b>&nbsp;&nbsp;&nbsp;<a href="index.php?add_subcategories" class="btn btn-primary" role="button">Add subCategories</a></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<table class="table table-striped"> 

	<tr>
		<th>SubCategory ID</th>
		<th>Category ID</th>
		<th>Category Name</th>
		<th>SubCategory Name</th>
		<th>SubCategory Image</th>
		<th>SubCategory Position</th>
		<th>SubCategory IsVisible</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php 
	
	$get_sub_cat = "SELECT * FROM fh_subcategories ORDER BY scId";
	
	$run_sub_cat = mysqli_query($conn, $get_sub_cat); 
	
	
	while($row_sub_cat = mysqli_fetch_array($run_sub_cat)){
		
		$sId = $row_sub_cat['sId'];
		$scId = $row_sub_cat['scId'];
		$sParentCategories = $row_sub_cat['sParentCategories'];
		$sName = $row_sub_cat['sName'];
		$sImage = $row_sub_cat['sImage'];
		$sPosition = $row_sub_cat['sPosition'];
		$sIsVisible = $row_sub_cat['sIsVisible'];
	
	?>
	<tr align="center">
		<td><?php echo $sId;?></td>
		<td><?php echo $scId;?></td>
		<td><?php echo $sParentCategories;?></td>
		<td><?php echo $sName;?></td>
		<td><?php echo $sImage;?>&nbsp;&nbsp;&nbsp;<img src="../img_sub_cat/<?php echo $sImage; ?>" width="60" height="60"/></td>
		<td><?php echo $sPosition;?></td>
		<td><?php echo $sIsVisible;?></td>
		<td><a href="index.php?edit_subcategories=<?php echo $sId; ?>">Edit</a></td>
		<td><a href="index.php?delete_subcategories=<?php echo $sId;?>">Delete</a></td>
	
	</tr>
	<?php } ?>




</table>
				</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>