<h3 class="page-title"><b>View, Edit and Delete Products</b>&nbsp;&nbsp;&nbsp;<a href="index.php?add_products" class="btn btn-primary" role="button">Add Products</a></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<table class="table table-striped"> 

	<tr>
		<th>Id</th>
		<th>CategoriesName</th>
		<th>SubCategoriesName</th>
		<th>Code</th>
		<th>Name</th>
		<th>OurPrice</th>
		<th>Image</th>
		<th>Position</th>
		<th>IsVisible</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php 
	// define how many results you want per page
		$results_per_page = 25;
		// find out the number of results stored in database
		$sql = "select pId,pCategoriesName,pSubCategoriesName,pCode,pName,pOurPrice,pImage,pPosition,pIsVisible from fh_products order by pPosition";
		$result = mysqli_query($conn, $sql);
		
		$number_of_products = mysqli_num_rows($result);
		if($number_of_products==0){
			echo "<h4 style='padding:20px;'>No products where found in this category....</h4>";
		}
		// determine number of total pages available
		$number_of_pages = ceil($number_of_products/$results_per_page);
		// determine which page number visitor is currently on
		if (!isset($_GET['page'])) {
		    $page = 1;
		} else {
		    $page = $_GET['page'];
		}
		// determine the sql LIMIT starting number for the results on the displaying page
		$this_page_first_result = ($page-1)*$results_per_page;
		
		// retrieve selected results from database and display them on page
		$sql="select pId,pCategoriesName,pSubCategoriesName,pCode,pName,pOurPrice,pImage,pPosition,pIsVisible from fh_products order by pPosition LIMIT " . $this_page_first_result . "," .  $results_per_page;
		$result = mysqli_query($conn, $sql);
	
		$run_products = mysqli_query($conn, $sql); 
		
		while ($row_products = mysqli_fetch_array($run_products)){
			
			$pId = $row_products['pId'];
			$pCategoriesName = $row_products['pCategoriesName'];
			$pSubCategoriesName = $row_products['pSubCategoriesName'];
			$pCode = $row_products['pCode'];
			$pName = $row_products['pName'];
			$pOurPrice = $row_products['pOurPrice'];
			$pImage = $row_products['pImage'];
			$pPosition = $row_products['pPosition'];
			$pIsVisible = $row_products['pIsVisible'];
		
		?>
		<tr align="center">
			<th><?php echo $pId; ?></th>
			<th><?php echo $pCategoriesName; ?></th>
			<th><?php echo $pSubCategoriesName; ?></th>
			<th><?php echo $pCode; ?></th>
			<th><?php echo $pName; ?></th>
			<th><?php echo $pOurPrice; ?></th>
			<th><img src="../img_product/<?php echo $pImage; ?>" width="60" height="60"/></th>
			<th><?php echo $pPosition; ?></th>
			<th><?php echo $pIsVisible; ?></th>
			<td><a href="index.php?edit_products=<?php echo $pId; ?>">Edit</a></td>
			<td><a href="index.php?delete_products=<?php echo $pId;?>">Delete</a></td>
		
		</tr>
		
	<?php } 
		echo "<ul>";
			for ($page=1;$page<=$number_of_pages;$page++) {
				echo "<a href='index.php?view_products&page=$page'><li>$page</li></a>";
			}
		echo "</ul>";
	?>

</table>
				</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>