<h3 class="page-title"><b>View Codes</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
<table class="table table-striped"> 

	<tr>
		<th>Codes Name</th>
		<th>Codes Description</th>
	</tr>
	<tr>
		<td>Name</td>
		<td>Description</td>
	</tr>
	<tr>
		<td>PAYMENT TERMS</td>
		<td>* For Less Than 10 Chair :Cash/ Cheque/ NEFT/ RTGS against Delivery.<br>&lt;br&gt;
			* For More Than 10 Chair : As Mutually Agreed
		</td>
	</tr>
	<tr>
		<td>DELIVERY TERMS</td>
		<td>* For Mumbai/Thane/New Mumbai: Single/Multiple chair delivery is possible.<br>&lt;br&gt;
			* For Rest Other Location : Minimum Order of 10 chairs are required.<br>&lt;br&gt;
			* If the selected product is available then it would be delivered within 3 to 4 working days.<br>&lt;br&gt;
			* The delivery would be till the door of your suggested address.<br>&lt;br&gt;
			* No Assembly required - Product is delivered pre-assembled and does not require any assembly at the specified order destination.<br>&lt;br&gt;
			* All care would be taken of during transportation that the goods do not get damaged.<br>&lt;br&gt;
			* Product would be delivered by our company is experience logistic and transport team.<br>&lt;br&gt;
			* Please check the product at the time of delivery. If it is not to your liking or is damaged/defective, you can return it on the spot.<br>&lt;br&gt;
			* In case you have any questions or need any clarifications do not hesitate to call our Customer Support Team on above phone no.<br>&lt;br&gt;
		</td>
	</tr>
	<tr>
		<td>warranty</td>
		<td>* The product comes with a 24 month warranty against any manufacturing defects and any other issues with the materials that have been used.<br>&lt;br&gt;
			* In case you face any issue with any of our product then simply call on above phone no or email us to register your complain.<br>&lt;br&gt;
			* We are committed to attend all complaints within two working days.<br>&lt;br&gt;
			* Except Fabric & Leather each and every spare parts like wheel; base ( stand) ; hydraulic gas lift; arm rest; mechanism; plywood etc are covered under free of cost replacement within guarantee period.<br>&lt;br&gt;
			* The warranty does not cover damages to fabric & leather beyond its intended use and wear & tear in the natural course of product usage.<br>&lt;br&gt;
			* We would repair fabric & leather material as well but at an extra cost what may be applicable.
		</td>
	</tr>
	<tr>
		<td>Features</td>
		<td>* Nylon Netted Mesh Back Rest.<br>&lt;br&gt;
			* Seat Made up of Foaming Cushion.<br>&lt;br&gt;
			* High Quality Fiber Arm Rest.<br>&lt;br&gt;
			* Ergonomic Back Support<br>&lt;br&gt;
			* Ideal for Long Hour Sitting.<br>&lt;br&gt;
			* No Sweating because of Long Sitting.<br>&lt;br&gt;
			* Push Back Machanism.<br>&lt;br&gt;
			* Up-Down Height Adjustment.<br>&lt;br&gt;
			* 90 Degree Tilt Lock.<br>&lt;br&gt;
			* Colour Option Available.<br>&lt;br&gt;
			* 360 Degree Revolving
		</td>
	</tr>
	
</table>
				</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>