<h3 class="page-title"><b>Edit and Update the products</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">

<?php 


if(isset($_GET['edit_categories'])){

	$cId = $_GET['edit_categories']; 
	
	$get_cat = "select * from fh_categories where cId='$cId'";
	
	$run_cat = mysqli_query($conn, $get_cat); 
	
	$row_cat = mysqli_fetch_array($run_cat);
		
		$cId = $row_cat['cId'];
		$cName = $row_cat['cName'];
		$cImage = $row_cat['cImage'];
		$cPosition = $row_cat['cPosition']; 
		$cIsVisible = $row_cat['cIsVisible'];
}
		
?>



	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table class="table table-striped">
			<tr>
				<td align="right"><b>Category id:</b></td>
				<td><?php echo $cId;?></td>
			</tr>
			<tr>
				<td align="right"><b>Category name:</b></td>
				<td><input type="text" name="category_name" size="60" value="<?php echo $cName;?>"></td>
			</tr>
			
			<tr>
				<td align="right"><b>Category image:</b></td>
				<td><input type="file" name="category_image" /><img src="../img_cat/<?php echo $cImage; ?>" width="60" height="60"/></td>
			</tr>
			
			<tr>
				<td align="right"><b>Category position:</b></td>
				<td><input type="text" name="category_position" value="<?php echo $cPosition;?>"></td>
			</tr>
			<tr>
				<td align="right"><b>Category isVisible:</b></td>
				<td><input type="checkbox" name="category_isVisible" value="Yes" checked/><?php echo $cIsVisible;?></td>
			</tr>
			
			<tr align="center">
				<td colspan="7"><input type="submit" class="btn btn-primary" name="update_categories" value="Update Categories Now"/></td>
			</tr>
		
		</table>
	
	
	</form>
 
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php 

	if(isset($_POST['update_categories'])){
	
		//getting the text data from the fields
		
		$update_id = $cId;
		$category_isVisible = 0;
		
		//getting the text data from the fields
		$category_name = $_POST['category_name'];
		$category_position = $_POST['category_position'];
		if(isset($_POST['category_isVisible']) && $_POST['category_isVisible'] == 'Yes'){
			$category_isVisible=1;
		}
		
		if($_FILES['category_image']['name'] == "") {
			$category_image = $cImage;
		}
		else
		{
			$category_image = $_POST['category_image'];
			
			//getting the image from the field
			$category_image = $_FILES['category_image']['name'];
			$category_image_tmp = $_FILES['category_image']['tmp_name'];
			
			move_uploaded_file($category_image_tmp,"../img_cat/$category_image");
		}
		
		
		
	
		 $update_categories_query = "update fh_categories set cName='$category_name',cImage='$category_image',cPosition='$category_position',cIsVisible='$category_isVisible' where cId='$update_id'";
		 
		 $updated_categories = mysqli_query($conn, $update_categories_query);
		 
		 if($updated_categories){
		 
		 echo "<script>alert('categories Has been updated!')</script>";
		 echo "<script>window.open('index.php?view_categories','_self')</script>";
		 
		 }
	}
?>