<?php 
if(isset($_GET['edit_products'])){

	$pId = $_GET['edit_products']; 
	
	$get_pro = "select * from fh_products where pId='$pId'";
	
	$run_pro = mysqli_query($conn, $get_pro); 
	
	$row_pro = mysqli_fetch_array($run_pro);
	
		$pCategoriesId = $row_pro['pCategoriesId'];
		$pSubCategoriesId = $row_pro['pSubCategoriesId'];
		$pCategoriesName = $row_pro['pCategoriesName'];
		$pSubCategoriesName = $row_pro['pSubCategoriesName'];
		$pCode = $row_pro['pCode'];
		$pName = $row_pro['pName'];
		$pPrice = $row_pro['pPrice'];
		$pOurPrice = $row_pro['pOurPrice'];
		$pQuantityDiscountPrice = $row_pro['pQuantityDiscountPrice'];
		$pDeliveryCost = $row_pro['pDeliveryCost'];
		$pGstRate = $row_pro['pGstRate'];
		$pWarranty = $row_pro['pWarranty'];
		$pDeliveryTime = $row_pro['pDeliveryTime'];
		$pColour = $row_pro['pColour'];
		$pSeatMaterial = $row_pro['pSeatMaterial'];
		$pBackMaterial = $row_pro['pBackMaterial'];
		$pDimension = $row_pro['pDimension'];
		$pStatus = $row_pro['pStatus'];
		$pPaymentCode = $row_pro['pPaymentCode'];
		$pFeaturesCode = $row_pro['pFeaturesCode'];
		$pWarrantyCode = $row_pro['pWarrantyCode'];
		$pDeliveryCode = $row_pro['pDeliveryCode'];
		$pImage = $row_pro['pImage'];
		$pPosition = $row_pro['pPosition'];
		$pIsVisible = $row_pro['pIsVisible'];
		$pHasFreeDelivery = $row_pro['pHasFreeDelivery'];
		$pDescription = $row_pro['pDescription'];
		$pKeyword = $row_pro['pKeyword'];
		
		$proImage = $pImage;
}	
?>
<h3 class="page-title"><b>Add new Products</b></h3>
	<div class="row">
		<div class="col-md-12">
			<!-- TABLE STRIPED -->
			<div class="panel">
	<form action="" method="post" enctype="multipart/form-data"> 
		
		<table align="center" class="table table-striped">
			<tr>
				<td align="right"><b>pId:</b></td>
				<td><?php echo $pId;?></td>
			</tr>
			<tr>
				<td align="right"><b>pCategoriesId:</b></td>
				<td>
				<select name="product_CategoriesId" >
					<?php 
						$get_cats = "select * from fh_categories";

						$run_cats = mysqli_query($conn, $get_cats);

						while ($row_cats = mysqli_fetch_array($run_cats)){

							$cId = $row_cats['cId']; 
							$cName = $row_cats['cName'];
							
							if($cId==$pCategoriesId)
							{echo "<option selected='selected' value='$cId'>$cId => $cName</option>";}
							else
							{echo "<option value='$cId'>$cId => $cName</option>";}
						}	
					?>
				</select>
				</td>
			</tr>
			<tr>
				<td align="right"><b>pCategoriesName:</b></td>
				<td>
				<select name="product_CategoriesName" >
					<?php 
						$get_cats = "select * from fh_categories";

						$run_cats = mysqli_query($conn, $get_cats);

						while ($row_cats = mysqli_fetch_array($run_cats)){

							$cId = $row_cats['cId']; 
							$cName = $row_cats['cName'];
							
							if($cId==$pCategoriesId)
							{echo "<option selected='selected' value='$cName'>$cId => $cName</option>";}
							else
							{echo "<option value='$cName'>$cId => $cName</option>";}
						}	
					?>
				</select>
				</td>
			</tr>
			<tr>
				<td align="right"><b>pSubCategoriesId:</b></td>
				<td>
				<select name="product_SubCategoriesId" >
					<?php 
						$get_subcats = "select * from subcategories";

						$run_subcats = mysqli_query($conn, $get_subcats);

						while ($row_subcats = mysqli_fetch_array($run_subcats)){

							$sId = $row_subcats['sId']; 
							$sName = $row_subcats['sName'];
							
							if($sId==$pSubCategoriesId)
							{echo "<option selected='selected' value='$sId'>$sId => $sName</option>";}
							else
							{echo "<option value='$sId'>$sId => $sName</option>";}
						}	
					?>
				</select>
				</td>
			</tr>
			
			<tr>
				<td align="right"><b>pSubCategoriesName:</b></td>
				<td>
				<select name="product_SubCategoriesName" >
					<?php 
						$get_subcats = "select * from subcategories";

						$run_subcats = mysqli_query($conn, $get_subcats);

						while ($row_subcats = mysqli_fetch_array($run_subcats)){

							$sId = $row_subcats['sId']; 
							$sName = $row_subcats['sName'];
							
							if($sId==$pSubCategoriesId)
							{echo "<option selected='selected' value='$sName'>$sId => $sName</option>";}
							else
							{echo "<option value='$sName'>$sId => $sName</option>";}
						}	
					?>
				</select>
				</td>
			</tr>
			<tr>
				<td align="right"><b>pCode:</b></td>
				<td><input type="text" name="product_Code" size="60" value="<?php echo $pCode;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pName:</b></td>
				<td><input type="text" name="product_Name" size="60" value="<?php echo $pName;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pPrice:</b></td>
				<td><input type="text" name="product_Price" size="60" value="<?php echo $pPrice;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pOurPrice:</b></td>
				<td><input type="text" name="product_OurPrice" size="60" value="<?php echo $pOurPrice;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pQuantityDiscountPrice:</b></td>
				<td><input type="text" name="product_QuantityDiscountPrice" size="60" value="<?php echo $pQuantityDiscountPrice;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pDeliveryCost:</b></td>
				<td><input type="text" name="product_DeliveryCost" size="60" value="<?php echo $pDeliveryCost;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pGstRate:</b></td>
				<td><input type="text" name="product_GstRate" size="60" value="<?php echo $pGstRate;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pWarranty:</b></td>
				<td><input type="text" name="product_Warranty" size="60" value="<?php echo $pWarranty;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pDeliveryTime:</b></td>
				<td><input type="text" name="product_DeliveryTime" size="60" value="<?php echo $pDeliveryTime;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pColour:</b></td>
				<td><input type="text" name="product_Colour" size="60" value="<?php echo $pColour;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pSeatMaterial:</b></td>
				<td><input type="text" name="product_SeatMaterial" size="60" value="<?php echo $pSeatMaterial;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pBackMaterial:</b></td>
				<td><input type="text" name="product_BackMaterial" size="60" value="<?php echo $pBackMaterial;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pDimension:</b></td>
				<td><input type="text" name="product_Dimension" size="60" value="<?php echo $pDimension;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pStatus:</b></td>
				<td><input type="text" name="product_Status" size="60" value="<?php echo $pStatus;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pPaymentCode:</b></td>
				<td><input type="text" name="product_PaymentCode" size="60" value="<?php echo $pPaymentCode;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pFeaturesCode:</b></td>
				<td><input type="text" name="product_FeaturesCode" size="60" value="<?php echo $pFeaturesCode;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pWarrantyCode:</b></td>
				<td><input type="text" name="product_WarrantyCode" size="60" value="<?php echo $pWarrantyCode;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pDeliveryCode:</b></td>
				<td><input type="text" name="product_DeliveryCode" size="60" value="<?php echo $pDeliveryCode;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pImage1:</b></td>
				<td><input type="file" name="fileToUpload" id="fileToUpload"><br><img src="../img_product/<?php echo $pImage; ?>" width="60" height="60"/><br><p style="color:red;">uploading pImage1 upload pImage2,pImage3 also.</p></td>
			</tr>
			<tr>
				<td align="right"><b>pImage2:</b></td>
				<td><input type="file" name="fileToUpload2" id="fileToUpload"><br><img src="../img_product2/<?php echo $pImage; ?>" width="60" height="60"/></td>
			</tr>
			<tr>
				<td align="right"><b>pImage3:</b></td>
				<td><input type="file" name="fileToUpload3" id="fileToUpload"><br><img src="../img_product3/<?php echo $pImage; ?>" width="60" height="60"/></td>
			</tr>
			<tr>
				<td align="right"><b>pPosition:</b></td>
				<td><input type="text" name="product_Position" size="60" value="<?php echo $pPosition;?>" required/></td>
			</tr>
			<tr>
				<td align="right"><b>pIsVisible:</b></td>
				<td><input type="checkbox" name="product_IsVisible" value="Yes" checked/></td>
			</tr>
			<tr>
				<td align="right"><b>pHasFreeDelivery:</b></td>
				<td><input type="checkbox" name="product_HasFreeDelivery" value="Yes" checked/></td>
			</tr>
			<tr>
				<td align="right"><b>pDescription:</b></td>
				<td><textarea name="product_Description" cols="60" rows="10" ><?php echo $pDescription;?></textarea></td>
			</tr>
			<tr>
				<td align="right"><b>pKeyword:</b></td>
				<td><input type="text" name="product_Keyword" size="60" value="<?php echo $pKeyword;?>" required/></td>
			</tr>
			<tr align="center">
				<td colspan="2"><input type="submit" class="btn btn-primary" name="update_product" value="update product Now"/></td>
			</tr>
		
		</table>
	</form>
			</div>
			<!-- END TABLE STRIPED -->
		</div>
	</div>
</div>
<?php require_once("func/config_admin.php");

	$pIsVisible = 0;
	$pHasFreeDelivery=0;
	
	if(isset($_POST['update_product'])){
		
		//getting the text data from the fields
		$pCategoriesId= $_POST['product_CategoriesId'];
		$pSubCategoriesId= $_POST['product_SubCategoriesId'];
		$pCategoriesName= $_POST['product_CategoriesName'];
		$pSubCategoriesName= $_POST['product_SubCategoriesName'];
		$pCode= $_POST['product_Code'];
		$pName= $_POST['product_Name'];
		$pPrice= $_POST['product_Price'];
		$pOurPrice= $_POST['product_OurPrice'];
		$pQuantityDiscountPrice= $_POST['product_QuantityDiscountPrice'];
		$pDeliveryCost= $_POST['product_DeliveryCost'];
		$pGstRate= $_POST['product_GstRate'];
		$pWarranty= $_POST['product_Warranty'];
		$pDeliveryTime= $_POST['product_DeliveryTime'];
		$pColour= $_POST['product_Colour'];
		$pSeatMaterial= $_POST['product_SeatMaterial'];
		$pBackMaterial= $_POST['product_BackMaterial'];
		$pDimension= $_POST['product_Dimension'];
		$pStatus= $_POST['product_Status'];
		$pPaymentCode= $_POST['product_PaymentCode'];
		$pFeaturesCode= $_POST['product_FeaturesCode'];
		$pWarrantyCode= $_POST['product_WarrantyCode'];
		$pDeliveryCode= $_POST['product_DeliveryCode'];
		$pPosition= $_POST['product_Position'];
		if(isset($_POST['product_IsVisible']) && $_POST['product_IsVisible'] == 'Yes'){
			$pIsVisible=1;
		}
		if(isset($_POST['product_HasFreeDelivery']) && $_POST['product_HasFreeDelivery'] == 'Yes'){
			$pHasFreeDelivery=1;
		}
		$pDescription = $_POST['product_Description'];
		$pKeyword = $_POST['product_Keyword'];
		
		
		
		// if($_FILES['fileToUpload']['name'] == "") {
		// 	$pImage = $proImage;
		// }
		// else
		// {			
		// 	$pImage = $pCode.'.jpg';			
		// }
		// $pImage_tmp = $_FILES['fileToUpload']['tmp_name'];
		// move_uploaded_file($pImage_tmp,"../img_product/$pImage");
		// $pImage_tmp = $_FILES['fileToUpload2']['tmp_name'];
		// move_uploaded_file($pImage_tmp,"../img_product2/$pImage");
		// $pImage_tmp = $_FILES['fileToUpload3']['tmp_name'];
		// move_uploaded_file($pImage_tmp,"../img_product3/$pImage");


		//getting the image from the field
        // $image_folder = "../product_image/";
        $img_folder = "product_image/";
		//image one
	     $file_extension_1 = pathinfo($_FILES["fileToUpload"]["name"], PATHINFO_EXTENSION);
	    $pImageName_1 = $img_folder.$pCode.'_1.'.$file_extension_1;
		$pImage_tmp_1 = $_FILES['fileToUpload']['tmp_name'];
	 move_uploaded_file($pImage_tmp_1,'../'."$pImageName_1");

         //image two
		$file_extension_2 = pathinfo($_FILES["fileToUpload2"]["name"], PATHINFO_EXTENSION);
	    $pImageName_2 = $img_folder.$pCode.'_2.'.$file_extension_2;
		$pImage_tmp_2 = $_FILES['fileToUpload2']['tmp_name'];
	 move_uploaded_file($pImage_tmp_2,'../'."$pImageName_2");


		//image three
		$file_extension_3 = pathinfo($_FILES["fileToUpload3"]["name"], PATHINFO_EXTENSION);
	    $pImageName_3 = $img_folder.$pCode.'_3.'.$file_extension_3;
		$pImage_tmp_3 = $_FILES['fileToUpload3']['tmp_name'];
 	move_uploaded_file($pImage_tmp_3,'../'."$pImageName_3");

		 $pImage = $pImageName_1.','.$pImageName_2.','.$pImageName_3;

	
		$update_product_query = "UPDATE fh_products SET pCategoriesId='$pCategoriesId',pSubCategoriesId='$pSubCategoriesId',pCategoriesName='$pCategoriesName',pSubCategoriesName='$pSubCategoriesName',pCode='$pCode',pName='$pName',pPrice='$pPrice',pOurPrice='$pOurPrice',pQuantityDiscountPrice='$pQuantityDiscountPrice',pDeliveryCost='$pDeliveryCost',pGstRate='$pGstRate',pWarranty='$pWarranty',pDeliveryTime='$pDeliveryTime',pColour='$pColour',pSeatMaterial='$pSeatMaterial',pBackMaterial='$pBackMaterial',pDimension='$pDimension',pStatus='$pStatus',pPaymentCode='$pPaymentCode',pFeaturesCode='$pFeaturesCode',pWarrantyCode='$pWarrantyCode',pDeliveryCode='$pDeliveryCode',pImage='$pImage',pPosition='$pPosition',pIsVisible='$pIsVisible',pHasFreeDelivery='$pHasFreeDelivery',pDescription='$pDescription',pKeyword='$pKeyword' WHERE pId = $pId";

		if (mysqli_query($conn, $update_product_query)) {
			echo "<script>alert('product Has been updated!')</script>";
			echo "<script>window.open('index.php?view_products','_self')</script>";
		}
	}
?>