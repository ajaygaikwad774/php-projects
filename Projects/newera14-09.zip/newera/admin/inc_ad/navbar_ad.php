<div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="index.php" class="simple-text">
                    Creative Tim
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="index.php?hub_page.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
				 <li >
                    <a href="index.php?hub_page">
                        <i class="pe-7s-graph"></i>
                        <p>Hub Page Images</p>
                    </a>
                </li>
                <li>
                    <a href="index.php?view_admin">
                        <i class="pe-7s-users"></i>
                        <p>Admin User</p>
                    </a>
                </li>
                <li>
                    <a href="index.php?view_categories">
                        <i class="pe-7s-menu"></i>
                        <p>Categories</p>
                    </a>
                </li>
				<li>
                    <a href="index.php?view_subcategories">
                        <i class="pe-7s-keypad"></i>
                        <p>SubCategories</p>
                    </a>
                </li>
                <li>
                    <a href="index.php?view_products">
                        <i class="pe-7s-look"></i>
                        <p>Products</p>
                    </a>
                </li>
				<li>
                    <a href="index.php?view_newsletter">
                        <i class="pe-7s-paper-plane"></i>
                        <p>Newsletter</p>
                    </a>
                </li>
                <li>
                    <a href="index.php?view_codes" target="_blank">
                        <i class="pe-7s-scissors"></i>
                        <p>Codes</p>
                    </a>
                </li>
                
                <li>
                    <a href="notifications.html">
                        <i class="pe-7s-bell"></i>
                        <p>Notifications</p>
                    </a>
                </li>
				
				
            </ul>
    	</div>
    </div>