

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Company
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Portfolio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
                </p>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
    <script src="assets/dropify/dist/js/dropify.min.js"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'pe-7s-gift',
            	message: "Welcome to <b>Light Bootstrap Dashboard</b> - a beautiful freebie for every web developer."

            },{
                type: 'info',
                timer: 4000
            });

            // Basic
        $('.dropify').dropify();

        // Translated
        $('.dropify-fr').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove':  'Remove',
                'error':   'Ooops, something wrong happended.'
            }
        });

        // Used events
        var drEvent = $('#input-file-events').dropify();

        drEvent.on('dropify.beforeClear', function(event, element) {
            return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
        });

        drEvent.on('dropify.afterClear', function(event, element) {
            alert('File deleted');
        });

        drEvent.on('dropify.errors', function(event, element) {
            console.log('Has Errors');
        });

        var drDestroy = $('#input-file-to-destroy').dropify();
        drDestroy = drDestroy.data('dropify')
        $('#toggleDropify').on('click', function(e) {
            e.preventDefault();
            if (drDestroy.isDropified()) {
                drDestroy.destroy();
            } else {
                drDestroy.init();
            }
        });

        

        $(".asImage").change(function(){
            asImageData();
        });

        $(".asImage1").change(function(){
            asImageData();
        });

        $(".asImage3").change(function(){
            asImageData();
        });

    });

        function asImageData(){
          var type= document.getElementById('type'); 
        alert(type);  
        var name= document.getElementById('name'); 
        alert(name);  
        var height= document.getElementById('height');   
        var width= document.getElementById('width');   
        var fi = document.getElementById(name);
        if (fi.files.length > 0) {      // FIRST CHECK IF ANY FILE IS SELECTED.
           
            for (var i = 0; i <= fi.files.length - 1; i++) {
                var fileName, fileExtension, fileSize, fileType, dateModified;

                // FILE NAME AND EXTENSION.
                fileName = fi.files.item(i).name;
                fileExtension = fileName.replace(/^.*\./, '');
                 fileSize = fi.files.item(i).size;
                if (fileExtension == 'png' || fileExtension == 'jpg' || fileExtension == 'jpeg') {
                   if(fileSize<=2560000){
                   // readImageFile(fi.files.item(i));  
                    alert("image file selected"+fileSize);  
                   }else{
                     alert("image file no more than 2.5mb");  
                     //$("#i1").val(''); 
                     $('.fileinput').fileinput('reset');
                   }         
                }else{
                    alert("image file only allowed");  
                    //$("#i1").val(''); 
                    $('.fileinput').fileinput('reset');
                }
                
            }
        }

        }

         function readImageFile(file) {
                var reader = new FileReader(); // CREATE AN NEW INSTANCE.

                reader.onload = function (e) {
                    var img = new Image();      
                    img.src = e.target.result;

                    img.onload = function () {
                        var w = this.width;
                        var h = this.height;
                       // alert(w+"/"+h);
                        if(w == 270 && h == 394 ){
                                alert("Image size allows"); 
                                
                                var form_data = new FormData();
                                    form_data.append("file",file);
                                    $.ajax({
                                      url:'upload.php',
                                      method:'POST',
                                      data:form_data,
                                      contentType:false,
                                      cache:false,
                                      processData:false,
                                      beforeSend:function(){
                                       // $('#msg').html('Loading......');
                                      },
                                      success:function(data){
                                        console.log(data);
                                        alert(data);
                                       // $('#msg').html(data);
                                      }
                                    });

                        }else {
                                alert("Image size should be 270*394");  
                                //$("#i1").val(''); 
                                $('.fileinput').fileinput('clear');
                        }
                    }
                };
                reader.readAsDataURL(file);
            }
	</script>

</html>
