<?php  
	
	if(isset($_GET['delete_subcategories'])){
	
	$delete_id = $_GET['delete_subcategories'];
	
	$delete_subcat = "delete from fh_subcategories where sId='$delete_id'"; 
	
	$run_delete = mysqli_query($conn, $delete_subcat); 
	
	if($run_delete){
	
	echo "<script>alert('A subcategories has been deleted!')</script>";
	echo "<script>window.open('index.php?view_subcategories','_self')</script>";
	}
	
	}
?>