<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
    <?php   if(isset($_SESSION["loggedin"]) && !isset($_SESSION["u_id"]) && !isset($_SESSION["username"]))
    { 
             
     } ?>
	    
        <!-- Header Area Start -->
       <?php require_once('_header_f/navbar.php'); ?>
        <?php include("function_j/connection.php"); ?>
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Shop</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
      
        <!-- Shop Area Start -->
         <?php 
        $query_01 ="SELECT `shop_1` FROM `fh_homepage` WHERE 1";
         $P_data01 = mysqli_query($conn,$query_01);
          $count_p01 = mysqli_num_rows($P_data01);
          if($count_p01 > 0)
          {
            $SubCategoriesRow01 = mysqli_fetch_array($P_data01);

            $slider11=$SubCategoriesRow01['shop_1'];
            
          }  
        ?>

        <div class="shop-area ptb-80">
            <div class="container">
                <div class="row">
                    <div class="order-xl-2 order-lg-2 col-xl-9 col-lg-8">
                        <div class="shop-banner">
                            <img src="<?php echo $home_page.$slider11;?>" alt="">
                        </div>
                        <h1 class="page-title"><?php echo "Products"; ?></h1>
                        <div class="ht-product-tab">
                            <div class="nav" role="tablist">
                                <a class="active" href="#grid" data-toggle="tab" role="tab" aria-selected="true" aria-controls="grid"><i class="fa fa-th"></i></a>
                                <a href="#list" data-toggle="tab" role="tab" aria-selected="false" aria-controls="list"><i class="fa fa-th-list" aria-hidden="true"></i></a>
                            </div>
                            <div class="shop-content-wrapper">
                                <div class="shop-results"><span>Sort By</span>
                                    <select name="number" id="sort_d">
                                        <option value="pCode">position</option>
                                        <option value="pName">product name</option>
                                        <option value="pOurPrice">price</option>
                                    </select>
                                </div>
                                <div class="shop-items">
                                    <a href="#"><i class="fa fa-long-arrow-up"></i></a>
                                    <span>Items 1-12 of 14</span>
                                </div>
                            </div>
                        </div>

                        <div class="ht-product-shop tab-content">
                              <div id="filtered_product">
                            <div class="tab-pane active show fade text-center" id="grid" role="tabpanel">
                                <div class="row">
    <?php //if(isset($_GET['cId']) &&  isset($_GET['sId']))
     // { 
      //   $cid = $_GET['cId']; 
    //     // $sid = $_GET['sId'];

 // include("function_j/connection.php");
     require_once('function_j/Product.php');

            $product_details = AllProduct();
    // print_r($product_details);
  if( $product_details != "NO Data")
  {
      if(count($product_details) > 0)
      {
        for($i=0;$i<count($product_details);$i++)
           { 

                $sId = $product_details[$i]['pSubCategoriesId'];
                 $pOurPrice = $product_details[$i]['pOurPrice']; 
                $pName = $product_details[$i]['pName'];
                 $pCode = $product_details[$i]['pCode'];
                 $pPrice = $product_details[$i]['pPrice'];
                 $pImage = $product_details[$i]['pImage'];
                 
     $m_image[] = explode(",",$pImage);
     //print_r($m_image);
              $m_image_1 = $m_image[$i][0];
              $m_image_2 = $m_image[$i][1];
              $m_image_3  = $m_image[$i][2];
?>
                           
            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="product-item">
                                    <div class="product-image-hover">
     <a id="p_id_l" href="product-details.php?pId=<?php echo $pCode;?>" data-img ="<?php echo $m_image_1 ?>">
    <img  class="primary-image" src="<?php echo $m_image_1 ?>" alt="">
    <img class="hover-image" src="<?php echo $m_image_2 ?>" alt="">
                                                </a>
                <div class="product-hover">
            <a data-id="<?php echo $pCode; ?>">  <i class="icon icon-FullShoppingCart"></i></a>
         <a class="whish_list-id" data-id="<?php echo $pCode; ?>" ><i class="icon icon-Heart"></i></a>
            <a  ><i class="icon icon-Files"></i></a>
                                                </div>
                                            </div>
                                            <div class="product-text">
                                                <div class="product-rating">
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <h4><a id="product_n_l" href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName; ?></a></h4>
                                                <div class=""> <span style="text-decoration: line-through;font-size:0.7em;"><?php echo $pPrice; ?></span></div>
                                                <div class="product-price"><span id="product_p_l"><?php echo $pOurPrice; ?></span></div>
                                            </div>
                                        </div>
                                    </div>
                               
                 <?php } 
             }
         }else
             {
                echo "No data Found";
             }?>                   
                                </div>
                            </div>
                        </div>

                           <!--  <div class="tab-pane fade" id="list" role="tabpanel">
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/1.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/2.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <a href="wishlist.htnl"><i class="icon icon-FullShoppingCart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Joust Duffle Bag</a></h4>
                                        <div class="product-price"><span>$34.00</span></div>
                                        <p>The sporty Joust Duffle Bag can't be beat - not in the gym, not on the luggage carousel, not anywhere. Big enough to haul a basketball or soccer ball and some sneakers with plenty of room to spare, it's ideal for athletes with places to go.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/3.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/4.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Strive Shoulder Pack</a></h4>
                                        <div class="product-price"><span>$32.00</span></div>
                                        <p>Our top-selling yoga prop, the 4-inch, high-quality Sprite Foam Yoga Brick is popular among yoga novices and studio professionals alike. An essential yoga accessory, the yoga brick is a critical tool for finding balance and alignment in many common yoga poses. Choose from 5 color options.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/5.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/6.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                        </div>
                                        <h4><a href="product-details.html">Crown Summit Backpack</a></h4>
                                        <div class="product-price"><span>$38.00</span></div>
                                        <p>The Go-Get'r Pushup Grips safely provide the extra range of motion you need for a deep-dip routine targeting core, shoulder, chest and arm strength. Do fewer pushups using more energy, getting better results faster than the standard floor-level technique yield.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/7.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/8.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Wayfarer Messenger Bag</a></h4>
                                        <div class="product-price"><span>$40.00</span></div>
                                        <p>One of the world's simplest and most portable exercise devices, a jump rope enables endless variations and fitness output. The Zing Jump Rope goes anywhere and can be used any time. It is adjustable in length and has contoured foam handles for a great grip.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/9.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/10.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Rival Field Messenger</a></h4>
                                        <div class="product-price">
                                            <span>$45.00</span>
                                            <span class="prev-price">$52.00</span>
                                        </div>
                                        <p>Make the most of your limited workout window with our Dual-Handle Cardio Ball. The 15-lb ball maximizes the effort-impact to your abdominal, upper arm and lower-body muscles. It features a handle on each side for a firm, secure grip.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                        <div class="pagination-wrapper">
                            <nav aria-label="navigation">
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-right"></i></a></li>
                                </ul>
                            </nav>
                            <div class="shop-results"><span>Show</span>
                                <select name="number" id="b-number">
                                    <option value="12">12</option>
                                    <option value="13">13</option>
                                    <option value="14">14</option>
                                    <option value="14">15</option>
                                </select>
                                <span>per page</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4">
                        <div class="sidebar-widget widget-style-1 panel-group" id="widget-parent" aria-multiselectable="true" role="tablist">
                            <h4>Shop By</h4>
                            <div class="panel widget-option">
                                <a data-toggle="collapse" href="#category" data-parent="#widget-parent">Category</a>
                                <div class="collapse show" id="category">
                                    <div class="collapse-content">
                                       
        <?php
         $query_9 =" SELECT `sId`, `scId`, `sParentCategories`, `sName`, `sImage`, `sPosition`, `sIsVisible` FROM `fh_subcategories` WHERE `sIsVisible`='1' order by sPosition ";
         $C_0_data = mysqli_query($conn,$query_9);

                 while ($CategoriesRow = mysqli_fetch_array($C_0_data))
            {
                 $sId = $CategoriesRow['sId'];
                // $scId = $SubCategoriesRow['scId']; 
                $sName = $CategoriesRow['sName'];
              //   $pCode = $CategoriesRow['pCode'];
             
               ?>  
          

            <div class="single-widget-opt">
            <input type="checkbox" id="entry<?php echo $sId;?>" value="<?php echo $sId;?>">
            <label for="tables"><?php echo $sName;  ?></label>
            </div>
            <?php } ?>

                                    
                                    </div>
                                </div>
                            </div>
                           <!--  <div class="panel widget-option">
                                <a class="collapsed" data-toggle="collapse" href="#color" data-parent="#widget-parent">Color</a>
                                <div class="collapse" id="color">
                                    <div class="collapse-content">
                                        <div class="widget-color">
                                            <span class="black"></span>
                                            <span class="blue"></span>
                                            <span class="gray"></span>
                                            <span class="green"></span>
                                            <span class="white"></span>
                                            <span class="purple"></span>
                                            <span class="red"></span>
                                            <span class="white"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel widget-option">
                                <a class="collapsed" data-toggle="collapse" href="#manufacture" data-parent="#widget-parent">Manufacturer</a>
                                <div class="collapse" id="manufacture">
                                    <div class="collapse-content">
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="adidas">
                                            <label for="adidas">Adidas <span>(1)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="chanel">
                                            <label for="chanel">Chanel <span>(4)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="dkny">
                                            <label for="dkny">DKNY <span>(2)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="dolce">
                                            <label for="dolce">Dolce <span>(5)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="gabbana">
                                            <label for="gabbana">Gabbana <span>(1)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="nike">
                                            <label for="nike">Nike <span>(2)</span></label>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                    <?php
                        $P_query_d11 ="SELECT ifnull(count(*),0) as count FROM `fh_products` WHERE pPrice BETWEEN 0 AND 500";
                        $p_deatails11 = mysqli_query($conn,$P_query_d11);
                        $Pro_details11 = mysqli_fetch_array($p_deatails11);
                        $count11 = $Pro_details11['count'];

                        $P_query_d12 ="SELECT ifnull(count(*),0) as count FROM `fh_products` WHERE pPrice BETWEEN 500 AND 1000";
                        $p_deatails12 = mysqli_query($conn,$P_query_d12);
                        $Pro_details12 = mysqli_fetch_array($p_deatails12);
                        $count12 = $Pro_details12['count'];

                        $P_query_d13 ="SELECT ifnull(count(*),0) as count FROM `fh_products` WHERE pPrice BETWEEN 1000 AND 1500";
                        $p_deatails13 = mysqli_query($conn,$P_query_d13);
                        $Pro_details13 = mysqli_fetch_array($p_deatails13);
                        $count13 = $Pro_details13['count'];

                        $P_query_d14 ="SELECT ifnull(count(*),0) as count FROM `fh_products` WHERE pPrice BETWEEN 1500 AND 2000";
                        $p_deatails14 = mysqli_query($conn,$P_query_d14);
                        $Pro_details14 = mysqli_fetch_array($p_deatails14);
                        $count14 = $Pro_details14['count'];

                    ?>

                            <div class="panel widget-option">
                                <a class="collapsed" data-toggle="collapse" href="#price" data-parent="#widget-parent">Price</a>
                                <div class="collapse" id="price">
                                    <div class="collapse-content">
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="low">
                                            <label for="low">₹0.00 - ₹500.00 <span>(<?php echo $count11; ?>)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="l-t-m">
                                            <label for="l-t-m">₹500.00 - ₹1000.00 <span>(<?php echo $count12; ?>)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="medium">
                                            <label for="medium">₹1000.00 - ₹1500.00 <span>(<?php echo $count13; ?>)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="m-t-h">
                                            <label for="m-t-h">₹1500.00 - ₹2000.00 <span>(<?php echo $count14; ?>)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="high">
                                            <label for="high">₹2000.00 - ₹3000.00 <span>(1)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="high">
                                            <label for="high">₹3000.00 - ₹5000.00 <span>(1)</span></label>
                                        </div>
                                        <div class="single-widget-opt">
                                            <input type="checkbox" id="highest">
                                            <label for="highest">₹5000.00 And Above <span>(1)</span></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="sidebar-widget widget-style-1">
                            <h4>Compare Products</h4>
                            <p>You have no items to compare.</p>
                        </div>
                        <div class="sidebar-widget widget-style-1">
                            <h4>My Wish List</h4>
                            <p>You have no items in your wish list.</p>
                        </div>
                        <div class="sidebar-widget">
                            <h4>Most viewed</h4>
                            <div id="box"></div>
                        
                        

<script>
    
      var json = localStorage.getItem('cart') || '{"products":[]}';
    var cart = JSON.parse(json);
     var data_v = localStorage.getItem('cart');
    var cart = JSON.parse(json);
   // console.log(cart['products'].length);
    
    var cart_count = cart['products'].length;
    console.log("count:"+cart_count);
    
     var i;
     var htm ='';
    for (i = 0; i < cart_count; i++)        
    {
     var id = cart['products'][i]['id'];
    var name = cart['products'][i]['name'];
    var price = cart['products'][i]['price'];
    var image = cart['products'][i]['image'];
    var quantity = cart['products'][i]['quantity'];
        console.log(id);
        var total_pri = quantity*price;
        htm ='<div class="product-widget-item">';
        htm+='<div class="product-wid-img">';
        htm+='<a href="product-details.php?pId='+id+'"><img src="'+image+'" alt=""></a>';
        htm+='</div>';
        htm+='<div class="product-text">';
        htm+='<h4><a href="product-details.html">'+name+'</a></h4>';
        htm+='<div class="product-rating">';
        htm+='<i class="fa fa-star color"></i>';
        htm+='<i class="fa fa-star color"></i>';
        htm+='<i class="fa fa-star color"></i>';
        htm+='<i class="fa fa-star "></i>';
        htm+='<i class="fa fa-star "></i>';
        htm+='</div>';
        htm+='<div class="product-price"><span>₹'+price+'</span></div>';
        htm+='</div>';
        htm+='</div>';
}

console.log("count:"+htm);

document.getElementById("box").innerHTML = htm;

   </script>

	                        <!-- <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="product-details.html"><img src="assets/img/widget/1.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="product-details.html">Sprite Foam Yoga Brick</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$5.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="product-details.html"><img src="assets/img/widget/2.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="product-details.html">Dual Handle Cardio Ball</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$8.00</span><span class="prev-price">$12.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="product-details.html"><img src="assets/img/widget/3.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="product-details.html">Push It Messenger Bag</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$50.00</span></div>
                                </div>
	                        </div> -->
                        </div>
                        <div class="sidebar-widget">
                            <a href="product-details.html" class="banner-image">
                                <img src="assets/img/banner/18.jpg" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php // } ?>
        <!-- Shop Area End -->
	    <!-- Footer Area Start -->
	   <?php require_once('_header_f/footer.php'); ?>
<script type="text/javascript">
    
     $('input[type="checkbox"]').click(function() {
        //Create an Array.
            var selected = new Array();
        $("input[type=checkbox]:checked").each(function () {
                selected.push(this.value);
            });
        if(selected.length == 0)
        {
         $("#filtered_product").load(" #filtered_product");

        }

          
         if (selected.length > 0) {
                // alert("Selected values: " + selected.join(","));


           $.ajax({
                        type: "POST",
                        url: "_code/filter_product.php",
                        data: {selected_id:selected.join(","),sort_data:'pCode'},
                        cache: false,
                        success: function (data) {
                            
         // $( "#filtered_product" ).replaceWith(data);
         $( "#filtered_product" ).html(data);

                          alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });



            }

});
 $("select#sort_d").change(function(){
        var selectedSort = $(this).children("option:selected").val();

         alert(selectedSort);
            var selected = new Array();
        $("input[type=checkbox]:checked").each(function () {
                selected.push(this.value);
            });
        if (selected.length > 0) {
             alert("Selected values: " + selected.join(","));


         $.ajax({
             type: "POST",
             url: "_code/filter_product.php",
            data: {sort_data:selectedSort,selected_id:selected.join(",")},
            cache: false,
            success: function (data) {
                            
         // $( "#filtered_product" ).replaceWith(data);
          $( "#filtered_product" ).html(data);
         

                          alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });
     }
    });


 $(".product-hover a").on('click', function()
      {

   var session_check = <?php isset($_SESSION["username"]); ?>
   console.log(session_check);
    var product = {};
     product.id = $(this).attr("data-id");
    var pid = product.id;
    product.name = $('#product_n_l').text();
    alert(product.name);
    product.price = $('#product_p_l').text();
    alert(product.price);
    product.image = $('#p_id_l').attr("data-img");
    alert(product.image);
    product.quantity = "1";
     
     if(session_check)
     {
         $product_id = $(this).attr("data-id");

    alert($product_id);
     cartadd($product_id);

     }
  
       addToCart(product);    
   
    });

     $(".whish_list-id").on('click', function()
      {
    $whish_list_id = $(this).attr("data-id");
    alert($whish_list_id);
     whishlistadd($whish_list_id);
    });  
</script>
    </body>
</html>