
<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
         <?php require_once('_header_f/navbar.php'); ?>
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Wishlist</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
    	<!-- Wishlist Area start -->
        <div class="wishlist-area ptb-90">
            <div class="container">
                <div class="wishlist-content">
                    <form action="#">
                        <div class="wishlist-table table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th class="product-remove"><span>Remove</span></th>
                                        <th class="product-thumbnail">Image</th>
                                        <th class="product-name"><span>Product</span></th>
                                        <th class="w-c-price"><span> Unit Price </span></th>
                                        <th class="product-stock-stauts"><span> Stock Status </span></th>
                                        <th class="product-add-to-cart"><span>Add to Cart </span></th>
                                    </tr>
                                </thead>
                                <tbody>
                                
  <?php 
                // require_once('_header_f/navbar.php');
             include_once("./function_j/wish_list.php");
              $wishlist_data = loadwishlist();
           if($wishlist_data != "No Data Found")
         {             
                  for ($i=0; $i < count($wishlist_data) ; $i++) 
        { 
                $p_name = $wishlist_data[$i]['product_name'];
                $w_id = $wishlist_data[$i]['w_id'];
                 $u_id = $wishlist_data[$i]['user_id']; 
                $us_name = $wishlist_data[$i]['user_name'];
                $color_code = $wishlist_data[$i]['color_code'];
                 $per_unit_price = $wishlist_data[$i]['per_unit_price'];
                 // $quantity_s_p = $wishlist_data[$i]['quantity_s'];
                $total_price_p = $wishlist_data[$i]['total_price'];
                 $product_image = $wishlist_data[$i]['product_image'];
                 $product_id = $wishlist_data[$i]['product_id'];

             //     $m_image[] = explode(",",$product_image);
             // // print_r($m_image);
             // for ($i=0; $i < count($m_image) ; $i++)
             //  { 
                
             //     $m_image_1 = './'.$m_image[$i][0];
             //     $m_image_2 = './'.$m_image[$i][1];
             //     $m_image_3  = './'.$m_image[$i][2];
             
             //            } 
             
        
       
        ?>     

                                    <tr>
                                        <td class="product-remove" id="wishlist_de"><a  data-id="<?php echo $w_id; ?>">×</a></td>
                                        <td class="product-thumbnail"><a href="product-details.html"><img src="assets/img/wishlist/1.jpg" alt="" /></a></td>
                                        <td class="product-name"><a href="product-details.php?<?php echo $product_id?>"><?php echo $p_name?></a></td>
                                        <td class="w-c-price"><span class="amount"><?php echo $per_unit_price ?></span></td>
                                        <td class="product-stock-status"><span class="wishlist-in-stock">In Stock</span></td>
                                        <td class="product-add-to-cart"><a data-id="<?php echo $product_id; ?>"> Add to Cart</a></td>
                                    </tr>
                           <?php } 
                         }else
                           { ?>
                            <tr><td colspan="6"><?php
                            echo $wishlist_data;
                            ?></td>
                            </tr>
                            <?php
                           }?> 
                                   
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="6">
                                            <div class="wishlist-share">
                                                <h4 class="wishlist-share-title">Share on:</h4>
                                                <ul>
                                                    <li><a class="facebook" href="#"></a></li>
                                                    <li><a class="twitter" href="#"></a></li>
                                                    <li><a class="pinterest" href="#"></a></li>
                                                    <li><a class="googleplus" href="#"></a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>	
                    </form>
                </div>
            </div>
        </div>
        <!-- Wishlist Area end -->
	    <!-- Footer Area Start -->

	   <?php require_once('_header_f/footer.php'); ?>
     <script type="text/javascript">
       $(".product-add-to-cart a").on('click', function()
      {
    $product_id = $(this).attr("data-id");
    alert($product_id);
     cartadd($product_id);
    });

     $("#wishlist_de a").on('click', function()
      {
    $whish_id = $(this).attr("data-id");
    alert($whish_id);
     whishlistdelete($whish_id);
    });  
     </script>
    </body>
</html>
