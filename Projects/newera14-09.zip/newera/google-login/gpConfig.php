<?php
session_start();

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '421998256898-uhcsm3j0fqeqojb0m61i4bne3bgv5722.apps.googleusercontent.com';
$clientSecret = 'fg09r2R_QDWjyOLfBm6K2BtU';
$redirectURL = 'http://localhost/newera/google-login/index.php';

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login Using Google');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>