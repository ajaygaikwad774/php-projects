<?php
//Include GP config file && User class
 require_once("../function_j/connection.php");
include_once 'gpConfig.php';
require_once("../function_j/User.php");
// require_once ('User.php');

if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
}

if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
}

if ($gClient->getAccessToken()) {
    //Get user profile data from google
    $gpUserProfile = $google_oauthV2->userinfo->get();
    
    //Initialize User class
    $user = new User();
    
    //Insert or update user data to the database
    $gpUserData = array(
        'oauth_provider'=> 'google',
        'oauth_uid'     => !empty($gpUserProfile['id'])?$gpUserProfile['id']:'',
        'first_name'    => $gpUserProfile['given_name'],
        'last_name'     => $gpUserProfile['family_name'],
        'email'         => $gpUserProfile['email'],
        'gender'        => !empty($gpUserProfile['gender'])?$gpUserProfile['gender']:'',
        'locale'        => !empty($gpUserProfile['locale'])?$gpUserProfile['locale']:'',
        'picture'       => $gpUserProfile['picture'],
        'link'          => !empty($gpUserProfile['link'])?$gpUserProfile['link']:''
    );
    $userData = $user->checkUser($gpUserData);
    
    //Storing user data into session
    $_SESSION['userData'] = $userData;
    
    //Render facebook profile data
    if(!empty($userData)){
   session_start();              
           $_SESSION["loggedin"] = true;
            $_SESSION["u_id"] = $userData['user_id'];
            $_SESSION["username"] = $userData['first_name'].' '.$userData['last_name'];  
    header('Location:../index.php');
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
        header('Location:../account.php');
    }
} else {
    $authUrl = $gClient->createAuthUrl();
    // $output = '<div style="padding-top: 150px;"><center><a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/></a></div></center>';
     header('Location: ' . filter_var($authUrl, FILTER_SANITIZE_URL));
}
?>

<!-- <div><php echo $output; ?></div> -->
