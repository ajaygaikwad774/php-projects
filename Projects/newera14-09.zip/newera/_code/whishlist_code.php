<?php

     require_once('../function_j/connection.php');
     require_once('../function_j/Product.php');
if(isset($_POST['Wlistid']))
{


	$whistlist = $_POST['Wlistid'];
  
      $single_wish ="SELECT * FROM `fh_wishlist` WHERE isvisiable = '1' AND w_id='$whistlist'";
         $single_a = mysqli_query($conn,$single_wish);
       $wish_count = mysqli_num_rows($single_a);
       if($wish_count > 0)
      {
        // header('Location:')
    
      }
      else
   {

   $single_cart ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`, `pPrice`, `pOurPrice`, `pQuantityDiscountPrice`, `pDeliveryCost`, `pGstRate`, `pWarranty`, `pDeliveryTime`, `pColour`, `pSeatMaterial`, `pBackMaterial`, `pDimension`, `pStatus`, `pPaymentCode`, `pFeaturesCode`, `pWarrantyCode`, `pDeliveryCode`, `pImage`, `pPosition`, `pIsVisible`, `pHasFreeDelivery`, `pDescription`, `pKeyword` FROM `fh_products` WHERE `pIsVisible` ='1' AND `pCode` = '$whistlist'";

  $single_d_a = mysqli_query($conn,$single_cart);
       $s_cart_count = mysqli_num_rows($single_d_a);
       if($s_cart_count > 0)
       {
            $cart_da = mysqli_fetch_array($single_d_a);
      
               $userid=" ";
               $username=" ";
                $sId = $cart_da['pSubCategoriesId'];
                 $pOurPrice = $cart_da['pOurPrice']; 
                $pName = $cart_da['pName'];
                 $pCode = $cart_da['pCode'];
                 $pPrice = $cart_da['pPrice'];
                 $color_code = " ";
                 $total_price =$cart_da['pOurPrice'];
                 $product_image =$cart_da['pImage'];

     echo $query_W_c ="INSERT INTO `fh_wishlist`(`user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `color_code`, `total_price`, `product_image`) VALUES ('$userid','$username','$pCode' ,'$pName','$pOurPrice','$color_code','$total_price','$product_image')";

       $w_data = mysqli_query($conn,$query_W_c);

 
   }
}
     }else if(isset($_POST['wish_d_id']))
  {

$wish_d_id_a = mysqli_real_escape_string($conn,$_POST['wish_d_id']);
 echo   $query_delete = "UPDATE `fh_wishlist` SET `isvisiable`= '0' WHERE w_id='$wish_d_id_a'";
    $stmt = mysqli_query($conn, $query_delete );
    



  }
 
  ?> 
