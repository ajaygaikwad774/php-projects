<?php 
require_once('../function_j/connection.php');
if(isset($_POST['selected_id']) && isset($_POST['sort_data']))
{
	$selected_id_1 = htmlentities($_POST['selected_id']);
     $sort_data_2 = htmlentities($_POST['sort_data']);
  $query_0 ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`,`pOurPrice` , `pPrice` FROM `fh_products` WHERE pIsVisible ='1' AND pSubCategoriesId IN ($selected_id_1) Order By $sort_data_2";
         $P_data = mysqli_query($conn,$query_0);
          $count_p = mysqli_num_rows($P_data);
          if($count_p > 0)
          {
         ?>
          <div class="tab-pane active show fade text-center" id="grid" role="tabpanel">
                                <div class="row">

           <?php      while ($SubCategoriesRow = mysqli_fetch_array($P_data))
            {
                 $sId = $SubCategoriesRow['pSubCategoriesId'];
                 $pOurPrice = $SubCategoriesRow['pOurPrice']; 
                $pName = $SubCategoriesRow['pName'];
                 $pCode = $SubCategoriesRow['pCode'];
                 $pPrice = $SubCategoriesRow['pPrice'];
             
               ?> 

	<div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="product-item">
                                    <div class="product-image-hover">
                                                <a href="product-details.html">
                                                    <img class="primary-image" src="<?php echo $sImage ?>" alt="">
                                                    <img class="hover-image" src="<?php echo $sImage ?>" alt="">
                                                </a>
                                                <div class="product-hover">
                                                    <button><i class="icon icon-FullShoppingCart"></i></button>
                                                    <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                                    <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                                </div>
                                            </div>
                                            <div class="product-text">
                                                <div class="product-rating">
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <h4><a href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName; ?></a></h4>
                                                <div class=""> <span style="text-decoration: line-through;font-size:0.7em;"><?php echo $pPrice; ?></span></div>
                                                <div class="product-price"><span><?php echo $pOurPrice; ?></span></div>
                                            </div>
                                        </div>
                                    </div>
<?php 
}
?>
</div>
</div>
<?php
}
else
{
 echo "No Data Found";
}
}
?>