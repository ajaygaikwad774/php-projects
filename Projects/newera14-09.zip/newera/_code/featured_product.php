<?php 
require_once('./function_j/connection.php');
	
  $query_0 ="SELECT DISTINCT(cName),cId FROM `fh_categories` fc INNER JOIN fh_products fd ON fc.cId=fd.pCategoriesId ORDER BY fc.cPosition ASC";
         $P_data = mysqli_query($conn,$query_0);
          $count_p = mysqli_num_rows($P_data);
          if($count_p > 0)
          {
           while ($SubCategoriesRow = mysqli_fetch_array($P_data)){
           $cId = $SubCategoriesRow['cId'];
           $cName = $SubCategoriesRow['cName'];

           ?>

                <div class="feature-product-area text-center ptb-60">
	        <div class="container">
	            <div class="section-title">
                    <!-- <span>featured SHOP ITEMS</span> -->
	                <h2><span><?php echo $cName; ?></span></h2>
	            </div>
	        </div>
	        <div class="container">
	            <div class="custom-row">
                    <div class="feature-product-carousel owl-carousel">

           <?php 
                 $query_1 ="SELECT pCode,pName,pPrice,pOurPrice FROM `fh_products` WHERE pCategoriesId=$cId ORDER BY pId DESC LIMIT 0,5";
		         $P_data1 = mysqli_query($conn,$query_1);
		          $count_p1 = mysqli_num_rows($P_data1);
		          if($count_p1 > 0)
		          {
		         ?>
		          <?php  while ($SubCategoriesRow1 = mysqli_fetch_array($P_data1))
		            {
		                 $pCode = $SubCategoriesRow1['pCode'];
		                 $pName = $SubCategoriesRow1['pName'];
		                 $pPrice = $SubCategoriesRow1['pPrice'];
		                 $pOurPrice = $SubCategoriesRow1['pOurPrice'];
                  
		           ?>         


                        <div class="custom-col">
                            <div class="product-item mb-25">
                                <!-- <span class="hot-sale">sale</span> -->
                                <div class="product-image-hover">
                                    <a href="product-details.php?pId=<?php echo $pCode;?>">
                                        <img class="primary-image" src="assets/img/product/13.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/14.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName; ?></a></h4>
                                    <div class="product-price">
                                        <span>₹<?php echo $pPrice; ?></span>
                                        <span class="prev-price">₹<?php echo $pOurPrice; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <?php } }?>
                    </div>
	            </div>
	        </div>
	    </div>

	   <?php  } }?>