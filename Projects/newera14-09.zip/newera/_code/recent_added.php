<?php 
require_once('./function_j/connection.php');
	
  $query_0 ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`,`pOurPrice` , `pPrice` FROM `fh_products` WHERE pIsVisible ='1' AND pSubCategoriesId order by pId desc limit 0,11";
         $P_data = mysqli_query($conn,$query_0);
          $count_p = mysqli_num_rows($P_data);
          if($count_p > 0)
          {
         ?>
          <?php  while ($SubCategoriesRow = mysqli_fetch_array($P_data))
            {
                 $sId = $SubCategoriesRow['pSubCategoriesId'];
                 $pOurPrice = $SubCategoriesRow['pOurPrice']; 
                $pName = $SubCategoriesRow['pName'];
                 $pCode = $SubCategoriesRow['pCode'];
                 $pPrice = $SubCategoriesRow['pPrice'];
             
               ?> 

                        <div class="custom-col">
                            <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="product-details.php?pId=<?php echo $pCode;?>">
                                        <img class="primary-image" src="assets/img/product/1.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/2.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName; ?></a></h4>
                                    <div class="product-price"><span><?php echo $pPrice; ?></span></div>
                                </div>
                            </div>
                        </div>
	
<?php 
}
?>

<?php
}
else
{
 echo "No Data Found";
}

?>