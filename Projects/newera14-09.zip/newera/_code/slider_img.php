<?php
require_once('./function_j/connection.php');
	
  $query_0 ="SELECT  `slider1`, `slider2`, `slider3`, `slider4`, `slider5` FROM `fh_homepage` WHERE 1";
         $P_data = mysqli_query($conn,$query_0);
          $count_p = mysqli_num_rows($P_data);
          if($count_p > 0)
          {
            $SubCategoriesRow = mysqli_fetch_array($P_data);

            $slider1=$SubCategoriesRow['slider1'];
            $slider2=$SubCategoriesRow['slider2'];
            $slider3=$SubCategoriesRow['slider3'];
            $slider4=$SubCategoriesRow['slider4'];
            $slider5=$SubCategoriesRow['slider5'];
				
			$array1= array();
            if($slider1!='-'){
             array_push($array1,$slider1);
            }

            if($slider2!='-'){
             array_push($array1,$slider2);
            }

            if($slider3!='-'){
             array_push($array1,$slider3);
            }

            if($slider4!='-'){
             array_push($array1,$slider4);
            }

            if($slider5!='-'){
             array_push($array1,$slider5);
            }
             
            
            }

            $arrlength = count($array1);
            for($x = 0; $x < $arrlength; $x++) {
?>

<div class="single-slide" style="background-image: url('<?php echo $home_page.$array1[$x];?>');">
	                <div class="container">
                        <div class="slider-banner">
                            <h1>Collection</h1>
                            <h2>Lamps light Color</h2>
                            <p>Eikon is made of certified wood and a lampshade that is attached<br>simply with the help of magnets.</p>
                                
                            <a href="shop.php" class="banner-btn">Shop now</a>
                        </div>
	                </div>
	            </div>
<?php  }?>
