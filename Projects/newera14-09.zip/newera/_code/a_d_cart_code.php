<?php

     require_once('../function_j/connection.php');
     require_once('../function_j/Product.php');
if(isset($_POST['pro_id']))
{


	$pid = $_POST['pro_id'];
  $quantity_s = $_POST['quantity_s'];
  
	

      $single_cart ="SELECT  fh_cart.quantity_s , fh_products.pOurPrice FROM `fh_cart` INNER JOIN `fh_products` ON fh_cart.product_id = fh_products.pCode WHERE fh_cart.isvisiable = '1' AND fh_cart.product_id ='$pid'";
         $single_d_a = mysqli_query($conn,$single_cart);
       $s_cart_count = mysqli_num_rows($single_d_a);
       if($s_cart_count > 0)
       {
   
        $cart_da = mysqli_fetch_array($single_d_a);
         
          echo $cart_da['pOurPrice'];
         $cart_quantity = $cart_da['quantity_s'];

        $cart_q_s = $cart_quantity + $quantity_s;
          
          $total_p_a = $cart_da['pOurPrice'] * $cart_q_s;
       
   $query_cart_c ="UPDATE `fh_cart` SET `quantity_s`='$cart_q_s' , total_price = '$total_p_a' WHERE isvisiable ='1' AND product_id='$pid' ";
   $update_d_a = mysqli_query($conn,$query_cart_c);
   }
      else
   {

  $single_cart ="SELECT `pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`, `pPrice`, `pOurPrice`, `pQuantityDiscountPrice`, `pDeliveryCost`, `pGstRate`, `pWarranty`, `pDeliveryTime`, `pColour`, `pSeatMaterial`, `pBackMaterial`, `pDimension`, `pStatus`, `pPaymentCode`, `pFeaturesCode`, `pWarrantyCode`, `pDeliveryCode`, `pImage`, `pPosition`, `pIsVisible`, `pHasFreeDelivery`, `pDescription`, `pKeyword` FROM `fh_products` WHERE `pIsVisible` ='1' AND `pCode` = '$pid'";

  $single_d_a = mysqli_query($conn,$single_cart);
       $s_cart_count = mysqli_num_rows($single_d_a);
       if($s_cart_count > 0)
       {
            $cart_da = mysqli_fetch_array($single_d_a);
      
               $userid=" ";
               $username=" ";
                $sId = $cart_da['pSubCategoriesId'];
                 $pOurPrice = $cart_da['pOurPrice']; 
                $pName = $cart_da['pName'];
                 $pCode = $cart_da['pCode'];
                 $pPrice = $cart_da['pPrice'];
                 $p_quantity = $quantity_s;
                 $color_code = " ";
                 $total_price =$cart_da['pOurPrice'];
                 $product_image =$cart_da['pImage'];


     echo $query_cart_c ="INSERT INTO `fh_cart`(`user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `quantity_s`, `color_code`, `total_price`, `product_image`) VALUES ('$userid','$username','$pCode' ,'$pName','$pOurPrice','$p_quantity','$color_code','$total_price','$product_image')";

                $i_cart_data = mysqli_query($conn,$query_cart_c);

            if($i_cart_data)
            {
                // echo "inserted";
            }
       }
}
}else if(isset($_POST['d_pro_id']))
{

$delete_cart_item = mysqli_real_escape_string($conn,$_POST['d_pro_id']);
 echo   $query_delete = "UPDATE `fh_cart` SET `isvisiable`= '0' WHERE cart_id='$delete_cart_item'";
    $stmt = mysqli_query($conn, $query_delete );
    



}

   
          
               ?> 
