   <header class="header-area bg-ash">
   	 <?php include("./function_j/connection.php"); ?>
    <!--  <php include("./function_j/functions.php"); ?> -->
            <!--Header Top Area Start -->
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <span class="welcome-text">Welcome you to ArtFurniture store!</span>
                        </div>
                        <div class="col-md-8">
                            <div class="header-top-links">
                                
                                <div class="account-wishlist">
                                    <!-- <a href="account.php">My Account</a> -->
                                    <a href="wishlist.php">My Wish List</a>
                                </div>
                                    <?php session_start();
 if(isset($_SESSION["loggedin"]) && isset($_SESSION["id"]) && isset($_SESSION["username"])){ ?>

     <ul class="header-submenu">
                                    <li><?php echo $_SESSION["username"]; ?><i class="fa fa-angle-down"></i></a>
                                        <ul class="h-submenu">
                                           
                                            <li><a href="./logout.php">Logout</a></li>
                                          
                                        </ul>
                                    </li>
                                </ul>
    
        
                                <?php } else { ?>
                                    <div class="account-wishlist">
                                	<a href="./account.php">Sign In</a>
                                     </div>
                                <?php } ?>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Header Top Area End -->
            <!--Header Middle Area Start -->
            <div class="header-middle-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="logo">
                                <a href="index.php"><img src="assets/img/logo/logo.png" alt="Artfurniture"></a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <span class="email-image">
                                <span><img src="assets/img/icon/email.png" alt=""></span>
                                <span><span>Email: </span>admin@artfurniture.com</span>
                            </span>
                        </div>
                        <div class="col-md-6">
                            <form action="#" method="post" class="header-search">
                                <input type="text" placeholder="Search for item...">
                                <button><i class="icon icon-Search"></i></button>
                            </form>
                            <div class="cart-box-wrapper">
                                <a class="cart-info" href="cart.php">
                                    <span>
                                        <img src="assets/img/icon/cart.png" alt="">
                <?php 
                // require_once('_header_f/navbar.php');
             include_once("./function_j/cart_code.php");
       // $cart_data = Allcartdata();
       // print_r($cart_data);
        ?>                   
                                        <span><?php echo $cart_item_count; ?></span>
                                    </span>
                                    <span>My Cart</span>
                                </a>
                                <div class="cart-dropdown">
                                    <button class="close"><i class="fa fa-close"></i></button>
                                    <div class="cart-item-a-wrapper">
                                        <div class="cart-item-amount">
                                            <span class="cart-number"><span><?php echo $cart_item_count; ?></span> items</span>
                                            <div class="cart-amount">
                                                <h5>Cart Subtotal :</h5>
                                                <h4>₹<?php echo $cart_total_amount;?></h4>
                                            </div>
                                        </div>
                                        <a href="checkout.php" class="grey-button">Go to Checkout</a>
                                    </div>

       <?php 
                 //  print_r($cart_data);
        if(!empty($cart_data))
       {   
     for ($i=0; $i < count($cart_data) ; $i++) 
        { 
                $p_name = $cart_data[$i]['product_name'];
                $cart_id = $cart_data[$i]['cart_id'];
                 $u_id = $cart_data[$i]['user_id']; 
                $us_name = $cart_data[$i]['user_name'];
                $color_code = $cart_data[$i]['color_code'];
                 $per_unit_price = $cart_data[$i]['per_unit_price'];
                 $quantity_s_p = $cart_data[$i]['quantity_s'];
                $total_price_p = $cart_data[$i]['total_price'];
                 $product_image = $cart_data[$i]['product_image'];
                 $product_id = $cart_data[$i]['product_id'];

                 $m_image[] = explode(",",$product_image);
             // print_r($m_image);
             for ($i=0; $i < count($m_image) ; $i++)
              { 
                
                 $m_image_1 = './'.$m_image[$i][0];
                 $m_image_2 = './'.$m_image[$i][1];
                 $m_image_3  = './'.$m_image[$i][2];
             
                        } 
             
        
       ?>                             
                                    <div class="cart-dropdown-item">
                                        <div class="cart-p-image">
                                            <a href="cart.php"><img src="<?php echo $m_image_1; ?>" alt=""></a>
                                        </div>
                                        <div class="cart-p-text">
                                            <a href="cart.php" class="cart-p-name"><?php  ?></a>
                                            <span><?php echo $total_price_p; ?></span>
                                            <div class="cart-p-qty">
                                                <label>Qty</label>
                                                <input type="text" placeholder="<?php echo $quantity_s_p ?>">
                                                <a id="delete_a_s" data-id="<?php echo $cart_id; ?>"><i class="icon icon-Delete"></i></a>
                                            </div>
                                        </div>
                                    </div>
             <?php }
         }else
         {
            echo ' <div class="cart-dropdown-item">'.$cart_d.'</div>';
         }
              ?>                       
                                    <!-- <div class="cart-dropdown-item">
                                        <div class="cart-p-image">
                                            <a href="cart.php"><img src="assets/img/cart/s-2.jpg" alt=""></a>
                                        </div>
                                        <div class="cart-p-text">
                                            <a href="cart.php" class="cart-p-name">Strive Shoulder Pack</a>
                                            <span>$32.00</span>
                                            <div class="cart-p-qty">
                                                <label>Qty</label>
                                                <input type="text" placeholder="1">
                                                <button><i class="icon icon-Delete"></i></button>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="cart-btn-wrapper">
                                        <a href="cart.php" class="grey-button">View and edit cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Header Middle Area End -->
            <!-- Mainmenu Area Start -->
            <div class="mainmenu-area header-sticky display-none">
                <div class="container">
                    <div class="menu-wrapper">
                        <div class="main-menu">
                            <nav>
                                <ul>
                                    <li class="active"><a href="index.php">Home</a>
                                      
                                    </li>
                                    <li class="megamenu"><a href="#">Megamenu</a>
                                        <ul>
                                            
                                                <?php  getAllCategories(); ?>
                                            
                                        </ul>

                                    </li>

                                    <li><a href="about.php">About Us</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                   <!-- <li><a href="shop.php">Shop</a>
                                        <ul>
                                            <li><a href="shop.php">Shop Page</a></li>
                                            <li><a href="product-details.php">Product Details</a></li>
                                            <li><a href="cart.php">Cart Page</a></li>
                                            <li><a href="checkout.php">Checkout Page</a></li>
                                            <li><a href="wishlist.php">Wishlist Page</a></li>
                                        </ul>
                                    </li>-->
                                   <!--  <li><a href="about.php">About Us</a></li> -->
                                   <!--  <li><a href="blog.html">Blog</a>
                                        <ul>
                                            <li><a href="blog-details.html">Blog Details</a></li>
                                        </ul>
                                    </li> -->
                                    <!-- <li><a href="#">Pages</a>
                                        <ul>
                                            <li><a href="about.html">About Page</a></li>
                                            <li><a href="cart.html">Cart Page</a></li>
                                            <li><a href="checkout.html">Checkout Page</a></li>
                                            <li><a href="wishlist.html">Wishlist Page</a></li>
                                            <li><a href="account.html">Account Page</a></li>
                                            <li><a href="blog.html">Blog Page</a>
                                            <li><a href="blog-details.html">Blog Details</a></li>
                                            <li><a href="contact.html">Contact</a></li>
                                        </ul>
                                    </li> -->
                                  <!--   <li><a href="contact.php">Contact</a></li> -->
                                  <!--  <li><a href="#">Buy Now</a></li>-->
                                </ul>
                                 
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mainmenu Area End -->
            <!-- Mobile Menu Area Start -->
            <div class="mobile-menu-area container">
                <div class="mobile-menu">
                    <nav id="mobile-menu-active">
                        <ul class="menu-overflow">
                            <li><a href="index.php">HOME</a>
                               <!--  <ul>
                                    <li><a href="index.html">Homepage One</a></li>
                                    <li><a href="index-2.html">Homepage Two</a></li>
                                    <li><a href="index-3.html">Homepage Three</a></li>
                                    <li><a href="index-4.html">Homepage Four</a></li>
                                </ul> -->
                            </li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="shop.php">Shop</a>
                                <ul>
                                    <li><a href="product-details.php">Product Details Page</a></li>
                                    <li><a href="cart.php">Cart Page</a></li>
                                    <li><a href="checkout.php">Checkout Page</a></li>
                                    <li><a href="wishlist.php">Wishlist Page</a></li>
                                </ul>
                            </li>
                            <!-- <li><a href="blog.html">Blog</a>
                                <ul>
                                    <li><a href="blog-details.html">Blog Details</a></li>
                                </ul>
                            </li> -->
                            <li><a href="account.php">Account</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav>							
                </div>
            </div>
            <!-- Mobile Menu Area End -->
        </header>