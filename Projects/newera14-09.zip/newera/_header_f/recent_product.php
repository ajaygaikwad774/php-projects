
<?php 

 // $actual_link = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
// print_r($_SERVER['QUERY_STRING']);
echo $_SERVER['SERVER_ADDR'];
 $url_file_name = basename($_SERVER['PHP_SELF']);
  if($url_file_name === 'recent_product.php')
  {


  }
// //set product id
// $product_id = [//some stuff here sets the product id]
// // if the cookie exists, read it and unserialize it. If not, create a blank array
// if(array_key_exists('recentviews', $_COOKIE)) {
//     $cookie = $_COOKIE['recentviews'];
//     $cookie = unserialize($cookie);
// } else {
//     $cookie = array();
// }

// // add the value to the array and serialize
// $cookie[] = $product_id;
// $cookie = serialize($cookie);

// // save the cookie
// setcookie('recentviews', $cookie, time()+3600);


?>