 <footer class="footer-area">
            <div class="footer-top pt-80 pb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-5">
                            <div class="single-footer-widget">
                                <div class="footer-logo">
                                    <a href="index.html"><img src="assets/img/logo/logo-2.png" alt=""></a>
                                </div>
                                <div class="single-footer-text">
                                    <span>Addresss: No 123 - Furtinure Street, USA.</span>
                                    <span>Phone 01: +(800) 123 456 78</span>
                                    <span>Phone 02: +(100) 123 456 789</span>
                                    <span>Fax : (800) 123 456 789</span>
                                    <span>Email:Contact@hastech.com</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-3">
                            <div class="single-footer-widget">
                                <h4>ABOUT US</h4>
                                <ul class="footer-widget-list">              
                                    <li><a href="#">Site Map</a></li>
                                    <li><a href="#">Specials</a></li>
                                    <li><a href="#">Delivery Information</a></li>
                                    <li><a href="#">Order History</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-4">
                            <div class="single-footer-widget">
                                <h4>INFORMATION</h4>
                                <ul class="footer-widget-list">              
                                    <li><a href="account.html">My Account</a></li>
                                    <li><a href="#">Gift Cards</a></li>
                                    <li><a href="#">Return Policy</a></li>
                                    <li><a href="#">Your Orders</a></li>
                                    <li><a href="#">Subway</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-3">
                            <div class="single-footer-widget">
                                <h4>my account</h4>
                                <ul class="footer-widget-list">              
                                    <li><a href="account.html">My Account</a></li>
                                    <li><a href="checkout.html">Checkout</a></li>
                                    <li><a href="account.html">Login</a></li>
                                    <li><a href="#">Order status</a></li>
                                    <li><a href="#">Site Map</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="single-footer-widget">
                                <h4>sign up newsletter</h4>
                                <p>Be the first to hear about new trending and offers and see how youve helped</p>
                                <div class="newsletter-form mc_embed_signup">
                                    <form action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                        <div id="mc_embed_signup_scroll" class="mc-form">
                                            <input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="Enter your email address" required>
                                            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                            <div class="mc-news" aria-hidden="true"><input type="text" name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef" tabindex="-1" value=""></div>
                                            <button id="mc-embedded-subscribe" type="submit" name="subscribe">Subscribe</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <span>Copyright &copy; 2018 <a href="https://hastech.company/">HasTech</a>. All rights reserved.</span>
                        </div>
                        <div class="col-lg-4 col-md-2">
                            <div class="social-link">
                                <a href="https://twitter.com/devitemsllc"><i class="fa fa-twitter"></i></a>
                                <a href="https://plus.google.com/117030536115448126648"><i class="fa fa-google-plus"></i></a>
                                <a href="https://www.facebook.com/devitems/"><i class="fa fa-facebook"></i></a>
                                <a href="https://www.youtube.com/channel/UC_AH6tcQrJa8txh_rNbL-AQ"><i class="fa fa-youtube"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <div class="payment-image">
                                <img src="assets/img/payment.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	    </footer>

        <!-- all js here -->
        <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="assets/js/popper.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/jquery.meanmenu.js"></script>
        <script src="assets/js/ajax-mail.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>
        <script type="text/javascript">
		
		

  function cartadd($product_id,$quantity="1")
  {
        $.ajax({
             type: "POST",
             url: "_code/a_d_cart_code.php",
            data: {pro_id:$product_id,quantity_s:$quantity},
            cache: false,
            success: function (data) {
                // location.reload();
          // $( "#filtered_product" ).html(data);
           alert(data);
             header("Location:../cart.php");
         // alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });

  }

   function whishlistadd($whish_list_id)
  {
        $.ajax({
             type: "POST",
             url: "_code/whishlist_code.php",
            data: {Wlistid:$whish_list_id},
            cache: false,
            success: function (data) {
                 // location.reload();
          // $( "#filtered_product" ).html(data);
           alert(data);
           // header('../wishlist.php');
           header("Location:../wishlist.php");
         // alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });

  }

    function whishlistdelete($whish_id)
  {
        $.ajax({
             type: "POST",
             url: "_code/whishlist_code.php",
            data: {wish_d_id:$whish_id},
            cache: false,
            success: function (data) {
              location.reload();
           
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });

  }

  $(".delete_a_s").on('click', function()
       {

          $product_id = $(this).attr("data-id");
           alert($product_id);
          Delete_add($product_id);
  function Delete_add($product_id)
  {
        $.ajax({
             type: "POST",
             url: "_code/a_d_cart_code.php",
            data: {d_pro_id:$product_id},
            cache: false,
            success: function (data) {
                 
          // $( "#filtered_product" ).html(data);
           cartadd($product_id);
           // header("Location:../cart.php");
           // header('../cart.php');
         //  alert(data);
         // alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });

  }
});

		

function addToCart(product,quantity="1") 
{
//  localStorage.clear();
   if (localStorage)
	   {
		   
  var json = localStorage.getItem('cart') || '{"products":[]}';
    var cart = JSON.parse(json);
 
     var cart_count = cart['products'].length;
	console.log(cart_count);
	  if(cart_count == 0)
	 {
     cart.products.push(product);
	  localStorage.setItem('cart', JSON.stringify(cart));
      var data_v = localStorage.getItem('cart');
      var cart = JSON.parse(json);
	 }
	 else{
	 
     localStorage.setItem('cart', JSON.stringify(cart));
      var data_v = localStorage.getItem('cart');
      var cart_e = JSON.parse(json);

      console.log(cart['products'][0]['id']);
      alert(product.id); 
	   
	    for (i = 0; i < cart_count; i++) 		
	{
	 var id_e = cart_e['products'][i]['id'];
	  //alert(id_e);
	 // alert(product.id);
        if(product.id == id_e) {
		newquantity = parseInt(product.quantity) + 1;
		 product.quantity = newquantity.toString();
		 
		
		}
	}
	console.log(cart['products']);
	console.log(product);
	console.log(cart['product']);
	cart.products.push(product);
	  localStorage.setItem('cart', JSON.stringify(cart));
      var data_v = localStorage.getItem('cart');
      var cart = JSON.parse(json);
	   
	  
     }
	 }

 //  window.location.href = "./cart.php"
}




        </script>
