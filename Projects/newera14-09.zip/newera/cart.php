<?php require_once('_header_f/header.php'); ?>
    <body>
     
        <!-- Header Area Start -->
       <?php require_once('_header_f/navbar.php');
       
       // print_r($cart_data);
        ?>
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Cart</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Main Area Start -->
        <div class="cart-main-area ptb-80">
            <div class="container">
			<div id="box"></div>
                <form action="#">
                    <div class="cart-table table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th class="p-image"></th>
                                    <th class="p-name">Product Name</th>
                                    <th class="p-amount">Unit Price</th>
                                    <th class="p-quantity">Qty</th>
                                    <th class="p-total">Total</th>
                                    <th class="p-edit">Edit</th>
                                </tr>
                            </thead>
                            <tbody>
			
   <script>
      var json = localStorage.getItem('cart') || '{"products":[]}';
    var cart = JSON.parse(json);
     var data_v = localStorage.getItem('cart');
    var cart = JSON.parse(json);
   // console.log(cart['products'].length);
	
	var cart_count = cart['products'].length;
	console.log(cart_count);
	
	 var i;
	 var htm ='<table>';
    for (i = 0; i < cart_count; i++) 		
	{
	 var id = cart['products'][i]['id'];
	var name = cart['products'][i]['name'];
	var price = cart['products'][i]['price'];
	var image = cart['products'][i]['image'];
	var quantity = cart['products'][i]['quantity'];
		console.log(id);
		var total_pri = quantity*price;
		
	 htm+='<tr>';
    htm+='<td class="p-image"><a href="product-details.html"><img alt="" src="'+image+'"></a></td>';
    htm+='<td class="p-name"><a href="product-details.php?pId='+id+'">'+name+'</a></td>';
    htm+='<td class="p-amount">'+price+'</td>';
	htm+='<td class="p-quantity"><input maxlength="12" type="text" value="'+quantity+'" name="quantity"></td>';
	htm+='<td class="p-total"><span>'+total_pri+'</span></td>';
	htm+='<td class="edit"> <a class ="delete_a_s" data-id="+id+"><img src="assets/img/icon/delte.png" alt=""></a></td>';
	 htm+='</tr>';

}
htm+="</table>";
document.getElementById("box").innerHTML = htm;

   </script>
			
                        <?php include_once("function_j/cart_code.php"); 
                        // print_r($cart_data);
                        $quantity=0;
                        $amount=0;
        if(!empty($cart_data))
        if(!empty($cart_data))
       {  
         for ($i=0; $i < count($cart_data) ; $i++) 
                { 

                $cart_id = $cart_data[$i]['cart_id'];
                  $p_name = $cart_data[$i]['product_name'];
                 $u_id = $cart_data[$i]['user_id']; 
                $us_name = $cart_data[$i]['user_name'];
                $color_code = $cart_data[$i]['color_code'];
                 $per_unit_price = $cart_data[$i]['per_unit_price'];
                 $quantity_s_p = $cart_data[$i]['quantity_s'];
                 $quantity+=$quantity_s_p;
                $total_price_p = $cart_data[$i]['total_price'];
                $amount+=$total_price_p;
                 $product_image = $cart_data[$i]['product_image'];
                 $product_id = $cart_data[$i]['product_id'];
                 
                   // print_r($product_image);
                  $m_image[] = explode(",",$product_image);
            
                
                 $m_image_1 = $m_image[$i][0];
                 $m_image_2 = $m_image[$i][1];
                 $m_image_3  = $m_image[$i][2];
             
                          
                          
                        ?>
                                <tr>
                                    <td class="p-image"><a href="product-details.html"><img alt="" src="<?php echo $m_image_1; ?>"></a></td>
                                    <td class="p-name"><a href="product-details.php?pId=<?php echo $product_id;?>"><?php echo $p_name; ?></a></td>
                                    <td class="p-amount"><?php echo $per_unit_price; ?></td>
                                    <td class="p-quantity"><input maxlength="12" type="text" value="<?php echo $quantity_s_p; ?>" name="quantity"></td>
                                    <td class="p-total"><span><?php echo $total_price_p; ?></span></td>
                                    <td class="edit"> <a class ="delete_a_s" data-id="<?php echo $cart_id; ?>"><img src="assets/img/icon/delte.png" alt=""></a></td>
                                </tr>
                            <?php
                          
                             }
                        }else 
                        {
                             echo '<tr><td colspan="6">'.$cart_d.'</td></tr>';
                        }
                             ?>
                            </tbody>
                        </table>
                    </div>
					
                    <div class="all-cart-buttons">
                        <button class="button" type="button"><span>Continue Shopping</span></button>
                        <button class="button" type="button"><span>CLEAR CART</span></button>
                        <button class="button" type="button"><span>Update Cart</span></button>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-12">
                            <div class="ht-shipping-content">
                                <h3>RELATED PRODUCTS</h3>
                                <p>Base on your selection, you may be interested in the following items:</p>  
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="ht-shipping-content">
                                <h3>Discount Code</h3>
                                <p>Enter your coupon code if you have one</p>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="postal-code">
                                            <input type="text" placeholder="">
                                        </div>
                                        <div class="buttons-set">
                                            <button class="button" type="button"><span>Apply Coupon</span></button>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            <div class="ht-shipping-content">
                                <h4>Estimate Shipping And Tax</h4>
                                <p>Enter your destination to get shipping &amp; tax</p>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-6">
                                        <div class="level">
                                            Country <span class="required">*</span>
                                        </div>
                                        <div class=" shipping-wrapper">
                                          <select class="country">
                                            <option value="state">Select</option>
                                            <option value="state">Bahasa Indonesia</option>
                                            <option value="state">Bahasa Melayu</option>		
                                            <option value="state">Deutsch (Deutschland)</option>		
                                            <option value="state">English (Australia)</option>		
                                            <option value="state">English (Canada)</option>		
                                            <option value="state">English (India)</option>		
                                            <option value="state">English (Ireland)</option>		
                                            <option value="state">English (Maktoob)</option>		
                                            <option value="state">English (Malaysia)</option>		
                                          </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-6">
                                        <div class="level">
                                            State/Province
                                        </div>
                                        <div class=" shipping-wrapper">
                                          <select class="country">
                                            <option value="state">Select</option>
                                            <option value="state">South Carolina</option>
                                            <option value="state">South Dakota</option>
                                            <option value="state">Tennessee</option>		
                                            <option value="state">Texas</option>		
                                            <option value="state">Utah</option>		
                                            <option value="state">Vermont</option>		
                                            <option value="state">Virginia</option>		
                                            <option value="state">Washington</option>		
                                            <option value="state">West Virginia</option>		
                                            <option value="state">Wyoming</option>		
                                          </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="postal-code">
                                            <div class="level">
                                                Zip / Postal Code 
                                            </div>
                                            <input type="text" placeholder="" name="zip-code">
                                        </div>
                                        <div class="buttons-set">
                                            <button class="button" type="button"><span>Get a Quote</span></button>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="ht-shipping-content">
                                <h3>Total</h3>
                                <div class="amount-totals">
                                    <p class="total">Subtotal <span>₹<?php echo $amount;?></span></p>
                                    <p class="total">Grandtotal <span>₹<?php echo $amount;?></span></p>
                                    <button class="button" type="button"><span>Procced to checkout</span></button>
                                    <div class="clearfix"></div>
                                    <p class="floatright">Checkout with multiples address</p>
                                </div>   
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Cart Main Area End -->  
	    <!-- Footer Area Start -->
	    <?php require_once('_header_f/footer.php'); ?>
    </body>
</html>