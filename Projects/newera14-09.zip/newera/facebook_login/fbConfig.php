<?php
if(!session_id()){
    session_start();
}

// Include the autoloader provided in the SDK
require_once __DIR__ . '/facebook-php-sdk/autoload.php';

// Include required libraries
use Facebook\Facebook;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

/*
 * Configuration and setup Facebook SDK
 */
//$appId         = '2369813536673655'; //Facebook App ID
$appId         = '2408135499270489'; //Facebook App ID
//$appSecret     = '13af5b3342df9890b9ad87ede7224c14'; //Facebook App Secret
$appSecret     = '6ec87428c2d24a725eaadcc5eae2f255'; //Facebook App Secret
$redirectURL   = 'http://localhost/newera/facebook_login/index.php'; //Callback URL
$fbPermissions = array('email');  //Optional permissions

$fb = new Facebook(array(
    'app_id' => $appId,
    'app_secret' => $appSecret,
    'default_graph_version' => 'v2.2',
));

// Get redirect login helper
$helper = $fb->getRedirectLoginHelper();
if (isset($_GET['state'])) 
  { $helper->getPersistentDataHandler()->set('state', $_GET['state']); }

try {
    if(isset($_SESSION['facebook_access_token'])){
        $accessToken = $_SESSION['facebook_access_token'];
    }else{
          $accessToken = $helper->getAccessToken();
    }
} catch(FacebookResponseException $e) {
     echo 'Graph returned an error: ' . $e->getMessage();
      exit;
} catch(FacebookSDKException $e) {
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
      exit;
}

?>