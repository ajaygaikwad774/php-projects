<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
       <?php require_once('_header_f/navbar.php'); ?>
        <?php include("function_j/connection.php"); ?>
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Category</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
      
        <!-- Shop Area Start -->
        <div class="shop-area ptb-80">
            <div class="container">
                <div class="row">
                    <div class="order-xl-2 order-lg-2 col-xl-9 col-lg-8">
                        <div class="shop-banner">
                            <img src="assets/img/banner/19.jpg" alt="">
                        </div>
                        <h1 class="page-title"><?php echo "Products"; ?></h1>
                        <div class="ht-product-tab">
                            <div class="nav" role="tablist">
                                <a class="active" href="#grid" data-toggle="tab" role="tab" aria-selected="true" aria-controls="grid"><i class="fa fa-th"></i></a>
                                <a href="#list" data-toggle="tab" role="tab" aria-selected="false" aria-controls="list"><i class="fa fa-th-list" aria-hidden="true"></i></a>
                            </div>
                            <div class="shop-content-wrapper">
                                <div class="shop-results"><span>Sort By</span>
                                    <select name="number" id="sort_d">
                                        <option value="pCode">position</option>
                                        <option value="pName">product name</option>
                                        <option value="pOurPrice">price</option>
                                    </select>
                                </div>
                                <div class="shop-items">
                                    <a href="#"><i class="fa fa-long-arrow-up"></i></a>
                                    <span>Items 1-12 of 14</span>
                                </div>
                            </div>
                        </div>

                        <div class="ht-product-shop tab-content">
                              <div id="filtered_product">
                            <div class="tab-pane active show fade text-center" id="grid" role="tabpanel">
                                <div class="row">
    <?php //if(isset($_GET['cId']) &&  isset($_GET['sId']))
     // { 
      //   $cid = $_GET['cId']; 
    //     // $sid = $_GET['sId'];

 // include("function_j/connection.php");
     require_once('function_j/Product.php');

            $product_details = AllProduct();
    // print_r($product_details);
      if(count($product_details) > 0)
      {
        for($i=0;$i<count($product_details);$i++)
           { 

                $sId = $product_details[$i]['pSubCategoriesId'];
                 $pOurPrice = $product_details[$i]['pOurPrice']; 
                $pName = $product_details[$i]['pName'];
                 $pCode = $product_details[$i]['pCode'];
                 $pPrice = $product_details[$i]['pPrice'];
                 $pImage = $product_details[$i]['pImage'];
                 
     $m_image[] = explode(",",$pImage);
     //print_r($m_image);
              $m_image_1 = $m_image[$i][0];
              $m_image_2 = $m_image[$i][1];
              $m_image_3  = $m_image[$i][2];
?>
                           
            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="product-item">
                                    <div class="product-image-hover">
     <a href="product-details.php?pId=<?php echo $pCode;?>">
    <img class="primary-image" src="<?php echo $m_image_1 ?>" alt="">
    <img class="hover-image" src="<?php echo $m_image_2 ?>" alt="">
                                                </a>
                <div class="product-hover">
            <a data-id="<?php echo $pCode; ?>">  <i class="icon icon-FullShoppingCart"></i></a>
         <a data-id="<?php echo $pCode; ?>" ><i class="icon icon-Heart"></i></a>
            <a href="wishlist.php"><i class="icon icon-Files"></i></a>
                                                </div>
                                            </div>
                                            <div class="product-text">
                                                <div class="product-rating">
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star color"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <h4><a href="product-details.php?pId=<?php echo $pCode;?>"><?php echo $pName; ?></a></h4>
                                                <div class=""> <span style="text-decoration: line-through;font-size:0.7em;"><?php echo $pPrice; ?></span></div>
                                                <div class="product-price"><span><?php echo $pOurPrice; ?></span></div>
                                            </div>
                                        </div>
                                    </div>
                               
                 <?php } 
             }else
             {
                echo "No data Found";
             }?>                   
                                </div>
                            </div>
                        </div>

                            <div class="tab-pane fade" id="list" role="tabpanel">
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/1.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/2.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <a href="wishlist.htnl"><i class="icon icon-FullShoppingCart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Joust Duffle Bag</a></h4>
                                        <div class="product-price"><span>$34.00</span></div>
                                        <p>The sporty Joust Duffle Bag can't be beat - not in the gym, not on the luggage carousel, not anywhere. Big enough to haul a basketball or soccer ball and some sneakers with plenty of room to spare, it's ideal for athletes with places to go.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/3.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/4.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Strive Shoulder Pack</a></h4>
                                        <div class="product-price"><span>$32.00</span></div>
                                        <p>Our top-selling yoga prop, the 4-inch, high-quality Sprite Foam Yoga Brick is popular among yoga novices and studio professionals alike. An essential yoga accessory, the yoga brick is a critical tool for finding balance and alignment in many common yoga poses. Choose from 5 color options.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/5.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/6.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                        </div>
                                        <h4><a href="product-details.html">Crown Summit Backpack</a></h4>
                                        <div class="product-price"><span>$38.00</span></div>
                                        <p>The Go-Get'r Pushup Grips safely provide the extra range of motion you need for a deep-dip routine targeting core, shoulder, chest and arm strength. Do fewer pushups using more energy, getting better results faster than the standard floor-level technique yield.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/7.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/8.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Wayfarer Messenger Bag</a></h4>
                                        <div class="product-price"><span>$40.00</span></div>
                                        <p>One of the world's simplest and most portable exercise devices, a jump rope enables endless variations and fitness output. The Zing Jump Rope goes anywhere and can be used any time. It is adjustable in length and has contoured foam handles for a great grip.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                                <div class="product-item">
                                    <div class="product-image-hover">
                                        <a href="product-details.html">
                                            <img class="primary-image" src="assets/img/product/9.jpg" alt="">
                                            <img class="hover-image" src="assets/img/product/10.jpg" alt="">
                                        </a>
                                        <div class="product-hover">
                                            <button><i class="icon icon-FullShoppingCart"></i></button>
                                            <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                            <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-text">
                                        <div class="product-rating">
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star color"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <h4><a href="product-details.html">Rival Field Messenger</a></h4>
                                        <div class="product-price">
                                            <span>$45.00</span>
                                            <span class="prev-price">$52.00</span>
                                        </div>
                                        <p>Make the most of your limited workout window with our Dual-Handle Cardio Ball. The 15-lb ball maximizes the effort-impact to your abdominal, upper arm and lower-body muscles. It features a handle on each side for a firm, secure grip.</p>
                                        <a href="product-details.html">Learn More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pagination-wrapper">
                            <nav aria-label="navigation">
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-right"></i></a></li>
                                </ul>
                            </nav>
                            <div class="shop-results"><span>Show</span>
                                <select name="number" id="b-number">
                                    <option value="12">12</option>
                                    <option value="13">13</option>
                                    <option value="14">14</option>
                                    <option value="14">15</option>
                                </select>
                                <span>per page</span>
                            </div>
                        </div>
                    </div>
                   	
            </div>
        </div>
    <?php // } ?>
        <!-- Shop Area End -->
	    <!-- Footer Area Start -->
	   <?php require_once('_header_f/footer.php'); ?>
<script type="text/javascript">
    
     $('input[type="checkbox"]').click(function() {
        //Create an Array.
            var selected = new Array();
        $("input[type=checkbox]:checked").each(function () {
                selected.push(this.value);
            });
        if(selected.length == 0)
        {
         $("#filtered_product").load(" #filtered_product");

        }

          
         if (selected.length > 0) {
                // alert("Selected values: " + selected.join(","));


           $.ajax({
                        type: "POST",
                        url: "_code/filter_product.php",
                        data: {selected_id:selected.join(","),sort_data:'pCode'},
                        cache: false,
                        success: function (data) {
                            
         // $( "#filtered_product" ).replaceWith(data);
         $( "#filtered_product" ).html(data);

                          alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });



            }

});
 $("select#sort_d").change(function(){
        var selectedSort = $(this).children("option:selected").val();

         alert(selectedSort);
            var selected = new Array();
        $("input[type=checkbox]:checked").each(function () {
                selected.push(this.value);
            });
        if (selected.length > 0) {
             alert("Selected values: " + selected.join(","));


         $.ajax({
             type: "POST",
             url: "_code/filter_product.php",
            data: {sort_data:selectedSort,selected_id:selected.join(",")},
            cache: false,
            success: function (data) {
                            
         // $( "#filtered_product" ).replaceWith(data);
          $( "#filtered_product" ).html(data);
         

                          alert("sucess");
                        },
                        error: function() {
                            e.preventDefault();
                             alert('Error occurs!');
                         }
                    });
     }
    });


 $(".product-hover a").on('click', function()
      {
    $product_id = $(this).attr("data-id");
    alert($product_id);
     cartadd($product_id);
    }); 
</script>
    </body>
</html>