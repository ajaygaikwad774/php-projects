<?php 
session_start();
 //if(isset($_SESSION["loggedin"]) && !isset($_SESSION["u_id"]) && !isset($_SESSION["username"])){ ?>
<?php require_once('_header_f/header.php'); ?>

 <style>
    


/* Shared */
.loginBtn {
  box-sizing: border-box;
  position: relative;
  /* width: 13em;  - apply for fixed size */
  margin: 0.2em;
  padding: 0 15px 0 46px;
  border: none;
  text-align: left;
  line-height: 34px;
  white-space: nowrap;
  border-radius: 0.2em;
  font-size: 16px;
  color: #FFF;
}
.loginBtn:before {
  content: "";
  box-sizing: border-box;
  position: absolute;
  top: 0;
  left: 0;
  width: 34px;
  height: 100%;
}
.loginBtn:focus {
  outline: none;
}
.loginBtn:active {
  box-shadow: inset 0 0 0 32px rgba(0,0,0,0.1);
}


/* Facebook */
.loginBtn--facebook {
  background-color: #4C69BA;
  background-image: linear-gradient(#4C69BA, #3B55A0);
  /*font-family: "Helvetica neue", Helvetica Neue, Helvetica, Arial, sans-serif;*/
  text-shadow: 0 -1px 0 #354C8C;
}
.loginBtn--facebook:before {
  border-right: #364e92 1px solid;
  background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/14082/icon_facebook.png') 6px 6px no-repeat;
}
.loginBtn--facebook:hover,
.loginBtn--facebook:focus {
  background-color: #5B7BD5;
  background-image: linear-gradient(#5B7BD5, #4864B1);
}


/* Google */
.loginBtn--google {
  /*font-family: "Roboto", Roboto, arial, sans-serif;*/
  background: #DD4B39;
}
.loginBtn--google:before {
  border-right: #BB3F30 1px solid;
  background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/14082/icon_google.png') 6px 6px no-repeat;
}
.loginBtn--google:hover,
.loginBtn--google:focus {
  background: #E74B37;
}
    </style>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
         <?php require_once('_header_f/navbar.php');
              // $output='';
          ?>

        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Account</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Account Area Start -->
        <div class="my-account-area ptb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <form action="_code/Login_code.php" method="POST">
                            <div class="form-fields">
                                <h2>Login</h2>
                                <p>
                                    <label for="login-name" class="important">Email</label>
                                    <input type="email" id="login-name" name="email_name">
                                </p>
                                <p>
                                    <label for="login-pass" class="important"  >Password</label>
                                    <input type="password" id="login-pass" name="u_password">
                                </p>
                                <!-- <p><php echo $output; ?></p> -->
                            </div>
                            <div class="form-action">
                                
                                <button type="submit">Login</button>
                               <!--  <label><input type="checkbox">Remember me</label> -->
                              <p> <a href="facebook_login/index.php"><button type="button" class="loginBtn loginBtn--facebook">Facebook</button></a>
            <a href="google-login/index.php"><button type="button" class="loginBtn loginBtn--google">Google</button></a></p> 
                           <p class="lost_password"><a href="#">Lost your password?</a></p>
                               
                            </div>

                        </form>
                          
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <form action="_code/reg_code.php" method="POST">
                            <div class="form-fields">
                                <h2>Register</h2>
                                <p>
                                    <label for="reg-email" class="important">Email address</label>
                                    <input type="email" id="reg-email" name="email_name">
                                </p>
                                <p>
                                    <label for="reg-pass" class="important">Password</label>
                                    <input type="password" id="reg-pass" name="u_pass_word">
                                </p>
                            </div>
                            <div class="form-action">
 <?php// $password_err ?>
                                <button type="submit">Register</button>
                                <p> <a href="facebook_login/index.php"><button type="button" class="loginBtn loginBtn--facebook">Facebook</button></a>
            <a href="google-login/index.php"><button type="button" class="loginBtn loginBtn--google">Google</button></a></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Account Area End -->
	    <!-- Footer Area Start -->
	      <?php require_once('_header_f/footer.php'); ?>
	    <!-- Footer Area End -->
	    
		<!-- all js here -->
       
    </body>
</html>
<?php //} else 
//{
 // header('Location:index.php');
//} ?>