<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
          <!-- Header Area Start -->
        <?php require_once('_header_f/navbar.php'); ?>
        <!-- Header Area End -->
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">About Us</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- About Skill Area Start -->
        <div class="about-skill-area pt-80 pb-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <h2>ABOUT ARtfurniture</h2>
                        <div class="about-skill-test">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eius mod tempor incididunt ut labore et dolore magna aliqua Ut enim ad mini KJd veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea coz consequat. Duis aute irure dolor in reprehenderit in voluptate velit se ckh dolore eu fugiat nulla pariatur.</p>
                            <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde ipsunms omnis iste natus error sit voluptatem acc there are lots of product in our page. Anyone can find it easily.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <h2>our skill</h2>
                        <div class="skill-bar">
                            <div class="skill-bar-item">
                                <span>investment</span>
                                <div class="progress">
                                    <div class="progress-bar wow fadeInLeft" data-progress="80%" style="width: 80%;" data-wow-duration="1.5s" data-wow-delay="1.2s">
                                        <span class="text-top">80%</span>
                                    </div>
                                </div>
                            </div>
                            <div class="skill-bar-item">
                                <span>consulting</span>
                                <div class="progress">
                                    <div class="progress-bar wow fadeInLeft" data-progress="90%" style="width: 90%;" data-wow-duration="1.5s" data-wow-delay="1.2s">
                                        <span class="text-top">90%</span>
                                    </div>
                                </div>
                            </div>
                            <div class="skill-bar-item">
                                <span>management</span>
                                <div class="progress">
                                    <div class="progress-bar wow fadeInLeft" data-progress="70%" style="width: 70%;" data-wow-duration="1.5s" data-wow-delay="1.2s">
                                        <span class="text-top">70%</span>
                                    </div>
                                </div>
                            </div>
                            <div class="skill-bar-item">
                                <span>planning</span>
                                <div class="progress">
                                    <div class="progress-bar wow fadeInLeft" data-progress="95%" style="width: 95%;" data-wow-duration="1.5s" data-wow-delay="1.2s">
                                        <span class="text-top">95%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Skill Area End -->
        <!-- Team Area Start -->
        <div class="team-area team-area pb-80">
            <div class="container">
	            <div class="section-title text-center title-style-2">
                    <span>Meet Our Team</span>
	                <h2><span>Our Member</span></h2>
	            </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-4">
                        <div class="single-team">
                            <div class="team-image"><img src="assets/img/team/1.png" alt=""></div>
                            <div class="team-hover">
                                <h4>John F. Burden</h4>
                                <span class="block">Executive</span>
                                <div class="team-links">
                                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                                    <a href="https://www.rss.com/"><i class="fa fa-rss"></i></a>
                                    <a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a>
                                    <a href="https://www.pinterest.com/"><i class="fa fa-pinterest"></i></a>
                                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-4">
                        <div class="single-team">
                            <div class="team-image"><img src="assets/img/team/2.png" alt=""></div>
                            <div class="team-hover">
                                <h4>Matteo Orlowski</h4>
                                <span class="block">CEO</span>
                                <div class="team-links">
                                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                                    <a href="https://www.rss.com/"><i class="fa fa-rss"></i></a>
                                    <a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a>
                                    <a href="https://www.pinterest.com/"><i class="fa fa-pinterest"></i></a>
                                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-4">
                        <div class="single-team">
                            <div class="team-image"><img src="assets/img/team/3.png" alt=""></div>
                            <div class="team-hover">
                                <h4>Gary Rankin</h4>
                                <span class="block">Manager</span>
                                <div class="team-links">
                                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                                    <a href="https://www.rss.com/"><i class="fa fa-rss"></i></a>
                                    <a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a>
                                    <a href="https://www.pinterest.com/"><i class="fa fa-pinterest"></i></a>
                                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team Area End -->
	    <!-- Footer Area Start -->
	    <?php require_once('_header_f/footer.php'); ?>
    </body>
</html>