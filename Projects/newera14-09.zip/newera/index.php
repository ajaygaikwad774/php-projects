<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
        <?php require_once('_header_f/navbar.php'); ?>
        <!-- Header Area End -->
	    <!-- Slider Area Start -->
	    <div class="slider-area">
	        <div class="slider-wrapper owl-carousel carousel-style-dot">
                <?php require_once('_code/slider_img.php'); ?>
	           <!--  <div class="single-slide" style="background-image: url('assets/img/slider/1.jpg');">
	                <div class="container">
                        <div class="slider-banner">
                            <h1>Collection</h1>
                            <h2>Lamps light Color</h2>
                            <p>Eikon is made of certified wood and a lampshade that is attached<br>simply with the help of magnets.</p>
                                
                            <a href="shop.php" class="banner-btn">Shop now</a>
                        </div>
	                </div>
	            </div>
	            <div class="single-slide slide-two" style="background-image: url('assets/img/slider/2.jpg');">
	                <div class="container">
                        <div class="slider-banner">
                            <h1>inimalist design</h1>
                            <h2>Lounge Chairs</h2>
                            <p>Doko Demo is a minimalist design created by<br>Copenhagen-based designer CZYK</p>
                            <a href="shop.php" class="banner-btn">Shop now</a>
                        </div>
	                </div>
	            </div> -->
	        </div>
	    </div>
	    <!-- Slider Area End -->
	    <!-- Banner Area Start -->
        <?php 
        $query_01 ="SELECT  `b1`, `b2`, `b3`FROM `fh_homepage` WHERE 1";
         $P_data01 = mysqli_query($conn,$query_01);
          $count_p01 = mysqli_num_rows($P_data01);
          if($count_p01 > 0)
          {
            $SubCategoriesRow01 = mysqli_fetch_array($P_data01);

            $slider11=$SubCategoriesRow01['b1'];
            $slider12=$SubCategoriesRow01['b2'];
            $slider13=$SubCategoriesRow01['b3'];
          }  
        ?>

	    <div class="banner-area pt-90">
	        <div class="container">
	            <div class="row">
	                <div class="col-lg-3 col-md-3">
                        <a class="banner-image" href="shop.php"><img src="<?php echo $home_page.$slider11; ?>" alt=""></a>
	                </div>
	                <div class="col-lg-6 col-md-6">
                        <a class="banner-image" href="shop.php"><img src="<?php echo $home_page.$slider12;?>" alt=""></a>
	                </div>
	                <div class="col-lg-3 col-md-3">
                        <a class="banner-image" href="shop.php"><img src="<?php echo $home_page.$slider13;?>" alt=""></a>
	                </div>
	            </div>
	        </div>
	    </div>
	    <!-- Banner Area End -->
	    <!-- Product Area Start -->
	    <div class="product-area text-center pt-90 pb-85">
	        <div class="container">
	            <div class="section-title">
                    <span>new shop item</span>
	                <h2><span>Nightstands</span></h2>
	            </div>
	        </div>
	        <div class="container">
	            <div class="custom-row">
	                <div class="product-carousel owl-carousel carousel-style-one">
                        <?php require_once('_code/recent_added.php'); ?>
	                    <!-- <div class="custom-col">
	                        <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/1.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/2.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Joust Duffle Bag</a></h4>
                                    <div class="product-price"><span>$34.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/3.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/4.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Strive Shoulder Pack</a></h4>
                                    <div class="product-price"><span>$32.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/5.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/6.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="shop.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price"><span>$38.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/7.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/8.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Wayfarer Messenger Bag</a></h4>
                                    <div class="product-price"><span>$40.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="">New</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/9.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/10.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Rival Field Messenger</a></h4>
                                    <div class="product-price"><span>$45.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/11.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/12.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Joust Duffle Bag</a></h4>
                                    <div class="product-price"><span>$34.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/13.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/14.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Strive Shoulder Pack</a></h4>
                                    <div class="product-price"><span>$32.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/15.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/16.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="shop.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price"><span>$38.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/17.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/18.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Wayfarer Messenger Bag</a></h4>
                                    <div class="product-price"><span>$40.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="">New</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/19.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/20.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Rival Field Messenger</a></h4>
                                    <div class="product-price"><span>$45.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/22.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/21.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="shop.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price"><span>$38.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                    <div class="custom-col">
	                        <div class="product-item">
	                            <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/23.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/17.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Wayfarer Messenger Bag</a></h4>
                                    <div class="product-price"><span>$40.00</span></div>
                                </div>
	                        </div>
	                    </div> -->
	                </div>
	            </div>
	        </div>
	    </div>
	    <!-- Product Area End -->
	    <!-- Banner Area Start -->
	   <!--  <div class="banner-area">
	        <div class="container">
	            <div class="row grid">
	                <div class="col-md-3 grid-item">
                        <a class="banner-image" href="shop.html">
                            <img src="assets/img/banner/4.jpg" alt="">
                            <span class="banner-hover-text">Chair collection</span>
                        </a>
	                </div>
	                <div class="col-md-3 grid-item">
                        <a class="banner-image" href="shop.html">
                            <img src="assets/img/banner/5.jpg" alt="">
                            <span class="banner-hover-text">Lighting collection</span>
                        </a>
	                </div>
	                <div class="col-md-3 grid-item">
                        <a class="banner-image" href="shop.html">
                            <img src="assets/img/banner/6.jpg" alt="">
                            <span class="banner-hover-text">HOME ACCESSORIES</span>
                        </a>
	                </div>
	                <div class="col-md-3 grid-item">
                        <a class="banner-image" href="shop.html">
                            <img src="assets/img/banner/7.jpg" alt="">
                            <span class="banner-hover-text">Black Hanging Chair</span>
                        </a>
	                </div>
	                <div class="col-md-3 grid-item">
                        <a class="banner-image" href="shop.html">
                            <img src="assets/img/banner/9.jpg" alt="">
                            <span class="banner-hover-text">COFFEE &amp; SIDE TABLES</span>
                        </a>
	                </div>
	                <div class="col-md-3 grid-item">
                        <a class="banner-image" href="shop.html">
                            <img src="assets/img/banner/8.jpg" alt="">
                            <span class="banner-hover-text">sofa collection</span>
                        </a>
	                </div>
	            </div>
	        </div>
	    </div> -->
	    <!-- Banner Area End -->
	    <!-- Feature Product Area Start -->

        <?php require_once('_code/featured_product.php'); ?>
	   <!--  <div class="feature-product-area text-center ptb-60">
	        <div class="container">
	            <div class="section-title">
                   
	                <h2><span>featured products</span></h2>
	            </div>
	        </div>
	        <div class="container fix">
	            <div class="custom-row">
                    <div class="feature-product-carousel owl-carousel">
                        <div class="custom-col">
                            <div class="product-item mb-25">
                                <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/13.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/14.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Strive Shoulder Pack</a></h4>
                                    <div class="product-price">
                                        <span>$32.00</span>
                                        <span class="prev-price">$42.00</span>
                                    </div>
                                </div>
                            </div>
                            <div class="product-item mb-25">
                                <span class="">New</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/24.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/25.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Joust Duffle Bag</a></h4>
                                    <div class="product-price"><span>$34.00</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item mb-25">
                                <span class="">New</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/26.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/27.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Strive Shoulder Pack</a></h4>
                                    <div class="product-price"><span>$32.00</span></div>
                                </div>
                            </div>
                            <div class="product-item mb-25">
                                <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/28.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/29.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="shop.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price">
                                        <span>$38.00</span>
                                        <span class="prev-price">$40.00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item mb-25">
                                <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/30.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/31.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Wayfarer Messenger Bag</a></h4>
                                    <div class="product-price">
                                        <span>$40.00</span>
                                        <span class="prev-price">$50.00</span>
                                    </div>
                                </div>
                            </div>
                            <div class="product-item mb-25">
                                <span class="">New</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/23.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/17.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Rival Field Messenger</a></h4>
                                    <div class="product-price"><span>$45.00</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item mb-25">
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/5.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/6.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Joust Duffle Bag</a></h4>
                                    <div class="product-price"><span>$34.00</span></div>
                                </div>
                            </div>
                            <div class="product-item mb-25">
                                <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/15.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/16.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="shop.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price">
                                        <span>$38.00</span>
                                        <span class="prev-price">$45.00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="product-item mb-25">
                                <span class="">New</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/19.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/20.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <h4><a href="shop.html">Rival Field Messenger</a></h4>
                                    <div class="product-price"><span>$45.00</span></div>
                                </div>
                            </div>
                            <div class="product-item mb-25">
                                <span class="hot-sale">sale</span>
                                <div class="product-image-hover">
                                    <a href="shop.html">
                                        <img class="primary-image" src="assets/img/product/32.jpg" alt="">
                                        <img class="hover-image" src="assets/img/product/33.jpg" alt="">
                                    </a>
                                    <div class="product-hover">
                                        <button><i class="icon icon-FullShoppingCart"></i></button>
                                        <a href="wishlist.htnl"><i class="icon icon-Heart"></i></a>
                                        <a href="wishlist.htnl"><i class="icon icon-Files"></i></a>
                                    </div>
                                </div>
                                <div class="product-text">
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                    </div>
                                    <h4><a href="shop.html">Crown Summit Backpack</a></h4>
                                    <div class="product-price"><span>$38.00</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
	            </div>
	        </div>
	    </div> -->
	    <!-- Feature Product Area End -->
	    <!-- Banner Area Start -->
        <?php 
        $query_0 ="SELECT  `hp_1`, `hp_2`, `hp_3`FROM `fh_homepage` WHERE 1";
         $P_data = mysqli_query($conn,$query_0);
          $count_p = mysqli_num_rows($P_data);
          if($count_p > 0)
          {
            $SubCategoriesRow = mysqli_fetch_array($P_data);

            $slider1=$SubCategoriesRow['hp_1'];
            $slider2=$SubCategoriesRow['hp_2'];
            $slider3=$SubCategoriesRow['hp_3'];
          }  
        ?>
	    <div class="banner-area">
	        <div class="container">
	            <div class="row">
	                <div class="col-md-4">
                        <a class="banner-image" href="shop.php"><img src="<?php echo $home_page.$slider1; ?>" alt=""></a>
	                </div>
	                <div class="col-md-4">
                        <a class="banner-image" href="shop.php"><img src="<?php echo $home_page.$slider2; ?>" alt=""></a>
	                </div>
	                <div class="col-md-4">
                        <a class="banner-image" href="shop.php"><img src="<?php echo $home_page.$slider3; ?>" alt=""></a>
	                </div>
	            </div>
	        </div>
	    </div>
	    <!-- Banner Area End -->
	    <!-- Product Widget Area Start -->
	   <!-- <div class="product-widget-area pt-90 pb-70">
	        <div class="container">
	            <div class="row">
	                <div class="col-lg-3 col-md-6">
	                    <div class="single-product-widget">
	                        <div class="product-widget-title">
	                            <span>Radom Furniture</span>
	                            <h4>Random products</h4>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/1.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Push It Messenger Bag</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$50.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/10.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Sprite Foam Yoga Brick</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$5.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/4.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Dual Handle Cardio Ball</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$8.00</span><span class="prev-price">$12.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-lg-3 col-md-6">
	                    <div class="single-product-widget">
	                        <div class="product-widget-title">
	                            <span>New Furniture</span>
	                            <h4>new arrivals products</h4>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/2.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Sprite Foam Yoga Brick</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$5.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/3.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Push It Messenger Bag</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$50.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/5.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Dual Handle Cardio Ball</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$8.00</span><span class="prev-price">$12.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-lg-3 col-md-6">
	                    <div class="single-product-widget">
	                        <div class="product-widget-title">
	                            <span>popular Furniture</span>
	                            <h4>best seller products</h4>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/6.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Push It Messenger Bag</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$50.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/7.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Dual Handle Cardio Ball</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$8.00</span><span class="prev-price">$12.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/8.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Sprite Foam Yoga Brick</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$5.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-lg-3 col-md-6">
	                    <div class="single-product-widget">
	                        <div class="product-widget-title">
	                            <span>Sale Furniture</span>
	                            <h4>On Sale products</h4>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/9.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Sprite Foam Yoga Brick</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$5.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/6.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Dual Handle Cardio Ball</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$8.00</span><span class="prev-price">$12.00</span></div>
                                </div>
	                        </div>
	                        <div class="product-widget-item">
	                            <div class="product-wid-img">
	                                <a href="shop.html"><img src="assets/img/widget/1.jpg" alt=""></a>
	                            </div>
                                <div class="product-text">
                                    <h4><a href="shop.html">Push It Messenger Bag</a></h4>
                                    <div class="product-rating">
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star color"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="product-price"><span>$50.00</span></div>
                                </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>-->
	    <!-- Product Widget Area End -->
	    <!-- Blog Area Start -->
	   <!--  <div class="blog-area pb-85">
	        <div class="container text-center">
	            <div class="section-title">
                    <span>Latest New</span>
	                <h2><span>FROM OUR BLOG</span></h2>
	            </div>
	        </div>
	        <div class="container">
	            <div class="custom-row">
                    <div class="blog-carousel owl-carousel">
                        <div class="custom-col">
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog.html">
                                        <img src="assets/img/blog/1.jpg" alt="">
                                        <span>05 <span>July</span></span>
                                    </a>
                                </div>
                                <div class="blog-text">
                                    <h5><a href="blog.html">Eodem modo typi qui nunc nobis</a></h5>
                                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                                    <a href="blog.html">Read More</a>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog.html">
                                        <img src="assets/img/blog/2.jpg" alt="">
                                        <span>20 <span>June</span></span>
                                    </a>
                                </div>
                                <div class="blog-text">
                                    <h5><a href="blog.html">Typi non habent claritatem insitam</a></h5>
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                    <a href="blog.html">Read More</a>
                                </div>
                            </div>
                        </div>
                        <div class="custom-col">
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog.html">
                                        <img src="assets/img/blog/3.jpg" alt="">
                                        <span>15 <span>May</span></span>
                                    </a>
                                </div>
                                <div class="blog-text">
                                    <h5><a href="blog.html">Claritas est etiam process dyname</a></h5>
                                    <p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum lorem ipsum dolor asmet.</p>
                                    <a href="blog.html">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
	            </div>
	        </div>
	    </div> -->
	    <!-- Blog Area End -->
	    <!-- Information Area Start -->
	    <div class="information-area">
	        <div class="container">
	            <div class="information-wrapper ptb-60">
	                <div class="row">
	                    <div class="col-md-4">
	                        <div class="single-information">
	                            <div class="s-info-img"><img src="assets/img/icon/shipping.png" alt=""></div>
	                            <div class="s-info-text">
	                                <h4>free shipping</h4>
	                                <span>Free shipping on all US order</span>
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-md-4">
	                        <div class="single-information">
	                            <div class="s-info-img"><img src="assets/img/icon/online.png" alt=""></div>
	                            <div class="s-info-text">
	                                <h4>Online Support 24/7</h4>
	                                <span>Support online 24 hours a day</span>
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-md-4">
	                        <div class="single-information">
	                            <div class="s-info-img"><img src="assets/img/icon/money.png" alt=""></div>
	                            <div class="s-info-text">
	                                <h4>Money Return</h4>
	                                <span>Back guarantee under 7 days</span>
	                            </div>
	                        </div>
	                    </div>
	                  <!--  <div class="col-md-3">
	                        <div class="single-information">
	                            <div class="s-info-img"><img src="assets/img/icon/member.png" alt=""></div>
	                            <div class="s-info-text">
	                                <h4>Member Discount</h4>
	                                <span>Onevery order over $120.00</span>
	                            </div>
	                        </div>
	                    </div>-->
	                </div>
	            </div>
	        </div>
	    </div>
	    <!-- Information Area End -->
	    <!-- Footer Area Start -->
	   <?php require_once('_header_f/footer.php'); ?>
	    <!-- Footer Area End -->
        <!--Start of Newsletter Form-->
    <!--    <div class="modal fade" id="newslettermodal" tabindex="-1" role="dialog">
            <div class="modal-dialog text-center" role="document">
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">close</span></button>
                    <div class="newsletter-popup">
                        <form class="newsletter-content" method="post" action="#">
                            <h2>NEWSLETTER</h2>
                            <p>Subscribe to the Artfurniture mailing list to receive updates on new arrivals, special offers and other discount information.</p>
                            <input type="text" placeholder="Enter your email address">
                            <button type="button">subscribe</button>
                            <div class="checkbox_newsletter">
                                <input type="checkbox" id="checkbox">
                                <label for="checkbox"> Don't show this popup again</label>
                            </div>
                        </form>
                    </div>	
                </div>	
            </div>
        </div>-->
        <!--End of Newsletter Form-->
	    
		
    </body>
</html>