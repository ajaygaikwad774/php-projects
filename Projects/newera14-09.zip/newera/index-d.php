<?php require_once('_header_f/header.php'); ?>
    <body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
	    
        <!-- Header Area Start -->
        <?php require_once('_header_f/navbar.php'); ?>
        <!-- Header Area End -->
        <!-- Breadcrumb Area Start -->
        <div class="breadcrumb-area bg-dark">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Account</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Account Area Start -->
        <?php
        $output=" ";
// Include configuration file
require_once 'config.php';

// Include User class
require_once 'User.class.php';

if(isset($accessToken))
{
    if(isset($_SESSION['facebook_access_token'])){
        $fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
    }else{
        // Put short-lived access token in session
        $_SESSION['facebook_access_token'] = (string) $accessToken;
        
          // OAuth 2.0 client handler helps to manage access tokens
        $oAuth2Client = $fb->getOAuth2Client();
        
        // Exchanges a short-lived access token for a long-lived one
        $longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($_SESSION['facebook_access_token']);
        $_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;
        
        // Set default access token to be used in script
        $fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
    }
    
    // Redirect the user back to the same page if url has "code" parameter in query string
    if(isset($_GET['code'])){
        header('Location: ./');
    }
    
    // Getting user's profile info from Facebook
    try {
        $graphResponse = $fb->get('/me?fields=name,first_name,last_name,email,link,gender,picture');
        $fbUser = $graphResponse->getGraphUser();
    } catch(FacebookResponseException $e) {
        echo 'Graph returned an error: ' . $e->getMessage();
        session_destroy();
        // Redirect user back to app login page
        header("Location: ./");
        exit;
    } catch(FacebookSDKException $e) {
        echo 'Facebook SDK returned an error: ' . $e->getMessage();
        exit;
    }
    
    // Initialize User class
    $user = new User();
    
    // Getting user's profile data
    $fbUserData = array();
    $fbUserData['oauth_uid']  = !empty($fbUser['id'])?$fbUser['id']:'';
    $fbUserData['first_name'] = !empty($fbUser['first_name'])?$fbUser['first_name']:'';
    $fbUserData['last_name']  = !empty($fbUser['last_name'])?$fbUser['last_name']:'';
    $fbUserData['email']      = !empty($fbUser['email'])?$fbUser['email']:'';
    $fbUserData['gender']     = !empty($fbUser['gender'])?$fbUser['gender']:'';
    $fbUserData['picture']    = !empty($fbUser['picture']['url'])?$fbUser['picture']['url']:'';
    $fbUserData['link']       = !empty($fbUser['link'])?$fbUser['link']:'';
    
    // Insert or update user data to the database
    $fbUserData['oauth_provider'] = 'facebook';
    $userData = $user->checkUser($fbUserData);
    
    // Storing user data in the session
    $_SESSION['userData'] = $userData;
    
    // Get logout url
    $logoutURL = $helper->getLogoutUrl($accessToken, 'http://localhost/gulam/front/logout.php');
    
    // Render Facebook profile data
    if(!empty($userData)){
        // $output  = '<h2>Facebook Profile Details</h2>';
        // $output .= '<div class="ac-data">';
        // $output .= '<img src="'.$userData['picture'].'"/>';
        // $output .= '<p><b>Facebook ID:</b> '.$userData['oauth_uid'].'</p>';
        // $output .= '<p><b>Name:</b> '.$userData['first_name'].' '.$userData['last_name'].'</p>';
        // $output .= '<p><b>Email:</b> '.$userData['email'].'</p>';
        // $output .= '<p><b>Gender:</b> '.$userData['gender'].'</p>';
        // $output .= '<p><b>Logged in with:</b> Facebook</p>';
        // $output .= '<p><b>Profile Link:</b> <a href="'.$userData['link'].'" target="_blank">Click to visit Facebook page</a></p>';
        // $output .= '<p><b>Logout from <a href="'.$logoutURL.'">Facebook</a></p>';
        // $output .= '</div>';
        header('Location:index.php');
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
    }
}else {

    // Get login url
    $permissions = ['email']; // Optional permissions
    $loginURL = $helper->getLoginUrl(FB_REDIRECT_URL, $permissions);
    $facebook_login = '<a href="'.htmlspecialchars($loginURL).'"><img src="images/fb-login-btn.png"></a>';
}

if(isset($_SESSION['token']) || isset($_GET['code']) )
{

if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var(GOOGLE_REDIRECT_URL, FILTER_SANITIZE_URL));
}

if(isset($_SESSION['token'])){

    $gClient->setAccessToken($_SESSION['token']);
}

if($gClient->getAccessToken()){
    // Get user profile data from google
    $gpUserProfile = $google_oauthV2->userinfo->get();
    
    // Initialize User class
    $user = new User();
    
    // Getting user profile info
    $gpUserData = array();
    $gpUserData['oauth_uid']  = !empty($gpUserProfile['id'])?$gpUserProfile['id']:'';
    $gpUserData['first_name'] = !empty($gpUserProfile['given_name'])?$gpUserProfile['given_name']:'';
    $gpUserData['last_name']  = !empty($gpUserProfile['family_name'])?$gpUserProfile['family_name']:'';
    $gpUserData['email']      = !empty($gpUserProfile['email'])?$gpUserProfile['email']:'';
    $gpUserData['gender']     = !empty($gpUserProfile['gender'])?$gpUserProfile['gender']:'';
    $gpUserData['locale']     = !empty($gpUserProfile['locale'])?$gpUserProfile['locale']:'';
    $gpUserData['picture']    = !empty($gpUserProfile['picture'])?$gpUserProfile['picture']:'';
    $gpUserData['link']       = !empty($gpUserProfile['link'])?$gpUserProfile['link']:'';
    
    // Insert or update user data to the database
    $gpUserData['oauth_provider'] = 'google';
    $userData = $user->checkUser($gpUserData);
    
    // Storing user data in the session
    $_SESSION['userData'] = $userData;
    
    // Render user profile data
    if(!empty($userData)){
        // $output  = '<h2>Google Account Details</h2>';
        // $output .= '<div class="ac-data">';
        // $output .= '<img src="'.$userData['picture'].'">';
        // $output .= '<p><b>Google ID:</b> '.$userData['oauth_uid'].'</p>';
        // $output .= '<p><b>Name:</b> '.$userData['first_name'].' '.$userData['last_name'].'</p>';
        // $output .= '<p><b>Email:</b> '.$userData['email'].'</p>';
        // $output .= '<p><b>Gender:</b> '.$userData['gender'].'</p>';
        // $output .= '<p><b>Locale:</b> '.$userData['locale'].'</p>';
        // $output .= '<p><b>Logged in with:</b> Google</p>';
        // $output .= '<p><a href="'.$userData['link'].'" target="_blank">Click to visit Google+</a></p>';
        // $output .= '<p>Logout from <a href="logout.php">Google</a></p>';
        // $output .= '</div>';
         header('Location:index.php');
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
    }
}
}
else{
 // Get login url
    $authUrl = $gClient->createAuthUrl();
    
    // Render google login button
    $google_login = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/google-sign-in-btn.png" alt="demo"/></a>';

}

?>
        <div class="my-account-area ptb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <form action="#">
                            <div class="form-fields">
                                <?php echo $output; ?>
                                <h2>Login</h2>
                                <p>
                                    <label for="login-name" class="important">Username</label>
                                    <input type="text" id="login-name">
                                </p>
                                <p>
                                    <label for="login-pass" class="important">Password</label>
                                    <input type="password" id="login-pass">
                                </p>
                            </div>
                            <div class="form-action">
                                <p class="lost_password"><a href="#">Lost your password?</a></p>
                                <button type="submit">Login</button>
                                <label><input type="checkbox">Remember me</label>
                                <?php echo $facebook_login; ?>
                                <?php echo $google_login; ?>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <form action="#">
                            <div class="form-fields">
                                <h2>Register</h2>
                                <p>
                                    <label for="reg-email" class="important">Email address</label>
                                    <input type="text" id="reg-email">
                                </p>
                                <p>
                                    <label for="reg-pass" class="important">Password</label>
                                    <input type="password" id="reg-pass">
                                </p>
                            </div>
                            <div class="form-action">
                                <button type="submit">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>       
        <!-- Account Area End -->
	    <!-- Footer Area Start -->
	      <?php require_once('_header_f/footer.php'); ?>
    </body>
</html>