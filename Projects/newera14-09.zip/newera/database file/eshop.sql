-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2019 at 09:05 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `fh_admin`
--

CREATE TABLE `fh_admin` (
  `aId` int(10) NOT NULL,
  `aEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aUsername` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aPassword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aActive` tinyint(1) NOT NULL,
  `aForget` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aContact` varchar(12) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_admin`
--

INSERT INTO `fh_admin` (`aId`, `aEmail`, `aUsername`, `aPassword`, `aActive`, `aForget`, `aContact`) VALUES
(1, 'g@g.com', 'sonu', 'sonu', 1, 'sonu', '8104237493'),
(2, 'rahul.appdid@gmail.com', 'rahul', 'rahul', 1, '1', '9967856357');

-- --------------------------------------------------------

--
-- Table structure for table `fh_banners`
--

CREATE TABLE `fh_banners` (
  `id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `banner_title` varchar(255) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `adding_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_banners`
--

INSERT INTO `fh_banners` (`id`, `category`, `banner_title`, `img_url`, `adding_date`) VALUES
(1, 'Banner Image', 'image1', 'uploads/img_2019_09_11_08_40_42.png', '2019-09-11 08:40:42');

-- --------------------------------------------------------

--
-- Table structure for table `fh_cart`
--

CREATE TABLE `fh_cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `per_unit_price` int(11) NOT NULL,
  `quantity_s` int(11) NOT NULL,
  `color_code` varchar(255) NOT NULL,
  `total_price` int(11) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `isvisiable` int(11) NOT NULL DEFAULT '1',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_cart`
--

INSERT INTO `fh_cart` (`cart_id`, `user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `quantity_s`, `color_code`, `total_price`, `product_image`, `isvisiable`, `added_date`) VALUES
(1, 0, ' ', 1101, 'Grefin mb', 3800, 4, ' ', 15200, ' ', 0, '2019-08-11 14:51:27'),
(2, 0, ' ', 1101, 'Grefin mb', 3800, 1, ' ', 0, ' ', 0, '2019-08-11 16:29:37'),
(3, 0, ' ', 1102, 'Sigma HB', 3500, 1, ' ', 0, ' ', 0, '2019-08-11 16:31:56'),
(4, 0, ' ', 1101, 'Grefin mb', 3800, 1, ' ', 0, ' ', 0, '2019-08-11 16:32:14'),
(5, 0, ' ', 1101, 'Grefin mb', 3800, 3, ' ', 11400, '1101.jpg', 0, '2019-08-11 16:37:09'),
(6, 0, ' ', 1101, 'Grefin mb', 3800, 1, ' ', 3800, '1101.jpg', 0, '2019-08-11 16:55:46'),
(7, 0, ' ', 1101, 'Grefin mb', 3800, 1, ' ', 3800, 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 0, '2019-08-11 17:57:34'),
(8, 0, ' ', 1102, 'Sigma HB', 3500, 2, ' ', 7000, 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 0, '2019-08-11 19:33:30'),
(9, 0, ' ', 1103, 'Sigma MB', 2400, 1, ' ', 2400, 'product_image/1103_1.jpg,product_image/1103_2.jpg,product_image/1103_3.jpg', 0, '2019-08-11 19:42:35'),
(10, 0, ' ', 1102, 'Sigma HB', 3500, 1, ' ', 3500, 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 0, '2019-08-11 20:41:54'),
(11, 0, ' ', 1103, 'Sigma MB', 2400, 1, ' ', 2400, 'product_image/1103_1.jpg,product_image/1103_2.jpg,product_image/1103_3.jpg', 0, '2019-09-07 10:51:44'),
(12, 0, ' ', 1102, 'Sigma HB', 3500, 1, ' ', 3500, 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 0, '2019-09-07 12:51:06'),
(13, 0, ' ', 1103, 'Sigma MB', 2400, 2, ' ', 4800, 'product_image/1103_1.jpg,product_image/1103_2.jpg,product_image/1103_3.jpg', 1, '2019-09-10 10:11:30'),
(14, 0, ' ', 112000, 'Demo', 0, 3, ' ', 0, 'product_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 1, '2019-09-12 17:48:06');

-- --------------------------------------------------------

--
-- Table structure for table `fh_categories`
--

CREATE TABLE `fh_categories` (
  `cId` int(11) NOT NULL,
  `cName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cImage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cPosition` tinyint(2) NOT NULL,
  `cIsVisible` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_categories`
--

INSERT INTO `fh_categories` (`cId`, `cName`, `cImage`, `cPosition`, `cIsVisible`) VALUES
(1, 'Chairs', 'executive.png', 2, 1),
(2, 'sofa', 'trackdidbg.png', 3, 1),
(3, 'table', 'shiv.jpg', 1, 1),
(4, 'table lamp', 'Screenshot (25).png', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fh_homepage`
--

CREATE TABLE `fh_homepage` (
  `id` int(10) NOT NULL,
  `slider1` varchar(100) NOT NULL,
  `slider2` varchar(100) NOT NULL,
  `slider3` varchar(100) NOT NULL,
  `slider4` varchar(100) NOT NULL,
  `slider5` varchar(100) NOT NULL,
  `hp_1` varchar(100) NOT NULL,
  `hp_2` varchar(100) NOT NULL,
  `hp_3` varchar(100) NOT NULL,
  `shop_1` varchar(100) NOT NULL,
  `b1` varchar(100) NOT NULL,
  `b2` varchar(100) NOT NULL,
  `b3` varchar(100) NOT NULL,
  `modified_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_homepage`
--

INSERT INTO `fh_homepage` (`id`, `slider1`, `slider2`, `slider3`, `slider4`, `slider5`, `hp_1`, `hp_2`, `hp_3`, `shop_1`, `b1`, `b2`, `b3`, `modified_date`) VALUES
(1, 'images/hub_page/slider_1.jpg', 'images/hub_page/slider_2.jpg', '-', '-', '-', 'images/hub_page/ads_1.png', 'images/hub_page/ads_2.png', 'images/hub_page/ads_3.png', 'images/hub_page/ads_4.jpg', 'images/hub_page/b_1.jpg', 'images/hub_page/b_2.jpg', 'images/hub_page/b_3.jpg', '2019-09-14');

-- --------------------------------------------------------

--
-- Table structure for table `fh_newsletter`
--

CREATE TABLE `fh_newsletter` (
  `nId` int(11) NOT NULL,
  `nEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nStatus` tinyint(1) NOT NULL,
  `nTime` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_newsletter`
--

INSERT INTO `fh_newsletter` (`nId`, `nEmail`, `nStatus`, `nTime`) VALUES
(1, 'gulamhuseinkhan@gmail.com', 1, '0000-00-00 00:0'),
(2, 'gulamhuseinkhan@gmail.com', 1, '0000-00-00 00:0'),
(3, 'gulamhuseinkhan@gmail.com', 1, '0000-00-00 00:0'),
(4, 'gulamhuseinkhan@gmail.com', 1, '2019-05-26 06-3'),
(5, 'gulamhuseinkhan@gmail.com', 1, '2019-05-26 06-59-59'),
(6, 'jafjasdkf@sdnjaf.ck', 1, '2019-05-27 10-02-00'),
(7, 'jaksfkhja@dskjaf.ds', 1, '2019-05-28 10-00-17'),
(8, 'sandj@jsjns.com', 1, '2019-07-02 09-18-15'),
(9, 'sandj@jsjns.com', 1, '2019-07-04 03-42-24');

-- --------------------------------------------------------

--
-- Table structure for table `fh_orders`
--

CREATE TABLE `fh_orders` (
  `oId` int(11) NOT NULL,
  `oName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oContact` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oPageProduct` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oProductId` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oProductName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oProductQuantity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oProductPrice` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oProductOurPrice` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oRecentProduct` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oDeliveryCost` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oGstRate` int(10) NOT NULL,
  `oWarranty` tinyint(2) NOT NULL,
  `oDeliveryTime` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oColour` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_orders`
--

INSERT INTO `fh_orders` (`oId`, `oName`, `oContact`, `oEmail`, `oPageProduct`, `oProductId`, `oProductName`, `oProductQuantity`, `oProductPrice`, `oProductOurPrice`, `oRecentProduct`, `oDeliveryCost`, `oGstRate`, `oWarranty`, `oDeliveryTime`, `oColour`) VALUES
(1, 'fss', 'sff', 'sdfs@sdfs', '1', '', '', '', '', '', '<br />\r\n<b>Notice</b>:  Undefined index: recentItem in <b>C:xampphtdocs\neweraitem.php</b> on line <b>172</b><br />\r\n', '', 0, 0, '', ''),
(2, 'kjaskdf', 'sdfsdf', 'dsd@kjasjasd', '1', '', '', '', '', '', '', '', 0, 0, '', ''),
(3, 'sdcs', 'sdsd', 'sds@sdsd', '1', '', '', '', '', '', '1,', '', 0, 0, '', ''),
(4, 'kjakja', 'jakjak', 'jakja@kkk', '2', '', '', '', '', '', '1,2,', '', 0, 0, '', ''),
(5, 'Gulam Husein Khan', '8104237493', 'gulamhuseinkhan@outlook.com', '3', '', '', '', '', '', '', '', 0, 0, '', ''),
(6, 'Bshz', '9796797', 'sandj@jsjns.com', '1', '', '', '', '', '', '', '', 0, 0, '', ''),
(7, 'demo', '09', 'kamal@gmail.com', '2', '', '', '', '', '', '', '', 0, 0, '', ''),
(8, 'rahul', '09', 'rahulyadav1598@gmail.com', '2', '', '', '', '', '', '', '', 0, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `fh_products`
--

CREATE TABLE `fh_products` (
  `pId` int(10) NOT NULL,
  `pCategoriesId` int(10) NOT NULL,
  `pSubCategoriesId` int(10) NOT NULL,
  `pCategoriesName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pSubCategoriesName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pPrice` int(10) NOT NULL,
  `pOurPrice` int(10) NOT NULL,
  `pQuantityDiscountPrice` int(10) NOT NULL,
  `pDeliveryCost` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pGstRate` int(10) NOT NULL,
  `pWarranty` tinyint(2) NOT NULL,
  `pDeliveryTime` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pColour` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pSeatMaterial` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pBackMaterial` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pDimension` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pStatus` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pPaymentCode` text COLLATE utf8_unicode_ci NOT NULL,
  `pFeaturesCode` text COLLATE utf8_unicode_ci NOT NULL,
  `pWarrantyCode` text COLLATE utf8_unicode_ci NOT NULL,
  `pDeliveryCode` text COLLATE utf8_unicode_ci NOT NULL,
  `pImage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pPosition` int(10) NOT NULL,
  `pIsVisible` tinyint(1) NOT NULL,
  `pHasFreeDelivery` tinyint(1) NOT NULL,
  `pDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `pKeyword` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_products`
--

INSERT INTO `fh_products` (`pId`, `pCategoriesId`, `pSubCategoriesId`, `pCategoriesName`, `pSubCategoriesName`, `pCode`, `pName`, `pPrice`, `pOurPrice`, `pQuantityDiscountPrice`, `pDeliveryCost`, `pGstRate`, `pWarranty`, `pDeliveryTime`, `pColour`, `pSeatMaterial`, `pBackMaterial`, `pDimension`, `pStatus`, `pPaymentCode`, `pFeaturesCode`, `pWarrantyCode`, `pDeliveryCode`, `pImage`, `pPosition`, `pIsVisible`, `pHasFreeDelivery`, `pDescription`, `pKeyword`) VALUES
(2, 1, 1, 'Chairs', 'Executive Series', '1102', 'Sigma HB', 4000, 3500, 3300, '100', 18, 2, '3 to 5 working days', 'blue @', 'CrapCloth @', 'CrapCloth @', '2ft X 3ft X 4ft', 'fully assembled', '* For Less Than 10 Chair :Cash/ Cheque/ NEFT/ RTGS against Delivery. <br> * For More Than 10 Chair : As Mutually Agreed', '* Nylon Netted Mesh Back Rest. <br> * Seat Made up of Foaming Cushion. <br> * High Quality Fiber Arm Rest. <br> * Ergonomic Back Support <br> * Ideal for Long Hour Sitting. <br> * No Sweating because of Long Sitting. <br> * Push Back Machanism. <br> * Up-Down Height Adjustment. <br> * 90 Degree Tilt Lock. <br> * Colour Option Available. <br> * 360 Degree Revolving ', ' The product comes with a 24 month warranty against any manufacturing defects and any other issues with the materials that have been used. <br> * In case you face any issue with any of our product then simply call on above phone no or email us to register your complain. <br> * We are committed to attend all complaints within two working days. <br> * Except Fabric & Leather each and every spare parts like wheel; base ( stand) ; hydraulic gas lift; arm rest; mechanism; plywood etc are covered under free of cost replacement within guarantee period. <br> * The warranty does not cover damages to fabric & leather beyond its intended use and wear & tear in the natural course of product usage. <br> * We would repair fabric & leather material as well but at an extra cost what may be applicable. ', '* For Mumbai/Thane/New Mumbai: Single/Multiple chair delivery is possible. <br> * For Rest Other Location : Minimum Order of 10 chairs are required. <br> * If the selected product is available then it would be delivered within 3 to 4 working days. <br> * The delivery would be till the door of your suggested address. <br> * No Assembly required - Product is delivered pre-assembled and does not require any assembly at the specified order destination. <br> * All care would be taken of during transportation that the goods do not get damaged. <br> * Product would be delivered by our company is experience logistic and transport team. <br> * Please check the product at the time of delivery. If it is not to your liking or is damaged/defective, you can return it on the spot. <br> * In case you have any questions or need any clarifications do not hesitate to call our Customer Support Team on above phone no. <br> ', 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 2, 1, 1, '<ul>\r\n<li>* For Less Than 10 Chair :Ca<em>sh/ Cheque/ NEFT/ RTGS against Delivery.</em><br /><em><br /> * For More Than 10 Chair : As M</em>utually Agreed</li>\r\n</ul>\r\n<p>* For Less Than 10 Chair :Cash/ Cheque/ N<strong>EFT/ RTGS against Delivery.</strong><br /><strong><br /> * For More Than 10 Chair : As Mutually Agreed</strong></p>\r\n<p><strong>* For Less Than 10 Chair :Cash/ Cheque/ NEFT/ RTGS against Delivery.</strong><br /><strong><br /> * For More Than 10 Chair : As Mutually Agreed</strong></p>\r\n<p><strong>* For Less Than 10 Chair :Cash/ Cheque/ NEFT/</strong> RTGS against Delivery.<br /><br /> * For More Than 10 Chair : As Mutually Agreed</p>', '* For Less Than 10 Chair :Cash/ Cheque/ NEFT/ RTGS against Delivery. <br> * For More Than 10 Chair : As Mutually Agreed'),
(3, 1, 1, 'Chairs', 'Executive Series', '1103', 'Sigma MB', 2500, 2400, 2200, '100', 18, 2, 'sdjakfskdl sdkjaf', 'bluqe @', 'rexi @', 'sdfsfds', 'sdfsdfsdf', 'sdfsdfsdf', 'sdfsdfsd', 'fsdfsf', 'sdfsdf', 'sdfsdf', 'product_image/1103_1.jpg,product_image/1103_2.jpg,product_image/1103_3.jpg', 3, 1, 1, '<p>erewruqewuqr</p>', 'jajaja'),
(4, 2, 2, 'sofa', 'Visitor Series', '112000', 'Demo', 0, 0, 0, 'Demo', 0, 0, 'Demo', 'DeomDe', 'DeomDe', 'DeomDe', 'DeomDe', 'DeomDe', 'DeomDe', 'DeomDe', 'DeomDe', 'DeomDe', 'product_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 0, 1, 1, '', 'DeomDe'),
(5, 1, 2, 'Chairs', 'Work Station Series', 'm m ', 'm m ', 0, 0, 0, 'm m', 0, 0, ' m m', ' m', ' m', ' m ', 'm', ' m', ' m', ' m', ' ', ' m', 'product_image/demo_1jpg,product_image/demo_2jpg,product_image/demo_3jpproduct_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 0, 1, 1, '', 'm m m '),
(6, 1, 1, 'Chairs', 'Executive Series', 'demo', 'demo', 0, 0, 0, 'demo', 0, 0, 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'product_image/demo_1jpg,product_image/demo_2jpg,product_image/demo_3jpg', 0, 1, 1, '', 'demo'),
(7, 1, 2, 'Chairs', 'Work Station Series', 'demo', 'demo', 0, 0, 0, 'demo', 0, 0, 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'product_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 0, 1, 1, '', 'demo'),
(8, 1, 4, 'Chairs', 'Visitor Series', 'ccc', 'ccc', 0, 0, 0, 'ccc', 0, 0, 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'product_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 0, 1, 1, '', 'ccc'),
(9, 1, 4, 'Chairs', 'Visitor Series', 'ccc1', 'ccc', 0, 0, 0, 'ccc', 0, 0, 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'product_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 0, 1, 1, '', 'ccc'),
(10, 1, 4, 'Chairs', 'Visitor Series', 'ccc2', 'ccc', 0, 0, 0, 'ccc', 0, 0, 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'product_image/ccc_1jpg,product_image/ccc_2jpg,product_image/ccc_3jpg', 0, 1, 1, '', 'ccc'),
(11, 1, 4, 'Chairs', 'Visitor Series', 'ccc3', 'ccc', 0, 0, 0, 'ccc', 0, 0, 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'product_image/ccc_1jpg,product_image/ccc_2jpg,product_image/ccc_3jpg', 0, 1, 1, '', 'ccc'),
(12, 1, 4, 'Chairs', 'Visitor Series', 'ccc4', 'ccc', 0, 0, 0, 'ccc', 0, 0, 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc', 'ccc.jpg', 0, 1, 1, '', 'ccc');

-- --------------------------------------------------------

--
-- Table structure for table `fh_subcategories`
--

CREATE TABLE `fh_subcategories` (
  `sId` int(11) NOT NULL,
  `scId` int(11) NOT NULL,
  `sParentCategories` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sImage` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sPosition` tinyint(2) NOT NULL,
  `sIsVisible` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_subcategories`
--

INSERT INTO `fh_subcategories` (`sId`, `scId`, `sParentCategories`, `sName`, `sImage`, `sPosition`, `sIsVisible`) VALUES
(1, 1, 'Chairs', 'Executive Series', 'executive.png', 1, 1),
(2, 1, 'Chairs', 'Work Station Series', 'work station.png', 2, 1),
(3, 1, 'Chairs', 'Mesh Back Series', 'mess back.png', 3, 1),
(4, 1, 'Chairs', 'Visitor Series', 'visitor.png', 4, 1),
(5, 1, 'Chairs', 'Cafeteria Series', 'cafe.png', 5, 1),
(6, 1, 'Chairs', 'Educational Series', 'educational.png', 6, 1),
(7, 1, 'Chairs', 'High Counter Series', 'counter .png', 7, 1),
(8, 2, 'sofa', 'sofaset', 'trackdidbg.png', 22, 1),
(9, 3, 'table', 'study table', 'Screenshot (27).png', 1, 1),
(10, 4, 'table lamp', 'lamp', 'Screenshot (36).png', 1, 1),
(11, 5, 'table1', 'qw', 'Screenshot (36).png', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fh_users`
--

CREATE TABLE `fh_users` (
  `user_id` int(11) NOT NULL,
  `oauth_provider` enum('','facebook','google') COLLATE utf8_unicode_ci NOT NULL,
  `oauth_uid` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fh_users`
--

INSERT INTO `fh_users` (`user_id`, `oauth_provider`, `oauth_uid`, `first_name`, `last_name`, `email`, `password`, `gender`, `locale`, `picture`, `link`, `created`, `modified`, `added_date`) VALUES
(1, 'google', '104331584792118829517', 'Rohan', 'Naik', 'rohannaik57@gmail.com', '', '', 'en-GB', 'https://lh5.googleusercontent.com/-cKN50N1bsAc/AAAAAAAAAAI/AAAAAAAASYI/YukXD6HxMuw/photo.jpg', '', '2019-08-10 23:00:59', '2019-08-10 23:00:59', '2019-08-10 21:00:59'),
(2, '', '', '', '', 'demo@gmail.com', '$2y$10$YeFroDlQUzhYlRDPoNV9UutBc0SpFzMGNh1RvO3LFNa.H7VdbRaCu', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-08-11 01:56:04'),
(3, '', '', '', '', 'bharshal@gmail.com', '$2y$10$QyagZ/f3mBYRghy2eUyiUOTKom1dV0pWOZHHwn3lPP5SL5ZibpuIS', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-09-07 10:16:54');

-- --------------------------------------------------------

--
-- Table structure for table `fh_wishlist`
--

CREATE TABLE `fh_wishlist` (
  `w_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `per_unit_price` int(11) NOT NULL,
  `quantity_s` int(11) NOT NULL,
  `color_code` varchar(255) NOT NULL,
  `total_price` int(11) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `isvisiable` int(11) NOT NULL DEFAULT '1',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fh_wishlist`
--

INSERT INTO `fh_wishlist` (`w_id`, `user_id`, `user_name`, `product_id`, `product_name`, `per_unit_price`, `quantity_s`, `color_code`, `total_price`, `product_image`, `isvisiable`, `added_date`) VALUES
(1, 0, ' ', 1102, 'Sigma HB', 3500, 0, ' ', 3500, 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 0, '2019-09-07 11:44:59'),
(2, 0, ' ', 0, 'ccc', 0, 0, ' ', 0, 'product_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 0, '2019-09-10 09:59:36'),
(3, 0, ' ', 1103, 'Sigma MB', 2400, 0, ' ', 2400, 'product_image/1103_1.jpg,product_image/1103_2.jpg,product_image/1103_3.jpg', 0, '2019-09-10 10:10:38'),
(4, 0, ' ', 1102, 'Sigma HB', 3500, 0, ' ', 3500, 'product_image/1102_1.jpg,product_image/1102_2.jpg,product_image/1102_3.jpg', 1, '2019-09-10 12:24:53'),
(5, 0, ' ', 0, 'm m ', 0, 0, ' ', 0, 'product_image/demo_1jpg,product_image/demo_2jpg,product_image/demo_3jpproduct_image/demo_1.jpg,product_image/demo_2.jpg,product_image/demo_3.jpg', 1, '2019-09-12 17:52:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fh_admin`
--
ALTER TABLE `fh_admin`
  ADD PRIMARY KEY (`aId`);

--
-- Indexes for table `fh_banners`
--
ALTER TABLE `fh_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fh_cart`
--
ALTER TABLE `fh_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `fh_categories`
--
ALTER TABLE `fh_categories`
  ADD PRIMARY KEY (`cId`);

--
-- Indexes for table `fh_homepage`
--
ALTER TABLE `fh_homepage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fh_newsletter`
--
ALTER TABLE `fh_newsletter`
  ADD PRIMARY KEY (`nId`);

--
-- Indexes for table `fh_orders`
--
ALTER TABLE `fh_orders`
  ADD PRIMARY KEY (`oId`);

--
-- Indexes for table `fh_products`
--
ALTER TABLE `fh_products`
  ADD PRIMARY KEY (`pId`);

--
-- Indexes for table `fh_subcategories`
--
ALTER TABLE `fh_subcategories`
  ADD PRIMARY KEY (`sId`);

--
-- Indexes for table `fh_users`
--
ALTER TABLE `fh_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `fh_wishlist`
--
ALTER TABLE `fh_wishlist`
  ADD PRIMARY KEY (`w_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fh_admin`
--
ALTER TABLE `fh_admin`
  MODIFY `aId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `fh_banners`
--
ALTER TABLE `fh_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `fh_cart`
--
ALTER TABLE `fh_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `fh_categories`
--
ALTER TABLE `fh_categories`
  MODIFY `cId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `fh_homepage`
--
ALTER TABLE `fh_homepage`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `fh_newsletter`
--
ALTER TABLE `fh_newsletter`
  MODIFY `nId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `fh_orders`
--
ALTER TABLE `fh_orders`
  MODIFY `oId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `fh_products`
--
ALTER TABLE `fh_products`
  MODIFY `pId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `fh_subcategories`
--
ALTER TABLE `fh_subcategories`
  MODIFY `sId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `fh_users`
--
ALTER TABLE `fh_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `fh_wishlist`
--
ALTER TABLE `fh_wishlist`
  MODIFY `w_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
