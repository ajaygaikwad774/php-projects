<?php
	if(isset($_GET['product']) && is_numeric($_GET['product'])){
		include '../components/cartlib.php';
		addToCart($_GET['product'], 1);
		header("Location: ../product-detail?product=".$_GET['product']."&msg=Product added to the cart successfully");
	}
?>