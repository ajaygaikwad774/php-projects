<?php
	if(isset($_GET['json'])){
		$cart = array();
		$cart=json_decode($_GET['json'], true);
		setcookie("product_cart", json_encode($cart), time()+3600, "/");				
	}
	header("Location: ../checkout");
?>