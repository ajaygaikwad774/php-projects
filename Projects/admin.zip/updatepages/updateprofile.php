<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="user"){
		header("Location: ../login?msg=Please Log In First");
	}
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$name=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['name'])));
   		$email=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email'])));
   		$contact=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['contact'])));
   		$dob=trim(str_replace("/", "-", htmlspecialchars(mysqli_real_escape_string($conn, $_POST['dob']))));
   		$gender=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['gender'])));

   		$pincode=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['pincode'])));
   		$streetaddress1=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['streetaddress1'])));
   		$streetaddress2=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['streetaddress2'])));
   		$landmark=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['landmark'])));
   		$city=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['city'])));
   		$state=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['state'])));
   		$addresstype=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['addresstype'])));

   		$password=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['password'])));
		$isError=false;
		$errMsg="";


		if($name=="" || $email=="" || $contact=="" || $dob=="" || $gender=="" || $pincode=="" || $streetaddress1=="" || $streetaddress2=="" || $landmark=="" || $city=="" || $state=="" || $addresstype=="" || $password==""){
			$isError=true;
			$errMsg="All fields are compulsory"; 
		}

		//email validation
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) { 
		} 
		else { 
			$isError=true;
			$errMsg="Please enter a valid email address"; 
		} 
		//contact validation
		if(!is_numeric($contact) || strlen($contact)!=10){
			$isError=true;
			$errMsg="Contact number must be a 10 digit number"; 			
		}

		//birth date validation
		$splitdate=explode("-", $dob);
		$day=$splitdate[0];
		$month=$splitdate[1];
		$year=$splitdate[2];
	
		if(!checkdate($month, $day, $year)){
			$isError=true;
			$errMsg="Invalid birth date"; 			
		}
		elseif(strtotime($year."-".$month."-".$day) > time()){
			$isError=true;
			$errMsg="Invalid birth date"; 			
		}

		//pincode validation

		if(!is_numeric($pincode) || strlen($pincode)!=6){
			$isError=true;
			$errMsg="Invalid Pin Code"; 			
		}


		//password validation
		if(strlen($password)<6){
			$isError=true;
			$errMsg="Please select a password of at least 6 characters length"; 			
		}

		if(!$isError){
			//if account with provided email already exists
			$q="select *from user where EMAIL='$email' and not ID=".$_COOKIE['user'];
			$rs=mysqli_query($conn, $q);
			if(mysqli_num_rows($rs)!=0){
				$isError=true;
				$errMsg="An another account with same email address already exists"; 			
			} 
		}

		if(!$isError){
			//update user
			$query="update user set EMAIL='$email', CONTACT='$contact', NAME='$name', PASSWORD='$password', DOB='$dob', GENDER='$gender', PINCODE='$pincode', STREETADDR1='$streetaddress1', STREETADDR2='$streetaddress2', LANDMARK='$landmark', CITY='$city', STATE='$state', ADDRESSTYPE='$addresstype' where ID=".$_COOKIE['user'];
			mysqli_query($conn, $query);

			//updating profile pic
			$salt=date('dmYHis');

	         if(!empty($_FILES['image']) && $_FILES['image']['error']!=UPLOAD_ERR_NO_FILE){
	            $target_dir="../admin/uploads/users/";
	            $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
	            $uploadok=1;
	            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	            $check = getimagesize($_FILES["image"]["tmp_name"]);
	            if($check!==false){
	               if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
	                  $query="update user set PIC='admin/uploads/users/".$salt.basename($_FILES['image']['name'])."' where ID=".$_COOKIE['user'];
	                  $res=mysqli_query($conn, $query);
	               }
	            }
	         }

			header("Location: ../update-profile?msg=Your account has been updated successfully."); 
		}else{
			header("Location: ../update-profile?msg=$errMsg. Profile not updated.");
		} 
   }
 ?>