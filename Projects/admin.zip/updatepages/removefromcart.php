<?php
	if(isset($_GET['product']) && is_numeric($_GET['product'])){
		include '../components/cartlib.php';
		removeItemFromCart($_GET['product']);
		header("Location: ../checkout");
	}
?>