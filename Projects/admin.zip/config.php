<?php
$keyId = 'rzp_live_11c9xV51n4M0kQ';
$keySecret = 'uJXCac8IbAcVPLGnJVvVzGxf';


/*$keyId = 'rzp_test_IlpK27y7EVU448';
$keySecret = 'YsJMYpjwEHcujrKnsJVLhog0';
*/
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
?>