<?php
	session_start();
	if(!isset($_SESSION['reset_request_email'])){
		header("Location: login");
	}
	if(isset($_COOKIE['usertype'])){
		if($_COOKIE['usertype']=="admin"){
			header("Location: admin/dashboard");
		}elseif($_COOKIE['usertype']=="user"){
			header("Location: update-profile");
		}
	}
	include 'components/header.php';		
?>
<main>
	<div class="container-fluid" style="padding-top: 50px; padding-bottom: 50px;">
		<div class="account-form col-sm-5">
			<center><h2><strong>Verify OTP</strong></h2></center>
			<center>
				<?php
					if(isset($_GET['msg'])){
						echo "<div class='errormsg'>";
						echo $_GET['msg'];
						echo "</div>";
					}
				?>
			</center>
			<br>
			<form method="post" action="postpages/verifyotp.php">
			  <div class="form-group">
			    <label for="otp"><span class="glyphicon glyphicon-lock"></span> Enter OTP:</label>
			    <input type="password" placeholder="Enter OTP" required class="form-control" id="otp" name="otp">
			  </div>
			  <button type="submit" class="btn btn-default">Verify OTP</button>
			  <br><br>
			  <a href="login">Back to Log In Page</a>
			</form>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>