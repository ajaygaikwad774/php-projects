<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
	require 'components/connection.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Add New Product</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
			<button class="btn btn-default" onclick="location.assign('manage-products')">Product List</button>
		</center>
		<hr> 
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
		<form method="post" action="postpages/addproduct.php" enctype="multipart/form-data">
			<div class="form-group">
			 	<label for="title">
			 		Product Title:
			 	</label>
			    <input type="text" placeholder="Enter Product Title" class="form-control" id="title" required name="title">			
			</div>
			<div class="form-group">
				<label for="image">Add Product Image:</label>
				<input type="file" name="image" required id="image">
			</div>
			<div class="form-group">
			 	<label for="description">
			 		Product Description:
			 	</label>
			    <textarea id="description" placeholder="Enter Product Description" rows="8" name="description" required class="form-control"></textarea>		
			</div>
			<div class="form-group">
				<label for="price">Set Product Price:</label>
				<input type="number" name="price" id="price" required class="form-control" style="width:100px;" placeholder="Price">
			</div>
			<div class="form-group">
				<label for="dprice">Set Discounted Price:</label>
				<input type="number" name="dprice" id="dprice" class="form-control" style="width:100px;" placeholder="Price">
			</div>
			<div class="form-group">
				<label for="pweight">Set Product Weight (in KG):</label>
				<input type="number" name="pweight" step="0.01" id="pweight" required class="form-control" placeholder="Product Weight (in KG)">
			</div>
			<div class="form-group">
				<label for="sweight">Set Shipping Weight (in KG):</label>
				<input type="number" name="sweight" step="0.01" id="sweight" class="form-control" placeholder="Shipping Weight (in KG)">
			</div>
			<div class="form-group">
				<label for="category">Select Product Category:</label>
				<select class="form-control" name="category">
					<?php
						$q="select *from product_category";
						$rs=mysqli_query($conn, $q);
						while ($rw=mysqli_fetch_array($rs)) {
							echo "<option value='".$rw['ID']."'>".$rw['TITLE']."</option>";
						}
					?>
				</select>
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%;">Create Product</button>
			</center>
		</form>
	</div>
</main>
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>
<?php
	include 'components/footer.php'
?>