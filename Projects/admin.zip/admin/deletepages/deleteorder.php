<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}

   require("../components/connection.php");
   if(isset($_GET['order']) && is_numeric($_GET['order'])){
  		$query="update orders set ISENABLED='false' where ID=".$_GET['order'];
   		mysqli_query($conn, $query);
   		header("Location:../manage-orders?msg=Entry Removed Successfully");
   }
?>