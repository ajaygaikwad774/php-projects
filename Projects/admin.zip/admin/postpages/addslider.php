 <?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$content=mysqli_real_escape_string($conn, $_POST['description']);
   		$alignment=mysqli_real_escape_string($conn, $_POST['alignment']);
         $salt=date('dmYHis');
         $target_dir="../uploads/sliders/";
         $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
         $uploadok=1;
         $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
         $check = getimagesize($_FILES["image"]["tmp_name"]);
         if($check!==false){
            if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
               $query="insert into frontpageslider(IMAGE, CONTENT, CONTENTALIGNMENT) values('admin/uploads/sliders/".$salt.basename($_FILES['image']['name'])."', '$content', '$alignment')";
               $res=mysqli_query($conn, $query);
            }
         }
  		header("Location:../slider?msg=Slide Added Successfully");
   }
?>