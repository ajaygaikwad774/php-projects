<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="admin"){
      header("Location: ../../login?msg=Please Log In First");
   }
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$title=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['title']));
   		$description=mysqli_real_escape_string($conn, $_POST['description']);
         $category=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['category']));
         $salt=date('dmYHis');
         $target_dir="../uploads/posts/";
         $target_file=$target_dir.$salt.basename($_FILES['image']['name']);
         $uploadok=1;
         $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
         $check = getimagesize($_FILES["image"]["tmp_name"]);
         if($check!==false){
            if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
               $query="insert into article(TITLE, PHOTO, CONTENT, CATEGORY, CREATE_DATE) values('$title', 'admin/uploads/posts/".$salt.basename($_FILES['image']['name'])."', '$description', $category, '".date('d-m-Y')."')";
               $res=mysqli_query($conn, $query);
            }
         }
  		header("Location:../add-post?msg=Post Added Successfully");
   }
?>