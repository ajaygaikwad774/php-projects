<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	require 'components/connection.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Users</strong></h1>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Pic</th>
						<th>Name</th>
						<th>Email</th>
						<th>Contact</th>
						<th>Date of Birth</th>
						<th>Gender</th>
						<th>Pin Code</th>
						<th>Street Address 1</th>
						<th>Street Address 2</th>
						<th>Landmark</th>
						<th>City</th>
						<th>State</th>
						<th>Address Type</th>
						<th>Registered On</th>
						<th>View Profile</th>
						<th>Delete/Block</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$query="select *from user where TYPE='user' order by ID DESC limit 20 offset ".(($pg-1)*20);
						$res=mysqli_query($conn, $query);
						$counter=(($pg-1)*20);
						while($row=mysqli_fetch_array($res)){
							$counter++;
					?>
					<tr <?php if($row['ISENABLED']=="false"){ ?> style="background-color: #dd0000; color: #fff;" <?php } ?>>
						<td><?=$counter; ?></td>
						<td>
							<img src="<?=$siteurl.$row['PIC']; ?>" style="width: 50px;">
						</td>
						<td><?=$row['NAME']; ?></td>
						<td><?=$row['EMAIL']; ?></td>
						<td><?=$row['CONTACT']; ?></td>
						<td><?=$row['DOB']; ?></td>
						<td><?=$row['GENDER']; ?></td>
						<td><?=$row['PINCODE']; ?></td>
						<td><?=$row['STREETADDR1']; ?></td>
						<td><?=$row['STREETADDR2']; ?></td>
						<td><?=$row['LANDMARK']; ?></td>
						<td><?=$row['CITY']; ?></td>
						<td><?=$row['STATE']; ?></td>
						<td><?=$row['ADDRESSTYPE']; ?></td>
						<td>
							<?=$row['CREATE_DATE']; ?>
						</td>
						<td>
							<a href="userprofile?user=<?php echo $row['ID']; ?>"
							<?php 
								if($row['ISENABLED']=="false"){
							?>
 							style="color: #fff;"
 							<?php							
								}									
							?>
							>View</a>
						</td>
						<td>
							<?php 
								if($row['ISENABLED']=="false"){
							?>
							<a href="updatepages/unblockuser.php?id=<?php echo $row['ID']; ?>" style="color: #fff;">
								Unblock this user
							</a>
							<?php							
								}else{									
							?>
							<a href="updatepages/blockuser.php?id=<?php echo $row['ID']; ?>">
								Delete/Block
							</a>
							<?php
								}
							?>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
	<center>
		<div class="clearfix"></div>
		<br><br>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from user where TYPE='user'";
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="users?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>

	</div>
</main>
<?php
	include 'components/footer.php'
?>