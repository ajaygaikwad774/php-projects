<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	include 'components/connection.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Front Page Slider</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
		</center>
		<hr>

		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<div class="col-sm-5">
			<h3><strong>Add New Slide</strong></h3><br>
			<form method="post" action="postpages/addslider.php" enctype="multipart/form-data">
				<div class="form-group">
					<label for="image"><span class="glyphicon glyphicon-picture"></span> Add Background Image:</label>
					<input type="file" name="image" required id="image">
				</div>				
				<div class="form-group">
				 	<label for="description">
				 		<span class="glyphicon glyphicon-pencil"></span>
				 		Add Slide Content:
				 	</label>
				    <textarea id="description" placeholder="Enter Slide Description" rows="5" name="description" required class="form-control"></textarea>		
				</div>
				<div class="form-group">
					<label for="alignment"><span class="glyphicon glyphicon-align-center"></span> Select Alignment:</label>
					<select class="form-control" name="alignment">
						<option>Left</option>
						<option>Right</option>
						<option>Center</option>
					</select>
				</div>
				<center>
					<button class="btn btn-default" style="width: 100%;">Create Slide</button>
				</center>
			</form>
		</div>
		<div class="col-sm-1">
			&nbsp;
		</div>
		<div class="col-sm-6">
			<h3><strong>Manage Slides</strong></h3><br>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Sr. No.</th>
							<th>Slider</th>
							<th>Edit</th>
							<th>Delete</th>
						</tr>
					</thead>
					<tbody>
						<?php
				            $query="select *from frontpageslider";
					   		$res=mysqli_query($conn, $query);
					   		$counter=0;
							while ($row=mysqli_fetch_array($res)) {
								$counter++;
						?>
						<tr>
							<td><?=$counter; ?></td>
							<td><?php echo "Slider-".$counter; ?></td>
							<td>
								<a href="editslide?id=<?php echo $row['ID']; ?>">Edit</a>
							</td>
							<td>
								<a href="deletepages/deleteslide.php?id=<?php echo $row['ID']; ?>">Delete</a>
							</td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>			
		</div>
	</div>
</main> 
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>
<?php
	include 'components/footer.php';
?>