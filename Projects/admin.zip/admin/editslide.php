<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
		header("Location: slider");
	}

	include 'components/header.php';
	include 'components/connection.php';

	$query="select *from frontpageslider where ID=".$_GET['id'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res);
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Update Slide</strong></h1><br>
			<a href="slider">Back to Slider Page</a><br><br>
		</center>
		<hr>
		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<div class="col-sm-5" style="float: none; margin: auto;">
			<h3><strong>Add New Slide</strong></h3><br>
			<form method="post" action="updatepages/updateslider.php?id=<?php echo $_GET['id']; ?>" enctype="multipart/form-data">
				<div class="form-group">
					<label for="image"><span class="glyphicon glyphicon-picture"></span> Update Background Image:</label>
					<img src="<?php echo $siteurl.$row['IMAGE']; ?>" class="img-responsive"><br>
					<input type="file" name="image" id="image">
				</div>				
				<div class="form-group">
				 	<label for="description">
				 		<span class="glyphicon glyphicon-pencil"></span>
				 		Update Slide Content:
				 	</label>
				    <textarea id="description" placeholder="Enter Slide Description" rows="5" name="description" required class="form-control"><?php echo $row['CONTENT']; ?></textarea>		
				</div>
				<div class="form-group">
					<label for="alignment"><span class="glyphicon glyphicon-align-center"></span> Alignment:</label>
					<select class="form-control" name="alignment">
						<option <?php if($row['CONTENTALIGNMENT']=="Left"){ echo "selected"; } ?>>Left</option>
						<option <?php if($row['CONTENTALIGNMENT']=="Right"){ echo "selected"; } ?>>Right</option>
						<option <?php if($row['CONTENTALIGNMENT']=="Center"){ echo "selected"; } ?>>Center</option>
					</select>
				</div>
				<center>
					<button class="btn btn-default" style="width: 100%;">Update Slide</button>
				</center>
			</form>
		</div>
	</div>
</main> 
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>
<?php
	include 'components/footer.php';
?>