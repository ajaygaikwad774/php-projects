<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
    require("components/connection.php");	
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage YouTube Videos</strong></h1>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr> 
		<br>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<form class="col-sm-5" method="post" action="postpages/addvideo.php">
			<div class="form-group"> 
			 	<label for="title">
			 		Video Title:
			 	</label>
			    <input type="text" placeholder="Enter Video Title" class="form-control" id="title" required name="title">			
			</div>
			<div class="form-group">
			 	<label for="link">
			 		Video Link:
			 	</label>
			    <input type="text" placeholder="Enter Video Link" class="form-control" id="link" required name="link">			
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%;">Add Video</button>
			</center>
		</form>
		<div class="col-sm-1">&nbsp;</div>
		<div class="col-sm-6" style="padding: 20px;">
			<center><h3>Uploaded Videos</h3></center><br>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>
								Sr. No.
							</th>
							<th>
								Title
							</th>
							<th>
								Edit
							</th>
							<th>
								Delete
							</th>
						</tr>
					</thead>
					<tbody>
					<?php
			            $query="select *from videos limit 20 offset ".(($pg-1)*20);
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							$counter++;
					?>
						<tr>
							<td><?=$counter+(($pg-1)*20); ?></td>
							<td><?=$row['TITLE'] ?></td>
							<td><a href="editvideos?id=<?php echo $row['ID']; ?>">Edit</a></td>
							<td><a href="deletepages/deletevideos.php?id=<?php echo $row['ID']; ?>">Delete</a></td>
						</tr>
					<?php
						}
					?>
					</tbody>
				</table>
			</div>
		<div class="clearfix"></div>
		<br><br>
		<center>
			<ul class="pagination pagination-sm">
			<?php
				$totalrowsQuery="select *from videos";
				$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
				$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
				for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
			?>
				  <li><a href="videos?pg=<?php echo $i; ?>" 
				  	<?php 
				  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
				  			{
				  	?> style="background-color: #a5ce3a; color: #000;" 
				  	<?php 
				  			} 
				  	?>><?php echo $i; ?></a></li>
			<?php
				}
			?>
			</ul>

		</center>


		</div>
	</div>
</main>
<?php
	include 'components/footer.php'
?>