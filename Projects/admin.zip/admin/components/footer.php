<div class="clearfix"></div>
<footer>
	<div class="container-fluid">
		<center>&copy; Copyright <?php echo date('Y'); ?>. All rights reserved by Ecomytra.</center>
	</div>

<script type="text/javascript">
	$("#openDrawer").click(function(){
		$("#drawer").animate({
			'padding-left': '10px',
			'width': '220px'
		}, 200);
	});

	$(".closeDrawer").click(function(){
		$("#drawer").animate(
			{
				'padding-left': '0px',
				'width': '0px'
			}, 200
		);
	});
</script>

</footer>
</div>
</body>
</html>
