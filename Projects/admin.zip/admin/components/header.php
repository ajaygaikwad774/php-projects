<!DOCTYPE html>
<html>
<head>
	<title>Ecomytra - Admin Panel</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">	
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">	
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
	<link rel="icon" href="images/ecomytra.ico">	
	<meta name="theme-color" content="#a5ce3a"/>

</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
   	<div class="container-fluid">
		  <span id="openDrawer">
			   <span class="glyphicon glyphicon-menu-hamburger">		   	
			   </span>		  	
		  </span>
	<div class="navbar-header">
		<div class="navbar-brand navbar-brand-centered">
			<a href="dashboard">
	    		<img src="images/ecomytra.png" style="width:170px !important; margin-top:-10px;">	
		    </a>
	    </div>
	    </div>
	</div><!-- /.container-fluid -->
</nav>
<div>
	<div class="drawer" id="drawer">
		<span class="closeDrawer glyphicon glyphicon-remove"></span>
		<div class="content">
			<ul>
				<li><a href="./dashboard">Dashboard</a></li>
				<li><a href="./users">Users</a></li>
				<li><a href="./add-product">Add Products</a></li>
				<li><a href="./manage-products">Manage Products</a></li>
				<li><a href="./add-post">Add Posts</a></li>
				<li><a href="./manage-posts">Manage Posts</a></li>
				<li><a href="./categories">Manage Categories</a></li>
				<li><a href="./manage-orders">Manage Orders</a></li>
				<li><a href="./manage-testimonials">Testimonials</a></li>
				<li><a href="./manage-contact-info">Site's Contact Info</a></li>
				<li><a href="./contact-form">Contact Form</a></li>
				<li><a href="./slider">Front Slider</a></li>
				<li><a href="./socialmedia">Social Media Links</a></li>
				<li><a href="./banners">Manage Promo Banners</a></li>
				<li><a href="./catbanners">Manage Category Banners</a></li>
				<li><a href="./comments">Manage User Comments</a></li>
				<li><a href="./videos">Manage YouTube Videos</a></li>
				<li><a href="./galleryimages">Manage Gallery Images</a></li>
				<li><a href="../logout">Log Out</a></li>
			</ul>
		</div>
	</div>
