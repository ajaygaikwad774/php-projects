<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}


	include 'components/header.php';
	require 'components/connection.php';
	if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
		header("Location: manage-posts");
	}

	$query="select *from article where ISENABLED='true' and ID=".$_GET['id'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res)
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Edit Article</strong></h1>
			<a href="manage-posts">Back to Article List</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
			<form method="post" action="updatepages/updatepost.php?id=<?php echo $_GET['id']; ?>" enctype="multipart/form-data">
			<div class="form-group">
			 	<label for="title">
			 		Post Title:
			 	</label>
			    <input type="text" placeholder="Enter Product Title" value="<?php echo $row['TITLE']; ?>" class="form-control" id="title" required name="title">			
			</div>
			<div class="form-group">
				<label for="image">Update Post Image:</label><br>
				<img src="<?php echo $siteurl.$row['PHOTO']; ?>" style="width: 150px;"><br><br>
				<input type="file" name="image" id="image">
			</div>
			<div class="form-group">
			 	<label for="description">
			 		Post Description:
			 	</label>
			    <textarea id="description" placeholder="Enter Post Description" rows="8" name="description" required class="form-control"><?php echo $row['CONTENT']; ?></textarea>		
			</div>
			<div class="form-group">
				<label for="category">Select Post Category:</label>
				<select class="form-control" name="category">
					<?php
						$q="select *from category";
						$rs=mysqli_query($conn, $q);
						while ($rw=mysqli_fetch_array($rs)) {
					?>
						<option value="<?php echo $rw['ID']; ?>" <?php if($rw['ID']==$row['CATEGORY']){ echo "selected"; } ?>><?php echo $rw['TITLE']; ?></option>";
					<?php
						}
					?>
				</select>
			</div>
			<center>
				<button class="btn btn-default">Update</button>
			</center>
			</form>
		</div>
	</div>
</main>
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>
<?php
	include 'components/footer.php';
?>