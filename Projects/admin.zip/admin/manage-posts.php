<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
    require("components/connection.php");	
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Post</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
			<button class="btn btn-default" onclick="location.assign('add-post')">Add New Article</button>			
		</center>
		<hr>

		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Title</th>
						<th>Description</th>
						<th>Pic</th>
						<th>Category</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>
				</thead>
				<tbody>
					<?php
			            $query="select *from article where ISENABLED='true' limit 20 offset ".(($pg-1)*20);
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							$counter++;
					?>
					<tr>
						<td><?=$counter+(($pg-1)*20); ?></td>
						<td><?=$row['TITLE']; ?></td>
						<td style="max-width: 300px;"><?=substr($row['CONTENT'], 0, 100)."......."; ?></td>
						<td><img src="<?=$siteurl.$row['PHOTO']; ?>" style="width: 80px;"></td>
						<td><?php
							$q="select *from category where ID=".$row['CATEGORY'];
							$rs=mysqli_query($conn, $q);
							$rw=mysqli_fetch_array($rs);
							echo $rw['TITLE'];
						?></td>
						<td>
							<a href="editpost?id=<?php echo $row['ID']; ?>">Edit</a>
						</td>
						<td>
							<a href="deletepages/deletepost.php?id=<?php echo $row['ID']; ?>">Delete</a>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
		<div class="clearfix"></div>
		<br><br>
	<center>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from article where ISENABLED='true'";
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="manage-posts?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>

	</div>
</main>
<?php
	include 'components/footer.php'
?>