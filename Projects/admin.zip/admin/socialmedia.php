<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
    require("components/connection.php");	
    $query="select *from socialmedia";
    $res=mysqli_query($conn, $query);
    $accounts=array();
    while($row=mysqli_fetch_array($res)){
    	if($row['TITLE']=="facebook"){
    		$accounts['facebook']=$row['LINK'];
    	}elseif($row['TITLE']=="instagram"){
    		$accounts['instagram']=$row['LINK'];
    	}elseif($row['TITLE']=="twitter"){
    		$accounts['twitter']=$row['LINK'];
    	}elseif($row['TITLE']=="linkedin"){
    		$accounts['linkedin']=$row['LINK'];
    	}
    }
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Social Media Links</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr>
		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<div class="col-sm-5" style="float: none; margin: auto;">
			<form method="post" action="updatepages/socialmedialinks.php">
			<div class="form-group">
			 	<label for="fb">
			 		<span class="fa fa-facebook"></span>
			 		Facebook Page Link:
			 	</label>
			    <input type="text" placeholder="Enter Facebook Page Link" class="form-control" id="fb" name="fb" value="<?php echo $accounts['facebook']; ?>">			
			</div>
			<div class="form-group">
			 	<label for="insta">
			 		<span class="fa fa-instagram"></span>
			 		Instagram Account Link:
			 	</label>
			    <input type="text" placeholder="Enter Instagram Account Link"  value="<?php echo $accounts['instagram']; ?>" class="form-control" id="insta" name="insta">			
			</div>
			<div class="form-group">
			 	<label for="twitter">
			 		<span class="fa fa-twitter"></span>
			 		Twitter Account Link:
			 	</label>
			    <input type="text" placeholder="Enter Twitter Account Link" value="<?php echo $accounts['twitter']; ?>" class="form-control" id="twitter" name="twitter">			
			</div>
			<div class="form-group">
			 	<label for="linkedin">
			 		<span class="fa fa-linkedin"></span>
			 		Linkedin Account Link:
			 	</label>
			    <input type="text" placeholder="Enter Linkedin Account Link" value="<?php echo $accounts['linkedin']; ?>" class="form-control" id="linkedin" name="linkedin">			
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%">Update Social Links</button>
			</center>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php'
?>