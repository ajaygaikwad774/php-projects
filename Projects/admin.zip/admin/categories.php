<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}
	include 'components/header.php';
    require("components/connection.php");	
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Categories</strong></h1>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr> 
		<br>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<form class="col-sm-5" method="post" action="postpages/addcategory.php" enctype="multipart/form-data">
			<div class="form-group"> 
			 	<label for="title">
			 		Category Title:
			 	</label>
			    <input type="text" placeholder="Enter Post Title" class="form-control" id="title" required name="title">			
			</div>
			<div class="form-group">
				<label for="image">Add Image:</label>
				<input type="file" name="image" required id="image">
			</div>
			<div class="form-group">
				<label for="category">Category Type:</label>
				<select class="form-control" name="type">
					<option>Post</option>
					<option>Product</option>
				</select>
			</div>
			<center>
				<button class="btn btn-default" style="width: 100%;">Create Category</button>
			</center>
		</form>
		<div class="clearfix"></div>
		<div class="col-sm-6" style="padding: 20px;">
			<h3>Product Categories</h3>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>
								Sr. No.
							</th>
							<th>
								Title
							</th>
							<th>
								Edit
							</th>
							<th>
								Delete
							</th>
						</tr>
					</thead>
					<tbody>
					<?php
			            $query="select *from product_category";
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							if($row['ID']==0){
								continue;
							}
							$counter++;
					?>
						<tr>
							<td><?=$counter; ?></td>
							<td><?=$row['TITLE'] ?></td>
							<td><a href="editproductcategory?id=<?php echo $row['ID']; ?>">Edit</a></td>
							<td><a href="deletepages/deleteproductcategory.php?id=<?php echo $row['ID']; ?>">Delete</a></td>
						</tr>
					<?php
						}
					?>
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-sm-6" style="padding: 20px;">
			<h3>Post Categories</h3>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>
								Sr. No.
							</th>
							<th>
								Title
							</th>
							<th>
								Edit
							</th>
							<th>
								Delete
							</th>
						</tr>
					</thead>
					<tbody>
					<?php
			            $query="select *from category";
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							if($row['ID']==0){
								continue;
							}
							$counter++;
					?>
						<tr>
							<td><?=$counter; ?></td>
							<td><?=$row['TITLE'] ?></td>
							<td><a href="editpostcategory?id=<?php echo $row['ID']; ?>">Edit</a></td>
							<td><a href="deletepages/deletepostcategory.php?id=<?php echo $row['ID']; ?>">Delete</a></td>
						</tr>
					<?php
						}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php'
?>