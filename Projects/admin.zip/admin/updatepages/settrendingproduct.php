<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../../login?msg=Please Log In First");
	}
   require("../components/connection.php");
   
   if(isset($_GET['id']) && is_numeric($_GET['id'])){
        $query="update product set IS_TRENDING='yes' where ID=".$_GET['id'];
   		$res=mysqli_query($conn, $query);
   		header("Location:../manage-products?&msg=Product Updated Successfully");
   }
?>