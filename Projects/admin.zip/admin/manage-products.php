<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
    require("components/connection.php");	
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Products</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
			<button class="btn btn-default" onclick="location.assign('add-product')">Add New Product</button>
		</center>
		<hr> 

		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<div class="clearfix"></div><br>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Title</th>
						<th>Description</th>
						<th>Pic</th>
						<th>Price</th>
						<th>Discount Price</th>
						<th>Category</th>
<?php #						<th>Featured</th> ?>
						<th>Trending</th>
						<th>Product Weight</th>
						<th>Shipping Weight</th>
						<th>Edit</th>
						<th>Availability</th>
					</tr>
				</thead>
				<tbody>
					<?php
			            $query="select *from product limit 20 offset ".(($pg-1)*20);
				   		$res=mysqli_query($conn, $query);
				   		$counter=0;
						while ($row=mysqli_fetch_array($res)) {
							$counter++;
					?>
					<tr>
						<td><?=$counter+(($pg-1)*20); ?></td>
						<td><?=$row['TITLE']; ?></td>
						<td style="max-width: 200px;"><?=substr($row['DESCRIPTION'], 0, 100)."......."; ?></td>
						<td><img src="<?=$siteurl.$row['IMAGE']; ?>" style="width: 50px;"></td>
						<td>Rs. <?=$row['PRICE']; ?>/-</td>
						<td><?php
							if($row['DISCOUNTPRICE']!=""){
								echo "Rs. ".$row['DISCOUNTPRICE']."/-"; 
							}

							?></td>
						<td><?php
							$q="select *from product_category where ID=".$row['CATEGORY'];
							$rs=mysqli_query($conn, $q);
							$rw=mysqli_fetch_array($rs);
							echo $rw['TITLE'];
						?></td>
<?php /*						<td>
							<?php
								if($row['IS_FEATURED']=="no"){
									$q="select *from product where IS_FEATURED='yes'";
									$rs=mysqli_query($conn, $q);
									$n=mysqli_num_rows($rs);
							?>
							<a <?php if($n>=4){?> href="manage-products?msg=Maximum 4 featured products are allowed" <?php }else{ ?> href="updatepages/setfeaturedproduct?id=<?php echo $row['ID']; ?>" <?php } ?>>Set as Featured</a>							
							<?php
								}elseif($row['IS_FEATURED']=="yes"){
							?>
							<a href="updatepages/unsetfeaturedproduct?id=<?php echo $row['ID']; ?>">Unset as Featured</a>							
							<?php
								}
							?>
						</td> */ ?>
						<td>
							<?php
								if($row['IS_TRENDING']=="no"){
							?>
							<a href="updatepages/settrendingproduct?id=<?php echo $row['ID']; ?>">Set as Trending</a>							
							<?php
								}elseif($row['IS_TRENDING']=="yes"){
							?>
							<a href="updatepages/unsettrendingproduct?id=<?php echo $row['ID']; ?>">Unset as Trending</a> 
							<?php
								}
							?>
						</td>
						<td>
							<?php echo $row['PRDWEIGHT']." KG"; ?>
						</td>
						<td>
							<?php echo $row['SHPWEIGHT']." KG"; ?>
						</td>
						<td>
							<a href="editproduct?id=<?php echo $row['ID']; ?>">Edit</a>						
						</td>
						<td>
							<?php
								if($row['ISENABLED']=="true"){
							?>
							<a href="deletepages/deleteproduct.php?id=<?php echo $row['ID']; ?>">Make Unavailable</a>
							<?php
								}else{
							?>
							<a href="deletepages/undeleteproduct.php?id=<?php echo $row['ID']; ?>">Make Available</a>
							<?php
								}
							?>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
	<center>
		<div class="clearfix"></div>
		<br><br>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from product";
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="manage-products?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>
	</div>
</main>
<?php
	include 'components/footer.php'
?>