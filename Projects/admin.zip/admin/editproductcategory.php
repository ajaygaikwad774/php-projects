<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	require 'components/connection.php';
	if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
		header("Location: categories");
	}

	$query="select *from product_category where ID=".$_GET['id'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res)
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Edit Product Category</strong></h1>
			<a href="categories">Back to Categories</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
			<form method="post" action="updatepages/updateproductcategory.php?id=<?php echo $_GET['id']; ?>" enctype="multipart/form-data">
				<div class="form-group">
					<label for="category">Title:</label>
					<input type="text" name="title" id="title" class="form-control" required placeholder="Category Title" value="<?php echo $row['TITLE']; ?>">
				</div>		
				<div class="form-group">
					<label>Image:</label><br>
					<img src="<?php echo $siteurl.$row['IMAGE']; ?>" style="width:200px;"><br><br>
					<input type="file" name="image" id="image">
				</div>	
				<button class="btn btn-default">Update</button>
			</form>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>