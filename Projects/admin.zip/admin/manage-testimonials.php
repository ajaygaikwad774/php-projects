<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
    require("components/connection.php");	
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage Testimonials</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
		</center>
		<hr>
		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>	
		</center>

		<div class="clearfix"></div><br>	

		<div class="col-sm-5">
			<h3><strong>Add New</strong></h3>
			<form method="post" action="postpages/addtestimonial.php" enctype="multipart/form-data">
				<div class="form-group">
				 	<label for="author">
				 		Author Name:
				 	</label>
				    <input type="text" placeholder="Enter Author Name" class="form-control" id="author" required name="name">			
				</div>
				<div class="form-group">
					<label for="image">Add Author's Pic (Optional):</label>
					<input type="file" name="image" id="image">
				</div>
				<div class="form-group">
				 	<label for="comment">
				 		Author's Comment:
				 	</label>
				    <textarea id="comment" placeholder="Enter Comment" name="comment" rows="3" required class="form-control"></textarea>		
				</div>
				<button class="btn btn-default" style="width: 100%;">Add</button>
			</form>
		</div>
		<div class="col-sm-1">&nbsp;</div>
		<div class="col-sm-6">

			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Sr. No.</th>
							<th>Author Name</th>
							<th>Pic</th>
							<th>Comment</th>
							<th>Delete</th>
						</tr>
					</thead>
					<tbody>
						<?php
				            $query="select *from testimonial";
					   		$res=mysqli_query($conn, $query);
					   		$counter=0;
							while ($row=mysqli_fetch_array($res)) {
								$counter++;
						?>
						<tr>
							<td><?=$counter; ?></td>
							<td><?=$row['AUTHOR']; ?></td>
							<td><img src="<?=$siteurl.$row['PIC']; ?>" style="width: 50px;"></td>
							<td><?=$row['COMMENT'];?></td>
							<td>
								<a href="deletepages/deletetestimonial.php?id=<?php echo $row['ID']; ?>">Delete</a>
							</td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>