<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	require 'components/connection.php'; 
	if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
		header("Location: manage-products");
	}

	$query="select *from product where ISENABLED='true' and ID=".$_GET['id'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res)
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Edit Product</strong></h1>
			<a href="manage-products">Back to Product List</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
			<form method="post" action="updatepages/updateproduct.php?id=<?php echo $_GET['id']; ?>" enctype="multipart/form-data">
			<div class="form-group">
			 	<label for="title">
			 		Product Title:
			 	</label>
			    <input type="text" placeholder="Enter Product Title" value="<?php echo $row['TITLE']; ?>" class="form-control" id="title" required name="title">			
			</div>
			<div class="form-group">
				<label for="image">Update Product Image:</label><br>
				<img src="<?php echo $siteurl.$row['IMAGE']; ?>" style="width: 100px;"><br><br>
				<input type="file" name="image" id="image">
			</div>
			<div class="form-group">
			 	<label for="description">
			 		Product Description:
			 	</label>
			    <textarea id="description" placeholder="Enter Product Description" rows="8" name="description" required class="form-control"><?php echo $row['DESCRIPTION']; ?></textarea>		
			</div>
			<div class="form-group">
				<label for="price">Set Product Price:</label>
				<input type="number" name="price" id="price" required class="form-control" style="width:100px;" placeholder="Price" value="<?php echo $row['PRICE']; ?>">
			</div>
			<div class="form-group">
				<label for="dprice">Set Discounted Price:</label>
				<input type="number" name="dprice" id="dprice" class="form-control" style="width:100px;" placeholder="Price" value="<?php echo $row['DISCOUNTPRICE']; ?>">
			</div>
			<div class="form-group">
				<label for="pweight">Set Product Weight (in KG):</label>
				<input type="number" name="pweight" value="<?php echo $row['PRDWEIGHT']; ?>" step="0.01" id="pweight" required class="form-control" placeholder="Product Weight (in KG)">
			</div>
			<div class="form-group">
				<label for="sweight">Set Shipping Weight (in KG):</label>
				<input type="number" name="sweight" step="0.01" id="sweight" value="<?php echo $row['SHPWEIGHT']; ?>" class="form-control" placeholder="Shipping Weight (in KG)">
			</div>
			<div class="form-group">
				<label for="category">Select Product Category:</label>
				<select class="form-control" name="category">
					<?php
						$q="select *from product_category";
						$rs=mysqli_query($conn, $q);
						while ($rw=mysqli_fetch_array($rs)) {
					?>
						<option value="<?php echo $rw['ID']; ?>" <?php if($rw['ID']==$row['CATEGORY']){ echo "selected"; } ?>><?php echo $rw['TITLE']; ?></option>";
					<?php
						}
					?>
				</select>
			</div>
			<center>
				<button class="btn btn-default">Update</button>
			</center>
			</form>
		</div>
	</div>
</main>
<script type="text/javascript">
        CKEDITOR.replace( 'description' );
</script>
<?php
	include 'components/footer.php';
?>