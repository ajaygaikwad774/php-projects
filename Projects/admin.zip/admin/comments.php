<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	require 'components/connection.php';
	$query="select *from comment where USER in(select ID from user where ISENABLED='true') order by ID DESC limit 20 offset ".(($pg-1)*20);
	$res=mysqli_query($conn, $query);
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Manage User Comments</strong></h1>
			<a href="dashboard">Back to Dashboard</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<?php 
			if(mysqli_num_rows($res)==0){
		?>
		<br>
		<center>
			<h3>No Comments Yet</h3>
		</center>
		<?php
			}else{
		?>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Sr. No.</th>
						<th>Product</th>
						<th>User</th>
						<th>Comment</th>
						<th>Rating</th>
						<th>Date</th>
						<th>Delete/Remove</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$counter=0;
						while($row=mysqli_fetch_array($res)){
							$counter++;

							$userquery="select *from user where ID=".$row['USER'];
							$userres=mysqli_query($conn, $userquery);
							$userrow=mysqli_fetch_array($userres);

							$productquery="select *from product where ID=".$row['PRODUCT'];
							$productres=mysqli_query($conn, $productquery);
							$productrow=mysqli_fetch_array($productres);
					?>
					<tr>
						<td><?=$counter+(($pg-1)*20); ?></td>
						<td>
							<a href="<?php echo $siteurl."product-detail?product=".$productrow['ID']; ?>">
								<?=$productrow['TITLE']; ?>				
							</a>
						</td>
						<td>
							<a href="userprofile?user=<?php echo $userrow['ID']; ?>">
								<?=$userrow['NAME']; ?>
							</a>								
						</td>
						<td><?=$row['COMMENT']; ?></td>
						<td>
							<div class="rating">
								<?php
									for($i=1; $i<=5; $i++){
								?>
								<span class="fa fa-star <?php if($row['STARS']>=$i){ echo "rated"; } ?>"></span>
								<?php
									}
								?>
							</div>									
						</td>
						<td><?=$row['DATE']; ?></td>
						<td><a href="deletepages/deletecomment.php?comment=<?php echo $row['ID']; ?>">Delete/Remove</a></td>
					</tr>
					<?php
						}
					?>
				</tbody>
			</table>
		</div>
		<?php 
			}
		?>
		<div class="clearfix"></div>
		<br><br>
	<center>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from comment where USER in(select ID from user where ISENABLED='true')";
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="comments?pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>

	</div>
</main>
<?php
	include 'components/footer.php'
?>