<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	require 'components/connection.php';

	$query="select *from contact";
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res);
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Site's Contact Info</strong></h1><br>
			<a href="dashboard">Back to Dashboard</a><br><br>
		</center>
		<hr>
		<br>
		<center>
			<?php 
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>	
		</center>
		<div class="clearfix"></div><br>
		<div class="col-sm-6 account-form">
			<form method="post" action="updatepages/sitecontactinfo.php">
				<div class="form-group">
				 	<label for="contact1">
				 		<span class="glyphicon glyphicon-phone"></span>
				 		Primary Contact Number:
				 	</label>
				    <input type="text" placeholder="Enter Contact Number" class="form-control" id="contact1" required value="<?php echo $row['PHONE1']; ?>" name="contact1">			
				</div>
				<div class="form-group">
				 	<label for="contact2">
				 		<span class="glyphicon glyphicon-phone"></span>
				 		Contact Number (Optional):
				 	</label>
				    <input type="text" placeholder="Enter Contact Number" value="<?php echo $row['PHONE2']; ?>" class="form-control" id="contact2" name="contact2">			
				</div>
				<div class="form-group">
				 	<label for="email1">
				 		<span class="glyphicon glyphicon-envelope"></span>
				 		Primary Email Address:
				 	</label>
				    <input type="email" placeholder="Enter Email Address" class="form-control" id="email1" value="<?php echo $row['EMAIL1']; ?>" required name="email1">			
				</div>
				<div class="form-group">
				 	<label for="email2">
				 		<span class="glyphicon glyphicon-envelope"></span>
				 		Email Address (Optional):
				 	</label>
				    <input type="email" value="<?php echo $row['EMAIL2']; ?>" placeholder="Enter Email Address" class="form-control" id="email2" name="email2">			
				</div>
				<div class="form-group">
				 	<label for="address">
				 		<span class="glyphicon glyphicon-map-marker"></span>
				 		Address:
				 	</label>
				    <textarea id="address" placeholder="Enter Your Address" rows="4" name="address" required class="form-control"><?php echo $row['ADDRESS']; ?></textarea>		
				</div>
				<div class="form-group">
				 	<label for="maplink">
				 		<span class="fa fa-map"></span>
				 		Google Maps Embed:
				 	</label>
				    <textarea id="maplink" placeholder="Enter Google Maps Embed Code Here" rows="8" name="maplink" required class="form-control"><?php echo $row['GOOGLEMAPS']; ?></textarea>		
				</div>
				<center>
					<button class="btn btn-default" style="width: 100%;">Update Contact Info</button>
				</center>

			</form>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>