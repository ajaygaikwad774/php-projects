<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: ../login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="admin"){
		header("Location: ../login?msg=Please Log In First");
	}

	include 'components/header.php';
	require 'components/connection.php';
	if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
		header("Location: videos");
	}

	$query="select *from videos where ID=".$_GET['id'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res)
?>
<main>
	<div class="container-fluid" style="padding-top: 20px; padding-bottom: 200px;">
		<center>
			<h1><strong>Edit YouTube Video</strong></h1>
			<a href="videos">Back to Videos</a>
		</center>
		<hr>
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<div class='errormsg'>";
					echo $_GET['msg'];
					echo "</div>";
				}
			?>
		</center>
		<br>
		<div class="col-sm-6 account-form">
			<form method="post" action="updatepages/updatevideos.php?id=<?php echo $_GET['id']; ?>">
				<iframe width="100%" height="300" src="<?php
					$temp=explode("/", $row['LINK']);
				 echo "https://youtube.com/embed/".$temp[count($temp)-1]; 

				 ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
				</iframe><br><br>
				<br><br>
				<div class="form-group">
					<label for="category">Title:</label>
					<input type="text" name="title" id="title" class="form-control" required placeholder="Category Title" value="<?php echo $row['TITLE']; ?>">
				</div>			
				<div class="form-group">
				 	<label for="link">
				 		Video Link:
				 	</label>
				    <input type="text" placeholder="Enter Video Link" value="<?php echo $row['LINK']; ?>" class="form-control" id="link" required name="link">			
				</div>
				<button class="btn btn-default">Update</button>
			</form>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>