<?php 
	if(!isset($_GET['cat']) || !is_numeric($_GET['cat'])){
		header("Location: ./");
	}		
	include 'components/header.php';
	$cat="select *from product_category where ID=".$_GET['cat'];
	$catres=mysqli_query($conn, $cat);
?>

<main>
		<?php
			if(mysqli_num_rows($catres)==0){
		?>
	<div class="container-fluid" style="padding-top: 50px;">
			<center>
				<br>
				<h2>No Category Found</h2>
				<a href="./">Click here to go back on the home page</a>
				<br><br>
			</center>
	</div>
		<?php
			}else{

			$catrow=mysqli_fetch_array($catres);
			
			$promobanner="select *from catpromobanner where PRODUCTCAT=".$_GET['cat'];
			$promobannerres=mysqli_query($conn, $promobanner);
			if(mysqli_num_rows($promobannerres)!=0){
			    $promobannerrow=mysqli_fetch_array($promobannerres);
		?>
	<div class="about-page-banner">
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
		  <div class="carousel-inner">
		    <div class="item active">
		      <img src="<?php echo $siteurl.$promobannerrow['IMAGE']; ?>">
		    </div>
		  </div>
		</div>
	
	</div>

	    <?php
			}
	    ?>
	<div class="container-fluid" style="padding-top: 50px;">
		<center>
			<h1 class="title"><?php echo $catrow['TITLE']; ?></h1>
			<img src="images/underline.png" style="width:300px;">
		</center>
		<br>
		<br>
		<div class="clearfix"></div>
		<br>
		<?php
			$product="select *from product where ISENABLED='true' and CATEGORY=".$_GET['cat']." order by ID desc limit 20 offset ".(($pg-1)*20);
			$productres=mysqli_query($conn, $product);
			if(mysqli_num_rows($productres)==0){
		?>
			<center>
				<h3>No Product Available</h3>
				<br><br>
			</center>
		<?php
			}
			while($productrow=mysqli_fetch_array($productres)){
		?>
		<div class="col-sm-3" style="padding-bottom: 20px;">
			<a href="product-detail?product=<?php echo $productrow['ID']; ?>">
				<div class="product">
					<div class="product-image-wrapper">
						<div class="product-img" style="background-image: url('<?php echo $siteurl.$productrow['IMAGE']; ?>');">
					</div>					
					</div>
					<table>
						<tr>
							<td class="product-title">
								<?php echo $productrow['TITLE']; ?>
							</td>
							<?php
								if(trim($productrow['DISCOUNTPRICE'])!=""){
							?>
							<td class="product-pricing">
								<strike>Rs. <?php echo $productrow['PRICE']; ?>/-</strike> 
								<strong>Rs. <?php echo $productrow['DISCOUNTPRICE']; ?>/-</strong>
							</td>						
							<?php
								}else{
							?>
							<td class="product-pricing">
								<strong>Rs. <?php echo $productrow['PRICE']; ?>/-</strong>
							</td>						
							<?php
								}
							?>
						</tr>
					</table>
				</div>
				</a>
		</div>		
		<?php
				}				
			}
		?>
	<center>
		<div class="clearfix"></div>
		<br><br>
		<ul class="pagination pagination-sm">
		<?php
			$totalrowsQuery="select *from product where ISENABLED='true' and CATEGORY=".$_GET['cat'];
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="products?cat=<?php echo $_GET['cat']; ?>&pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>

	</center>	
	</div>
</main>

<?php
	include 'components/footer.php';
?>