<?php
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 30px; padding-bottom: 100px;">
			<center>
				<h1 class="title">Media Topics</h1>
				<img src="images/underline.png" style="width:300px;">
			</center>
			<br><br>
			<a href="gallery">
				  <div class="col-sm-6 text-center" style="padding: 10px;">
					<div style="background-color: #f0f0f0; padding: 10px; min-height:300px; padding-top:80px;">
				  	<img src="images/gallery.jpg" style="width: 100px; margin: auto; float: none;" class="img-responsive">
				  	<h3>Gallery</h3>
				  </div>
				</div>
			</a>
			<a href="videos">
				  <div class="col-sm-6 text-center" style="padding: 10px;">
					<div style="background-color: #f0f0f0; padding: 10px; min-height:300px; padding-top:80px;">
				  	<img src="images/youtube.jpg" style="width: 100px; margin: auto; float: none;" class="img-responsive">
				  	<h3>Youtube Videos</h3>
				  </div>
				</div>
			</a>
	</div>
</main>
<?php
	include 'components/footer.php';
?>