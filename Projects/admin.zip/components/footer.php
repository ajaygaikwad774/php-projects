<div class="clearfix"></div>
<footer>
	<div class="container-fluid">
		<div class="col-sm-3">
			<h3>Ecomytra</h3><br>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat.
		</div>

		<div class="col-sm-3">
			<h3>Links</h3><br>
			<a href="./">Home</a><hr>
			<a href="about">About Us</a><hr>
			<a href="contact">Contact Us</a>
		</div>


		<div class="col-sm-3">
			<h3>Product Links</h3><br>
			<a href="checkout">Checkout</a><hr>
			<a href="media">Media</a><hr>
		</div>


		<div class="col-sm-3">
			<h3>Contact Us</h3><br>
			<strong>Location: </strong> <?php echo nl2br($contactinforow['ADDRESS']); ?> <br>
			<strong>Email: </strong> <a href="mailto: <?php echo $contactinforow['EMAIL1']; ?>"><?php echo $contactinforow['EMAIL1']; ?></a> <br>
			<strong>Contact: </strong> <a href="tel: <?php echo $contactinforow['PHONE1']; ?>"><?php echo $contactinforow['PHONE1']; ?></a><br><br>
			<div class="socialmedia">
				<?php 
					$social="select *from socialmedia";
					$socialres=mysqli_query($conn, $social);
					while($socialrow=mysqli_fetch_array($socialres)){
				?>
					<?php
						if($socialrow['TITLE']=="facebook"){
					?>
					<a href="<?php echo $socialrow['LINK']; ?>" style="background-color: #3b579d;">
						<i class="fa fa-facebook"></i>
					</a>
					<?php							
						}elseif($socialrow['TITLE']=="instagram"){
					?>
					<a href="<?php echo $socialrow['LINK']; ?>" style="background-color: #C13584;">
						<i class="fa fa-instagram"></i>
					</a>
					<?php
						}elseif($socialrow['TITLE']=="linkedin"){
					?>
					<a href="<?php echo $socialrow['LINK']; ?>" style="background-color: #00a0dc;">
						<i class="fa fa-linkedin"></i>
					</a>
					<?php
						}elseif($socialrow['TITLE']=="twitter"){
					?>
					<a href="<?php echo $socialrow['LINK']; ?>" style="background-color: #00acee;">
						<i class="fa fa-twitter"></i>
					</a>
					<?php
						}
					?>
				<?php
					}
				?>					
			</div>
		</div>
	</div>
	<div class="container-fluid" style="padding-top: 30px;">
		<center>&copy; Copyright <?php echo date('Y'); ?>. All rights reserved by Ecomytra.</center>
	</div>
</footer>
</div>
</body>
</html>
