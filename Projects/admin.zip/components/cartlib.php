<?php
	function addToCart($product_id, $quantity){
		require 'connection.php';
		$cart = array();
		if(isset($_COOKIE['product_cart'])){
			$cart=json_decode($_COOKIE['product_cart'], true);
		}	
		$cartcount=count($cart);

		$isproductalreadyadded=false;
		$temp=0;

		for($i=0; $i<$cartcount; $i++){
			if($cart[$i]['product']==$product_id){
				$isproductalreadyadded=true;
				$temp=$i;
				break;
			}
		}
		if($isproductalreadyadded){
			$cart[$temp]['quantity']+=$quantity;
		}else{
			$cart[$cartcount]['product']=$product_id;
			$cart[$cartcount]['quantity']=$quantity;			

			$pq="select *from product where ID=".$product_id;
			$pqres=mysqli_query($conn, $pq);
			$price=0;
			$pqrow=mysqli_fetch_array($pqres);
			if(trim($pqrow['DISCOUNTPRICE'])==""){
				$price=$pqrow['PRICE'];
			}else{
				$price=$pqrow['DISCOUNTPRICE'];
			}				
			$cart[$cartcount]['product_price']=$price;
			$cart[$cartcount]['pweight']=$pqrow['PRDWEIGHT'];
			$cart[$cartcount]['sweight']=$pqrow['SHPWEIGHT'];
		}
		setcookie("product_cart", json_encode($cart), time()+3600, "/");		
	}


	function removeItemFromCart($product_id){
		$cart = array();
		$cartcopy=array();
		if(isset($_COOKIE['product_cart'])){
			$cart=json_decode($_COOKIE['product_cart'], true);
		}	
		$counter=0;
		for($i=0; $i<count($cart); $i++){
			if($cart[$i]['product']!=$product_id){
				$cartcopy[$counter]['product']=$cart[$i]['product'];
				$cartcopy[$counter]['quantity']=$cart[$i]['quantity'];	
				$cartcopy[$counter]['product_price']=$cart[$i]['product_price'];
				$cartcopy[$counter]['pweight']=$cart[$i]['pweight'];
				$cartcopy[$counter]['sweight']=$cart[$i]['sweight'];
				$counter++;
			}
		}

		setcookie("product_cart", json_encode($cartcopy), time()+3600, "/");		
	}

	function resetCart(){
		setcookie("product_cart", "", time()-3600, "/");				
	}

	function getCartItems(){
		$cart = array();
		if(isset($_COOKIE['product_cart'])){
			$cart=json_decode($_COOKIE['product_cart'], true);
		}	
		return $cart;
	}

	function getCartItemsCount(){
		$cart=array();
		if(isset($_COOKIE['product_cart'])){
			$cart=json_decode($_COOKIE['product_cart'], true);
		}	

		$totalitems=0;

		for($i=0; $i<count($cart); $i++){
			$totalitems+=$cart[$i]['quantity'];
		}

		return $totalitems;
	}
?>
