<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="user"){
		header("Location: login?msg=Please Log In First");
	}
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 50px; padding-bottom: 50px;">
			<center>
				<br><br>
				<center>
					<h1>Order Placed Successfully</h1>
					<h4>Thank you for shopping on Ecomytra.</h4>
					<h4>You can track your order delivery status on your <a href="order-history"><strong>Order History Page</strong></a>.</h4>
				</center>
			</center>
	</div>
</main>
<?php
	include 'components/footer.php'
?>