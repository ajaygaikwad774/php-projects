<?php
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 30px; padding-bottom: 100px;">
			<center>
				<h1 class="title">Media</h1>
				<img src="images/underline.png" style="width:300px;">
			</center>
			<br><br>
			<a href="topics">
				  <div class="col-sm-6 text-center" style="padding: 10px;">
					<div style="background-color: #f0f0f0; padding: 10px; min-height:300px; padding-top:80px;">
				  	<img src="images/blog.jpg" style="width: 150px; margin: auto; float: none;" class="img-responsive">
				  	<h3>Blogs</h3>
				  </div>
				</div>
			</a>
			<a href="mediatopics">
				  <div class="col-sm-6 text-center" style="padding: 10px;">
					<div style="background-color: #f0f0f0; padding: 10px; min-height:300px; padding-top:80px;">
				  	<img src="images/media.jpg" style="width: 150px; margin: auto; float: none;" class="img-responsive">
				  	<h3>Media</h3>
				  </div>
				</div>
			</a>
	</div>
</main>
<?php
	include 'components/footer.php';
?>