<?php
	setcookie("usertype", "", time()-3600, "/");
	setcookie("user", "", time()-3600, "/");

	header("Location: login?msg=You are logged out");
?>