<?php
	if(!isset($_COOKIE['usertype'])){
		header("Location: login?msg=Please Log In First");
	}
	elseif($_COOKIE['usertype']!="user"){
		header("Location: login?msg=Please Log In First");
	}
	include 'components/header.php';
	$query="select *from user where ID=".$_COOKIE['user'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res);
?>
<main>
	<div class="container-fluid" style="padding-top: 30px; padding-bottom: 50px;">
		<div class="account-form col-sm-7">
			<center>
				<h1><strong>My Profile Page</strong></h1><br>
			</center>
			<form method="post" action="updatepages/updateprofile.php" enctype="multipart/form-data">
				<div class="form-group">
					<div class="profile-pic" style="background-image: url('<?php echo $siteurl.$row['PIC']; ?>');">
					</div>
				</div>
			<center>
				<?php
					if(isset($_GET['msg'])){
						echo "<br><div class='errormsg'>";
						echo $_GET['msg'];
						echo "</div><br><br>";
					}
				?>
			</center>
			  <div style="padding-top: 20px;"><center><h3><span class="glyphicon glyphicon-user"></span> Personal Info</h3></center></div>
			  <div class="form-group">
			    <label for="name"><span class="glyphicon glyphicon-user"></span> Your Name:</label>
			    <input type="text" required name="name" value="<?php echo $row['NAME']; ?>" placeholder="Full Name" class="form-control" id="name">
			  </div>
			  <div class="form-group">
			    <label for="email"><span class="glyphicon glyphicon-envelope"></span> Your Email address:</label>
			    <input type="email" placeholder="Email Address" required name="email" value="<?php echo $row['EMAIL'];  ?>" class="form-control" id="email">
			  </div>
			  <div class="form-group">
			    <label for="image"><span class="glyphicon glyphicon-picture"></span> Change Your Profile Pic:</label>			  	
			    <input type="file" name="image">
			  </div>
			  <div class="form-group">
			    <label for="contact"><span class="glyphicon glyphicon-phone"></span> Your Contact Number:</label>
			    <input type="text" name="contact" required value="<?php echo $row['CONTACT']; ?>"  placeholder="Contact Number" class="form-control" id="contact">
			  </div>
			  <div class="form-group">
			    <label for="dob"><span class="glyphicon glyphicon-calendar"></span> Your Birth Date:</label>
			    <div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
			            <input type="text" placeholder="dd-mm-yyyy" name="dob" required value="<?php echo $row['DOB']; ?>" class="form-control" id="dob">
			            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                </div>
			  </div>
			  <div class="form-group">
			  		<label><i class="glyphicon glyphicon-user"></i> Select Gender:</label><br>
					<div class="radio">
					  <label><input type="radio" value="male" name="gender" <?php if($row['GENDER']=="" || $row['GENDER']=="male"){ echo "checked"; } ?>>Male</label>
					</div>
					<div class="radio disabled">
					  <label><input type="radio" value="female" <?php if($row['GENDER']=="female"){ echo "checked"; } ?> name="gender">Female</label>
					</div>			  	
			  </div>
			  <div class="form-group">
			    <label for="pwd"><span class="glyphicon glyphicon-lock"></span> Your Password:</label>
			    <input type="password" placeholder="Password" required name="password" value="<?php echo $row['PASSWORD']; ?>" class="form-control" id="pwd">
			  </div>
			  <div style="padding-top: 20px;"><center><h3><span class="glyphicon glyphicon-map-marker"></span> Delivery Location</h3></center></div>

			  <div class="form-group">
			    <label for="pincode">Pin Code:</label>
			    <script>
			        function validatePincode(a){
			            var inp=a.value;
                        var xhttp=new XMLHttpRequest();
                        xhttp.onreadystatechange=function(){
                            if(xhttp.readyState==4 || xhttp.status==200){
                                var resp=JSON.parse(xhttp.response);
                                if(resp[0].Message=="No records found"){
                                    document.getElementById("pincodeerror").innerHTML="Invalid Pin Code";
                                    document.getElementById("submitbtnn").disabled=true;
                                    document.getElementById("submitbtnn").innerHTML="Please Enter a Valid Pin Code";
                                }else{
                                    document.getElementById("pincodeerror").innerHTML="";
                                    document.getElementById("submitbtnn").disabled=false;
                                    document.getElementById("submitbtnn").innerHTML="Update Profile";
                                }
                            }
                        };
                        xhttp.open("GET", "https://api.postalpincode.in/pincode/"+inp, true);
                        xhttp.send();
			        }
			    </script>
			    <input type="number" name="pincode" oninput="validatePincode(this)" required value="<?php echo $row['PINCODE']; ?>"  placeholder="Pin Code" class="form-control" id="pincode">
			    <br>
			    <div id="pincodeerror" style="text-align:center; color: #dd0000;"></div>
			  </div>

			  <div class="form-group">
			    <label for="streetaddress1">Street Address 1:</label>
			    <input type="text" name="streetaddress1" required value="<?php echo $row['STREETADDR1']; ?>"  placeholder="Line 1" class="form-control" id="streetaddress1">
			  </div>

			  <div class="form-group">
			    <label for="streetaddress2">Street Address 2:</label>
			    <input type="text" name="streetaddress2" required value="<?php echo $row['STREETADDR2']; ?>"  placeholder="Line 2" class="form-control" id="streetaddress2">
			  </div>

			  <div class="form-group">
			    <label for="landmark">Landmark:</label>
			    <input type="text" name="landmark" required value="<?php echo $row['LANDMARK']; ?>"  placeholder="Landmark" class="form-control" id="landmark">
			  </div>

			  <div class="form-group">
			    <label for="city">City:</label>
			    <input type="text" name="city" required value="<?php echo $row['CITY']; ?>"  placeholder="City" class="form-control" id="city">
			  </div>
			  <div class="form-group">
			    <label for="state">State:</label>
			    <select class="form-control" name="state">
<?php
$state = array(
                "Maharashtra",
				"Andhra Pradesh",
                "Arunachal Pradesh",
                "Assam",
                "Bihar",
                "Chhattisgarh",
                "Goa",
                "Gujarat",
                "Haryana",
                "Himachal Pradesh",
                "Jammu and Kashmir",
                "Jharkhand",
                "Karnataka",
                "Kerala",
                "Madhya Pradesh",
                "Manipur",
                "Meghalaya",
                "Mizoram",
                "Nagaland",
                "Odisha",
                "Punjab",
                "Rajasthan",
                "Sikkim",
                "Tamil Nadu",
                "Telangana",
                "Tripura",
                "Uttarakhand",
                "Uttar Pradesh",
                "West Bengal",
                "Andaman and Nicobar Islands",
                "Chandigarh",
                "Dadra and Nagar Haveli",
                "Daman and Diu",
                "Delhi",
                "Lakshadweep",
                "Puducherry");

				for($i=0; $i<count($state); $i++){
?>
					<option value="<?php echo $state[$i]; ?>" <?php if($row['STATE']==$state[$i]){ echo "selected"; } ?>><?php echo $state[$i]; ?></option>
<?php
				}
?>
			    </select>
			  </div>
			  <div class="form-group">
			  	<label for="addresstype">Address Type</label>
			  	<select id="addresstype" name="addresstype" class="form-control">
			  		<option <?php if($row['ADDRESSTYPE']=="Home"){echo "selected";} ?>>Home</option>
			  		<option <?php if($row['ADDRESSTYPE']=="Office"){echo "selected";} ?>>Office</option>
			  	</select>
			  </div>
			  <button type="submit" id="submitbtnn" class="btn btn-default">Update Profile</button>	
			</form>
		</div>
	</div>
</main>
<script type="text/javascript">
$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true,
        format: 'dd-mm-yyyy'
  }).datepicker();
});
	
</script>

<?php
	include 'components/footer.php';
?>