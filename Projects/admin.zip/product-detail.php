<?php
	if(!isset($_GET['product']) || !is_numeric($_GET['product'])){
		header("Location: ./");
	}	

	include 'components/header.php';
	$product="select *from product where ISENABLED='true' and ID=".$_GET['product'];
	$productres=mysqli_query($conn, $product);
?>
<main> 
	<div class="container-fluid" style="padding-top: 30px;">
		<?php
			if(isset($_GET['msg'])){
				echo "<div class='errormsg'>";
				echo $_GET['msg'];
				echo "</div><br><br>";
			}
			if(mysqli_num_rows($productres)==0){
		?>
			<center>
				<br><br>
				<h2>Product Not Found</h2>
				<a href="./">Click here to go back on the home page</a>
				<br><br>
			</center>
		<?php
			}else{
				$productrow=mysqli_fetch_array($productres);
		?>

		<div class="col-sm-3" id="img-magnifier-container" class="img-magnifier-container" style="background-color: #f0f0f0; padding: 0; overflow: hidden; text-align: center;">
			    <center>
				    <img id="product-image" src="<?php echo $siteurl.$productrow['IMAGE']; ?>" class="img-responsive">
    			</center>
		</div>
		<div class="col-sm-1">&nbsp;</div>
		<div class="col-sm-8">
			<h1><strong><?php echo $productrow['TITLE']; ?></strong></h1><br>
			<?php
				echo $productrow['DESCRIPTION'];
			?>
			<br>
			<?php
				$averagerating="select AVG(STARS), COUNT(*) from comment where PRODUCT=".$_GET['product']." and USER in(select ID from user where ISENABLED='true')";
				$averageratingres=mysqli_query($conn, $averagerating);
				$averageratingrow=mysqli_fetch_array($averageratingres);
				if($averageratingrow[1]!=0){
			?>
			<strong>Average rating:</strong>
			<div class="rating">
				<?php
					for($i=1; $i<=5; $i++){
				?>
				<span class="fa fa-star <?php if($averageratingrow[0]>=$i){ echo "rated"; } ?>"></span>
				<?php
					}
				?>
			</div>		
			<strong><?php echo $averageratingrow[1]; ?> users rated this product.</strong>
			<?php
				}
				if(trim($productrow['DISCOUNTPRICE'])!=""){
			?>
			<h3><strong>Price:</strong><br> <strike style="display: inline-block;"><small>Rs. <?php echo $productrow['PRICE']; ?>/-</small></strike> Rs. <?php echo $productrow['DISCOUNTPRICE']; ?>/-</h3>
			<?php
				}else{					
			?>
			<h3><strong>Price:</strong><br>Rs. <?php echo $productrow['PRICE']; ?>/-</h3>
			<?php
				}
			?>
			<br>
			<div>
			<label>Qty:</label> &nbsp;
			<input type="number" min="1" id="itemcount" style="width:70px; display: inline-block; height: 40px; margin-right: 10px;" value="1" class="form-control">
			<button class="btn btn-default" onclick="addToCartAsync(this)" data-product="<?php echo $_GET['product']; ?>"><span class="glyphicon glyphicon-shopping-cart"></span> Add to Cart</button>
			</div>
		</div>
	</div>
	<div class="clearfix" style="margin-bottom: 100px;" id="writecomment"></div>
	<?php
		if(isset($_COOKIE['usertype']) && $_COOKIE['usertype']=="user"){			
	?>
	<br><br>
	<div class="container-fluid">
		<h2>Your Comment</h2>
		<?php
			if(isset($_GET['commentmsg'])){
				echo "<div style='font-weight:bold; color:#dd0000;'>";
				echo $_GET['commentmsg'];
				echo "</div><br>";
			}
		?>
		<div class="col-sm-8" style="padding-left: 0px;">
			<form method="post" action="postpages/addcomment.php?product=<?php echo $_GET['product']; ?>">
			<?php
				$commentq="select *from comment where PRODUCT=".$_GET['product']." and USER=".$_COOKIE['user'];
				$commentqrs=mysqli_query($conn, $commentq);
				$commentqrw=mysqli_fetch_array($commentqrs);
			?>	
				<textarea class="form-control" name="comment" required placeholder="Add your comment"><?php echo $commentqrw['COMMENT']; ?></textarea><br>
				<button class="btn btn-default">Submit</button>
			</form>
			<br>
				<h3>Your rating for this product: </h3>
					<div class="rating" id="editablerating">
						<?php 
							for($i=1; $i<=5; $i++){
						?>
							<span class="fa fa-star <?php if($commentqrw['STARS']>=$i){ echo "rated"; } ?>" onclick="rateThisProduct(this)" data-product="<?php echo $_GET['product']; ?>" data-rate="<?php echo $i; ?>" style="cursor: pointer; font-size: 20px;"></span>
						<?php
							}

						?>
					</div>						
					<div id="ratingresponse" style="color: #dd0000; font-weight: bold; padding-top:5px;"></div>
				</div>
	</div>
	<div class="clearfix"></div>
	<?php
		}
	?>
	<br><br>
	<div class="container-fluid">
	<?php
		if(isset($_COOKIE['usertype']) && $_COOKIE['usertype']=="user"){			
	?>
		<h2>Other Users' Comments and Reviews:</h2>
	<br>
	<?php
		}else{
	?>
		<h2>Comments and Reviews:</h2>			
	<br>
	<?php
		}
		if(isset($_COOKIE['usertype']) && $_COOKIE['usertype']=="user"){			
			$comments="select *from comment where PRODUCT=".$_GET['product']." and USER in(select ID from user where ISENABLED='true') and not USER=".$_COOKIE['user']." order by ID desc limit 20";
		}else{
			$comments="select *from comment where PRODUCT=".$_GET['product']." and USER in(select ID from user where ISENABLED='true') order by ID desc limit 20";			
		}
		$commentsres=mysqli_query($conn, $comments);
		if(mysqli_num_rows($commentsres)==0){
	?>
		<h4>No comments and reviews added yet.</h4>
	<?php
		}else{
	?>	
		<ul class="comments">
	<?php
		while($commentsrow=mysqli_fetch_array($commentsres)){
			$user="select *from user where ID=".$commentsrow['USER'];
			$userres=mysqli_query($conn, $user);
			$userrow=mysqli_fetch_array($userres);
	?>
			<li>
				<div class="col-sm-1" style="min-width: 80px; padding-bottom: 10px;">
					<div class="avatar" style="background-image: url('<?php echo $siteurl.$userrow['PIC']; ?>');"></div>
				</div>
				<div class="col-sm-10">
					<?php
						echo "<strong>".$userrow['NAME']."</strong><br>";
						echo $commentsrow['COMMENT']."<br>";
					?>
					<div class="rating">
						<?php 
							for($i=1; $i<=5; $i++){
						?>
							<span class="fa fa-star <?php if($commentsrow['STARS']>=$i){ echo "rated"; } ?>"></span>
						<?php
							}

						?>
					</div>		
					<div class="date">Added On <?php echo $commentsrow['DATE']; ?></div>
				</div>
			</li>
	<?php
		}
	?>
		</ul>
		<?php
			}
		}
		?>
	</div>
	
<div id="cartModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#a5ce3a; color:#fff;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <center>
            <h4 class="modal-title">Success!!!</h4>
        </center>
      </div>
      <div class="modal-body">
          <p>
              <center>
              The product has been added to the cart.
              
          </center>
          </p><br>
      <center>
        <button class="btn btn-default" onclick="location.assign('categories')">Continue Shopping</button> &nbsp;
        <button class="btn btn-default" onclick="location.assign('checkout')">Checkout</button>
      </center>
      </div>
    </div>
  </div>
</div>
</main>
<script>
function magnify(imgID, zoom) {
  var img, glass, w, h, bw;
  img = document.getElementById(imgID);
  /*create magnifier glass:*/
  glass = document.createElement("DIV");
  glass.setAttribute("class", "img-magnifier-glass");
  /*insert magnifier glass:*/
  img.parentElement.insertBefore(glass, img);
  /*set background properties for the magnifier glass:*/
  glass.style.backgroundImage = "url('" + img.src + "')";
  glass.style.backgroundRepeat = "no-repeat";
  glass.style.backgroundSize = (img.width * zoom) + "px " + (img.height * zoom) + "px";
  bw = 3;
  w = glass.offsetWidth / 2;
  h = glass.offsetHeight / 2;
  /*execute a function when someone moves the magnifier glass over the image:*/
  glass.addEventListener("mousemove", moveMagnifier);
  img.addEventListener("mousemove", moveMagnifier);
  /*and also for touch screens:*/
  glass.addEventListener("touchmove", moveMagnifier);
  img.addEventListener("touchmove", moveMagnifier);
  function moveMagnifier(e) {
    var pos, x, y;
    /*prevent any other actions that may occur when moving over the image*/
    e.preventDefault();
    /*get the cursor's x and y positions:*/
    pos = getCursorPos(e);
    x = pos.x;
    y = pos.y;
    /*prevent the magnifier glass from being positioned outside the image:*/
    if (x > img.width - (w / zoom)) {x = img.width - (w / zoom);}
    if (x < w / zoom) {x = w / zoom;}
    if (y > img.height - (h / zoom)) {y = img.height - (h / zoom);}
    if (y < h / zoom) {y = h / zoom;}
    /*set the position of the magnifier glass:*/
    glass.style.left = (x - w) + "px";
    glass.style.top = (y - h) + "px";
    /*display what the magnifier glass "sees":*/
    glass.style.backgroundPosition = "-" + ((x * zoom) - w + bw) + "px -" + ((y * zoom) - h + bw) + "px";
  }
  function getCursorPos(e) {
    var a, x = 0, y = 0;
    e = e || window.event;
    /*get the x and y positions of the image:*/
    a = img.getBoundingClientRect();
    /*calculate the cursor's x and y coordinates, relative to the image:*/
    x = e.pageX - a.left;
    y = e.pageY - a.top;
    /*consider any page scrolling:*/
    x = x - window.pageXOffset;
    y = y - window.pageYOffset;
    return {x : x, y : y};
  }
}

magnify("product-image", 3);
</script>
<script>
document.getElementById('img-magnifier-container').onmouseover = function(){
    document.getElementsByClassName('img-magnifier-glass')[0].style.display = 'block';
}
document.getElementById('img-magnifier-container').onmouseout = function(){
    document.getElementsByClassName('img-magnifier-glass')[0].style.display = 'none';
}    
</script>
<?php
	include 'components/footer.php';
?>