<?php
	include 'components/header.php';
?>
<main>
	<div class="latest-article" style="background-image: url('images/contact-us.jpg');">
		<div class="light-overlay">
			<h1>Feel Free to Get In Touch</h1>
			<h3><strong>Our friendly team is always ready to help you.</strong></h3><br>
		</div>			
	</div>

	<div class="clearfix"></div>
	<br><br>
	<div class="container-fluid contact-us">
		<div class="col-sm-6">
			<h2>Contact Details</h2><br>
			<strong><span class="fa fa-phone"></span> Call us on:</strong><br> <a href="tel: <?php echo $contactinforow['PHONE1']; ?>"><?php echo $contactinforow['PHONE1']; ?></a>
			<?php
				if($contactinforow['PHONE2']!=""){
			?>
			 / 
			 <a href="tel: <?php echo $contactinforow['PHONE2']; ?>"><?php echo $contactinforow['PHONE2']; ?></a>
			 <?php
			 	}
			 ?>
			 <br><br>
			<strong><span class="glyphicon glyphicon-envelope"></span> Mail us on:</strong><br> <a href="mailto: <?php echo $contactinforow['EMAIL1']; ?>"><?php echo $contactinforow['EMAIL1']; ?></a> 
			<?php 
				if($contactinforow['EMAIL2']!=""){
			?>
			/ 
			<a href="mailto: <?php echo $contactinforow['EMAIL2']; ?>"><?php echo $contactinforow['EMAIL2']; ?></a>
			<?php
				}
			?>
			<br><br>
			<strong><span class="glyphicon glyphicon-map-marker"></span> Visit us at:</strong><br> 
			<?php echo nl2br($contactinforow['ADDRESS']); ?>
			<br><br>			
		</div>
		<div class="col-sm-6">
			<h2>Message Us Here</h2>
			<br>
			<center>
				<?php
					if(isset($_GET['msg'])){
						echo "<div class='errormsg'>";
						echo $_GET['msg'];
						echo "</div>";
					}
				?>
			</center>
			<br>			
			<form method="post" action="postpages/contactform.php">
			  <div class="form-group">
			    <label for="name"><span class="glyphicon glyphicon-user"></span> Your Full Name:</label>
			    <input type="text" placeholder="Full Name" required name="name" class="form-control" id="name">
			  </div>
			  <div class="form-group">
			    <label for="email"><span class="glyphicon glyphicon-envelope"></span> Your Email address:</label>
			    <input type="email" placeholder="Email Address" required name="email" class="form-control" id="email">
			  </div>
			  <div class="form-group">
			    <label for="contact"><span class="glyphicon glyphicon-phone"></span> Your Contact Number:</label>
			    <input type="text" required name="contact" placeholder="Contact Number" class="form-control" id="contact">
			  </div>
			  <div class="form-group">
			    <label for="message"><span class="glyphicon glyphicon-pencil"></span> Your Message:</label>
			    <textarea placeholder="Your Message" required class="form-control" id="message" rows="5" name="message"></textarea>
			  </div>
			  <button class="btn btn-default">Send Us</button>
			</form>
		</div>
	</div>
	<br><br>
	<div class="clearfix"></div>
	<div class="google-maps" style="padding-top: 50px;">
		<?php
			echo $contactinforow['GOOGLEMAPS'];
		?>
	</div>
</main>
<?php
	include 'components/footer.php';
?>