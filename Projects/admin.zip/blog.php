<?php
    if(!isset($_GET['topic']) || !is_numeric($_GET['topic'])){
        header("Location: ./topics");
    }
	include 'components/header.php';
	$articles="select *from article where ISENABLED='true' and CATEGORY=".$_GET['topic']." order by ID desc limit 20 offset ".(($pg-1)*20);
	$articleres=mysqli_query($conn, $articles);
?>
<main>
	<div class="container-fluid blog-page-blog" style="padding-top: 50px;">
		<?php
			if(mysqli_num_rows($articleres)==0){
		?>
			<center>
				<br>
				<h2>No Articles Found</h2>
				<a href="./">Click here to go back on the home page</a>
				<br><br>
			</center>
		<?php
			}else{
			$cate="select *from category where ID=".$_GET['topic'];
			$cateres=mysqli_query($conn, $cate);
			$caterow=mysqli_fetch_array($cateres);
		?>
		<center>
			<h1 class="title"><?php echo $caterow['TITLE']; ?></h1>
			<img src="images/underline.png" style="width:300px;">
		</center>
		<br>
		<div class="clearfix"></div>
		<br>
        <?php
			while($articlerow=mysqli_fetch_array($articleres)){
		?>
		<div class="col-sm-4">
			<a href="article?post=<?php echo $articlerow['ID']; ?>">
				<div class="image" style="background-image: url('<?php echo $siteurl.$articlerow['PHOTO']; ?>');">
				</div>
				<h3><?php echo $articlerow['TITLE']; ?></h3>
			</a>			
		</div>		
		<?php
				}				
			}
		?>
	<center>
		<div class="clearfix"></div>
		<br><br>
		<ul class="pagination pagination-sm" style="float: none; margin: auto; display: inline-block;">
		<?php
			$totalrowsQuery="select *from article where ISENABLED='true' and CATEGORY=".$_GET['topic'];
			$totalrowsRes=mysqli_query($conn, $totalrowsQuery);
			$totalRowsRowCount=mysqli_num_rows($totalrowsRes);
			for($i=1; $i<($totalRowsRowCount/20)+1 && $totalRowsRowCount>20; $i++){
		?>
			  <li><a href="blog?topic=<?php echo $_GET['topic']; ?>&pg=<?php echo $i; ?>" 
			  	<?php 
			  		if(isset($_GET['pg']) && is_numeric($_GET['pg']) && $_GET['pg']==$i)
			  			{
			  	?> style="background-color: #a5ce3a; color: #000;" 
			  	<?php 
			  			} 
			  	?>><?php echo $i; ?></a></li>
		<?php
			}
		?>
		</ul>
	</center>	
	</div>
</main>
<?php
	include 'components/footer.php';
?>