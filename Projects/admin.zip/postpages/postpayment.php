<?php
        if($_SERVER['REQUEST_METHOD']=="POST"){
		   require("../components/connection.php");
		   include '../components/cartlib.php';

   		$orderid=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['myorderid']));
   		$totalpaid=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['totalpaid']));
   		$shippingcharge=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['shippingcharge']));

			$query="select *from user where ID=".$_COOKIE['user'];
			$res=mysqli_query($conn, $query);
			$row=mysqli_fetch_array($res);
			
			$email=$row['EMAIL'];

 	  	  $placeorder="insert into orders(USER, ORDER_DATE, ORDERJSON, ORDERSTATUS, PINCODE, STREETADDR1, STREETADDR2, LANDMARK, CITY, STATE, ADDRESSTYPE, ORDERID, TOTALPAID, SHIPPINGCHARGE) values(".$_COOKIE['user'].", '".date('d-m-Y')."', '".json_encode(getCartItems())."', 'pending', '".$row['PINCODE']."', '".$row['STREETADDR1']."', '".$row['STREETADDR2']."', '".$row['LANDMARK']."', '".$row['CITY']."', '".$row['STATE']."', '".$row['ADDRESSTYPE']."', '$orderid', '$totalpaid', '$shippingcharge')";
		  $placeorderres=mysqli_query($conn, $placeorder);

		  	$orderdata=getCartItems();
	        /*
                PHP Mailing
            */
            $message="<h3>Greetings from Ecomytra!<br><br> Thank you for buying from Ecomytra!!</h3><strong>Your purchase details are as follows:</strong><br>";
            $message.="<strong>Payment Date: </strong>".date('d-m-Y');
            $message.="<br><strong>Order ID: </strong>".$orderid;
            $message.="<br><h3>Order Details:</h3>";
			$message.="<table class=\"table table-striped\" border=\"1\">
				<thead>
					<tr>
						<th>Product Name</th>
						<th>Quantity</th>
						<th>Price</th>
						<th>Total</th>
					</tr>
				</thead>
				<tbody>";
			$totalpayable=0;
			for($i=0; $i<count($orderdata); $i++){
			$q="select *from product where ID=".$orderdata[$i]['product'];
			$rs=mysqli_query($conn, $q);
			$rw=mysqli_fetch_array($rs);

					$message.="<tr>
						<td><strong>".$rw['TITLE']."</strong></td>
						<td>
							".$orderdata[$i]['quantity']."
						</td>
						<td>Rs. ".$orderdata[$i]['product_price']."/-</td>
						<td>Rs. ".$orderdata[$i]['product_price']*$orderdata[$i]['quantity']."/-</td>
					</tr>";
					 $totalpayable+=$orderdata[$i]['product_price']*$orderdata[$i]['quantity'];
			}

			$message.="</tbody></table>";
			$message.="<br><strong>Shipping Charges: </strong> Rs. ".$shippingcharge."/-";
			$message.="<br><br><strong>Total Amount Paid: </strong>Rs. ".$totalpaid."/-";
            $message.="<br><br>Best Regards,<br> Team Ecomytra";
                      
            $to=$email;
            $subject="Ecomytra: Payment Successful";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: <info@ecomytra.com>' . "\r\n";
            $headers .= "Reply-To: info@ecomytra.com\r\n";
            $headers .= "Return-Path: info@ecomytra.com\r\n";
            mail($to,$subject,$message,$headers);

		   resetCart();
		   header("Location: ../thankyou");
        }
?>