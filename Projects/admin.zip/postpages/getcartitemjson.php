<?php
	include '../components/cartlib.php';
	echo json_encode(getCartItems());
?>