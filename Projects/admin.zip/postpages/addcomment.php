<?php
   if(!isset($_COOKIE['usertype'])){
      header("Location: ../login?msg=Please Log In First");
   }
   elseif($_COOKIE['usertype']!="user"){
      header("Location: ../login?msg=Please Log In First");
   }
   require("../components/connection.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['product']) && is_numeric($_GET['product'])) {
   		$comment=htmlspecialchars(mysqli_real_escape_string($conn, $_POST['comment']));
         $product=$_GET['product'];
         $msg="";

         $commentq="select *from comment where PRODUCT=".$_GET['product']." and USER=".$_COOKIE['user'];
         $commentqrs=mysqli_query($conn, $commentq);
         if(mysqli_num_rows($commentqrs)==0){
            $query="insert into comment(USER, PRODUCT, COMMENT, DATE) values(".$_COOKIE['user'].", ".$_GET['product'].", '$comment', '".date('d-m-Y')."')";
            mysqli_query($conn, $query);
            $msg="Comment Added Successfully";
         }else{
            $query="update comment set COMMENT='$comment' where USER=".$_COOKIE['user']." and  PRODUCT=".$_GET['product'];
            mysqli_query($conn, $query);
            $msg="Comment Updated Successfully";
         }
     		header("Location:../product-detail?product=".$_GET['product']."&commentmsg=$msg#writecomment");
   }
?>