<?php
	if(isset($_GET['product']) && is_numeric($_GET['product']) && isset($_GET['qty']) && is_numeric($_GET['qty'])){
		include '../components/cartlib.php';
		addToCart($_GET['product'], $_GET['qty']);
		echo "success";
	}
?>