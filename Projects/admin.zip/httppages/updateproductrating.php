<?php
	if(isset($_GET['product']) && is_numeric($_GET['product']) && isset($_GET['rate']) && is_numeric($_GET['rate']) && isset($_COOKIE['usertype']) && $_COOKIE['usertype']=="user"){
		require '../components/connection.php';

		$query="update comment set STARS=".$_GET['rate']." where PRODUCT=".$_GET['product']." and USER=".$_COOKIE['user'];
		$res=mysqli_query($conn, $query);
		if($res){
			echo "success";
		}else{
			echo mysqli_error($conn);
		}
	}
?>