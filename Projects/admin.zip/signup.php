<?php
	if(isset($_COOKIE['usertype'])){
		if($_COOKIE['usertype']=="admin"){
			header("Location: admin/dashboard");
		}elseif($_COOKIE['usertype']=="user"){
			header("Location: admin/update-profile");
		}
	}
	include 'components/header.php';
?>
<main>
	<div class="container-fluid" style="padding-top: 50px; padding-bottom: 50px;">
		<div class="account-form col-sm-5">
			<center><h2><strong>Create an Account</strong></h2></center>
			<center>
				<?php
					if(isset($_GET['msg'])){
						echo "<div class='errormsg'>";
						echo $_GET['msg'];
						echo "</div>";
					}
				?>
			</center>
			<br>
			<form method="post" action="postpages/newuser.php"> 
			  <div class="form-group">
			    <label for="name"><span class="glyphicon glyphicon-user"></span> Full Name:</label>
			    <input type="text" required name="name" placeholder="Full Name" class="form-control" id="name">
			  </div>
			  <div class="form-group">
			    <label for="email"><span class="glyphicon glyphicon-envelope"></span> Email address:</label>
			    <input type="email" required name="email" placeholder="Email Address" class="form-control" id="email">
			  </div>
			  <div class="form-group">
			    <label for="contact"><span class="glyphicon glyphicon-phone"></span> Contact Number:</label>
			    <input type="text" required name="contact" placeholder="Contact Number" class="form-control" id="contact">
			  </div>
			  <div class="form-group">
			    <label for="pwd"><span class="glyphicon glyphicon-lock"></span> Password:</label>
			    <input type="password" required name="password" placeholder="Password" class="form-control" id="pwd">
			  </div>
			  <button type="submit" class="btn btn-default">Create Account</button>
			  <br><br>
			  Already a User? <a href="./login">Log In Here.</a>
			</form>
		</div>
	</div>
</main>
<?php
	include 'components/footer.php';
?>